import cadquery as cq
from math import acos, degrees

class Measures:
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

m = Measures(
    linear_width=45.0,
    depth=12.0,
    height=10.0,
    outer_diameter=80.0,
    top_fillet=2.0,
    vertical_fillet=1.5,
    chamfer=0.5,
    bolt_diameter=3.0,
    head_diameter=6.0,
    head_height=2.0,
)

m.outer_radius = 0.5 * m.outer_diameter
m.inner_radius = m.outer_radius - m.depth
m.arc_center_angle = degrees(acos((2 * m.inner_radius**2 - m.linear_width**2) / (2 * m.inner_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.inner_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(m.vertical_fillet)
    .edges(">Z")
    .fillet(m.top_fillet)
    .edges("<Z")
    .chamfer(m.chamfer)
    .faces(">Z")
    .workplane()
    .cboreHole(m.bolt_diameter, m.head_diameter, m.head_height)
)
