import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile sketch on XY plane, inner corner at origin
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.vertical_height)
            .lineTo(m.thickness, m.vertical_height)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.horizontal_length, m.thickness)
            .lineTo(m.horizontal_length, 0)
            .close()
        )
        base = profile.extrude(m.thickness)
        # Rib protruding 2 mm from inner vertical face along whole height
        rib = (
            cq.Workplane("XY")
            .box(m.rib_height, m.vertical_height, m.thickness)
            .translate((-m.rib_height/2, m.vertical_height/2, 0))
        )
        body = base.union(rib)
        # Clearance holes on horizontal flange top surface
        hole_positions = [
            (m.hole_edge_distance + i * m.hole_spacing, 0)
            for i in range(3)
        ]
        body = (
            body.faces(">Z")
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        # Chamfer outer vertical edges
        result = body.edges("|Z").chamfer(m.chamfer_distance)
        self.model = result

measures = Measures(
    horizontal_length=60.0,
    vertical_height=70.0,
    thickness=6.0,
    rib_height=2.0,
    hole_diameter=5.0,
    hole_spacing=20.0,
    hole_edge_distance=10.0,
    chamfer_distance=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model