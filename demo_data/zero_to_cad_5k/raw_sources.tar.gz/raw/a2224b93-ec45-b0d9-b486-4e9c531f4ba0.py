import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.vertical_leg_height + m.leg_width)
            .lineTo(0, m.vertical_leg_height + m.leg_width)
            .close()
        )
        solid = profile.extrude(m.bracket_thickness)
        bracket = solid.shell(-m.wall_thickness)
        # Apply exterior chamfer before further cuts
        bracket = bracket.edges().chamfer(m.chamfer_size)
        # Pocket on vertical leg (>X face)
        pocket = (
            bracket.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.pocket_center_y, m.pocket_center_z)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        # Six through holes on top face (>Z)
        final = (
            pocket.faces(">Z")
            .workplane()
            .center(-m.horizontal_leg_length/2 + m.hole_spacing/2, 0)
            .rarray(m.hole_spacing, 0, 6, 1)
            .hole(m.hole_diameter)
        )
        self.model = final

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_height=60.0,
    leg_width=20.0,
    bracket_thickness=10.0,
    wall_thickness=1.0,
    pocket_width=12.0,
    pocket_height=24.0,
    pocket_depth=8.0,
    pocket_center_y=5.0,
    pocket_center_z=30.0,
    hole_diameter=4.0,
    hole_spacing=12.0,
    chamfer_size=2.0,
)

result = LBracket(cq.Workplane("XY"), measures).model