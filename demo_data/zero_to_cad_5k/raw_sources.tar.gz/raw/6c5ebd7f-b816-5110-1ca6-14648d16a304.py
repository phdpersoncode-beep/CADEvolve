import cadquery as cq

# Dimensions (max 100 units)
width = 60.0
depth = 20.0
height = 15.0
wall_thickness = 2.0
chamfer = 0.5
mount_hole_diameter = 4.0
mount_hole_spacing = 40.0
cam_radius = 8.0
cam_thickness = 4.0
cam_offset_y = depth / 2.0
cam_offset_z = height / 2.0
pin_diameter = 3.0
pin_length = 12.0
spring_diameter = 2.0
spring_depth = 5.0
pocket_width = pin_diameter + 2 * wall_thickness
pocket_height = pin_length
pocket_depth = wall_thickness + spring_depth

# Base block
base = (
    cq.Workplane("XY")
    .box(width, depth, height)
    .translate((width / 2.0, 0, height / 2.0))
    .edges("|Z")
    .chamfer(chamfer)
    .faces(">Z")
    .workplane()
    .pushPoints([(-mount_hole_spacing / 2.0, 0), (mount_hole_spacing / 2.0, 0)])
    .hole(mount_hole_diameter)
)

# Cam profile (non‑trivial)
cam_profile = (
    cq.Workplane("XY")
    .moveTo(0, 0)
    .lineTo(cam_thickness, 0)
    .lineTo(cam_thickness, cam_radius * 0.4)
    .threePointArc((cam_thickness * 1.2, cam_radius * 0.7), (0, cam_radius))
    .close()
)
cam = cam_profile.revolve()
cam = cam.translate((width - wall_thickness - cam_radius, cam_offset_y, cam_offset_z))

# Side pocket for detent pin and spring
side_cut = (
    base.faces(">X").workplane()
    .center(0, 0)
    .rect(pocket_width, pocket_height)
    .extrude(-pocket_depth)
)
base = base.cut(side_cut)

# Detent pin (protruding outward)
pin = (
    cq.Workplane("YZ")
    .circle(pin_diameter / 2.0)
    .extrude(pin_length)
    .translate((width, depth / 2.0, height / 2.0))
)

# Spring (simple cylindrical representation)
spring = (
    cq.Workplane("YZ")
    .circle(spring_diameter / 2.0)
    .extrude(spring_depth)
    .translate((width - wall_thickness - spring_depth, depth / 2.0, height / 2.0))
)

# Assemble all components
result = base.union(cam).union(pin).union(spring)
