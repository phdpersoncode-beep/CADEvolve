import cadquery as cq
bracket_len = 80
bracket_wid = 30
bracket_thk = 8
latch_len = 20
latch_thk = 8
snap_clearance = 2
fillet_rad = 1.5
counterbore_x = 20
counterbore_dia = 5
counterbore_depth = 2
screw_hole_dia = 3
slot_len = latch_len - 4
slot_width = snap_clearance
pts = [
    (0, 0),
    (bracket_len, 0),
    (bracket_len, bracket_wid/2 - latch_thk/2),
    (bracket_len + latch_len, bracket_wid/2 - latch_thk/2),
    (bracket_len + latch_len, bracket_wid/2 + latch_thk/2),
    (bracket_len, bracket_wid/2 + latch_thk/2),
    (bracket_len, bracket_wid),
    (0, bracket_wid)
]
result = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .extrude(bracket_thk)
    .faces(">X")
    .workplane()
    .center(latch_len/2, bracket_wid/2)
    .rect(slot_len, slot_width)
    .cutBlind(-bracket_thk)
    .edges("|Z and >X")
    .fillet(fillet_rad)
    .faces(">Z")
    .workplane()
    .center(counterbore_x, 0)
    .hole(counterbore_dia, depth=counterbore_depth)
    .hole(screw_hole_dia)
)
