import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.leg_length, 0),
            (m.leg_length, m.thickness),
            (m.thickness, m.thickness),
            (m.thickness, m.leg_length),
            (0, m.leg_length),
        ]
        self.model = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.depth)
        )
        # recessed pocket at inner corner
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .move(m.thickness/2, m.thickness/2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(m.pocket_depth)
        )
        # blind tapped holes on vertical leg
        hole_positions = [
            (m.thickness/2, m.leg_length/3),
            (m.thickness/2, 2*m.leg_length/3),
        ]
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .pushPoints(hole_positions)
            .cboreHole(m.hole_dia, m.cbore_dia, m.cbore_depth, depth=m.blind_hole_depth)
        )
        # chamfer outer corners
        self.model = (
            self.model.faces(">X").edges().chamfer(m.chamfer)
            .faces(">Y").edges().chamfer(m.chamfer)
        )

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

measures = Measures(
    leg_length=80.0,
    thickness=10.0,
    depth=12.0,
    pocket_width=30.0,
    pocket_height=20.0,
    pocket_depth=6.0,
    hole_dia=5.0,
    cbore_dia=7.0,
    cbore_depth=2.0,
    blind_hole_depth=8.0,
    chamfer=4.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
