import cadquery as cq
from math import acos, degrees

class Params:
    def __init__(self):
        self.block_width = 60.0
        self.block_depth = 20.0
        self.block_height = 15.0
        self.arc_outer_diameter = 100.0
        self.arc_thickness = 12.0
        self.chamfer_distance = 2.0
        self.pocket_radius = 8.0
        self.pocket_depth = 8.0
        self.mount_hole_diameter = 4.0
        self.mount_hole_offset_x = 15.0
        self.mount_hole_offset_y = 5.0
        self.mount_head_diameter = 7.0
        self.mount_head_height = 4.0

p = Params()

p.arc_outer_radius = 0.5 * p.arc_outer_diameter
p.arc_center_diameter = p.arc_outer_diameter - p.arc_thickness
p.arc_center_radius = 0.5 * p.arc_center_diameter
p.arc_center_angle = degrees(acos((2 * p.arc_center_radius**2 - p.block_width**2) / (2 * p.arc_center_radius**2)))
p.arc_secant_angle = 0.5 * (180 - p.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((p.block_width, 0.0), p.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -p.arc_secant_angle, 0))
    .rect(p.arc_thickness, p.block_height)
    .sweep(path, transition="round")
    .edges()
    .chamfer(p.chamfer_distance)
    .faces("<Z")
    .workplane()
    .center(0, 0)
    .circle(p.pocket_radius)
    .cutBlind(-p.pocket_depth)
    .faces(">Z")
    .workplane()
    .center(-p.mount_hole_offset_x, -p.mount_hole_offset_y)
    .cboreHole(p.mount_hole_diameter, p.mount_head_diameter, p.mount_head_height)
    .center(2 * p.mount_hole_offset_x, 0)
    .cboreHole(p.mount_hole_diameter, p.mount_head_diameter, p.mount_head_height)
)
