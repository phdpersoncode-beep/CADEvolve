import cadquery as cq

bracket_width = 60
bracket_height = 40
bracket_thickness = 8
channel_width = 30
channel_depth = 6
channel_fillet = 2
blind_hole_dia = 4
blind_hole_depth = 4
mount_hole_dia = 5
mount_hole_offset_x = 20
mount_hole_offset_y = 15
rib_height = 3
rib_thickness = 2
chamfer = 1

result = (
    cq.Workplane('XY')
    .rect(bracket_width, bracket_height)
    .extrude(bracket_thickness)
)

result = result.edges("|Z").chamfer(chamfer)

result = (
    result
    .faces('>Z')
    .workplane()
    .pushPoints([
        (-mount_hole_offset_x, -mount_hole_offset_y),
        (mount_hole_offset_x, -mount_hole_offset_y),
        (-mount_hole_offset_x, mount_hole_offset_y),
        (mount_hole_offset_x, mount_hole_offset_y)
    ])
    .hole(mount_hole_dia)
)

result = (
    result
    .faces('<Z')
    .workplane()
    .rect(bracket_width - 2 * chamfer, rib_thickness)
    .extrude(rib_height)
)

result = (
    result
    .faces('>Z')
    .workplane()
    .sketch()
    .rect(channel_width, channel_depth)
    .vertices()
    .fillet(channel_fillet)
    .finalize()
    .cutBlind(channel_depth)
)

total_hole_depth = channel_depth + blind_hole_depth
cylinder = (
    cq.Workplane('XY')
    .center(0, 0)
    .circle(blind_hole_dia / 2)
    .extrude(-total_hole_depth)
    .translate((0, 0, bracket_thickness))
)
result = result.cut(cylinder)

result = (
    result
    .faces('<Z')
    .workplane()
    .rect(bracket_width - 2 * chamfer, rib_thickness)
    .extrude(rib_height)
)
