import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        points = [
            (0, 0),
            (m.leg_thickness, 0),
            (m.leg_thickness, m.long_leg - m.leg_thickness),
            (m.leg_thickness + m.short_leg, m.long_leg - m.leg_thickness),
            (m.leg_thickness + m.short_leg, m.long_leg),
            (m.short_leg, m.long_leg),
            (0, m.long_leg)
        ]
        self.model = (
            cq.Workplane("XY")
            .polyline(points)
            .close()
            .extrude(m.bracket_thickness)
            .faces(">Z")
            .edges()
            .fillet(m.fillet_radius)
        )
        self.model = (
            self.model
            .faces(">Y")
            .workplane()
            .center(m.short_leg/2 - m.counterbore_offset, 0)
            .cboreHole(m.clearance_hole_dia, m.counterbore_diameter, m.counterbore_depth)
        )
        self.model = (
            self.model
            .faces("<Y")
            .workplane()
            .center(m.leg_thickness/2, -m.long_leg/2 + m.clearance_hole_line_offset)
            .rarray(m.clearance_hole_spacing, 0, 3, 1)
            .hole(m.clearance_hole_dia)
        )

measures = Measures(
    long_leg=70.0,
    short_leg=50.0,
    leg_thickness=15.0,
    bracket_thickness=9.0,
    fillet_radius=5.0,
    clearance_hole_dia=4.0,
    clearance_hole_spacing=12.0,
    clearance_hole_line_offset=20.0,
    counterbore_diameter=8.0,
    counterbore_depth=5.0,
    counterbore_offset=20.0,
)

result = LBracket(cq.Workplane("XY"), measures).model