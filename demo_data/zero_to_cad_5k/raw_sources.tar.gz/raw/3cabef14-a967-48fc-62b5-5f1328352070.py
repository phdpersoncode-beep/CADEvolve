import cadquery as cq

# Primary dimensions (max 100 units)
bracket_length = 80.0          # X direction length
bracket_width = 30.0           # Y direction extrusion width
base_thickness = 10.0          # Z thickness at fixed end
top_thickness = 6.0            # Z thickness at tapered end
taper_length = 60.0            # Length over which thickness tapers
fillet_radius = 2.0
chamfer_size = 1.0
hole_diameter = 4.2            # M4 tap clearance
hole_depth = base_thickness    # through hole depth
hole_spacing = 10.0
hole_count = 3
rib_height = 4.0               # Height of rib in Z
rib_thickness = 2.0            # Rib thickness in X
rib_spacing_z = 5.0            # Vertical spacing between ribs
slot_width = 6.0
slot_height = base_thickness - 2.0
slot_offset = 10.0

# Derived geometry
taper_start = bracket_length - taper_length
profile_pts = [
    (0, 0),
    (bracket_length, 0),
    (bracket_length, base_thickness),
    (taper_start, top_thickness),
    (0, top_thickness),
]

# Create main body by extruding an XZ sketch along Y
result = (
    cq.Workplane("XZ")
    .polyline(profile_pts)
    .close()
    .extrude(bracket_width)
)

# Chamfer vertical edges (parallel to Z)
result = result.edges("|Z").chamfer(chamfer_size)

# Fillet free outer edge at +X (vertical edge)
result = result.edges("(Z and >X)").fillet(fillet_radius)

# Drill tapped holes on the top face (+Z) before ribs are added
hole_start_x = taper_start + (taper_length - (hole_count - 1) * hole_spacing) / 2
hole_positions = [hole_start_x + i * hole_spacing for i in range(hole_count)]
for x in hole_positions:
    result = (
        result
        .faces(">Z")
        .workplane()
        .center(x - bracket_length / 2, 0)
        .hole(hole_diameter, depth=hole_depth)
    )

# Add clearance slot near base on bottom face (-Z)
result = (
    result
    .faces("-Z")
    .workplane()
    .center(-bracket_length / 2 + slot_offset, 0)
    .rect(slot_width, slot_height)
    .cutBlind(-2.0)
)

# Add ribs on the inner -X face after other features
num_ribs = int(base_thickness // rib_spacing_z)
for i in range(num_ribs):
    z_center = rib_spacing_z * i + rib_spacing_z / 2
    rib = (
        cq.Workplane("XZ")
        .rect(rib_thickness, rib_height)
        .extrude(bracket_width)
        .translate((rib_thickness / 2, 0, z_center))
    )
    result = result.union(rib)
