import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile extruded
        self.model = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.leg1_length, 0),
                (m.leg1_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.leg2_length),
                (0, m.leg2_length),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
        )
        # Chamfer outer vertical edges on +X and +Y faces
        self.model = self.model.edges('>X').chamfer(m.chamfer)
        self.model = self.model.edges('>Y').chamfer(m.chamfer)
        # Through hole on longer leg interior
        self.model = (
            self.model
            .faces('>Z')
            .workplane()
            .center(m.thickness/2, m.leg2_length/2)
            .hole(m.hole_diameter)
        )
        # Shell operation for 2mm wall thickness
        self.model = self.model.shell(m.shell_thickness)

measures = Measures(
    leg1_length=70.0,
    leg2_length=50.0,
    thickness=10.0,
    hole_diameter=8.0,
    chamfer=1.0,
    shell_thickness=2.0,
)

result = LBracket(cq.Workplane('XY'), measures).model