import cadquery as cq
BS = cq.selectors.BoxSelector
outer_length = 80.0
outer_width = 50.0
outer_height = 20.0
wall_thickness = 4.0
bobbin_inner_radius = 12.0
bobbin_outer_radius = bobbin_inner_radius + wall_thickness
bobbin_length = 40.0
outlet_diameter = 8.0
outlet_length = 30.0
chamfer_size = 1.0
fillet_radius = 2.0
mount_hole_dia = 5.0
mount_hole_offset = 6.0
slot_width = 4.0
slot_depth = wall_thickness
base = cq.Workplane("XY").box(outer_length, outer_width, outer_height, centered=True)
bobbin_wp = cq.Workplane("XY", origin=(0, 0, -outer_height/2 + wall_thickness))
bobbin_cavity = (
    bobbin_wp
    .moveTo(bobbin_inner_radius, -bobbin_length/2)
    .lineTo(bobbin_outer_radius, -bobbin_length/2)
    .lineTo(bobbin_outer_radius, bobbin_length/2)
    .lineTo(bobbin_inner_radius, bobbin_length/2)
    .close()
    .extrude(wall_thickness)
)
bobbin_cavity = (
    bobbin_cavity
    .faces("<Z")
    .workplane(centerOption="CenterOfMass")
    .moveTo((bobbin_outer_radius + slot_depth/2), 0)
    .rect(slot_width, slot_depth)
    .cutBlind(-wall_thickness)
)
jacket = base.cut(bobbin_cavity)
outlet = (
    cq.Workplane("YZ")
    .rect(outlet_diameter, outlet_length)
    .extrude(wall_thickness)
    .translate((outer_length/2 - wall_thickness, 0, 0))
    .edges("|X")
    .fillet(fillet_radius)
)
jacket = jacket.union(outlet)
# Chamfer vertical outer edges for mold release
jacket = jacket.edges("|Z").chamfer(chamfer_size)
# Mounting holes at four corners on bottom face
hole_x = outer_length/2 - mount_hole_offset
hole_y = outer_width/2 - mount_hole_offset
jacket = (
    jacket
    .faces("<Z")
    .workplane()
    .pushPoints([
        ( hole_x,  hole_y),
        (-hole_x,  hole_y),
        (-hole_x, -hole_y),
        ( hole_x, -hole_y)
    ])
    .hole(mount_hole_dia)
)
result = jacket