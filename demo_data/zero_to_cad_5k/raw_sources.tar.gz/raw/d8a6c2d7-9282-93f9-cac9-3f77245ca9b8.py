import cadquery as cq
import math

leaf_length = 80.0
leaf_thickness = 10.0
boss_radius = 6.0
central_hole_diameter = 4.0
peripheral_hole_diameter = 3.0
hole_ring_radius = 12.0
hole_pattern_count = 4
chamfer_distance = 0.2

boss = cq.Workplane('XY').circle(boss_radius).extrude(leaf_length)
leaf_shell = (
    cq.Workplane('XY')
    .moveTo(boss_radius, 0)
    .lineTo(boss_radius, leaf_length)
    .lineTo(boss_radius + leaf_thickness, leaf_length)
    .lineTo(boss_radius + leaf_thickness, 0)
    .close()
    .revolve(360, (0, 0, 0), (0, 1, 0))
)
leaf = boss.union(leaf_shell)

central_hole = (
    cq.Workplane('XY')
    .circle(central_hole_diameter / 2)
    .extrude(leaf_length + 2)
    .rotate((0, 0, 0), (1, 0, 0), -90)
    .translate((0, leaf_length / 2, 0))
)
leaf = leaf.cut(central_hole)

peripheral_hole = (
    cq.Workplane('XY')
    .circle(peripheral_hole_diameter / 2)
    .extrude(leaf_length + 2)
    .rotate((0, 0, 0), (1, 0, 0), -90)
)

holes = None
for i in range(hole_pattern_count):
    angle = i * 360 / hole_pattern_count
    x = hole_ring_radius * math.cos(math.radians(angle))
    z = hole_ring_radius * math.sin(math.radians(angle))
    positioned = peripheral_hole.translate((x, leaf_length / 2, z))
    if holes is None:
        holes = positioned
    else:
        holes = holes.union(positioned)
leaf = leaf.cut(holes)

leaf = leaf.faces('>Z').edges().chamfer(chamfer_distance)

result = leaf