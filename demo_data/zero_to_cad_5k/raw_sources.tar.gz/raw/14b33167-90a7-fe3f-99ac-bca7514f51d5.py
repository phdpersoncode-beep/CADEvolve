import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_width, 0),
                (m.leg_width, m.vertical_leg_height),
                (m.leg_width + m.horizontal_leg_length, m.vertical_leg_height),
                (m.leg_width + m.horizontal_leg_length, m.vertical_leg_height + m.leg_width),
                (0, m.vertical_leg_height + m.leg_width),
            ])
            .close()
            .extrude(m.thickness)
        )
        cb_x = m.leg_width + m.horizontal_leg_length / 2
        cb_y = m.leg_width / 2
        base = (
            base.faces(">Z")
            .workplane()
            .moveTo(cb_x, cb_y)
            .cboreHole(m.counterbore_clearance, m.counterbore_diameter, m.counterbore_depth)
        )
        mh_x = m.leg_width / 2
        base = (
            base.faces(">Z")
            .workplane()
            .pushPoints([
                (mh_x, m.vertical_leg_height * 0.3),
                (mh_x, m.vertical_leg_height * 0.7),
            ])
            .hole(m.mount_hole_diameter)
        )
        self.model = base

measures = Measures(
    vertical_leg_height=70,
    horizontal_leg_length=45,
    leg_width=12,
    thickness=8,
    counterbore_clearance=4,
    counterbore_diameter=8,
    counterbore_depth=6,
    mount_hole_diameter=5,
)

result = LBracket(cq.Workplane("XY"), measures).model