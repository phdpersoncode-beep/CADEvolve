import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    plate_width=80.0,
    plate_height=30.0,
    plate_thickness=8.0,
    edge_fillet_radius=2.0,
    pivot_hole_x=20.0,
    pivot_hole_diameter=4.0,
    pocket_width=30.0,
    pocket_length=20.0,
    pocket_depth=4.0,
    pocket_center_x=45.0,
    catch_height=12.0,
    catch_thickness=6.0,
    catch_chamfer=0.8,
    mount_hole_spacing=50.0,
    mount_hole_offset=10.0,
    mount_hole_diameter=3.0,
    mount_hole_cbore_diameter=5.5,
    mount_hole_cbore_depth=3.0
)

base = (
    cq.Workplane("XY")
    .box(m.plate_width, m.plate_height, m.plate_thickness)
    .translate((0, 0, m.plate_thickness/2))
    .edges().fillet(m.edge_fillet_radius)
)

pivot = (
    base
    .faces(">Z")
    .workplane()
    .center(m.pivot_hole_x - m.plate_width/2, 0)
    .hole(m.pivot_hole_diameter)
)

pocket = (
    pivot
    .faces(">Z")
    .workplane()
    .center(m.pocket_center_x - m.plate_width/2, 0)
    .rect(m.pocket_width, m.pocket_length)
    .cutBlind(m.pocket_depth)
)

catch = (
    cq.Workplane()
    .box(m.catch_thickness, m.catch_height, m.plate_thickness)
    .translate((m.plate_thickness/2 + m.catch_thickness/2, 0, m.plate_thickness/2))
    .edges().chamfer(m.catch_chamfer)
)

assembled = pocket.union(catch)

result = (
    assembled
    .faces(">Z")
    .workplane()
    .pushPoints([
        (-m.mount_hole_spacing/2, -m.mount_hole_offset),
        (m.mount_hole_spacing/2, -m.mount_hole_offset)
    ])
    .cboreHole(m.mount_hole_diameter, m.mount_hole_cbore_diameter, m.mount_hole_cbore_depth)
)
