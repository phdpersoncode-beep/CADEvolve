import cadquery as cq

# Parameters
outer_diameter = 80.0
hub_diameter = 30.0
base_thickness = 10.0
flange_width = 15.0
flare_extension = 10.0
flare_height = 5.0
bolt_circle_diameter = 50.0
hole_diameter = 6.5
chamfer_distance = 4.0
seal_groove_depth = 2.0
seal_groove_width = 2.0

inner_radius = hub_diameter / 2.0
outer_radius = inner_radius + flange_width
flare_outer_radius = outer_radius + flare_extension

# Revolved flange profile
flange = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(inner_radius, 0)
    .lineTo(inner_radius, base_thickness)
    .lineTo(outer_radius, base_thickness)
    .lineTo(flare_outer_radius, base_thickness + flare_height)
    .lineTo(0, base_thickness + flare_height)
    .close()
    .revolve()
)

# Central hub cylinder
hub = cq.Workplane("XY").circle(inner_radius).extrude(base_thickness)

result = flange.union(hub)

# Seal groove
result = (
    result.faces("<Z")
    .workplane(offset=-seal_groove_depth)
    .circle(inner_radius - seal_groove_width)
    .cutBlind(seal_groove_depth)
)

# Through‑holes
result = (
    result.faces(">Z")
    .workplane()
    .pushPoints([
        (bolt_circle_diameter/2, 0),
        (0, bolt_circle_diameter/2),
        (-bolt_circle_diameter/2, 0),
        (0, -bolt_circle_diameter/2),
    ])
    .hole(hole_diameter)
)

# Chamfer on outer flare
result = result.faces(">Z").edges().chamfer(chamfer_distance)

# Reinforcing ribs (intersecting)
rib_thickness = 4.0
rib_height = base_thickness / 2.0
rib_length = outer_radius - inner_radius

rib1 = (
    result.faces("<Z")
    .workplane()
    .rect(rib_length, rib_thickness)
    .extrude(rib_height*2, both=True)
)
result = result.union(rib1)

rib2 = (
    result.faces("<Z")
    .workplane()
    .transformed(rotate=(0,0,90))
    .rect(rib_length, rib_thickness)
    .extrude(rib_height*2, both=True)
)
result = result.union(rib2)

# Central boss on top face (intersecting)
central_boss_diameter = 12.0
central_boss_height = 5.0
boss = (
    result.faces(">Z")
    .workplane()
    .circle(central_boss_diameter/2)
    .extrude(central_boss_height)
)
result = result.union(boss)
