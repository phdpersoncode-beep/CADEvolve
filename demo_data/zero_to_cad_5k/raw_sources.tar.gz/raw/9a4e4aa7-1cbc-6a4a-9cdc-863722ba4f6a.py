import cadquery as cq

# Parameters
base_length = 80.0
base_width = 60.0
base_thickness = 6.0
frame_height = 12.0
frame_outer_side = 55.0
frame_thickness = 3.0
hole_radius = 2.5
clearance_hole_diameter = 2 * hole_radius
shell_thickness = 1.2
chamfer_distance = 0.5

# Base plate with clearance holes
base_plate = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .faces(">Z")
    .workplane()
    .pushPoints([
        ( -20.0, -15.0),
        (  20.0, -15.0),
        ( -20.0,   0.0),
        (  20.0,   0.0),
        ( -20.0,  15.0),
        (  20.0,  15.0),
        (   0.0,   0.0)
    ])
    .hole(clearance_hole_diameter)
)

# Triangular frame (hollow)
inner_triangle_side = frame_outer_side - 2 * frame_thickness
outer_triangle = (
    cq.Workplane("XY")
    .polygon(3, frame_outer_side)
    .extrude(frame_height)
)
inner_triangle = (
    cq.Workplane("XY")
    .polygon(3, inner_triangle_side)
    .extrude(frame_height + 0.01)
)
triangular_frame = outer_triangle.cut(inner_triangle).translate((0, 0, base_thickness))

# Combine base and frame
combined = base_plate.union(triangular_frame)

# Shell operation
shelled = combined.shell(shell_thickness)

# Chamfer outer vertical edges
result = shelled.edges("|Z").chamfer(chamfer_distance)
