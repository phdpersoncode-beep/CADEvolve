import cadquery as cq

flange_width = 80
flange_height = 30
base_thickness = 5
clamp_width = 30
clamp_extension = 20
hole_diameter = 6
countersink_diameter = 10
countersink_angle = 82
countersink_depth = base_thickness
hole_spacing = 40
rib_thickness = 3
rib_height = 2
slot_width = 4
slot_length = clamp_extension - 5
slot_depth = base_thickness + 0.5
chamfer_dist = 1

base = cq.Workplane('XY').box(flange_width, flange_height, base_thickness)
clamp = (
    cq.Workplane('XY')
    .box(clamp_width, clamp_extension, base_thickness)
    .translate((0, flange_height/2 + clamp_extension/2, 0))
)
solid = base.union(clamp)

rib1 = (
    solid
    .faces('>Z')
    .workplane(centerOption='CenterOfMass')
    .rect(flange_width - 10, rib_thickness)
    .extrude(rib_height)
)
solid = solid.union(rib1)

rib2 = (
    solid
    .faces('>Z')
    .workplane(centerOption='CenterOfMass')
    .rect(rib_thickness, flange_height - 10)
    .extrude(rib_height)
)
solid = solid.union(rib2)

slot = (
    solid
    .faces('>Z')
    .workplane()
    .center(0, flange_height/2 + clamp_extension/2)
    .rect(slot_width, slot_length)
    .cutBlind(-slot_depth)
)
solid = solid.cut(slot)

hole_positions = [(-hole_spacing/2, -flange_height/4), (0, -flange_height/4), (hole_spacing/2, -flange_height/4)]
solid = (
    solid
    .faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .cskHole(hole_diameter, countersink_diameter, countersink_angle, countersink_depth)
)

solid = solid.edges('|Z and >Y').chamfer(chamfer_dist)

result = solid