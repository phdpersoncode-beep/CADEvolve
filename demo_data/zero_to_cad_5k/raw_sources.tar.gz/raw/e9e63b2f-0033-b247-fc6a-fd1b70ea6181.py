import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.short_leg)
            .lineTo(m.thickness, m.short_leg)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.long_leg, m.thickness)
            .lineTo(m.long_leg, 0)
            .close()
            .extrude(m.thickness)
        )
        gusset = (
            cq.Workplane("XY")
            .rect(m.gusset_thickness, m.gusset_height)
            .extrude(m.thickness)
            .translate((m.thickness, m.thickness, 0))
        )
        model = base.union(gusset)
        model = model.edges("|Z and >X").fillet(m.fillet_radius)
        wp = model.faces(">Z").workplane(centerOption="CenterOfBoundBox")
        center_y = m.short_leg / 2
        hole_y_offset = (m.thickness/2) - center_y
        points = [(-m.hole_spacing/2, hole_y_offset), (m.hole_spacing/2, hole_y_offset)]
        model = wp.pushPoints(points).cboreHole(m.hole_clearance, m.hole_cbore_dia, m.hole_cbore_depth)
        self.model = model

measures = Measures(
    long_leg=80.0,
    short_leg=50.0,
    thickness=8.0,
    fillet_radius=2.0,
    gusset_thickness=4.0,
    gusset_height=30.0,
    hole_spacing=20.0,
    hole_clearance=5.0,
    hole_cbore_dia=7.5,
    hole_cbore_depth=4.0,
)

result = LBracket(cq.Workplane("XY"), measures).model