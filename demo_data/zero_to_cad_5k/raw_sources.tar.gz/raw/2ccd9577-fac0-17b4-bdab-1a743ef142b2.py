import cadquery as cq
from types import SimpleNamespace as Measures

leg_length = 60.0
wall_thickness = 20.0
fillet_radius = 12.0
bracket_thickness = 8.0
rib_height = 4.0
rib_thickness = 6.0
rib_length = 40.0
hole_diameter = 3.0
hole_count = 5
hole_spacing = 12.0

measures = Measures(
    leg_length=leg_length,
    wall_thickness=wall_thickness,
    fillet_radius=fillet_radius,
    bracket_thickness=bracket_thickness,
    rib_height=rib_height,
    rib_thickness=rib_thickness,
    rib_length=rib_length,
    hole_diameter=hole_diameter,
    hole_count=hole_count,
    hole_spacing=hole_spacing,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.wall_thickness),
                (m.wall_thickness + m.fillet_radius, m.wall_thickness),
            ])
            .radiusArc((m.wall_thickness, m.wall_thickness + m.fillet_radius), m.fillet_radius)
            .lineTo(m.wall_thickness, m.leg_length)
            .lineTo(0, m.leg_length)
            .close()
            .extrude(m.bracket_thickness)
        )
        rib_center_y = (m.wall_thickness + m.fillet_radius + m.leg_length) / 2.0
        rib = (
            cq.Workplane("XY")
            .box(m.rib_thickness, m.rib_length, m.bracket_thickness)
            .translate((m.wall_thickness/2.0, rib_center_y, m.bracket_thickness/2.0))
        )
        combined = base.union(rib)
        holes = (
            combined.faces(">Z")
            .workplane()
            .rarray(m.hole_spacing, 0, m.hole_count, 1)
            .hole(m.hole_diameter)
        )
        self.model = holes

result = LBracket(cq.Workplane("XY"), measures).model
