import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .rect(m.leg_width, m.leg_height)
            .extrude(m.thickness)
            .translate((0, m.leg_height / 2, 0))
        )
        horizontal = (
            cq.Workplane("XY")
            .rect(m.leg_length, m.leg_width)
            .extrude(m.thickness)
            .translate((m.leg_width / 2 + m.leg_length / 2, m.leg_width / 2, 0))
        )
        gusset = (
            cq.Workplane("XY")
            .moveTo(m.leg_width / 2, 0)
            .lineTo(m.leg_width / 2 + m.gusset_width, 0)
            .lineTo(m.leg_width / 2, m.gusset_width)
            .close()
            .extrude(m.thickness)
        )
        base = vertical.union(horizontal).union(gusset)
        base = base.edges("|Z").chamfer(m.chamfer)
        result = (
            base.faces(">Z")
            .workplane()
            .moveTo(0, m.hole_pattern_offset_y)
            .rect(m.hole_spacing_x, m.hole_spacing_y, forConstruction=True)
            .vertices()
            .hole(m.hole_diameter)
        )
        self.model = result

measures = Measures(
    leg_width=20.0,
    leg_height=70.0,
    leg_length=50.0,
    thickness=10.0,
    gusset_width=15.0,
    hole_diameter=5.0,
    hole_spacing_x=30.0,
    hole_spacing_y=30.0,
    hole_pattern_offset_y=35.0,
    chamfer=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
