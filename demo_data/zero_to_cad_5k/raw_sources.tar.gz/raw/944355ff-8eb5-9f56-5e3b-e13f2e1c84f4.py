import cadquery as cq

outer_diameter = 80.0
inner_diameter = 45.0
plate_thickness = 5.0
vent_hole_width = 6.0
vent_hole_length = 20.0
vent_hole_radius = 3.0
vent_hole_depth = plate_thickness + 0.01
mount_hole_diameter = 5.0
mount_hole_offset = 12.0
chamfer_distance = 0.8
cross_slot_width = 4.0
cross_slot_depth = plate_thickness / 2.0
pocket_width = 30.0
pocket_depth = plate_thickness / 2.0

outer_radius = outer_diameter / 2.0
inner_radius = inner_diameter / 2.0
mid_radius = (inner_radius + outer_radius) / 2.0

base = (
    cq.Workplane("XY")
    .circle(outer_radius)
    .circle(inner_radius)
    .extrude(plate_thickness)
)

vent_sketch = (
    cq.Sketch()
    .rect(vent_hole_width, vent_hole_length)
    .circle(vent_hole_radius)
)

result = (
    base
    .faces(">Z")
    .workplane()
    .polarArray(count=4, radius=mid_radius, startAngle=0, angle=360)
    .placeSketch(vent_sketch)
    .cutBlind(-vent_hole_depth)
)

result = (
    result
    .faces(">Z")
    .workplane()
    .polarArray(count=4, radius=inner_radius + mount_hole_offset, startAngle=45, angle=360)
    .hole(mount_hole_diameter)
)

result = (
    result
    .faces(">Z")
    .workplane()
    .rect(cross_slot_width, outer_diameter)
    .cutBlind(-cross_slot_depth)
)

result = (
    result
    .faces("<Z")
    .workplane()
    .rect(pocket_width, pocket_width)
    .cutBlind(-pocket_depth)
)

result = result.faces(">Z").edges().chamfer(chamfer_distance)
