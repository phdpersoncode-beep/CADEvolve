import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        profile = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(0, m.vertical_leg_length)
            .lineTo(m.vertical_leg_thickness, m.vertical_leg_length)
            .lineTo(m.vertical_leg_thickness, m.horizontal_leg_thickness)
            .lineTo(m.horizontal_leg_length, m.horizontal_leg_thickness)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.vertical_leg_thickness, 0)
            .close()
        )
        solid = profile.extrude(m.flange_thickness)
        solid = solid.edges('|Z').fillet(m.interior_fillet_radius)
        solid = (
            solid.faces('>Z')
            .workplane()
            .center(m.vertical_leg_thickness/2, m.vertical_leg_length - m.upper_hole_offset)
            .cboreHole(m.upper_hole_diameter, m.upper_hole_cbore_diameter, m.upper_hole_cbore_depth)
        )
        vertical_hole_positions = [m.vertical_leg_length*0.3, m.vertical_leg_length*0.7]
        for y in vertical_hole_positions:
            solid = (
                solid.faces('>Z')
                .workplane()
                .center(m.vertical_leg_thickness/2, y)
                .hole(m.mount_hole_diameter)
            )
        horizontal_hole_positions = [m.horizontal_leg_length*0.25, m.horizontal_leg_length*0.75]
        for x in horizontal_hole_positions:
            solid = (
                solid.faces('>Z')
                .workplane()
                .center(x, m.horizontal_leg_thickness/2)
                .hole(m.mount_hole_diameter)
            )
        gusset = (
            cq.Workplane('XY')
            .moveTo(0, m.horizontal_leg_thickness)
            .lineTo(0, m.vertical_leg_length)
            .lineTo(m.vertical_leg_thickness, m.vertical_leg_length)
            .close()
            .extrude(m.gusset_thickness)
        )
        solid = solid.union(gusset)
        self.model = solid

measures = Measures(
    vertical_leg_length=60.0,
    horizontal_leg_length=80.0,
    vertical_leg_thickness=4.0,
    horizontal_leg_thickness=4.0,
    flange_thickness=4.0,
    upper_hole_diameter=10.0,
    upper_hole_cbore_diameter=14.0,
    upper_hole_cbore_depth=2.0,
    upper_hole_offset=5.0,
    mount_hole_diameter=4.0,
    gusset_thickness=4.0,
    interior_fillet_radius=1.0,
)

result = LBracket(cq.Workplane('XY'), measures).model