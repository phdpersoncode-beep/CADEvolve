import cadquery as cq

# Parameters
flange_radius = 40.0
flange_thickness = 5.0
collar_height = 10.0
collar_outer_radius = 15.0
collar_inner_radius = 10.0
collar_fillet = 0.6
hole_diameter = 2.0
hole_spacing = 10.0
hole_pattern_rows = 6
hole_pattern_cols = 8
hole_clearance_from_collar = 5.0
hole_clearance_from_edge = 5.0

# Base flange solid
base = (
    cq.Workplane("XY")
    .circle(flange_radius)
    .extrude(flange_thickness)
)

# Generate hole positions in a rectangular grid, filter by clearance
points = []
col_offset = -(hole_pattern_cols // 2) * hole_spacing
row_offset = -(hole_pattern_rows // 2) * hole_spacing
for i in range(hole_pattern_cols + 1):
    for j in range(hole_pattern_rows + 1):
        x = col_offset + i * hole_spacing
        y = row_offset + j * hole_spacing
        r2 = x * x + y * y
        if r2 < (flange_radius - hole_clearance_from_edge) ** 2 and r2 > (collar_outer_radius + hole_clearance_from_collar) ** 2:
            points.append((x, y))

# Drill laser-etched pattern holes through the flange thickness
if points:
    base = (
        base.faces(">Z")
        .workplane()
        .pushPoints(points)
        .hole(hole_diameter)
    )

# Collar solid placed on top of flange
collar = (
    cq.Workplane("XY", origin=(0, 0, flange_thickness))
    .circle(collar_outer_radius)
    .circle(collar_inner_radius)
    .extrude(collar_height)
)
collar = collar.fillet(collar_fillet)

# Combine flange and collar
result = base.union(collar)
