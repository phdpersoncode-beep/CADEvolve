import cadquery as cq
wp = cq.Workplane('XY').box(80,60,40)
wp = wp.faces('>Z').workplane().hole(5)
wp = wp.union(cq.Workplane('XY').center(0,0).rect(10,10).extrude(20))
result = wp
