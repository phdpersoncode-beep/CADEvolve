import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L shape
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_leg_length),
                (0, m.vertical_leg_length),
            ])
            .close()
            .extrude(m.leg_thickness)
        )
        # Pocket on vertical face (>Y)
        with_pocket = (
            base.faces('>Y')
            .workplane()
            .center(m.pocket_offset_x, 0)
            .rect(m.pocket_width, m.pocket_depth)
            .cutBlind(-m.pocket_depth)
        )
        # Through hole on horizontal face (>X)
        with_hole = (
            with_pocket.faces('>X')
            .workplane()
            .center(m.horizontal_hole_offset_x, 0)
            .hole(m.hole_diameter)
        )
        # Triangular gusset filling inner corner, created on XY plane and unioned
        gusset = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.gusset_height, 0),
                (0, m.gusset_height),
            ])
            .close()
            .extrude(m.leg_thickness)
        )
        combined = with_hole.union(gusset)
        # Chamfer outer edges
        result = combined.edges('>Z or <Z or >X or >Y')
        result = result.chamfer(m.chamfer_size)
        self.model = result

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=60.0,
    leg_thickness=10.0,
    pocket_width=30.0,
    pocket_depth=7.0,
    pocket_offset_x=15.0,
    hole_diameter=9.0,
    horizontal_hole_offset_x=40.0,
    gusset_height=20.0,
    gusset_thickness=10.0,  # same as leg_thickness for consistency
    chamfer_size=0.8,
)

result = LBracket(cq.Workplane('XY'), measures).model