import cadquery as cq

# Parameters
outer_diameter = 80.0
body_length = 60.0
wall_thickness = 4.0
rim_chamfer = 2.0
port_diameter = 15.0
port_angle_offset = 30.0
port_radius = outer_diameter / 2 - wall_thickness / 2
sensor_cavity_diameter = 20.0
sensor_cavity_depth = 12.0
sensor_cavity_offset = 20.0
mount_hole_diameter = 5.0
mount_hole_radius = 30.0
rib_diameter = 6.0
rib_count = 4

# Base cylindrical body with wall thickness
result = (
    cq.Workplane("XY")
    .cylinder(body_length, outer_diameter / 2)
    .shell(-wall_thickness)
)

# Chamfer outer rim on the top edge
result = (
    result
    .faces(">Z")
    .edges()
    .chamfer(rim_chamfer)
)

# Dual side ports drilled through the wall at symmetric angles
for angle in (-port_angle_offset, port_angle_offset):
    result = (
        result
        .workplane(offset=body_length / 2)
        .transformed(rotate=(0, angle, 0))
        .center(port_radius, 0)
        .hole(port_diameter)
    )

# Recessed sensor cavity on the top face
result = (
    result
    .faces(">Z")
    .workplane()
    .center(sensor_cavity_offset, 0)
    .circle(sensor_cavity_diameter / 2)
    .cutBlind(-sensor_cavity_depth)
)

# Four mounting holes evenly spaced around the top face
for i in range(4):
    theta = i * 90
    result = (
        result
        .faces(">Z")
        .workplane()
        .polarArray(radius=mount_hole_radius, startAngle=theta, count=1, angle=0)
        .hole(mount_hole_diameter)
    )

# Internal radial ribs for stiffness, evenly distributed around Z axis
for i in range(rib_count):
    theta = i * (360 / rib_count)
    rib = (
        cq.Workplane("XY")
        .circle(rib_diameter / 2)
        .extrude(body_length)
        .rotate((0, 0, 0), (0, 0, 1), theta)
    )
    result = result.union(rib)
