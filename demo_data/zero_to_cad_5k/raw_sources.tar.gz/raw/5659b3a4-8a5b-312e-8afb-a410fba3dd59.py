import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.bracket_thickness)
            .lineTo(m.leg_thickness, m.bracket_thickness)
            .lineTo(m.leg_thickness, m.vertical_leg_length)
            .lineTo(0, m.vertical_leg_length)
            .close()
            .extrude(m.leg_thickness)
        )
        filleted = base.edges("<X and <Y and |Z").fillet(m.inner_fillet_radius)
        pocketed = (
            filleted
            .faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.bracket_thickness)
        )
        result = (
            pocketed
            .faces(">Z")
            .workplane()
            .rect(m.hole_pattern_width, m.hole_pattern_height, forConstruction=True)
            .vertices()
            .cboreHole(m.hole_clearance_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.model = result

measures = Measures(
    leg_thickness=8.0,
    bracket_thickness=10.0,
    vertical_leg_length=60.0,
    horizontal_leg_length=70.0,
    inner_fillet_radius=3.0,
    pocket_width=30.0,
    pocket_height=20.0,
    hole_clearance_diameter=4.0,
    cbore_diameter=6.5,
    cbore_depth=2.5,
    hole_pattern_width=50.0,
    hole_pattern_height=4.0,
)

result = LBracket(cq.Workplane("XY"), measures).model