import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.leg_width, 0)
            .lineTo(m.leg_width, m.horizontal_leg_length)
            .lineTo(m.leg_width + m.leg_thickness, m.horizontal_leg_length)
            .lineTo(m.leg_width + m.leg_thickness, m.total_height)
            .lineTo(0, m.total_height)
            .close()
            .extrude(m.bracket_thickness)
        )
        inner_edges = base.edges('|Z').filter(
            lambda e: (abs(e.Center().x - m.leg_width) < 0.01) or (abs(e.Center().y - m.total_height) < 0.01)
        )
        base = inner_edges.fillet(m.fillet_radius)
        hole_x = m.leg_width + m.leg_thickness / 2
        hole_y = m.horizontal_leg_length / 2
        base = (
            base
            .faces('>Z')
            .workplane()
            .center(hole_x, hole_y)
            .hole(m.hole_diameter, depth=m.hole_depth)
        )
        shoulder = (
            cq.Workplane('XY')
            .moveTo(-m.shoulder_protrusion/2, m.total_height - m.shoulder_height/2)
            .rect(m.shoulder_protrusion, m.shoulder_height)
            .extrude(m.bracket_thickness)
        )
        base = base.union(shoulder)
        self.model = base

measures = Measures(
    leg_width=20.0,
    leg_thickness=20.0,
    total_height=80.0,
    horizontal_leg_length=60.0,
    bracket_thickness=8.0,
    shoulder_height=12.0,
    shoulder_protrusion=6.0,
    hole_diameter=10.0,
    hole_depth=5.0,
    fillet_radius=1.5,
)

result = LBracket(cq.Workplane('XY'), measures).model
