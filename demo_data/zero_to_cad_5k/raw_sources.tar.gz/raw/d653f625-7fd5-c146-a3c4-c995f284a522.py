import cadquery as cq
result = cq.Workplane('XY').box(20,20,2).faces('>Z').edges().chamfer(1,1)
