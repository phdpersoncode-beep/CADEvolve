import cadquery as cq

plate_diameter = 80.0
plate_thickness = 5.0
blind_hole_diameter = 20.0
blind_hole_depth = 3.5
rib_offset = 5.0
rib_width = 6.0
rib_height = 3.0
mount_hole_diameter = 5.0
mount_hole_radius = 30.0
chamfer_distance = 0.5

base = cq.Workplane("XY").circle(plate_diameter/2).extrude(plate_thickness)
base = base.faces(">Z").workplane().hole(blind_hole_diameter, blind_hole_depth)

outer_rib_radius = plate_diameter/2 - rib_offset
inner_rib_radius = outer_rib_radius - rib_width
rib = cq.Workplane("XY").circle(outer_rib_radius).extrude(rib_height)
inner_cut = cq.Workplane("XY").circle(inner_rib_radius).extrude(rib_height)
rib = rib.cut(inner_cut)
rib = rib.translate((0, 0, plate_thickness))
result = base.union(rib)

result = result.faces("<Z").workplane().pushPoints([
    (mount_hole_radius, 0),
    (0, mount_hole_radius),
    (-mount_hole_radius, 0),
    (0, -mount_hole_radius)
]).hole(mount_hole_diameter)

result = result.edges(">Z").chamfer(chamfer_distance)
