import cadquery as cq

panel_width = 80.0
panel_height = 60.0
panel_thickness = 10.0
wall_thickness = 2.0
pin_hole_diameter = 3.9
pin_hole_spacing = 10.0
pin_hole_count = 5
mount_hole_diameter = 5.0
mount_hole_offset = 5.0
chamfer_distance = 0.5

profile = (
    cq.Workplane("XY")
    .moveTo(-panel_width/2, -panel_height/2)
    .lineTo(panel_width/2, -panel_height/2)
    .lineTo(panel_width/2, panel_height/2 - 10)
    .lineTo(panel_width/2 + 5, panel_height/2 - 10)
    .lineTo(panel_width/2 + 5, -panel_height/2 + 10)
    .lineTo(panel_width/2, -panel_height/2 + 10)
    .lineTo(panel_width/2, -panel_height/2)
    .lineTo(-panel_width/2, -panel_height/2)
    .close()
)

base_panel = profile.extrude(panel_thickness)

hollow_panel = base_panel.shell(wall_thickness)

pin_holes = (
    hollow_panel.faces(">Z")
    .workplane()
    .rarray(pin_hole_spacing, 0, pin_hole_count, 1, center=True)
    .hole(pin_hole_diameter)
)

mount_holes = (
    pin_holes.faces(">Z")
    .workplane()
    .pushPoints([
        (-panel_width/2 + mount_hole_offset, -panel_height/2 + mount_hole_offset),
        ( panel_width/2 - mount_hole_offset, -panel_height/2 + mount_hole_offset),
        ( panel_width/2 - mount_hole_offset,  panel_height/2 - mount_hole_offset),
        (-panel_width/2 + mount_hole_offset,  panel_height/2 - mount_hole_offset),
    ])
    .hole(mount_hole_diameter)
)

result = (
    mount_holes
    .edges("|Z")
    .chamfer(chamfer_distance)
)
