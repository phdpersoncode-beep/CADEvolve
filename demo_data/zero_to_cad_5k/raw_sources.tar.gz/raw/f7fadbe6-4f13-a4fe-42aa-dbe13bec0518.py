import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, measures):
        self.wp = wp
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            self.wp
            .moveTo(0, 0)
            .lineTo(m.short_leg_length, 0)
            .lineTo(m.short_leg_length, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.long_leg_length)
            .lineTo(0, m.long_leg_length)
            .close()
            .extrude(m.thickness)
        )
        base = base.edges("|Z").chamfer(m.chamfer)
        rib = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.thickness, m.long_leg_length)
            .extrude(m.rib_width)
        )
        rib = (
            rib.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(-m.leg_width/2 + m.hole_offset, m.long_leg_length/2 - m.hole_offset)
            .hole(m.hole_diameter)
        )
        self.model = rib

measures = Measures(
    long_leg_length=80.0,
    short_leg_length=50.0,
    leg_width=30.0,
    thickness=5.0,
    rib_width=8.0,
    hole_diameter=6.0,
    hole_offset=5.0,
    chamfer=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model
