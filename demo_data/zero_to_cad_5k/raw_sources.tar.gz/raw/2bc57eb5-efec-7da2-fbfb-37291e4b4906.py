import cadquery as cq
beam_length = 80.0
beam_height = 50.0
flange_width = 30.0
web_thickness = 4.0
flange_thickness = 6.0
pts_primary = [
    (0,0), (0,beam_height), (web_thickness, beam_height), (flange_width, beam_height), (flange_width, flange_thickness + (beam_height-2*flange_thickness)), (web_thickness, flange_thickness + (beam_height-2*flange_thickness)), (web_thickness, flange_thickness), (0, flange_thickness), (0,0)
]
solid = cq.Workplane('XY').polyline(pts_primary).close().extrude(80.0)
result = solid
