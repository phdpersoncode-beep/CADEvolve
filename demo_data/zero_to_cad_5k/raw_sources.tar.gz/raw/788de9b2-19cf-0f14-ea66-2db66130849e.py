
import cadquery as cq
import math

# Parameters
arc_outer_diameter = 80.0
arc_thickness = 12.0
arc_angle_degrees = 120.0
block_height = 15.0
slot_width = 6.0
slot_depth = 8.0
hole_diameter = 4.0
hole_spacing = 15.0
chamfer_distance = 0.5

# Derived dimensions
outer_radius = 0.5 * arc_outer_diameter
inner_radius = outer_radius - arc_thickness
arc_angle_radians = math.radians(arc_angle_degrees)
outer_end_x = outer_radius * math.cos(arc_angle_radians)
outer_end_y = outer_radius * math.sin(arc_angle_radians)
inner_end_x = inner_radius * math.cos(arc_angle_radians)
inner_end_y = inner_radius * math.sin(arc_angle_radians)

# Base sector profile with chamfer on vertical edges
sector = (
    cq.Workplane("XY")
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius, 0)
    .radiusArc((outer_end_x, outer_end_y), outer_radius)
    .lineTo(inner_end_x, inner_end_y)
    .radiusArc((inner_radius, 0), inner_radius)
    .close()
    .extrude(block_height)
    .edges("|Z")
    .chamfer(chamfer_distance)
)

# Slot on the radial face at angle 0 (positive X direction)
with_slot = (
    sector
    .faces(">X")
    .workplane(centerOption="CenterOfMass")
    .rect(slot_width, slot_depth)
    .cutBlind(-block_height)
)

# Cross pattern holes on top face
result = (
    with_slot
    .faces(">Z")
    .workplane()
    .center(0, hole_spacing / 2)
    .hole(hole_diameter)
    .center(0, -hole_spacing)  # move down to opposite side
    .hole(hole_diameter)
    .center(hole_spacing / 2, hole_spacing / 2)  # move to (+x,+y) from current
    .hole(hole_diameter)
    .center(-hole_spacing, 0)  # move to (-x,+y)
    .hole(hole_diameter)
)
