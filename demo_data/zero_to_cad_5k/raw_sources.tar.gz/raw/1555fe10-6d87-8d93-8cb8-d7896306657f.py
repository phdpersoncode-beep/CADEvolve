import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical_leg = (
            cq.Workplane("XY")
            .box(m.leg_thickness, m.vertical_leg_length, m.bracket_thickness)
            .translate((m.leg_thickness / 2, m.vertical_leg_length / 2, 0))
        )
        horizontal_leg = (
            cq.Workplane("XY")
            .box(m.horizontal_leg_length, m.leg_thickness, m.bracket_thickness)
            .translate((m.horizontal_leg_length / 2, m.leg_thickness / 2, 0))
        )
        gusset = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_thickness, 0),
                (0, m.leg_thickness),
            ])
            .close()
            .extrude(m.gusset_thickness)
        )
        base = vertical_leg.union(horizontal_leg).union(gusset)
        central_hole = (
            cq.Workplane("XY")
            .center(m.leg_thickness / 2, m.vertical_leg_length / 2)
            .circle(m.central_hole_diameter / 2)
            .extrude(m.bracket_thickness + 0.01)
        )
        clearance_hole_1 = (
            cq.Workplane("XY")
            .center(m.leg_thickness / 2, m.vertical_leg_length - m.clearance_hole_offset)
            .circle(m.clearance_hole_diameter / 2)
            .extrude(m.bracket_thickness + 0.01)
        )
        clearance_hole_2 = (
            cq.Workplane("XY")
            .center(m.leg_thickness / 2, m.clearance_hole_offset)
            .circle(m.clearance_hole_diameter / 2)
            .extrude(m.bracket_thickness + 0.01)
        )
        self.model = (
            base
            .cut(central_hole)
            .cut(clearance_hole_1)
            .cut(clearance_hole_2)
        )

measures = Measures(
    vertical_leg_length=70.0,
    horizontal_leg_length=50.0,
    leg_thickness=10.0,
    bracket_thickness=8.0,
    gusset_thickness=4.0,
    central_hole_diameter=8.0,
    clearance_hole_diameter=6.5,
    clearance_hole_offset=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
