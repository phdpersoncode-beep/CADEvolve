import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 40.0
base_thickness = 5.0
fin_height = 15.0
fin_width = 6.0
fin_gap = 4.0
num_fins = 6
sensor_pocket_length = 20.0
sensor_pocket_width = 15.0
sensor_pocket_depth = 3.0
mount_hole_diameter = 3.0
mount_hole_offset = 5.0
chamfer_distance = 0.5
fin_fillet_radius = 0.8

# Build cross‑section outline for base + fins (XZ plane)
points = []
# start at lower left corner
points.append((0.0, 0.0))
points.append((0.0, base_thickness))
# generate fin pattern
x = 0.0
# initial half gap to first fin
x += fin_gap / 2.0
points.append((x, base_thickness))
for i in range(num_fins):
    # left side of fin
    x += fin_width
    points.append((x, base_thickness))
    points.append((x, fin_height))
    # right side of fin (top edge)
    points.append((x, base_thickness))
    # gap after fin (half gap for next fin except after last)
    x += fin_gap
    points.append((x, base_thickness))
# ensure final point reaches total length
if x < base_length:
    points.append((base_length, base_thickness))
points.append((base_length, 0.0))
points.append((0.0, 0.0))

# Create solid by extruding the profile along Y
result = (
    cq.Workplane("XZ")
    .polyline(points)
    .close()
    .extrude(base_width)
)

# Recessed sensor pocket on top surface
sensor_center_x = base_length / 2.0
sensor_center_y = base_width / 2.0
result = (
    result.faces(">Z")
    .workplane()
    .pushPoints([(sensor_center_x, sensor_center_y)])
    .rect(sensor_pocket_length, sensor_pocket_width)
    .cutBlind(-sensor_pocket_depth)
)

# Mounting holes on bottom surface (four corners)
mount_hole_positions = [
    (mount_hole_offset, mount_hole_offset),
    (base_length - mount_hole_offset, mount_hole_offset),
    (mount_hole_offset, base_width - mount_hole_offset),
    (base_length - mount_hole_offset, base_width - mount_hole_offset),
]
result = (
    result.faces("<Z")
    .workplane()
    .pushPoints(mount_hole_positions)
    .hole(mount_hole_diameter)
)

# Chamfer bottom edges for safety
result = result.edges("|Z and (<X or >X)").chamfer(chamfer_distance)

# Fillet fin top edges to reduce stress concentrations
result = result.edges("|Y and (>Z)").fillet(fin_fillet_radius)
