import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
leg_length_x = 80.0
leg_length_y = 60.0
wall_thickness = 8.0
bracket_height = 20.0
boss_width = 30.0
boss_depth = 30.0
boss_height = 10.0
tap_hole_clearance = 5.0
tap_hole_cbore_diameter = 8.0
tap_hole_cbore_depth = 4.0
mount_hole_clearance = 4.0
mount_hole_cbore_diameter = 6.5
mount_hole_cbore_depth = 3.0
mount_hole_spacing = 40.0
chamfer_size = 1.0

class LBracket:
    def __init__(self, workplane, measures):
        self.wp = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # horizontal leg
        horiz = (
            cq.Workplane("XY")
            .rect(m.leg_length_x, m.wall_thickness, centered=False)
            .extrude(m.bracket_height)
        )
        # vertical leg
        vert = (
            cq.Workplane("XY")
            .rect(m.wall_thickness, m.leg_length_y, centered=False)
            .extrude(m.bracket_height)
        )
        # union legs to form L shape
        bracket = horiz.union(vert)
        # recessed boss in interior corner
        boss = (
            cq.Workplane("XY")
            .rect(m.boss_width, m.boss_depth, centered=False)
            .extrude(m.boss_height)
            .translate((m.wall_thickness, m.wall_thickness, 0))
        )
        bracket = bracket.union(boss)
        # tap hole in boss center
        bracket = (
            bracket.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.wall_thickness + m.boss_width/2, m.wall_thickness + m.boss_depth/2)
            .cboreHole(m.tap_hole_clearance, m.tap_hole_cbore_diameter, m.tap_hole_cbore_depth)
        )
        # mounting holes on horizontal leg
        bracket = (
            bracket.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.leg_length_x/2, m.wall_thickness/2)
            .rect(m.mount_hole_spacing, m.mount_hole_spacing, forConstruction=True)
            .vertices()
            .cboreHole(m.mount_hole_clearance, m.mount_hole_cbore_diameter, m.mount_hole_cbore_depth)
        )
        # mounting holes on vertical leg
        bracket = (
            bracket.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.wall_thickness/2, m.leg_length_y/2)
            .rect(m.mount_hole_spacing, m.mount_hole_spacing, forConstruction=True)
            .vertices()
            .cboreHole(m.mount_hole_clearance, m.mount_hole_cbore_diameter, m.mount_hole_cbore_depth)
        )
        # chamfer outer edges
        bracket = bracket.edges().chamfer(m.chamfer_size)
        self.result = bracket

measures = Measures(
    leg_length_x=leg_length_x,
    leg_length_y=leg_length_y,
    wall_thickness=wall_thickness,
    bracket_height=bracket_height,
    boss_width=boss_width,
    boss_depth=boss_depth,
    boss_height=boss_height,
    tap_hole_clearance=tap_hole_clearance,
    tap_hole_cbore_diameter=tap_hole_cbore_diameter,
    tap_hole_cbore_depth=tap_hole_cbore_depth,
    mount_hole_clearance=mount_hole_clearance,
    mount_hole_cbore_diameter=mount_hole_cbore_diameter,
    mount_hole_cbore_depth=mount_hole_cbore_depth,
    mount_hole_spacing=mount_hole_spacing,
    chamfer_size=chamfer_size,
)

result = LBracket(cq.Workplane("XY"), measures).result
