import cadquery as cq

# Parameters (scale max 100)
rail_length = 80.0
rail_width = 20.0
rail_height = 10.0
fillet_radius = 2.0
draft_angle = 2.0  # degrees
hole_diameter = 4.0
hole_spacing = 20.0
edge_clearance = 5.0

class EjectorPinGuideRail:
    def __init__(self, length, width, height, fillet, draft, hole_dia, hole_spacing, clearance):
        self.length = length
        self.width = width
        self.height = height
        self.fillet = fillet
        self.draft = draft
        self.hole_dia = hole_dia
        self.hole_spacing = hole_spacing
        self.clearance = clearance

    def build(self):
        half_w = self.width / 2.0
        half_h = self.height / 2.0
        # Composite sketch on YZ plane (Workplane "YZ")
        profile = (
            cq.Workplane("YZ")
            .moveTo(-half_w, -half_h)
            .line(self.width, 0)
            .line(0, self.height)
            .line(-self.width, 0)
            .close()
        )
        # Extrude along X with draft (taper) for mold release
        rail = profile.extrude(self.length, taper=self.draft)
        # Fillet the trailing end (+X face) edges
        rail = rail.faces(">X").edges().fillet(self.fillet)
        # Add mounting holes on top (+Z face) spaced along length
        usable_length = self.length - 2 * self.clearance
        num_holes = int(usable_length // self.hole_spacing) + 1
        start_x = -self.length / 2 + self.clearance
        hole_positions = [(start_x + i * self.hole_spacing, 0) for i in range(num_holes)]
        rail = (
            rail.faces(">Z")
            .workplane()
            .pushPoints(hole_positions)
            .hole(self.hole_dia)
        )
        return rail

guide = EjectorPinGuideRail(
    length=rail_length,
    width=rail_width,
    height=rail_height,
    fillet=fillet_radius,
    draft=draft_angle,
    hole_dia=hole_diameter,
    hole_spacing=hole_spacing,
    clearance=edge_clearance,
)
result = guide.build()
