import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    width=70.0,
    depth=40.0,
    height=6.0,
    wall_thickness=1.2,
    latch_width=15.0,
    latch_height=4.0,
    latch_thickness=1.2,
    outer_chamfer=0.2,
    latch_fillet=0.4,
    hole=Measures(
        diameter=4.0,
        positions=[(20.0, 0), (50.0, 0)],
    )
)

base = (
    cq.Workplane("XY")
    .box(m.width, m.depth, m.height)
    .translate((0.5 * m.width, 0, 0.5 * m.height))
)

shell = base.shell(-m.wall_thickness)

latch = (
    cq.Workplane("XY")
    .center(m.width / 2 + m.wall_thickness / 2, 0)
    .rect(m.latch_width, m.latch_height)
    .extrude(m.latch_thickness)
)

combined = shell.union(latch)

with_holes = (
    combined.faces(">Z").workplane()
    .pushPoints(m.hole.positions)
    .hole(m.hole.diameter)
)

result = (
    with_holes
    .edges().chamfer(m.outer_chamfer)
    .faces(">X").edges().fillet(m.latch_fillet)
)
