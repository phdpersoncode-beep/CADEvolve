import cadquery as cq
box = cq.Workplane('XY').box(80,50,60).shell(2)
outer = box.faces('+X').first()
# create workplane on outer face
wp = outer.workplane()
result = wp.rect(10,10).extrude(1)
