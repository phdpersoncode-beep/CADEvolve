import cadquery as cq
import math
from types import SimpleNamespace as Measures

# Parameters
arm_length_x = 70.0
arm_length_y = 50.0
bracket_thickness = 10.0
bracket_height = 15.0
draft_angle_deg = 2.0
inner_fillet_radius = 5.0
hole_diameter = 6.0
hole_offset_x = 20.0
hole_offset_y = 20.0
chamfer_distance = 0.8

measures = Measures(
    arm_length_x=arm_length_x,
    arm_length_y=arm_length_y,
    bracket_thickness=bracket_thickness,
    bracket_height=bracket_height,
    draft_angle_deg=draft_angle_deg,
    inner_fillet_radius=inner_fillet_radius,
    hole_diameter=hole_diameter,
    hole_offset_x=hole_offset_x,
    hole_offset_y=hole_offset_y,
    chamfer_distance=chamfer_distance,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.wp = workplane
        self.m = measures
        self.model = None
        self.build()

    def build(self):
        m = self.m
        # Sketch L profile with inner fillet built-in
        profile = (
            self.wp
            .moveTo(0, 0)
            .lineTo(m.arm_length_x, 0)
            .lineTo(m.arm_length_x, m.bracket_thickness)
            .lineTo(m.bracket_thickness + m.inner_fillet_radius, m.bracket_thickness)
            .threePointArc((m.bracket_thickness, m.bracket_thickness), (m.bracket_thickness, m.bracket_thickness + m.inner_fillet_radius))
            .lineTo(m.bracket_thickness, m.arm_length_y)
            .lineTo(0, m.arm_length_y)
            .close()
        )
        # Extrude with draft (taper)
        solid = profile.extrude(m.bracket_height, taper=math.radians(m.draft_angle_deg))
        # Apply chamfer to outer edges for safety
        solid = solid.edges().chamfer(m.chamfer_distance)
        # Add tapped holes on each arm
        hx = m.arm_length_x - m.hole_offset_x
        hy = m.bracket_thickness / 2
        vx = m.bracket_thickness / 2
        vy = m.arm_length_y - m.hole_offset_y
        solid = (
            solid.faces("<Z")
            .workplane()
            .pushPoints([(hx, hy), (vx, vy)])
            .hole(m.hole_diameter)
        )
        self.model = solid

result = LBracket(cq.Workplane("XY"), measures).model
