import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Vertical arm solid
        vertical = (
            cq.Workplane("XY")
            .box(m.vertical_thickness, m.vertical_height, m.plate_thickness)
        )
        # Horizontal arm solid positioned at top of vertical arm
        horizontal = (
            cq.Workplane("XY")
            .transformed(offset=(0, m.vertical_height/2 + m.plate_thickness/2, 0))
            .box(m.horizontal_length, m.plate_thickness, m.plate_thickness)
        )
        # Combine arms into L shape
        l_shape = vertical.union(horizontal)
        # Notch cutout on horizontal side
        notch = (
            cq.Workplane("XY")
            .transformed(
                offset=(
                    m.horizontal_length - m.notch_width/2,
                    m.vertical_height/2 + m.plate_thickness/2,
                    0,
                )
            )
            .box(m.notch_width, m.notch_height, m.plate_thickness + 1)
        )
        l_shape = l_shape.cut(notch)
        # Drill through-hole pattern on vertical front face
        hole_ys = [m.hole_spacing * i for i in range(m.hole_rows)]
        l_shape = (
            l_shape.faces(">Y")
            .workplane()
            .pushPoints([(0, y) for y in hole_ys])
            .hole(m.hole_diameter)
        )
        # Small chamfer on interior corner edges for safety
        l_shape = l_shape.edges("<Z and >Y").chamfer(m.chamfer_distance)
        self.model = l_shape

# Parameter definitions
measures = Measures(
    vertical_thickness=10.0,
    vertical_height=70.0,
    horizontal_length=60.0,
    plate_thickness=8.0,
    notch_width=20.0,
    notch_height=15.0,
    hole_diameter=5.0,
    hole_rows=3,
    hole_spacing=20.0,
    chamfer_distance=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model