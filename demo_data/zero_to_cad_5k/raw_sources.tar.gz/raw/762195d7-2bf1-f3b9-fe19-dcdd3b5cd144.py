import cadquery as cq
from types import SimpleNamespace as Measures

leg_length_long = 80.0
leg_length_short = 60.0
leg_width = 15.0
bracket_depth = 10.0
inner_fillet_radius = 3.0
m5_clearance_dia = 5.5
counterbore_clearance_dia = 5.5
counterbore_head_dia = 8.5
counterbore_depth = 3.0
hole_offset_from_edge = 10.0
counterbore_offset = 7.0

tol = 0.01

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_length_long, 0)
            .lineTo(m.leg_length_long, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.leg_length_short)
            .lineTo(0, m.leg_length_short)
            .close()
        )
        solid = profile.extrude(m.bracket_depth)
        # Fillet inner corner edges only
        solid = solid.edges().filter(
            lambda e: (
                abs(e.Center().x - m.leg_width) < tol and e.Center().y > m.leg_width
            ) or (
                abs(e.Center().y - m.leg_width) < tol and e.Center().x > m.leg_width
            )
        ).fillet(m.inner_fillet_radius)
        # Counterbore at inner corner offset inward
        solid = (
            solid.faces('>Z')
            .workplane()
            .move(m.counterbore_offset, m.counterbore_offset)
            .cboreHole(
                m.counterbore_clearance_dia,
                m.counterbore_head_dia,
                m.counterbore_depth,
            )
        )
        # Four M5 clearance holes on outer faces
        hole_positions = [
            (m.leg_length_long - m.hole_offset_from_edge, m.leg_width / 2),
            (m.leg_length_long - m.hole_offset_from_edge, m.leg_width + m.leg_length_short - m.hole_offset_from_edge),
            (m.leg_width / 2, m.leg_length_short - m.hole_offset_from_edge),
            (m.leg_width + m.leg_length_long - m.hole_offset_from_edge, m.leg_length_short - m.hole_offset_from_edge),
        ]
        solid = (
            solid.faces('>Z')
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.m5_clearance_dia)
        )
        self.model = solid

measures = Measures(
    leg_length_long=leg_length_long,
    leg_length_short=leg_length_short,
    leg_width=leg_width,
    bracket_depth=bracket_depth,
    inner_fillet_radius=inner_fillet_radius,
    m5_clearance_dia=m5_clearance_dia,
    counterbore_clearance_dia=counterbore_clearance_dia,
    counterbore_head_dia=counterbore_head_dia,
    counterbore_depth=counterbore_depth,
    hole_offset_from_edge=hole_offset_from_edge,
    counterbore_offset=counterbore_offset,
)

bracket = LBracket(cq.Workplane("XY"), measures)
result = bracket.model
