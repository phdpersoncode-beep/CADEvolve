import cadquery as cq
BS = cq.selectors.BoxSelector

# Parameters (scale max 100 units)
plate_length = 80.0
plate_width = 60.0
plate_thickness = 4.0
border_width = 5.0
border_height = 3.0
slot_width = 3.0
slot_height = 8.0
slot_spacing_x = 10.0
slot_spacing_y = 12.0
chamfer_size = 0.5
mount_hole_dia = 4.0
mount_hole_offset = 8.0

# Base plate solid (centered at origin)
base = cq.Workplane("XY").box(plate_length, plate_width, plate_thickness, centered=True)

# Create raised border by extruding outer rectangle on top face, then removing inner material
result = (
    base
    .faces(">Z")
    .workplane()
    .rect(plate_length, plate_width)
    .extrude(border_height)
    .faces(">Z")
    .workplane()
    .rect(plate_length - 2 * border_width, plate_width - 2 * border_width)
    .cutBlind(-border_height)
)

# Lattice slot pattern within interior region (excluding border)
interior_x = plate_length - 2 * border_width
interior_y = plate_width - 2 * border_width
cols = int(interior_x // slot_spacing_x)
rows = int(interior_y // slot_spacing_y)
# Center the grid
x_start = -interior_x / 2 + slot_spacing_x / 2
y_start = -interior_y / 2 + slot_spacing_y / 2
points = []
for i in range(cols):
    for j in range(rows):
        px = x_start + i * slot_spacing_x
        py = y_start + j * slot_spacing_y
        points.append((px, py))

# Cut slots through full thickness (base + border)
total_depth = plate_thickness + border_height
result = (
    result
    .faces(">Z")
    .workplane(offset=plate_thickness)  # start at top of base surface
    .pushPoints(points)
    .rect(slot_width, slot_height)
    .cutBlind(-total_depth)
)

# Chamfer outer vertical edges for mold release
result = result.edges(BS((-plate_length/2-0.1, -plate_width/2-0.1, -100), (plate_length/2+0.1, plate_width/2+0.1, 100))).chamfer(chamfer_size)

# Mounting holes at each corner of the outer border
corner_offset_x = plate_length/2 - mount_hole_offset
corner_offset_y = plate_width/2 - mount_hole_offset
result = (
    result
    .faces("<Z")
    .workplane()
    .pushPoints([
        ( corner_offset_x,  corner_offset_y),
        (-corner_offset_x,  corner_offset_y),
        (-corner_offset_x, -corner_offset_y),
        ( corner_offset_x, -corner_offset_y)
    ])
    .hole(mount_hole_dia)
)
