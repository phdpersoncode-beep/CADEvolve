import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    outer_radius = 75.0,
    thickness = 15.0,
    height = 30.0,
    linear_width = 40.0,
    outer_fillet = 2.0,
    bolt_hole_diameter = 5.0,
    bolt_hole_offset = 20.0,
    bolt_hole_spacing = 30.0
)

m.inner_radius = m.outer_radius - m.thickness
m.arc_center_radius = m.outer_radius - (m.thickness / 2.0)
# angle subtended by chord (linear_width) at circle center
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180.0 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.thickness, m.height)
    .sweep(path, transition="round")
    .cut(
        cq.Workplane("XY")
        .circle(m.inner_radius)
        .extrude(m.height)
    )
    .edges("|Z")
    .fillet(m.outer_fillet)
    .faces(">Z")
    .workplane()
    .center(m.bolt_hole_offset, 0)
    .hole(m.bolt_hole_diameter)
    .center(-m.bolt_hole_spacing, 0)
    .hole(m.bolt_hole_diameter)
)
