import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile sketch and extrusion
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_height),
                (m.thickness, m.vertical_height),
                (m.thickness, m.thickness),
                (m.horizontal_length + m.thickness, m.thickness),
                (m.horizontal_length + m.thickness, 0),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        # Chamfer lower outer edge of vertical leg (edges parallel to Y at the smallest X)
        bracket = profile.edges("|Y and <X").chamfer(m.chamfer_distance)
        # Add mounting holes on vertical leg face (>Z)
        bracket = (
            bracket.faces(">Z")
            .workplane()
            .pushPoints([
                (m.thickness/2, m.vertical_height/2 + m.hole_spacing/2),
                (m.thickness/2, m.vertical_height/2 - m.hole_spacing/2),
            ])
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        # Add mounting hole on horizontal leg
        bracket = (
            bracket.faces(">Z")
            .workplane()
            .center(m.horizontal_length/2 + m.thickness/2, m.thickness/2)
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        # Add reinforcing rib on inner corner (face >X)
        bracket = (
            bracket.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_thickness)
        )
        self.model = bracket

measures = Measures(
    vertical_height=70.0,
    horizontal_length=50.0,
    thickness=8.0,
    chamfer_distance=2.0,
    hole_diameter=5.0,
    cbore_diameter=8.0,
    cbore_depth=2.0,
    hole_spacing=20.0,
    rib_width=10.0,
    rib_height=30.0,
    rib_thickness=4.0,
)

result = LBracket(cq.Workplane("XY"), measures).model