import cadquery as cq

# dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 5.0
frame_outer_x = 70.0
frame_outer_y = 50.0
frame_inner_x = 50.0
frame_inner_y = 30.0
frame_height = 10.0
cutout_diameter = 20.0
tap_hole_diameter = 3.0
tap_hole_depth = 6.0
chamfer_dist = 0.5
fillet_radius = 0.3

hole_positions = [
    (-15.0, 0.0),
    (-5.0, 0.0),
    (5.0, 0.0),
    (15.0, 0.0),
    (0.0, 10.0),
    (0.0, -10.0),
]

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    # raised frame outer block
    .faces(">Z")
    .workplane()
    .rect(frame_outer_x, frame_outer_y)
    .extrude(frame_height, combine=True)
    # cut inner rectangle cavity
    .faces(">Z")
    .workplane()
    .rect(frame_inner_x, frame_inner_y)
    .cutBlind(-frame_height)
    # cut circular opening in frame
    .faces(">Z")
    .workplane()
    .circle(cutout_diameter / 2)
    .cutBlind(-frame_height)
    # chamfer and fillet edges
    .edges("|Z").chamfer(chamfer_dist)
    .edges(">Z").fillet(fillet_radius)
    # blind tapped holes
    .faces(">Z")
    .workplane()
    .pushPoints(hole_positions)
    .circle(tap_hole_diameter / 2)
    .cutBlind(-tap_hole_depth)
)
