import cadquery as cq
import math
from types import SimpleNamespace as Measures

m = Measures(
    sweep_angle_deg = 105.0,
    outer_radius = 35.0,
    block_depth = 12.0,
    block_height = 10.0,
    chamfer_dist = 0.8,
    vertical_fillet = 0.8,
    top_fillet = 0.5,
    screw_shank_dia = 3.5,
    screw_csk_dia = 6.5,
    screw_csk_angle = 82.0,
    screw_depth_clearance = 2.0
)

m.sweep_angle_rad = math.radians(m.sweep_angle_deg)
m.inner_radius = m.outer_radius - m.block_depth
m.linear_width = 2.0 * m.inner_radius * math.sin(m.sweep_angle_rad / 2.0)
m.inner_center_angle = math.degrees(math.acos((2 * m.inner_radius**2 - m.linear_width**2) / (2 * m.inner_radius**2)))
m.secant_angle = 0.5 * (180.0 - m.inner_center_angle)
m.screw_hole_depth = m.block_height - m.screw_depth_clearance

arc_path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.inner_radius)
    .wire()
)

model = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.secant_angle, 0))
    .rect(m.block_depth, m.block_height)
    .sweep(arc_path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_dist)
    .edges("|Z")
    .fillet(m.vertical_fillet)
    .edges(">Z")
    .fillet(m.top_fillet)
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .cskHole(m.screw_shank_dia, m.screw_csk_dia, m.screw_csk_angle, depth=m.screw_hole_depth)
)

result = model
