import cadquery as cq

outer_diameter = 50
inner_hole_diameter = 8
base_thickness = 5
rib_width = 4
rib_height = 2
blind_hole_diameter = 8
blind_hole_depth = base_thickness + rib_height - 0.5
chamfer_size = 0.5
fillet_radius = 0.5
slot_length = 8
slot_width = 2
slot_count = 4
pocket_depth = 2
pocket_width = 6
pocket_height = 6
radial_rib_thickness = 2
radial_rib_count = 3
radial_rib_length = 10
radial_rib_height = base_thickness / 2

outer_radius = outer_diameter / 2
inner_hole_radius = inner_hole_diameter / 2
rib_outer_radius = outer_radius + rib_width
rib_inner_radius = outer_radius

base = (
    cq.Workplane("XY")
    .circle(outer_radius)
    .circle(inner_hole_radius)
    .extrude(base_thickness)
)

rib = (
    cq.Workplane("XY")
    .circle(rib_outer_radius)
    .circle(rib_inner_radius)
    .extrude(rib_height)
)

result = base.union(rib)

result = (
    result
    .faces(">Z")
    .workplane()
    .hole(blind_hole_diameter, blind_hole_depth)
)

result = result.edges().chamfer(chamfer_size)

angle_step = 360 / slot_count
for i in range(slot_count):
    result = (
        result
        .faces(">Z")
        .workplane(offset=rib_height/2)
        .center(rib_inner_radius + rib_width/2, 0)
        .rotate((0, 0, 0), (0, 0, 1), i * angle_step)
        .rect(slot_length, slot_width)
        .cutBlind(rib_height)
    )

result = (
    result
    .faces("<Z")
    .workplane(offset=base_thickness)
    .rect(pocket_width, pocket_height)
    .cutBlind(pocket_depth)
)

angle_radial = 360 / radial_rib_count
for i in range(radial_rib_count):
    rib_solid = (
        cq.Workplane("XY")
        .workplane(offset=base_thickness/2)
        .center(0, 0)
        .rotate((0, 0, 0), (0, 0, 1), i * angle_radial)
        .rect(radial_rib_thickness, radial_rib_length)
        .extrude(radial_rib_height)
    )
    result = result.union(rib_solid)

result = result.edges("|Z").fillet(fillet_radius)
