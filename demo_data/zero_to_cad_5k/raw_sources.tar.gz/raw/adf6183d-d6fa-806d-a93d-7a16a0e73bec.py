import cadquery as cq

# Parameters
hub_radius = 12.0
outer_radius = 40.0
leg_height = 25.0
hole_diameter = 5.0
hole_center_radius = (hub_radius + outer_radius) / 2.0
fillet_radius = 2.0
revolve_angle = 120.0

# Create a single leg sector profile and revolve it
leg_sector = (
    cq.Workplane('XZ')
    .moveTo(hub_radius, 0)
    .lineTo(hub_radius, leg_height)
    .lineTo(outer_radius, leg_height)
    .lineTo(outer_radius, 0)
    .close()
    .revolve(revolve_angle)
)

# Duplicate the sector three times to form three legs
bracket = leg_sector
for i in range(1, 3):
    bracket = bracket.union(leg_sector.rotate((0, 0, 0), (0, 0, 1), i * 120.0))

# Add central hub cylinder
hub = cq.Workplane('XY').circle(hub_radius).extrude(leg_height)
bracket = bracket.union(hub)

# Create through holes and array them on each leg
hole = (
    cq.Workplane('XY')
    .circle(hole_diameter / 2.0)
    .extrude(leg_height + 2.0)
    .translate((hole_center_radius, 0, 0))
)
holes = hole
for i in range(1, 3):
    holes = holes.union(hole.rotate((0, 0, 0), (0, 0, 1), i * 120.0))
bracket = bracket.cut(holes)

# Apply fillet to all edges for safety and base rounding
bracket = bracket.edges().fillet(fillet_radius)

result = bracket