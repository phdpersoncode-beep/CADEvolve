import cadquery as cq
import math

leg_width = 50.0
leg_height = 70.0
wall_thickness = 8.0
chamfer_size = 2.0

tap_diameter = 3.5
blind_hole_depth = wall_thickness - 1.0

clearance_hole_diameter = 4.0
clearance_spacing_x = 15.0
clearance_spacing_y = 20.0
clearance_rows = 2
clearance_cols = 3
clearance_start_x = -((clearance_cols - 1) * clearance_spacing_x) / 2
clearance_start_y = -((clearance_rows - 1) * clearance_spacing_y) / 2

profile = (
    cq.Workplane("XY")
    .moveTo(0, 0)
    .lineTo(leg_width, 0)
    .lineTo(leg_width, wall_thickness)
    .lineTo(wall_thickness, wall_thickness)
    .lineTo(wall_thickness, leg_height)
    .lineTo(0, leg_height)
    .close()
)
solid = (
    profile
    .revolve()
    .edges()
    .chamfer(chamfer_size)
)

hole_radius = leg_width - wall_thickness / 2
blind_positions = []
for angle in [0, 120, 240]:
    rad = math.radians(angle)
    blind_positions.append((hole_radius * math.cos(rad), hole_radius * math.sin(rad)))

clearance_points = []
for i in range(clearance_cols):
    for j in range(clearance_rows):
        x = clearance_start_x + i * clearance_spacing_x
        y = clearance_start_y + j * clearance_spacing_y
        clearance_points.append((x, y))

result = (
    solid
    .faces(cq.selectors.DirectionSelector(cq.Vector(0, 0, 1)))
    .workplane()
    .pushPoints(blind_positions)
    .hole(tap_diameter, blind_hole_depth)
    .pushPoints(clearance_points)
    .hole(clearance_hole_diameter)
)
