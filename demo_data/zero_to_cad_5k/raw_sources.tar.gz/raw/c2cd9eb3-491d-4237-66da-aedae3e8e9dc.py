import cadquery as cq
from types import SimpleNamespace as Measures

horizontal_leg_length = 80.0
vertical_leg_length = 60.0
leg_thickness = 10.0
bracket_thickness = 6.0
rib_width = 8.0
rib_height = 4.0
rib_spacing = 20.0
countersink_clearance = 5.0
countersink_diameter = 8.0
countersink_depth = 2.0
chamfer_size = 1.0

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.horizontal_leg_length, 0),
            (m.horizontal_leg_length, m.leg_thickness),
            (m.leg_thickness, m.leg_thickness),
            (m.leg_thickness, m.vertical_leg_length + m.leg_thickness),
            (0, m.vertical_leg_length + m.leg_thickness)
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .mirrorY()
            .extrude(m.bracket_thickness)
        )
        num_ribs = int((m.horizontal_leg_length - m.rib_width) // m.rib_spacing) + 1
        rib_positions = [m.rib_spacing * i + m.rib_width/2 for i in range(num_ribs)]
        for x in rib_positions:
            rib = (
                cq.Workplane("XY")
                .center(x, m.leg_thickness/2)
                .rect(m.rib_width, m.rib_height)
                .extrude(m.leg_thickness)
            )
            base = base.union(rib)
        base = (
            base
            .faces("<X")
            .workplane()
            .center(m.vertical_leg_length/2, m.bracket_thickness/2)
            .cboreHole(m.countersink_clearance, m.countersink_diameter, m.countersink_depth)
        )
        self.model = base.edges().chamfer(m.chamfer_size)

measures = Measures(
    horizontal_leg_length=horizontal_leg_length,
    vertical_leg_length=vertical_leg_length,
    leg_thickness=leg_thickness,
    bracket_thickness=bracket_thickness,
    rib_width=rib_width,
    rib_height=rib_height,
    rib_spacing=rib_spacing,
    countersink_clearance=countersink_clearance,
    countersink_diameter=countersink_diameter,
    countersink_depth=countersink_depth,
    chamfer_size=chamfer_size,
)

result = LBracket(cq.Workplane("XY"), measures).model
