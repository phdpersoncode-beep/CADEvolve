import cadquery as cq
from types import SimpleNamespace as Measures

measures = Measures(
    outer_radius=40.0,
    inner_radius=30.0,
    height=10.0,
    rib_height=3.0,
    rib_width=5.0,
    rib_thickness=2.0,
    pin_hole_diameter=3.0,
    pin_hole_offset=35.0,
    fillet=0.5,
    snap_cavity_radius=2.0,
    snap_cavity_offset=5.0,
    snap_cavity_depth=2.5,
)

profile = (
    cq.Workplane("XZ")
    .moveTo(measures.inner_radius, 0)
    .lineTo(measures.inner_radius, measures.height - measures.rib_height)
    .lineTo(measures.inner_radius + measures.rib_thickness, measures.height - measures.rib_height)
    .lineTo(measures.inner_radius + measures.rib_thickness, measures.height)
    .lineTo(measures.inner_radius + measures.rib_width, measures.height)
    .lineTo(measures.inner_radius + measures.rib_width - 1.0, measures.height - 0.5)
    .lineTo(measures.inner_radius + measures.rib_width, measures.height - measures.rib_height)
    .lineTo(measures.outer_radius, measures.height - measures.rib_height)
    .lineTo(measures.outer_radius, 0)
    .close()
)

latch = profile.revolve()

latch = (
    latch
    .faces(">Z")
    .workplane()
    .center(measures.pin_hole_offset, 0)
    .hole(measures.pin_hole_diameter)
)

latch = (
    latch
    .faces(">Z")
    .workplane()
    .center(measures.inner_radius + measures.snap_cavity_offset, 0)
    .circle(measures.snap_cavity_radius)
    .cutBlind(-measures.snap_cavity_depth)
)

latch = latch.edges("<Z").fillet(measures.fillet)

result = latch