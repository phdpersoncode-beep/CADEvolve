import cadquery as cq

# Parameters
leg_long = 80.0
leg_short = 50.0
plate_thickness = 6.0
bracket_width = 12.0  # extrusion depth (Z direction)
hole_diameter = 4.5
hole_spacing = 20.0
hole_origin_x = 15.0
hole_origin_y = 15.0
pocket_width = 20.0
pocket_length = 30.0
pocket_depth = 4.0
chamfer_size = 1.0

class LBracket:
    def __init__(self, workplane):
        self.model = workplane
        self.build()

    def build(self):
        # L profile in XY
        profile = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(leg_long, 0)
            .lineTo(leg_long, plate_thickness)
            .lineTo(plate_thickness, plate_thickness)
            .lineTo(plate_thickness, leg_short)
            .lineTo(0, leg_short)
            .close()
        )
        solid = profile.extrude(bracket_width)
        # Chamfer outer edges (those with normal in +/-Z direction)
        solid = solid.edges('<<Z').chamfer(chamfer_size)
        # Five clearance holes on front face (>Y)
        points = [
            (hole_origin_x, hole_origin_y),
            (hole_origin_x + hole_spacing, hole_origin_y),
            (hole_origin_x, hole_origin_y + hole_spacing),
            (hole_origin_x + hole_spacing, hole_origin_y + hole_spacing),
            (hole_origin_x + 2*hole_spacing, hole_origin_y)
        ]
        solid = solid.faces('>Y').workplane().pushPoints(points).hole(hole_diameter)
        # Recessed pocket on short leg front surface (>Y)
        pocket = (
            solid.faces('>Y')
            .workplane()
            .center(plate_thickness/2, leg_short/2)
            .rect(pocket_width, pocket_length)
            .cutBlind(-pocket_depth)
        )
        self.model = pocket

result = LBracket(cq.Workplane('XY')).model
