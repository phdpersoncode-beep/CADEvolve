import cadquery as cq
from types import SimpleNamespace as Measures

vertical_leg_height = 70.0
horizontal_leg_length = 80.0
leg_width = 15.0
extrude_depth = 8.0
wall_thickness = 3.0
hole_diameter = 6.0
hole_spacing_vertical = 30.0
hole_spacing_horizontal = 40.0
num_holes_vertical = 2
num_holes_horizontal = 2
chamfer_distance = 1.0

measures = Measures(
    vertical_leg_height=vertical_leg_height,
    horizontal_leg_length=horizontal_leg_length,
    leg_width=leg_width,
    extrude_depth=extrude_depth,
    wall_thickness=wall_thickness,
    hole_diameter=hole_diameter,
    hole_spacing_vertical=hole_spacing_vertical,
    hole_spacing_horizontal=hole_spacing_horizontal,
    num_holes_vertical=num_holes_vertical,
    num_holes_horizontal=num_holes_horizontal,
    chamfer_distance=chamfer_distance,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Vertical leg, will be shelled and chamfered
        vertical = (
            cq.Workplane("XY")
            .rect(m.leg_width, m.vertical_leg_height)
            .extrude(m.extrude_depth)
        )
        vertical = (
            vertical
            .faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(0, -m.vertical_leg_height/2 + m.hole_spacing_vertical/2)
            .rarray(m.hole_spacing_vertical, 0, m.num_holes_vertical, 1)
            .hole(m.hole_diameter)
        )
        vertical = vertical.shell(m.wall_thickness)
        vertical = vertical.edges().chamfer(m.chamfer_distance)

        # Horizontal leg, solid
        horizontal = (
            cq.Workplane("XY")
            .rect(m.horizontal_leg_length, m.leg_width)
            .extrude(m.extrude_depth)
            .translate((0, -m.leg_width/2, 0))
        )
        horizontal = (
            horizontal
            .faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(-m.horizontal_leg_length/2 + m.hole_spacing_horizontal/2, 0)
            .rarray(m.hole_spacing_horizontal, 0, m.num_holes_horizontal, 1)
            .hole(m.hole_diameter)
        )

        # Triangular gusset connecting legs
        gusset = (
            cq.Workplane("XY")
            .moveTo(m.leg_width, 0)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width + m.leg_width, 0)
            .close()
            .extrude(m.extrude_depth)
        )

        # Union all parts
        self.model = vertical.union(horizontal).union(gusset)

result = LBracket(cq.Workplane("XY"), measures).model