import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(0, m.vertical_leg_length)
            .lineTo(m.leg_thickness, m.vertical_leg_length)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.horizontal_leg_length, m.leg_thickness)
            .lineTo(m.horizontal_leg_length, 0)
            .close()
        )
        base = profile.extrude(m.extrude_thickness)
        filleted = base.edges("|Z").fillet(m.fillet_radius)
        hole_center_x = (m.leg_thickness + m.horizontal_leg_length) / 2
        cb = (
            filleted
            .faces('>Z')
            .workplane()
            .center(hole_center_x, m.leg_thickness / 2)
            .cboreHole(m.through_hole_diameter, m.counterbore_diameter, m.counterbore_depth)
        )
        result_part = (
            cb
            .faces('>Y')
            .workplane()
            .center(m.leg_thickness / 2, m.vertical_leg_length / 2)
            .rect(m.slot_width, m.slot_height)
            .cutBlind(-m.extrude_thickness)
        )
        self.model = result_part

measures = Measures(
    leg_thickness=30.0,
    vertical_leg_length=70.0,
    horizontal_leg_length=80.0,
    extrude_thickness=8.0,
    fillet_radius=12.0,
    through_hole_diameter=4.0,
    counterbore_diameter=6.0,
    counterbore_depth=5.0,
    slot_width=12.0,
    slot_height=3.0,
)

bracket = LBracket(cq.Workplane('XY'), measures)
result = bracket.model