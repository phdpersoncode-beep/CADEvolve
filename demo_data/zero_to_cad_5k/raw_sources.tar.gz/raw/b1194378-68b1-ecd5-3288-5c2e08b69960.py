import cadquery as cq
from types import SimpleNamespace as Measures

leg_length = 80.0
leg_height = 60.0
thickness = 6.0
depth = 12.0
wall_thickness = 1.5
pocket_diameter = 20.0
pocket_depth = 2.0
pocket_offset_from_top = 15.0
countersink_diameter = 4.0
countersink_cboresize = 6.0
countersink_depth = 2.5
hole_spacing = 25.0
hole_count = 6
chamfer = 0.1

measures = Measures(
    leg_length=leg_length,
    leg_height=leg_height,
    thickness=thickness,
    depth=depth,
    wall_thickness=wall_thickness,
    pocket_diameter=pocket_diameter,
    pocket_depth=pocket_depth,
    pocket_offset_from_top=pocket_offset_from_top,
    countersink_diameter=countersink_diameter,
    countersink_cboresize=countersink_cboresize,
    countersink_depth=countersink_depth,
    hole_spacing=hole_spacing,
    hole_count=hole_count,
    chamfer=chamfer,
)

class LBracket:
    def __init__(self, workplane, m):
        self.model = workplane
        self.measures = m
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.leg_height),
                (0, m.leg_height),
                (0, 0),
            ])
            .close()
        )
        solid = profile.extrude(m.depth)
        solid = solid.shell(-m.wall_thickness)
        pocket_center_x = m.thickness / 2
        pocket_center_y = m.leg_height - m.pocket_offset_from_top
        solid = (
            solid.workplane()
            .center(pocket_center_x, pocket_center_y)
            .circle(m.pocket_diameter / 2)
            .cutBlind(-m.pocket_depth)
        )
        solid = (
            solid.faces("<Z")
            .workplane()
            .rarray(m.hole_spacing, 0, m.hole_count, 1, center=True)
            .cboreHole(m.countersink_diameter, m.countersink_cboresize, m.countersink_depth)
        )
        for dir_sel in ["<X", ">X", "<Y", ">Y"]:
            solid = solid.faces(dir_sel).edges().chamfer(m.chamfer)
        self.model = solid

result = LBracket(cq.Workplane("XY"), measures).model
