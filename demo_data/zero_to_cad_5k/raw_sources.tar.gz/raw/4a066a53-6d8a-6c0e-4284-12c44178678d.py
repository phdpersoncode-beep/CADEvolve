import cadquery as cq

plate_outer_diameter = 80.0
plate_thickness = 8.0
dome_radius = 15.0
dome_height = 5.0
hole_diameter = 5.0
hole_depth = 6.0
hole_pattern_radius = 30.0
num_holes = 6
chamfer_size = 0.5
boss_radius = 7.5
boss_height = 4.0
tab_length = 20.0
tab_width = 10.0
tab_thickness = plate_thickness
rib_length = 60.0
rib_width = 10.0
rib_height = 2.0

base_plate = cq.Workplane("XY").circle(plate_outer_diameter/2).extrude(plate_thickness)

boss = cq.Workplane("XY").circle(boss_radius).extrude(boss_height)

sphere_center_z = plate_thickness + dome_radius - dome_height

dome = cq.Workplane("XY").sphere(dome_radius).translate((0, 0, sphere_center_z))

rib = (
    cq.Workplane("XY")
    .rect(rib_length, rib_width)
    .extrude(rib_height)
    .translate((0, 0, -rib_height/2))
)

tab = (
    cq.Workplane("XY")
    .center(plate_outer_diameter/2 - tab_length/2, 0)
    .box(tab_length, tab_width, tab_thickness)
)

assembly = base_plate.union(boss).union(dome).union(rib).union(tab)

assembly = (
    assembly
    .workplane(offset=plate_thickness)
    .polarArray(radius=hole_pattern_radius, count=num_holes, startAngle=0, angle=360)
    .hole(hole_diameter, hole_depth)
)

assembly = assembly.faces(">Z").edges().chamfer(chamfer_size)

result = assembly