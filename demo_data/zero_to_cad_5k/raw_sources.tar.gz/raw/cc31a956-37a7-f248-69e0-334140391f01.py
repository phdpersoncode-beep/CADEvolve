import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile sketch on XY plane, then extrude to thickness
        base_profile = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.web_thickness),
                (m.web_thickness, m.web_thickness),
                (m.web_thickness, m.leg_height),
                (0, m.leg_height),
                (0, 0)
            ])
            .close()
        )
        # Extrude to bracket thickness
        self.model = base_profile.extrude(m.bracket_thickness)
        # Relief cut on outer corner of horizontal leg
        self.model = (
            self.model.faces('>Z')
            .workplane(centerOption='CenterOfBoundBox')
            .move(m.leg_length - m.relief_cut_depth/2, m.web_thickness/2)
            .rect(m.relief_cut_depth, m.relief_cut_width)
            .cutBlind(-m.bracket_thickness)
        )
        # Tapped hole on vertical leg, offset from inner bend
        hole_center_x = m.web_thickness/2
        hole_center_y = m.leg_height - m.tap_hole_offset
        self.model = (
            self.model.faces('>Z')
            .workplane(centerOption='CenterOfBoundBox')
            .move(hole_center_x, hole_center_y - m.leg_height/2)
            .hole(m.tap_hole_clearance)
        )
        # Chamfer outer edges for safety
        self.model = self.model.edges('|Z').chamfer(m.chamfer)
        # Reinforcing gusset at inner corner (triangular pocket)
        gusset = (
            cq.Workplane('XY')
            .polygon(3, m.gusset_size)
            .translate((m.web_thickness/2, m.web_thickness/2, 0))
            .extrude(m.bracket_thickness)
        )
        self.model = self.model.union(gusset)

# Parameter definitions
measures = Measures(
    leg_length=80.0,
    leg_height=80.0,
    web_thickness=3.0,
    bracket_thickness=5.0,
    relief_cut_depth=20.0,
    relief_cut_width=10.0,
    tap_hole_diameter=4.0,
    tap_hole_clearance=4.5,
    tap_hole_offset=6.0,
    chamfer=0.5,
    gusset_size=8.0,
)

result = LBracket(cq.Workplane('XY'), measures).model