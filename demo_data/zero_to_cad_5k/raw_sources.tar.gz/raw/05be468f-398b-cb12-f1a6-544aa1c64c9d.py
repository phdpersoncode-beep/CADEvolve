import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.vertical_leg_thickness, 0),
                (m.vertical_leg_thickness, m.vertical_leg_height),
                (m.horizontal_leg_length, m.vertical_leg_height),
                (m.horizontal_leg_length, m.vertical_leg_height - m.horizontal_leg_thickness),
                (m.vertical_leg_thickness, m.vertical_leg_height - m.horizontal_leg_thickness),
                (m.vertical_leg_thickness, 0),
            ])
            .close()
        )
        base = profile.extrude(m.bracket_depth)
        base_chamfered = base.edges("|Z").chamfer(m.chamfer_size)
        rib = (
            base_chamfered.faces(">Z")
            .workplane()
            .center(
                m.horizontal_leg_length / 2 - m.rib_width / 2,
                m.vertical_leg_height - m.horizontal_leg_thickness / 2,
            )
            .rect(m.rib_width, m.rib_thickness)
            .extrude(m.rib_height)
        )
        combined = base_chamfered.union(rib)
        result = (
            combined.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .move(0, m.hole_offset_y)
            .cboreHole(m.hole_diameter, m.countersink_diameter, m.countersink_depth)
        )
        self.model = result

measures = Measures(
    vertical_leg_height=60.0,
    vertical_leg_thickness=12.0,
    horizontal_leg_length=80.0,
    horizontal_leg_thickness=10.0,
    bracket_depth=8.0,
    rib_width=30.0,
    rib_thickness=8.0,
    rib_height=6.0,
    chamfer_size=2.0,
    hole_diameter=5.0,
    countersink_diameter=8.0,
    countersink_depth=2.0,
    hole_offset_y=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model