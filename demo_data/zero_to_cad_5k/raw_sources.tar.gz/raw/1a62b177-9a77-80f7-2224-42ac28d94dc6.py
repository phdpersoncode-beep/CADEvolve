import cadquery as cq
from types import SimpleNamespace as Measures

class LBracketSupport:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        self.model = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.vertical_arm_length)
            .lineTo(m.arm_thickness, m.vertical_arm_length)
            .lineTo(m.arm_thickness, m.arm_thickness)
            .lineTo(m.horizontal_arm_length, m.arm_thickness)
            .lineTo(m.horizontal_arm_length, 0)
            .lineTo(0, 0)
            .close()
            .extrude(m.bracket_depth)
        )
        # Blind clearance hole on vertical arm (does not cut through)
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .center(m.arm_thickness/2, m.vertical_arm_length - m.hole_offset)
            .hole(m.hole_diameter, depth=m.hole_depth)
        )
        # Two through mounting holes on horizontal arm
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .center(m.horizontal_arm_length - m.mount_hole_spacing/2, m.arm_thickness/2)
            .hole(m.mount_hole_diameter)
            .faces(">Z")
            .workplane()
            .center(m.horizontal_arm_length - 3*m.mount_hole_spacing/2, m.arm_thickness/2)
            .hole(m.mount_hole_diameter)
        )
        # Rectangular pocket on horizontal arm near end
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .moveTo(m.horizontal_arm_length - m.pocket_offset, m.arm_thickness/2)
            .rect(m.pocket_length, m.pocket_width)
            .cutBlind(-m.pocket_depth)
        )
        # Fillet inner corner (vertical edges)
        self.model = self.model.edges("|Z").fillet(m.fillet_radius)

measures = Measures(
    vertical_arm_length=60.0,
    horizontal_arm_length=80.0,
    arm_thickness=3.0,
    bracket_depth=12.0,
    hole_diameter=7.0,
    hole_offset=20.0,
    hole_depth=8.0,
    fillet_radius=0.8,
    mount_hole_diameter=4.0,
    mount_hole_spacing=20.0,
    pocket_length=15.0,
    pocket_width=10.0,
    pocket_depth=6.0,
    pocket_offset=5.0,
)

result = LBracketSupport(cq.Workplane("XY"), measures).model
