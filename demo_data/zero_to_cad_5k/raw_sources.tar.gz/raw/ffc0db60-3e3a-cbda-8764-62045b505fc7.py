import cadquery as cq
from types import SimpleNamespace as Measures

leg_thickness = 10.0
bracket_thickness = 8.0
vertical_length = 60.0
horizontal_length = 70.0
shoulder_extra = 6.0
shoulder_length = 30.0
hole_diameter = 5.0
fillet_radius = 2.0
hole_offsets = [vertical_length * 0.35, vertical_length * 0.75]

vertical_block = (
    cq.Workplane("XY")
    .box(leg_thickness, vertical_length, bracket_thickness)
    .translate((leg_thickness / 2, vertical_length / 2, 0))
)
horizontal_block = (
    cq.Workplane("XY")
    .box(horizontal_length, leg_thickness, bracket_thickness)
    .translate((leg_thickness + horizontal_length / 2, leg_thickness / 2, 0))
)
shoulder_block = (
    cq.Workplane("XY")
    .box(shoulder_length, shoulder_extra, bracket_thickness)
    .translate((leg_thickness + shoulder_length / 2, leg_thickness + shoulder_extra / 2, 0))
)
base = vertical_block.union(horizontal_block).union(shoulder_block)
result = (
    base
    .faces(">X")
    .workplane()
    .move(0, -vertical_length / 2)
    .pushPoints([[0, y] for y in hole_offsets])
    .hole(hole_diameter)
)
inner_edge = result.edges().filter(lambda e: abs(e.Center().x) < 1e-6 and abs(e.Center().y) < 1e-6)
result = inner_edge.fillet(fillet_radius)
