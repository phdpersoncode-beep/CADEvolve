import cadquery as cq
import math
from types import SimpleNamespace as Bunch

params = Bunch(
    block_length = 60.0,
    block_thickness = 12.0,
    block_height = 12.0,
    arc_outer_diameter = 90.0,
    fillet_side = 1.5,
    fillet_top = 2.0,
    chamfer_dist = 0.5,
    hole_offset = 15.0,
    bolt_diameter = 4.0,
    head_diameter = 7.0,
    head_height = 3.0,
    rib_width = 8.0,
    rib_height = 6.0,
    pocket_diameter = 10.0,
    pocket_depth = 4.0
)

params.arc_outer_radius = 0.5 * params.arc_outer_diameter
params.arc_center_diameter = params.arc_outer_diameter - params.block_thickness
params.arc_center_radius = 0.5 * params.arc_center_diameter
cos_angle = (2 * params.arc_center_radius**2 - params.block_length**2) / (2 * params.arc_center_radius**2)
params.arc_center_angle = math.degrees(math.acos(max(min(cos_angle,1),-1)))
params.arc_secant_angle = 0.5 * (180.0 - params.arc_center_angle)

path = (
    cq.Workplane('XY')
    .radiusArc((params.block_length, 0.0), params.arc_center_radius)
    .wire()
)

base = (
    cq.Workplane('XY')
    .transformed(rotate=(90, -params.arc_secant_angle, 0))
    .rect(params.block_thickness, params.block_height)
    .sweep(path, transition='round')
    .edges('|Z')
    .fillet(params.fillet_side)
    .edges('>Z')
    .fillet(params.fillet_top)
    .edges('<Z')
    .chamfer(params.chamfer_dist)
)

rib_box = (
    cq.Workplane('XY')
    .center(0, 0)
    .box(params.rib_width, params.rib_height, params.block_thickness)
)

combined = base.union(rib_box)

pocketed = (
    combined
    .faces('<Z')
    .workplane()
    .center(params.block_length/4, 0)
    .circle(params.pocket_diameter/2)
    .cutBlind(-params.pocket_depth)
)

result = (
    pocketed
    .faces('>Z')
    .workplane()
    .pushPoints([
        (params.hole_offset, params.hole_offset),
        (params.hole_offset, -params.hole_offset),
        (-params.hole_offset, params.hole_offset),
        (-params.hole_offset, -params.hole_offset)
    ])
    .cboreHole(params.bolt_diameter, params.head_diameter, params.head_height)
)
