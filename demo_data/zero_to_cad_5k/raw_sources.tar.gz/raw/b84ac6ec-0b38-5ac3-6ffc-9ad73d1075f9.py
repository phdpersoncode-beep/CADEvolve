import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    outer_radius=30.0,
    inner_radius=25.0,
    height=15.0,
    rib_thickness=2.0,
    rib_height=5.0,
    opening_diameter=10.0,
    opening_fillet=1.0,
    mount_offset=12.0,
    mount_diameter=3.0,
    mount_counterbore_diameter=5.5,
    mount_counterbore_depth=2.0,
)

profile = (
    cq.Workplane('XY')
    .moveTo(m.inner_radius, 0)
    .lineTo(m.outer_radius, 0)
    .lineTo(m.outer_radius, m.height)
    .lineTo(m.inner_radius, m.height)
    .lineTo(m.inner_radius, m.rib_height)
    .lineTo(m.inner_radius - m.rib_thickness, m.rib_height)
    .lineTo(m.inner_radius - m.rib_thickness, 0)
    .close()
)

result = profile.revolve(360)

# Counterbore mounting holes on top surface
result = (
    result.workplane(offset=m.height)
    .pushPoints([(-m.mount_offset, 0), (m.mount_offset, 0)])
    .cboreHole(m.mount_diameter, m.mount_counterbore_diameter, m.mount_counterbore_depth)
)

# Create filleted opening tool
hole_tool = (
    cq.Workplane('XY')
    .center(0, 0)
    .circle(m.opening_diameter / 2)
    .extrude(m.height + 1)
    .edges('>Z')
    .fillet(m.opening_fillet)
)

result = result.cut(hole_tool)
