import cadquery as cq

body_diameter = 80.0
body_length = 70.0
wall_thickness = 5.0
bore_diameter = 30.0
vent_diameter = 25.0
rib_height = 6.0
rib_width = 8.0
rib_count = 8
chamfer_size = 2.0

base = (cq.Workplane('XY')
        .circle(body_diameter/2)
        .extrude(body_length)
        .faces('>Z')
        .workplane()
        .hole(bore_diameter))

ribs = (cq.Workplane('XY')
        .polarArray(radius=body_diameter/2 + rib_height/2, count=rib_count, startAngle=0, angle=360)
        .rect(rib_width, rib_height)
        .extrude(body_length))

body_with_ribs = base.union(ribs)

vented = (body_with_ribs
          .faces('>X')
          .workplane()
          .hole(vent_diameter))

result = vented.edges('|Z').chamfer(chamfer_size)