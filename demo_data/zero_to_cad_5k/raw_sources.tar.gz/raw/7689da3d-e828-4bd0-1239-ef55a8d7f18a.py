
import cadquery as cq
# Parameters
beam_length = 80.0  # length of extrusion
total_height = 60.0  # overall height of I-beam
flange_thickness = 6.0  # vertical thickness of each flange
web_thickness = 8.0  # total web thickness
flange_width_half = 30.0  # half-width of flange (outer extent in X)
hole_diameter = 4.0
hole_spacing = 12.0
num_holes = 3
chamfer_size = 1.0
# Derived
web_half = web_thickness / 2.0
# Polyline points describing half‑section (counter‑clockwise)
pts = [
    (0, -total_height/2),                # center bottom inner corner
    (web_half, -total_height/2),        # bottom outer edge of web half
    (flange_width_half, -total_height/2),                # bottom outer corner of flange
    (flange_width_half, -total_height/2 + flange_thickness),  # up along outer flank
    (web_half, -total_height/2 + flange_thickness),          # inner bottom of flange
    (web_half, total_height/2 - flange_thickness),          # inner top of web
    (flange_width_half, total_height/2 - flange_thickness),  # inner top of flange
    (flange_width_half, total_height/2),                    # outer top corner
    (0, total_height/2),                                    # top inner center
    (0, -total_height/2)                                     # close back to start
]
# Build half I‑beam profile and extrude
half_beam = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .extrude(beam_length)
)
# Apply chamfer to outer edges of flange (those parallel to Z)
chamfered = (
    half_beam
    .edges("|Z and >X")
    .chamfer(chamfer_size)
)
# Create a row of through holes in the top flange region
# Select the top face (+Z) of the solid
holes = (
    chamfered
    .faces(">Z")
    .workplane()
    .rarray(hole_spacing, 0, num_holes, 1, center=True)
    .hole(hole_diameter)
)
result = holes
