import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 5.0
frame_outer_length = 70.0
frame_outer_width = 50.0
frame_inner_length = 60.0
frame_inner_width = 40.0
frame_height = 8.0
clearance_hole_diameter = 5.0
fillet_radius = 3.0
inner_chamfer = 0.5

# Base plate
result = (
    cq.Workplane('XY')
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .faces('>Z')
    .workplane()
    # Raise outer frame
    .rect(frame_outer_length, frame_outer_width)
    .extrude(frame_height)
    # Cut inner cavity to create frame
    .faces('>Z')
    .workplane()
    .rect(frame_inner_length, frame_inner_width)
    .cutBlind(-frame_height)
    # Chamfer inner edges of frame
    .edges('>Z and |X')
    .chamfer(inner_chamfer)
    # Add clearance holes on top face of frame
    .faces('>Z')
    .workplane()
    .pushPoints([
        ( -frame_outer_length/2 + 10, -frame_outer_width/2 + 10),
        ( -frame_outer_length/2 + 10,  frame_outer_width/2 - 10),
        (  frame_outer_length/2 - 10, -frame_outer_width/2 + 10),
        (  frame_outer_length/2 - 10,  frame_outer_width/2 - 10),
        ( -frame_outer_length/2 + 20, 0),
        (  frame_outer_length/2 - 20, 0),
        (0, -frame_outer_width/2 + 20),
        (0,  frame_outer_width/2 - 20),
    ])
    .hole(clearance_hole_diameter)
    # Fillet outer vertical edges of the whole part
    .edges('|Z')
    .fillet(fillet_radius)
)
