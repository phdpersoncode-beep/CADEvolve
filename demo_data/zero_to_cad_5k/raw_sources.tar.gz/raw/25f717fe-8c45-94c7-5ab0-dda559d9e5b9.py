import cadquery as cq

# Dimensions (max 100 units)
base_length = 80.0
base_width = 60.0
base_thickness = 8.0
frame_height = 12.0
frame_thickness = 5.0
hole_diameter = 4.2
csk_diameter = 7.0
csk_angle = 82.0
wall_thickness = 2.0
fillet_radius = 1.5

# Base plate
base = cq.Workplane("XY").box(base_length, base_width, base_thickness, centered=(True, True, False))

# Raised frame (outer box minus inner cavity)
frame_outer = (
    cq.Workplane("XY")
    .box(base_length, base_width, frame_height, centered=(True, True, False))
    .translate((0, 0, base_thickness))
)
inner_cavity = (
    cq.Workplane("XY")
    .box(base_length - 2*frame_thickness, base_width - 2*frame_thickness, frame_height + 2, centered=(True, True, False))
    .translate((0, 0, base_thickness - 1))
)
frame = frame_outer.cut(inner_cavity)

# Combine base and frame
result = base.union(frame)

# Six countersunk tapped holes on top of the frame
hole_positions = [
    (-20.0, -12.0), (0.0, -12.0), (20.0, -12.0),
    (-20.0, 12.0), (0.0, 12.0), (20.0, 12.0)
]
result = (
    result
    .faces(">Z")
    .workplane(offset=frame_height)
    .pushPoints(hole_positions)
    .cskHole(hole_diameter, csk_diameter, csk_angle, depth=frame_height + base_thickness)
)

# Shell operation to create thin walls
result = result.shell(wall_thickness)

# Fillet all external edges
result = result.edges().fillet(fillet_radius)
