
import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width = 50.0,            # chord length of the arc block
    block_thickness = 12.0,        # thickness orthogonal to the arc (depth of sweep profile)
    block_height = 20.0,           # extrude height of the swept rectangle
    arc_outer_diameter = 80.0,     # overall outer diameter of the arc
    groove_width_margin = 1.5,     # margin from side edges for groove
    groove_front_margin = 4.0,     # margin from ends of the chord for groove
    groove_depth = 2.0,            # shallow groove depth
    edge_chamfer = 0.8,            # chamfer for vertical edges
    hole = Measures(
        offset_along_chord = 0.0, # centered along chord (x direction)
        offset_radial = 5.0,       # distance from inner arc toward outer edge (y direction)
        bolt_diameter = 4.0,
        head_diameter = 7.0,
        head_height = 3.5,
    )
)

# Derived dimensions
m.arc_outer_radius = 0.5 * m.arc_outer_diameter
# Center radius for sweep path sits halfway through block thickness
m.arc_center_radius = m.arc_outer_radius - 0.5 * m.block_thickness
# Central angle of the chord based on geometry
m.arc_center_angle = degrees(
    acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2))
)
# Angle needed to align the rectangle with the start of the arc
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

# Path for sweep – an arc defined by its end point and radius
path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

# Build the arc block, add chamfers, groove, and counterbore
result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_thickness, m.block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.edge_chamfer)
    .faces(">Z")
    .workplane()
    # Shallow groove centered on top face
    .rect(
        m.block_thickness - 2 * m.groove_width_margin,
        m.linear_width - 2 * m.groove_front_margin,
    )
    .cutBlind(-m.groove_depth)
    # Counterbore hole for socket head cap screw
    .center(
        m.hole.offset_along_chord,
        m.arc_center_radius - m.block_thickness/2 + m.hole.offset_radial,
    )
    .cboreHole(
        m.hole.bolt_diameter,
        m.hole.head_diameter,
        m.hole.head_height,
    )
)
