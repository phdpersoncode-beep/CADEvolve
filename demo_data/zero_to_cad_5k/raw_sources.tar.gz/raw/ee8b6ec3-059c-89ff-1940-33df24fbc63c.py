import cadquery as cq
import math
overall_length = 80.0
overall_width = 30.0
base_thickness = 8.0
lip_length = 20.0
lip_end_width = 12.0
chamfer_angle_deg = 30.0
hole_diameter = 9.6
rib_width = 6.0
rib_height = 3.0
rib_spacing = 15.0
chamfer_length = base_thickness * math.tan(math.radians(chamfer_angle_deg))
points = [
    (-overall_width/2, 0),
    (overall_width/2, 0),
    (overall_width/2, overall_length - lip_length),
    (lip_end_width/2, overall_length),
    (-lip_end_width/2, overall_length),
    (-overall_width/2, overall_length - lip_length)
]
solid = (
    cq.Workplane("XY")
    .polyline(points)
    .close()
    .extrude(base_thickness)
)
solid = (
    solid.faces(">Z")
    .workplane()
    .center(0, overall_length - lip_length/2)
    .hole(hole_diameter)
)
solid = solid.edges("|Z and >Y").chamfer(chamfer_length)
num_ribs = int((overall_length - lip_length) / rib_spacing)
for i in range(num_ribs):
    y_pos = rib_spacing/2 + i * rib_spacing
    rib = (
        cq.Workplane("XY")
        .center(-overall_width/2 + rib_width/2, y_pos)
        .rect(rib_width, rib_height)
        .extrude(base_thickness)
    )
    solid = solid.union(rib)
result = solid