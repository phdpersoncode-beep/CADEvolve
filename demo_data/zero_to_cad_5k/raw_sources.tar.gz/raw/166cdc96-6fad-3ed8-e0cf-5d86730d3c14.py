import cadquery as cq
from types import SimpleNamespace as Measures

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()
    def build(self):
        m = self.m
        profile = (
            cq.Workplane("XZ")
            .moveTo(0, 0)
            .lineTo(m.long_leg, 0)
            .lineTo(m.long_leg, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.short_leg)
            .lineTo(0, m.short_leg)
            .close()
        )
        base = profile.extrude(m.width)
        base = (
            base.faces(">Y")
            .workplane()
            .center(m.thickness / 2, m.short_leg / 2)
            .cboreHole(m.hole_diameter, m.cbo_diameter, m.cbo_depth)
        )
        base = (
            base.faces(">Y")
            .workplane()
            .center(m.long_leg / 2, m.thickness / 2)
            .rect(m.slot_length, m.slot_width)
            .cutBlind(-m.width)
        )
        base = base.edges().chamfer(m.chamfer)
        self.model = base

measures = Measures(
    long_leg=80.0,
    short_leg=60.0,
    thickness=10.0,
    width=15.0,
    hole_diameter=5.0,
    cbo_diameter=8.0,
    cbo_depth=4.0,
    slot_width=9.0,
    slot_length=50.0,
    chamfer=1.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
