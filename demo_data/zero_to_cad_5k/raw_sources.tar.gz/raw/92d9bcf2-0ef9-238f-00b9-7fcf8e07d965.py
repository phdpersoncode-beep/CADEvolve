import cadquery as cq
import math
module = 2.0
addendum = module
dedendum = 1.25 * module
pitch = module * math.pi
tooth_thickness = pitch / 2.0
rack_length = 80.0
thickness = 10.0
fillet_radius = 0.5
mount_hole_diameter = 6.0
mount_hole_x = rack_length / 2.0
mount_hole_y = dedendum / 2.0
number_of_teeth = int(rack_length / pitch)
if number_of_teeth < 1:
    number_of_teeth = 1
actual_length = number_of_teeth * pitch
base_plate = (cq.Workplane('XY')
              .rect(actual_length, dedendum)
              .extrude(thickness))
base_plate = base_plate.edges('|Z').fillet(fillet_radius)
left_gap = (pitch - tooth_thickness) / 2.0
tri = (cq.Workplane('XY')
       .polyline([(0, 0), (tooth_thickness, 0), (tooth_thickness/2.0, addendum)])
       .close()
       .extrude(thickness))
teeth_wp = cq.Workplane('XY')
for i in range(number_of_teeth):
    x_offset = i * pitch + left_gap
    teeth_wp = teeth_wp.union(tri.translate((x_offset, 0, 0)))
teeth = teeth_wp.val()
gear_body = base_plate.combine(teeth)
gear_body = (gear_body
             .faces('>Z')
             .workplane()
             .center(mount_hole_x, mount_hole_y)
             .hole(mount_hole_diameter))
result = gear_body
