import cadquery as cq
outer_radius = 40.0
inner_radius = 10.0
thickness = 15.0
torus_major_radius = 25.0
torus_tube_radius = 5.0
fillet_radius = 1.0
mount_hole_radius = 2.5
mount_hole_distance = 20.0
rib_width = 5.0
rib_length = 20.0
rib_height = 8.0
slot_width = 4.0
slot_length = 25.0
slot_depth = 3.0
fin_thickness = 2.0
fin_height = 5.0
fin_extension = 8.0
profile = cq.Workplane('XZ').polyline([
    (inner_radius, 0),
    (inner_radius, thickness),
    (outer_radius, thickness),
    (outer_radius, 0)
]).close().revolve(360)
# torus solid
torus = cq.Workplane('XZ').moveTo(torus_major_radius, 0).circle(torus_tube_radius).revolve(360)
torus = torus.translate((0, 0, thickness/2))
result = profile.cut(torus)
# mounting holes on top surface
mount_positions = [
    (mount_hole_distance, 0),
    (-mount_hole_distance, 0),
    (0, mount_hole_distance),
    (0, -mount_hole_distance)
]
result = result.faces('>Z').workplane().pushPoints(mount_positions).hole(mount_hole_radius*2)
# ventilation slots on top surface
for i in range(-1, 2):
    result = result.workplane(offset=thickness).moveTo(i*20, 0).rect(slot_width, slot_length).cutBlind(-slot_depth)
# fillet edges at inner bore and torus junction
result = result.edges('<Z').fillet(fillet_radius)
# ribs pattern
base_rib = cq.Workplane('XZ').workplane(offset=thickness).rect(rib_width, rib_length).extrude(rib_height)
ribs = base_rib
for i in range(1,6):
    ribs = ribs.union(base_rib.rotate((0,0,0), (0,1,0), i*60))
result = result.union(ribs)
# outer fins pattern
base_fin = cq.Workplane('XZ').workplane(offset=thickness).rect(fin_thickness, fin_height).extrude(fin_extension)
fins = base_fin
for i in range(1,6):
    fins = fins.union(base_fin.rotate((0,0,0), (0,1,0), i*60))
result = result.union(fins)
