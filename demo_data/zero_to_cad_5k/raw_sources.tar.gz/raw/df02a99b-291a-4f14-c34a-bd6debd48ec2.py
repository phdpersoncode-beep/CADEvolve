import cadquery as cq
import math
from types import SimpleNamespace as NS

# Parameters
p = NS(
    linear_width=30.0,                # chord length of sweep
    central_angle_deg=85.0,
    block_thickness=15.0,            # height of swept rectangle
    block_depth=12.0,                 # width of swept rectangle (radial thickness)
    chamfer=1.0,
    fillet=2.0,
    counterbore_diameter=6.0,
    counterbore_depth=4.0,
    through_hole_diameter=3.0,
    hole_offset_radius_ratio=0.5    # fraction of radial thickness where hole center lies
)

# Derived geometry
p.arc_radius = p.linear_width / (2 * math.sin(math.radians(p.central_angle_deg / 2)))
# radial position for hole measured from inner face
p.hole_center_radius = p.block_depth * p.hole_offset_radius_ratio

# Create sweep path: circular arc with given chord and radius
path = (
    cq.Workplane("XY")
    .radiusArc((p.linear_width, 0), p.arc_radius)
    .wire()
)

# Sweep a rectangular profile along the arc to generate the arc block
sweep_body = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -0.5 * (180 - p.central_angle_deg), 0))
    .rect(p.block_depth, p.block_thickness)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(p.fillet)
    .edges("<X")
    .chamfer(p.chamfer)
)

# Add counterbored hole on the top face
result = (
    sweep_body
    .faces(">Z")
    .workplane()
    .center(p.arc_radius - p.block_depth/2, 0)  # approximate central radial location
    .cboreHole(p.through_hole_diameter, p.counterbore_diameter, p.counterbore_depth)
)
