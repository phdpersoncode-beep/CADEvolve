import cadquery as cq
panel_width = 100
panel_height = 80
panel_thickness = 4
rib_width = 12
rib_thickness = 6
pocket_width = 6
pocket_height = 20
pocket_depth = 4
chamfer_size = 0.5
hole_diameter = 2.8
hole_spacing = 10
hole_count = 5
result = (cq.Workplane('XY')
          .box(panel_width, panel_height, panel_thickness)
          .faces('>Z').workplane()
          .center(-panel_width/2 + rib_width/2, 0)
          .rect(rib_width, panel_height)
          .extrude(rib_thickness)
          .faces('>Z').workplane()
          .center(0, 0)
          .rect(pocket_width, pocket_height)
          .cutBlind(-pocket_depth)
          .edges('|Z and >X')
          .chamfer(chamfer_size)
         )
for i in range(hole_count):
    x = - (hole_count-1) * hole_spacing / 2 + i * hole_spacing
    result = result.faces('>Z').workplane().center(x, 0).hole(hole_diameter)
