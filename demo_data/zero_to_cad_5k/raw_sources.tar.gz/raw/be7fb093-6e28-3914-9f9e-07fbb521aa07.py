import cadquery as cq
result = (
    cq.Workplane('XY')
    .box(80,50,20)
    .translate((0,0,10))
    .faces('>Z').workplane()
    .moveTo(-20, -10)
    .lineTo(20, -10)
    .threePointArc((22,0),(20,10))
    .lineTo(-20,10)
    .threePointArc((-22,0),(-20,-10))
    .close()
    .cutBlind(-5)
)
