import cadquery as cq

flange_length = 80.0
flange_width = 50.0
flange_thickness = 8.0
gusset_height = 30.0
gusset_thickness = 12.0
chamfer_dist = 6.0
hole_diameter = 12.2
hole_spacing = 20.0
rib_width = 8.0
rib_thickness = 2.0
rib_spacing = 12.0

base = cq.Workplane('XY').rect(flange_length, flange_width).extrude(flange_thickness)

gusset = (
    cq.Workplane('XY')
    .polyline([
        (0, 0),
        (gusset_height, -gusset_thickness),
        (0, -gusset_thickness)
    ])
    .close()
    .extrude(flange_thickness)
)

part0 = base.union(gusset)

part0 = part0.edges('|Z').chamfer(chamfer_dist)

rib_count = int(flange_width // rib_spacing) + 1
ribs = (
    part0
    .faces('>Z')
    .workplane()
    .rarray(rib_spacing, 0, rib_count, 1, center=True)
    .rect(flange_length, rib_width)
    .extrude(rib_thickness)
)

result = part0.union(ribs)

hole_y_positions = [
    flange_width/2 - hole_spacing,
    flange_width/2,
    flange_width/2 + hole_spacing
]

hole_points = [(flange_length/2, y) for y in hole_y_positions]

result = (
    result
    .faces('>Z')
    .workplane()
    .pushPoints(hole_points)
    .hole(hole_diameter)
)
