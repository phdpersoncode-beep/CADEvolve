import cadquery as cq

# Parameters
overall_diameter = 80.0
plate_thickness = 10.0
hole_diameter = 12.0
hole_pattern_radius = 25.0
groove_width = 5.0
groove_depth = 3.0
fillet_radius = 1.0

# Base flange solid
base = (
    cq.Workplane('XY')
    .circle(overall_diameter / 2)
    .extrude(plate_thickness)
)

# Three M12 mounting holes on circular pattern
holes = (
    base
    .faces('>Z')
    .workplane()
    .pushPoints([
        (hole_pattern_radius, 0),
        (hole_pattern_radius * -0.5, hole_pattern_radius * 0.8660254),
        (hole_pattern_radius * -0.5, hole_pattern_radius * -0.8660254),
    ])
    .hole(hole_diameter)
)

# Peripheral groove (ring) cut
outer_radius = overall_diameter / 2
inner_radius = outer_radius - groove_width
groove = (
    holes
    .faces('>Z')
    .workplane()
    .circle(outer_radius)
    .circle(inner_radius)
    .cutBlind(groove_depth)
)

# Fillet on bottom edges of groove and base
result = (
    groove
    .faces('<Z')
    .edges()
    .fillet(fillet_radius)
)
