import cadquery as cq
from types import SimpleNamespace as Measures

params = Measures(
    leg_height=70.0,
    leg_thickness=20.0,
    foot_length=50.0,
    foot_thickness=12.0,
    bracket_thickness=8.0,
    blind_hole_diameter=6.0,
    blind_hole_depth_factor=0.6,
    chamfer_size=1.0,
    slot_width=8.0,
    slot_length=30.0,
    slot_offset_from_edge=5.0,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.foot_length, 0)
            .lineTo(m.foot_length, m.foot_thickness)
            .lineTo(m.leg_thickness, m.foot_thickness)
            .lineTo(m.leg_thickness, m.leg_height)
            .lineTo(0, m.leg_height)
            .close()
        )
        solid = profile.extrude(m.bracket_thickness)
        slot = (
            solid.faces("<Z")
            .workplane()
            .center(m.foot_length/2, m.foot_thickness/2 + m.slot_offset_from_edge)
            .rect(m.slot_width, m.slot_length)
            .cutBlind(-m.bracket_thickness)
        )
        hole_center_x = m.leg_thickness/2
        hole_center_y = m.leg_height * 0.4
        hole_depth = m.bracket_thickness * m.blind_hole_depth_factor
        with_hole = (
            slot.faces(">Y")
            .workplane()
            .center(hole_center_x, hole_center_y)
            .circle(m.blind_hole_diameter/2)
            .cutBlind(-hole_depth)
        )
        result = (
            with_hole.edges("|Z")
            .chamfer(m.chamfer_size)
        )
        self.model = result

result = LBracket(cq.Workplane("XY"), params).model