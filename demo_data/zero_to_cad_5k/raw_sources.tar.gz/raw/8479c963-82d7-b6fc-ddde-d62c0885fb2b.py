import cadquery as cq

# Primary dimensions
conduit_length = 80.0
conduit_width = 40.0
conduit_height = 30.0
wall_thickness = 2.0
chamfer_size = 0.5

# Rib parameters (double rib)
rib_height = conduit_height - 2 * wall_thickness - 4.0  # leave clearance
rib_thickness = 3.0
rib_spacing = 8.0  # distance between rib centers in Y direction

# Blind counterbore (non-through)
cb_diameter = 8.0
cb_depth = 6.0
cb_offset_y = conduit_width/2 - wall_thickness - 5.0  # from outer +Y face inward
cb_offset_z = wall_thickness + 5.0

# Base conduit shell
base_shell = (
    cq.Workplane('XY')
    .box(conduit_length, conduit_width, conduit_height, centered=(True, True, False))
    .shell(-wall_thickness)
    .edges('|Z')
    .chamfer(chamfer_size)
)

# Compute interior length for ribs
interior_length = conduit_length - 2 * wall_thickness

# First rib (negative Y side)
first_rib = (
    cq.Workplane('YZ')
    .rect(rib_height, rib_thickness)
    .extrude(interior_length)
    .translate((-(conduit_length/2 - wall_thickness), -rib_spacing/2, conduit_height/2))
)

# Second rib (positive Y side)
second_rib = (
    cq.Workplane('YZ')
    .rect(rib_height, rib_thickness)
    .extrude(interior_length)
    .translate((-(conduit_length/2 - wall_thickness), rib_spacing/2, conduit_height/2))
)

# Fuse ribs with shell
with_ribs = base_shell.union(first_rib).union(second_rib)

# Add blind counterbore on the +Y outer face
result = (
    with_ribs
    .faces('>Y')
    .workplane()
    .center(cb_offset_y, cb_offset_z)
    .hole(cb_diameter, depth=cb_depth)
)
