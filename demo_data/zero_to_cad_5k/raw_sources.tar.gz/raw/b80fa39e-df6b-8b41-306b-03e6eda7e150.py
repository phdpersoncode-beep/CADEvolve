import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
params = {
    'leg_length_x': 70.0,
    'leg_length_y': 50.0,
    'profile_width': 15.0,      # width in direction of leg (Y direction when swept)
    'profile_thickness': 10.0,  # thickness out of plane (Z direction)
    'hole_diameter': 6.0,
    'hole_offset_x': 20.0,
    'hole_offset_y': 15.0,
    'chamfer_distance': 1.0,
}

class LBracket:
    def __init__(self, wp, measures):
        self.model = wp
        self.m = measures
        self.build()
    def build(self):
        m = self.m
        # L-shaped path (open wire)
        path = (
            cq.Workplane('XY')
            .polyline([(0, 0), (m.leg_length_x, 0), (m.leg_length_x, m.leg_length_y)])
            .wire()
        )
        # Profile oriented perpendicular to initial path direction (YZ plane)
        body = (
            cq.Workplane('YZ')
            .rect(m.profile_width, m.profile_thickness)
            .sweep(path)
        )
        # Hole positions relative to inner corner (origin)
        hole_positions = [
            (m.hole_offset_x, 0),
            (m.leg_length_x - m.hole_offset_x, 0),
            (m.leg_length_x, m.hole_offset_y),
            (m.leg_length_x, m.leg_length_y - m.hole_offset_y),
        ]
        body = (
            body.faces('>Z')
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        # Chamfer outer edges (edges parallel to Z)
        body = body.edges('|Z').chamfer(m.chamfer_distance)
        self.model = body

measures = Measures(**params)
result = LBracket(cq.Workplane('XY'), measures).model
