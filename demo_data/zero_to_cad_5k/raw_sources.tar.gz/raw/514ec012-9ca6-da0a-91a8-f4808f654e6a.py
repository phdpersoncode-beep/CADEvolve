import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Sketch L profile
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_width, 0)
            .lineTo(m.leg_width, m.vertical_leg_length)
            .lineTo(-m.horizontal_leg_length, m.vertical_leg_length)
            .lineTo(-m.horizontal_leg_length, 0)
            .close()
        )
        # Extrude to thickness
        self.model = (
            profile
            .extrude(m.thickness)
            .faces("<Z")
            .workplane()
            # Add mounting holes on horizontal leg (pattern of 3 holes)
            .pushPoints([
                (-m.horizontal_leg_length/2, -m.thickness/2),
                (-m.horizontal_leg_length/2 + m.hole_spacing, -m.thickness/2),
                (-m.horizontal_leg_length/2 + 2*m.hole_spacing, -m.thickness/2),
            ])
            .hole(m.hole_diameter)
            # Add rectangular pocket on vertical leg
            .faces("<Z")
            .workplane()
            .center(m.leg_width/2, m.vertical_leg_length/2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
            # Fillet interior corner
            .edges("|Z")
            .fillet(m.fillet_radius)
        )

# Define measures
measures = Measures(
    leg_width=20.0,
    horizontal_leg_length=60.0,
    vertical_leg_length=70.0,
    thickness=10.0,
    fillet_radius=5.0,
    pocket_width=12.0,
    pocket_height=8.0,
    pocket_depth=6.0,
    hole_diameter=6.0,
    hole_spacing=20.0,
)

result = LBracket(cq.Workplane("XY"), measures).model