import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # L profile sketch
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_length, 0)
            .lineTo(m.horizontal_length, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness, m.vertical_height)
            .lineTo(0, m.vertical_height)
            .close()
        )
        base = profile.extrude(m.bracket_thickness)
        # vertical leg through holes (four 8mm holes)
        hole_points = [(0, m.hole_margin + i * m.hole_spacing) for i in range(4)]
        base = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints(hole_points)
            .hole(m.hole_diameter)
        )
        # pocket on horizontal leg
        base = (
            base.faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .moveTo(m.horizontal_length / 2, -m.pocket_depth / 2)
            .rect(m.pocket_width, m.pocket_depth)
            .cutBlind(-m.pocket_depth)
        )
        # gusset reinforcement inside corner
        gusset = (
            cq.Workplane("XY")
            .moveTo(m.gusset_offset, m.gusset_offset)
            .lineTo(m.gusset_offset + m.gusset_width, m.gusset_offset)
            .lineTo(m.gusset_offset, m.gusset_offset + m.gusset_height)
            .close()
            .extrude(m.gusset_thickness)
        )
        base = base.union(gusset)
        # chamfer outer edges for safety
        base = base.edges("|Z").chamfer(m.chamfer)
        self.model = base

measures = Measures(
    horizontal_length=70.0,
    vertical_height=80.0,
    leg_thickness=10.0,
    bracket_thickness=8.0,
    hole_diameter=8.0,
    hole_margin=15.0,
    hole_spacing=12.0,
    pocket_width=30.0,
    pocket_depth=6.0,
    gusset_offset=10.0,
    gusset_width=20.0,
    gusset_height=20.0,
    gusset_thickness=5.0,
    chamfer=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model