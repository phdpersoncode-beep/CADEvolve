import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 5.0
edge_chamfer = 0.5
recess_radius = 6.0
recess_depth = 2.0
mount_hole_dia = 4.0
mount_offset = 10.0
mount_spacing = 20.0
rib_height = 1.5
rib_width = 5.0
rib_spacing = 12.0

# Base leaf
result = (
    cq.Workplane('XY')
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)

# Mounting holes (through thickness)
hole_positions = [
    (-leaf_length/2 + mount_offset, 0),
    (leaf_length/2 - mount_offset, 0)
]
result = (
    result.faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .hole(mount_hole_dia)
)

# Recessed circular pocket on top surface
result = (
    result.faces('>Z')
    .workplane()
    .center(0, 0)
    .circle(recess_radius)
    .cutBlind(recess_depth)
)

# Front-side weight reduction ribs (cut pockets) on top surface
num_ribs = int((leaf_length - 2*mount_offset) // rib_spacing) + 1
rib_x_positions = [
    -leaf_length/2 + mount_offset + i * rib_spacing for i in range(num_ribs)
]
result = (
    result.faces('>Z')
    .workplane()
    .pushPoints([(x, leaf_width/4) for x in rib_x_positions])
    .rect(rib_width, leaf_thickness/2)
    .cutBlind(rib_height)
)
result = (
    result.faces('>Z')
    .workplane()
    .pushPoints([(x, -leaf_width/4) for x in rib_x_positions])
    .rect(rib_width, leaf_thickness/2)
    .cutBlind(rib_height)
)

# Chamfer outer perimeter edges
result = result.edges('|Z').chamfer(edge_chamfer)
