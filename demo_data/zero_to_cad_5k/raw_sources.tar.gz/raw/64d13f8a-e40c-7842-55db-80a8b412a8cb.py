import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()

    def build(self):
        m = self.m
        # Base L profile extruded to thickness
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.vertical_leg_length)
            .lineTo(0, m.vertical_leg_length)
            .close()
            .extrude(m.thickness)
        )
        # Reinforcement rib at inner corner
        rib = (
            cq.Workplane("XY")
            .moveTo(m.thickness, m.thickness)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.thickness)
        )
        self.model = base.union(rib)
        # Rectangular slot on vertical leg (through thickness)
        self.model = (
            self.model.faces(">Y")
            .workplane()
            .center(m.thickness / 2, m.vertical_leg_length / 2)
            .rect(m.slot_width, m.slot_height)
            .cutBlind(-m.thickness)
        )
        # Counterbore hole on horizontal leg
        self.model = (
            self.model.faces(">X")
            .workplane()
            .center(m.thickness / 2, m.thickness / 2)
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        # Chamfer outer edges for safety
        self.model = self.model.edges("|Z").chamfer(m.chamfer)

measures = Measures(
    horizontal_leg_length=70.0,
    vertical_leg_length=70.0,
    thickness=10.0,
    slot_width=6.0,
    slot_height=20.0,
    hole_diameter=5.0,
    cbore_diameter=9.0,
    cbore_depth=3.0,
    chamfer=1.0,
    rib_width=8.0,
    rib_height=8.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
