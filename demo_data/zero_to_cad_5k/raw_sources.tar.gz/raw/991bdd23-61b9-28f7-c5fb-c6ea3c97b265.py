import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .rect(m.leg_thickness, m.vertical_height)
            .extrude(m.depth)
            .translate((m.leg_thickness/2, m.vertical_height/2, 0))
        )
        horizontal = (
            cq.Workplane("XY")
            .rect(m.horizontal_length, m.leg_thickness)
            .extrude(m.depth)
            .translate(((m.horizontal_length/2)+(m.leg_thickness/2), m.leg_thickness/2, 0))
        )
        bracket = vertical.union(horizontal)
        gusset = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_thickness, 0),
                (0, m.leg_thickness),
                (0, 0)
            ])
            .close()
            .extrude(m.gusset_thickness)
        )
        bracket = bracket.union(gusset)
        bracket = bracket.edges("|Z").chamfer(m.chamfer)
        bracket = (
            bracket.faces(">Z")
            .workplane()
            .moveTo(
                m.leg_thickness + m.hole_margin + (m.cols-1)*m.col_spacing/2,
                m.leg_thickness/2
            )
            .rect(
                (m.cols-1)*m.col_spacing,
                (m.rows-1)*m.row_spacing,
                forConstruction=True,
            )
            .vertices()
            .hole(m.hole_diameter)
        )
        self.model = bracket

measures = Measures(
    leg_thickness=10.0,
    vertical_height=70.0,
    horizontal_length=50.0,
    depth=12.0,
    gusset_thickness=4.0,
    chamfer=0.8,
    rows=2,
    cols=3,
    col_spacing=14.0,
    row_spacing=12.0,
    hole_margin=5.0,
    hole_diameter=5.0,
)

result = LBracket(cq.Workplane("XY"), measures).model