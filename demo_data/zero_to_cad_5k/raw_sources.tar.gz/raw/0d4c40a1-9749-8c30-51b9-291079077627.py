import cadquery as cq

# Dimensions (max 100 units scale)
length = 80.0
full_height = 40.0
flange_width = 20.0
web_thickness = 2.0
flange_thickness = 4.0
shell_thickness = 1.5
fillet_radius = 1.0
hole_diameter = 4.0
hole_spacing = 30.0

# Half‑section polyline points (starting at bottom web centre)
pts_half = [
    (0.0, -full_height/2.0),
    (flange_width, -full_height/2.0),
    (flange_width, -full_height/2.0 + flange_thickness),
    (web_thickness/2.0, -full_height/2.0 + flange_thickness),
    (web_thickness/2.0, full_height/2.0 - flange_thickness),
    (flange_width, full_height/2.0 - flange_thickness),
    (flange_width, full_height/2.0),
    (0.0, full_height/2.0)
]

# Build solid half‑beam, mirror, fillet vertical edges, then shell
solid = (
    cq.Workplane("XY")
    .polyline(pts_half)
    .close()
    .mirrorY()
    .extrude(length)
)

filleted = solid.edges("|Z").fillet(fillet_radius)

hollow = filleted.shell(-shell_thickness)

# Add two through‑holes on the top face, spaced along the beam length
hole_positions = [(-hole_spacing/2.0, 0.0), (hole_spacing/2.0, 0.0)]
result = (
    hollow
    .faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)
