import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .polyline([
                (0, 0),
                (m.base_length, 0),
                (m.base_length, m.base_width),
                (m.leg_width, m.base_width),
                (m.leg_width, m.base_width + m.leg_height),
                (0, m.base_width + m.leg_height),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        # Fillet interior vertical edge
        filleted_v = base.faces("<X").edges("|Z").fillet(m.fillet_radius_inner)
        # Fillet interior horizontal edge
        filleted = filleted_v.faces("<Y").edges("|Z").fillet(m.fillet_radius_inner)
        pocketed = (
            filleted.faces("<Z")
            .workplane()
            .move(m.leg_width / 2, m.base_width + m.leg_height / 2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.thickness)
        )
        holed = (
            pocketed.faces(">Z")
            .workplane(invert=True)
            .move(m.base_length - m.hole_offset, m.base_width / 2)
            .hole(m.hole_diameter)
        )
        gusseted = (
            holed.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.gusset_offset_x, m.gusset_offset_y)
            .polyline([
                (0, 0),
                (m.gusset_length, 0),
                (0, m.gusset_height),
                (0, 0),
            ])
            .close()
            .extrude(-m.gusset_thickness)
        )
        self.model = gusseted

measures = Measures(
    base_length=80.0,
    base_width=10.0,
    leg_height=60.0,
    leg_width=12.0,
    thickness=8.0,
    pocket_width=6.0,
    pocket_height=30.0,
    fillet_radius_inner=1.0,
    hole_diameter=5.0,
    hole_offset=8.0,
    gusset_length=20.0,
    gusset_height=30.0,
    gusset_thickness=4.0,
    gusset_offset_x=4.0,
    gusset_offset_y=12.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
