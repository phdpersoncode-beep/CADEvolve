import cadquery as cq
import math

# Primary dimensions (max 100 units)
outer_radius = 40.0
inner_radius = 20.0
height = 30.0
channel_width = 2.0
pitch_per_turn = 5.0
turns = 3.0
stop_thickness = 4.0
stop_height = 6.0

# Additional functional features
pocket_length = 20.0
pocket_width = 10.0
pocket_depth = 5.0
mount_hole_diameter = 4.0
mount_offset = 5.0
central_boss_height = height / 2.0
central_boss_radius = inner_radius / 2.0

# Base cylinder
base = cq.Workplane('XY').circle(outer_radius).extrude(height)

# Top pocket for access
base = (
    base.faces('>Z')
    .workplane()
    .rect(pocket_length, pocket_width)
    .cutBlind(pocket_depth)
)

# Central cylindrical boss for reinforcement
base = (
    base.faces('<Z')
    .workplane()
    .center(0, 0)
    .circle(central_boss_radius)
    .extrude(central_boss_height)
)

# Four mounting holes on top face
hole_radius = outer_radius - mount_offset
hole_positions = [
    (hole_radius * math.cos(a), hole_radius * math.sin(a))
    for a in [0, math.pi/2, math.pi, 3*math.pi/2]
]
base = (
    base.faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .hole(mount_hole_diameter)
)

# Generate spiral ribbon points in XZ plane for channel
num_pts = 120
outer_pts = []
inner_pts = []
for i in range(num_pts + 1):
    theta = i / num_pts * turns * 2 * math.pi
    radius_center = inner_radius + (pitch_per_turn / (2 * math.pi)) * theta
    z = pitch_per_turn * (theta / (2 * math.pi))
    outer_pts.append((radius_center + channel_width / 2.0, z))
    inner_pts.append((radius_center - channel_width / 2.0, z))
profile_pts = outer_pts + inner_pts[::-1]

# Spiral channel solid by revolving ribbon profile
channel = (
    cq.Workplane('XZ')
    .polyline(profile_pts)
    .close()
    .revolve()
)

# Subtract channel from base
part = base.cut(channel)

# Machined stop at beginning of channel
stop = (
    cq.Workplane('XY')
    .center(inner_radius - channel_width / 2.0 - stop_thickness / 2.0, 0)
    .circle(stop_thickness / 2.0)
    .extrude(stop_height)
    .translate((0, 0, stop_height / 2.0))
)
result = part.union(stop)
