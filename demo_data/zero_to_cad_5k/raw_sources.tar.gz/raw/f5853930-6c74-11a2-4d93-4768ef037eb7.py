import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

# Parameters
p = Measures(
    linear_width = 45.0,
    depth = 12.0,
    height = 15.0,
    arc_outer_diameter = 80.0,
    outer_fillet_radius = 8.0,
    inner_chamfer = 2.0,
    pocket_width = 25.0,
    pocket_depth = 8.0,
    pocket_depth_height = 6.0,
    holes = Measures(
        hole_1_x_offset = 15.0,
        hole_1_y_offset = 5.0,
        hole_2_x_offset = 30.0,
        hole_2_y_offset = 5.0,
        bolt_diameter = 4.0,
        head_diameter = 7.0,
        head_height = 4.0,
    )
)

p.arc_outer_radius = 0.5 * p.arc_outer_diameter
p.arc_center_radius = p.arc_outer_radius - p.depth
p.arc_center_angle = degrees(acos((2 * p.arc_center_radius**2 - p.linear_width**2) / (2 * p.arc_center_radius**2)))
p.arc_secant_angle = 0.5 * (180.0 - p.arc_center_angle)

arc_path = (
    cq.Workplane("XY")
    .radiusArc((p.linear_width, 0.0), p.arc_center_radius)
    .wire()
)

block = (
    cq.Workplane("XY")
    .transformed(rotate = (90, -p.arc_secant_angle, 0))
    .rect(p.depth, p.height)
    .sweep(arc_path, transition = "round")
    .edges("<X")
    .chamfer(p.inner_chamfer)
    .edges(">X")
    .fillet(p.outer_fillet_radius)
    .faces(">Z")
    .workplane()
    .rect(p.pocket_width, p.pocket_depth)
    .cutBlind(-p.pocket_depth_height)
    .center(p.holes.hole_1_x_offset, p.holes.hole_1_y_offset)
    .cboreHole(p.holes.bolt_diameter, p.holes.head_diameter, p.holes.head_height)
    .center(-p.holes.hole_1_x_offset, -p.holes.hole_1_y_offset)
    .center(p.holes.hole_2_x_offset, p.holes.hole_2_y_offset)
    .cboreHole(p.holes.bolt_diameter, p.holes.head_diameter, p.holes.head_height)
)

result = block