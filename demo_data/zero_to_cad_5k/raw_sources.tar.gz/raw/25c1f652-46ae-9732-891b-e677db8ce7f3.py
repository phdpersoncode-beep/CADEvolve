import cadquery as cq
import math
module = 2.0
num_teeth = 30
pressure_angle_deg = 20.0
gear_width = 15.0
helix_angle_deg = 33.0
hub_radius = module * 4.0
key_width = 8.0
key_height = 6.0
key_depth = 3.0
relief_width = 20.0
relief_depth = 5.0
relief_offset = 5.0
chamfer_size = 0.5
pitch_diameter = module * num_teeth
pitch_radius = pitch_diameter / 2.0
addendum = module
dedendum = 1.25 * module
gear_outer_radius = pitch_radius + addendum
gear_root_radius = pitch_radius - dedendum
tooth_thickness = (math.pi * module) / 2.0
tooth_height = gear_outer_radius - gear_root_radius
lead = math.pi * pitch_diameter * math.tan(math.radians(helix_angle_deg))
twist_angle = 360.0 * gear_width / lead
base_cylinder = cq.Workplane('XY').circle(gear_root_radius).extrude(gear_width)
hub = cq.Workplane('XY').circle(hub_radius).extrude(gear_width)
gear_body = base_cylinder.union(hub)
tooth_profiles = (cq.Workplane('XY')
                 .rect(tooth_thickness, tooth_height)
                 .polarArray(gear_root_radius + tooth_height/2, 0, num_teeth, 360))
teeth = tooth_profiles.twistExtrude(gear_width, twist_angle)
gear_with_teeth = gear_body.union(teeth)
keyway = (cq.Workplane('YZ')
          .rect(key_width, gear_width)
          .extrude(key_depth)
          .translate((hub_radius - key_depth/2, 0, 0)))
gear_with_key = gear_with_teeth.cut(keyway)
gear_with_relief = gear_with_key.faces('<Z').workplane().center(0, 0).rect(relief_width, relief_width).cutBlind(relief_depth)
result = gear_with_relief.edges('|Z').chamfer(chamfer_size)