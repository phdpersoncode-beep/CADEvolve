import cadquery as cq
import math
outer_flat = 80.0
thickness = 10.0
groove_width = 40.0
groove_depth = 4.0
hole_diam = 4.5
edge_fillet = 2.0
rib_width = 6.0
rib_thick = 3.0
boss_dia = 20.0
boss_height = 4.0
side_length = outer_flat / math.sqrt(3.0)
base = (cq.Workplane('XY')
        .polygon(6, side_length)
        .extrude(thickness))
base = (base.faces('>Z')
        .workplane()
        .rect(groove_width, thickness)
        .cutBlind(-groove_depth))
base = base.edges('|Z').fillet(edge_fillet)
# central raised boss on bottom side
boss = (base.faces('<Z')
        .workplane()
        .circle(boss_dia/2)
        .extrude(boss_height))
# orthogonal ribs attached to boss for stiffness
rib1 = (boss.faces('>Z')
        .workplane()
        .rect(rib_width, thickness)
        .extrude(rib_thick)
        .translate((0, 0, -rib_thick)))
rib2 = rib1.rotate((0,0,0), (0,0,1), 90)
combined = base.union(boss).union(rib1).union(rib2)
for i in range(6):
    angle = math.radians(60*i)
    x = side_length * math.cos(angle)
    y = side_length * math.sin(angle)
    combined = (combined.faces('>Z')
                .workplane()
                .center(x, y)
                .hole(hole_diam))
result = combined
