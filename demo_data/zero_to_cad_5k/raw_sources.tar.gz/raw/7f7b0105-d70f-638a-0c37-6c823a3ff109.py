import cadquery as cq

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile sketch
        pts = [
            (0, 0),
            (m.leg_x, 0),
            (m.leg_x, m.thickness),
            (m.thickness, m.thickness),
            (m.thickness, m.leg_y),
            (0, m.leg_y),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.thickness)
        )
        # Inner corner rib
        rib = (
            cq.Workplane("XY")
            .box(m.rib_width, m.rib_width, m.thickness)
            .translate((m.thickness + m.rib_width/2, m.thickness + m.rib_width/2, m.thickness/2))
        )
        part = base.union(rib)
        # Chamfer outer edges
        part = part.edges("|Z and (<X or >X or <Y or >Y)").chamfer(m.chamfer)
        # Hole positions
        h_offset = m.hole_offset
        pts_horiz = [
            (m.thickness + h_offset, m.thickness/2),
            (m.leg_x - h_offset, m.thickness/2),
        ]
        pts_vert = [
            (m.thickness/2, m.thickness + h_offset),
            (m.thickness/2, m.leg_y - h_offset),
        ]
        all_holes = pts_horiz + pts_vert
        part = (
            part
            .faces(">Z")
            .workplane()
            .pushPoints(all_holes)
            .hole(m.clearance_dia)
        )
        self.model = part

# Parameter definitions
class Measures:
    pass

measures = Measures()
measures.leg_x = 70.0
measures.leg_y = 60.0
measures.thickness = 8.0
measures.rib_width = 6.0
measures.chamfer = 0.5
measures.clearance_dia = 5.5
measures.hole_offset = 20.0

result = LBracket(cq.Workplane("XY"), measures).model
