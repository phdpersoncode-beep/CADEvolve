import cadquery as cq

# Parameters
length = 80.0
flange_width = 30.0
web_height = 40.0
flange_thickness = 5.0
web_thickness = 4.0
inner_chamfer = 1.0
outer_fillet = 0.5
hole_diameter = 5.0
hole_spacing = 20.0

# Half‑I profile points in the YZ plane
half_pts = [
    (0, -web_height/2.0),
    (0, -web_height/2.0 + flange_thickness),
    (flange_thickness, -web_height/2.0 + flange_thickness),
    (flange_width/2.0 - web_thickness/2.0, -web_height/2.0 + flange_thickness),
    (flange_width/2.0 - web_thickness/2.0, web_height/2.0 - flange_thickness),
    (flange_thickness, web_height/2.0 - flange_thickness),
    (0, web_height/2.0 - flange_thickness),
    (0, web_height/2.0)
]

# Build half profile, mirror, extrude
base = (
    cq.Workplane("YZ")
    .polyline(half_pts)
    .close()
    .mirrorY()
    .extrude(length)
)

# Chamfer inner flange corners (edges parallel to extrusion direction)
chamfered = base.edges("|X").chamfer(inner_chamfer)

# Fillet outer flange edges for safety (edges perpendicular to extrusion direction on outer faces)
filleted = chamfered.edges("|Z").fillet(outer_fillet)

# Add mounting holes on both outer flange faces
holes = (
    filleted.faces(">Z").workplane()
    .pushPoints([(0, -hole_spacing/2.0), (0, hole_spacing/2.0)])
    .hole(hole_diameter)
    .faces("<Z").workplane()
    .pushPoints([(0, -hole_spacing/2.0), (0, hole_spacing/2.0)])
    .hole(hole_diameter)
)

result = holes