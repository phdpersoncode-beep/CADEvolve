import cadquery as cq

bracket_length = 70
bracket_width = 40
bracket_thickness = 8
rib_height = 4
rib_width = 5
rib_spacing = 8
rib_count = int((bracket_width - 2 * rib_spacing) // (rib_width + rib_spacing))
fastener_diameter = 6
mounting_hole_diameter = 4
mounting_hole_offset = 10
chamfer_size = 1

result = (
    cq.Workplane("XY")
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
    .edges("|Z")
    .chamfer(chamfer_size)
    .faces(">Z")
    .workplane(invert=True)
    .rect(rib_width, rib_height)
    .rarray(rib_width + rib_spacing, 0, rib_count, 1)
    .extrude(-rib_height)
    .faces(">Z")
    .workplane()
    .hole(fastener_diameter)
    .faces(">Z")
    .workplane()
    .pushPoints([
        (mounting_hole_offset, bracket_width/2),
        (bracket_length - mounting_hole_offset, bracket_width/2)
    ])
    .hole(mounting_hole_diameter)
)
