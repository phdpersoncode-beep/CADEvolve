import cadquery as cq

leaf_thickness = 8.0
inner_radius = 10.0
outer_radius = 30.0
sweep_angle = 45.0
hole_diameter = 6.0
fillet_radius = 1.5
boss_width = 4.0
boss_length = 12.0
boss_height = 4.0
slot_width = 3.0
slot_length = 5.0

profile = (
    cq.Workplane('XZ')
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius - leaf_thickness, 0)
    .threePointArc((outer_radius, leaf_thickness/2), (outer_radius - leaf_thickness, leaf_thickness))
    .lineTo(inner_radius, leaf_thickness)
    .close()
)

leaf = profile.revolve(sweep_angle, (0, 0, 0), (0, 1, 0))

leaf = leaf.edges().fillet(fillet_radius)

leaf = (
    leaf.faces("<Y")
    .workplane()
    .center(inner_radius + leaf_thickness/2, leaf_thickness/2)
    .rect(boss_width, boss_length)
    .extrude(boss_height)
)

leaf = (
    leaf.faces(">Z")
    .workplane()
    .center(inner_radius + leaf_thickness/4, leaf_thickness/2)
    .hole(hole_diameter)
)

leaf = (
    leaf.faces(">Y")
    .workplane()
    .center(outer_radius - leaf_thickness/2, leaf_thickness/2)
    .rect(slot_width, slot_length)
    .cutBlind(-leaf_thickness)
)

result = leaf