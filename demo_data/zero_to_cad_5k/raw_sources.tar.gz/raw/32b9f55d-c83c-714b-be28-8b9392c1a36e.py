import cadquery as cq

# Parameters
number_of_teeth = 62
pitch = 1.5  # distance per tooth (units)
base_thickness = 2.0  # thickness of rack base (Y direction)
tooth_height = 5.0  # height of each tooth above base
part_thickness = 10.0  # extrusion depth (Z direction)
reinforcement_depth = 2.0  # extra material extruded on rear side
mount_hole_diameter = 2.0
mount_hole_offset = 5.0  # distance from each end along X

# Derived dimensions
rack_length = number_of_teeth * pitch

# Generate rack outline points (XY plane)
points = []
# start at origin bottom left
points.append((0, 0))
points.append((rack_length, 0))
points.append((rack_length, base_thickness))
# top edge with teeth
x = rack_length
for i in range(number_of_teeth):
    # move backwards to create tooth pattern
    x_start = rack_length - (i + 1) * pitch
    x_mid = x_start + pitch / 2.0
    points.append((x_start, base_thickness))
    points.append((x_mid, base_thickness + tooth_height))
    points.append((x_start + pitch, base_thickness))
points.append((0, base_thickness))
points.append((0, 0))

# Main rack body
main_body = (
    cq.Workplane("XY")
    .polyline(points)
    .close()
    .extrude(part_thickness)
)

# Reinforcement on rear side (negative Z) – a thin rim following base outline
reinforcement = (
    main_body.faces("<Z")
    .workplane()
    .polyline([
        (0, 0),
        (rack_length, 0),
        (rack_length, base_thickness),
        (0, base_thickness),
        (0, 0)
    ])
    .close()
    .extrude(-reinforcement_depth)
)

# Combine main body and reinforcement
combined = main_body.union(reinforcement)

# Rear mounting holes on -Y side
hole_positions = [
    (mount_hole_offset, 0),
    (rack_length - mount_hole_offset, 0)
]
result = (
    combined
    .faces("<Y")
    .workplane()
    .pushPoints(hole_positions)
    .hole(mount_hole_diameter)
)
