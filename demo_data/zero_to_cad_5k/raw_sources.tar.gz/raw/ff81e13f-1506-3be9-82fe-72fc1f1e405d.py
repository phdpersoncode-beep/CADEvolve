import cadquery as cq
from types import SimpleNamespace as Measures

leg_length_x = 80.0
leg_length_y = 60.0
leg_thickness = 10.0
rib_thickness = 2.0
rib_height = 5.0
rib_width = 8.0
rib_spacing = 12.0
hole_clearance = 6.0
cbore_diameter = 8.0
cbore_depth = 2.0
hole_offset = 20.0
hole_spacing = 20.0
num_holes_x = 2
num_holes_y = 2
chamfer_size = 0.5

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        leg_x = (
            cq.Workplane("XY")
            .box(m.leg_length_x, m.leg_thickness, m.leg_thickness)
            .translate((m.leg_length_x / 2, m.leg_thickness / 2, 0))
        )
        leg_y = (
            cq.Workplane("XY")
            .box(m.leg_thickness, m.leg_length_y, m.leg_thickness)
            .translate((m.leg_thickness / 2, m.leg_length_y / 2, 0))
        )
        base = leg_x.union(leg_y)
        base = base.edges().chamfer(m.chamfer_size)
        # Mounting holes on top surface
        base = (
            base.faces(">Z")
            .workplane()
            .pushPoints([
                (m.hole_offset + i * m.hole_spacing, m.leg_thickness / 2)
                for i in range(m.num_holes_x)
            ] + [
                (m.leg_thickness / 2, m.hole_offset + i * m.hole_spacing)
                for i in range(m.num_holes_y)
            ])
            .cboreHole(m.hole_clearance, m.cbore_diameter, m.cbore_depth)
        )
        # Rib pattern cut into horizontal leg outer face (+Y)
        base = (
            base.faces(">Y")
            .workplane(centerOption="CenterOfMass")
            .rarray(m.rib_spacing, 0, int(m.leg_length_x / m.rib_spacing), 1)
            .rect(m.rib_width, m.rib_thickness)
            .cutBlind(m.rib_height)
        )
        # Rib pattern cut into vertical leg outer face (+X)
        base = (
            base.faces(">X")
            .workplane(centerOption="CenterOfMass")
            .rarray(0, m.rib_spacing, 1, int(m.leg_length_y / m.rib_spacing))
            .rect(m.rib_width, m.rib_thickness)
            .cutBlind(m.rib_height)
        )
        self.model = base

measures = Measures(
    leg_length_x=leg_length_x,
    leg_length_y=leg_length_y,
    leg_thickness=leg_thickness,
    rib_thickness=rib_thickness,
    rib_height=rib_height,
    rib_width=rib_width,
    rib_spacing=rib_spacing,
    hole_clearance=hole_clearance,
    cbore_diameter=cbore_diameter,
    cbore_depth=cbore_depth,
    hole_offset=hole_offset,
    hole_spacing=hole_spacing,
    num_holes_x=num_holes_x,
    num_holes_y=num_holes_y,
    chamfer_size=chamfer_size,
)

result = LBracket(cq.Workplane("XY"), measures).model
