import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Create L‑profile by sketching polygon and extruding
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_leg_length),
                (m.plate_thickness, m.vertical_leg_length),
                (m.plate_thickness, m.plate_thickness),
                (m.horizontal_leg_length, m.plate_thickness),
                (m.horizontal_leg_length, 0),
                (0, 0),
            ])
            .close()
            .extrude(m.plate_thickness)
        )
        # Cut‑away pocket on horizontal leg
        with_pocket = (
            base.faces(">Z")
            .workplane()
            .move(m.horizontal_leg_length - m.pocket_offset_from_end - m.pocket_width / 2, m.plate_thickness / 2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(m.pocket_depth)
        )
        # Blind tapped hole on vertical side
        with_hole = (
            with_pocket.faces(">Y")
            .workplane()
            .move(m.hole_offset_x, m.vertical_leg_length / 2)
            .hole(m.hole_diameter, depth=m.hole_depth)
        )
        # Apply chamfer to all outer edges parallel to Z
        result = (
            with_hole.edges("|Z")
            .chamfer(m.chamfer_size)
        )
        self.model = result

# Parameter set (scaled to max dimension 100)
measures = Measures(
    vertical_leg_length=80.0,
    horizontal_leg_length=60.0,
    plate_thickness=8.0,
    pocket_width=20.0,
    pocket_height=30.0,
    pocket_depth=6.0,
    pocket_offset_from_end=10.0,
    hole_diameter=6.0,
    hole_depth=4.0,
    hole_offset_x=4.0,
    chamfer_size=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model
