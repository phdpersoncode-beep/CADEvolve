import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_length, 0)
            .lineTo(m.leg_length, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.leg_width)
            .lineTo(0, m.leg_width)
            .close()
        )
        self.model = (
            profile.extrude(m.thickness)
            .edges("|Z").fillet(m.interior_fillet)
            .faces(">Z").workplane()
            .move(m.clearance_offset, m.clearance_offset)
            .hole(m.clearance_hole_diameter)
            .faces(">Z").workplane()
            .pushPoints([
                (m.mount_offset, m.leg_width - m.mount_offset),
                (m.mount_offset, m.leg_width - 2 * m.mount_offset),
            ])
            .hole(m.mount_hole_diameter)
            .faces(">Z").workplane()
            .pushPoints([
                (m.leg_length - m.mount_offset, m.mount_offset),
                (m.leg_length - 2 * m.mount_offset, m.mount_offset),
            ])
            .hole(m.mount_hole_diameter)
        )

measures = Measures(
    leg_length=70.0,
    leg_width=60.0,
    thickness=5.0,
    interior_fillet=1.0,
    clearance_hole_diameter=6.0,
    clearance_offset=10.0,
    mount_hole_diameter=4.0,
    mount_offset=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
