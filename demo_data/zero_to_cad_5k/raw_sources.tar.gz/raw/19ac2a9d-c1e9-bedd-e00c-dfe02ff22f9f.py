import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    block_width = 50.0,
    block_height = 20.0,
    arc_radius = 40.0,
    hole_diameter = 5.0,
    hole_depth = 12.0,
    chamfer_distance = 1.0,
)

profile = (
    cq.Workplane("XY")
    .moveTo(0, 0)
    .lineTo(m.block_width, 0)
    .lineTo(m.block_width, m.block_height)
    .radiusArc((0, m.block_height), m.arc_radius)
    .close()
)

result = (
    profile
    .revolve()
    .edges()
    .chamfer(m.chamfer_distance)
    .workplane(offset=m.block_height)
    .hole(m.hole_diameter, depth=m.hole_depth)
)
