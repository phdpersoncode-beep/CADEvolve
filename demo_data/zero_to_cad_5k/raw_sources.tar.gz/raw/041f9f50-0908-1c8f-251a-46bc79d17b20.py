import cadquery as cq

outer_radius = 40
wheel_thickness = 12
flute_width = 5
flute_height = 8
num_teeth = 16
keyway_width = 6
keyway_depth = 10
chamfer_size = 0.5

base_disc = cq.Workplane('XY').circle(outer_radius).extrude(wheel_thickness)

tooth_cuts = (
    cq.Workplane('XY')
    .rect(flute_width, flute_height)
    .rotate((0, 0, 0), (0, 0, 1), 90)
    .polarArray(outer_radius - flute_height / 2, 0, 360, num_teeth)
    .extrude(wheel_thickness)
)

keyway_cut = (
    cq.Workplane('XY')
    .rect(keyway_width, keyway_depth)
    .rotate((0, 0, 0), (0, 0, 1), 90)
    .extrude(wheel_thickness)
)

result = base_disc.cut(tooth_cuts).cut(keyway_cut).edges("|Z").chamfer(chamfer_size)
