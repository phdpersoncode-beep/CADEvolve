import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        # create L profile and extrude
        self.model = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness, m.vertical_leg_height + m.leg_thickness)
            .lineTo(0, m.vertical_leg_height + m.leg_thickness)
            .close()
            .extrude(m.leg_depth)
        )
        # compute hole spacing
        total_available = m.horizontal_leg_length - 2 * m.hole_edge_clearance - 4 * m.hole_diameter
        hole_gap = total_available / 3.0
        hole_spacing = m.hole_diameter + hole_gap
        # place four holes on horizontal leg
        self.model = (
            self.model
            .faces("<Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.hole_edge_clearance + m.hole_diameter/2, m.leg_thickness/2)
            .rarray(hole_spacing, 0, 4, 1)
            .hole(m.hole_diameter)
        )
        # chamfer outer edges
        self.model = (
            self.model.edges(">X")
            .chamfer(m.chamfer_distance)
            .edges(">Y")
            .chamfer(m.chamfer_distance)
        )

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_height=60.0,
    leg_thickness=10.0,
    leg_depth=8.0,
    hole_diameter=5.0,
    hole_edge_clearance=8.0,
    chamfer_distance=2.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
