import cadquery as cq
import math
outer_radius = 40
cover_height = 10
shell_thickness = 2
sensor_pocket_width = 15
sensor_pocket_length = 20
sensor_pocket_depth = 5
sensor_offset = 20
fillet_radius = 1
hole_diameter = 5
mount_radius = 30
cable_hole_diameter = 3
# Base cylindrical shell
outer = cq.Workplane('XY').circle(outer_radius).extrude(cover_height)
inner = cq.Workplane('XY').circle(outer_radius - shell_thickness).extrude(cover_height)
cover_shell = outer.cut(inner)
# Sensor recessed pocket on top face
pocketed = (
    cover_shell.faces('>Z')
    .workplane()
    .center(sensor_offset, 0)
    .rect(sensor_pocket_width, sensor_pocket_length)
    .cutBlind(-sensor_pocket_depth)
)
# Mounting holes pattern on top face
holes = (
    pocketed.faces('>Z')
    .workplane()
    .polarArray(mount_radius, 0, 360/3, 3)
    .hole(hole_diameter)
)
# Cable passage hole within the sensor pocket
cable = (
    holes.faces('>Z')
    .workplane()
    .center(sensor_offset, 0)
    .circle(cable_hole_diameter/2)
    .cutBlind(-sensor_pocket_depth)
)
result = cable.edges('|Z').fillet(fillet_radius)
