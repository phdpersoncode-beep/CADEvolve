import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 6.0
frame_outer_length = 70.0
frame_outer_width = 50.0
frame_height = 12.0
frame_wall_thickness = 5.0
bevel_distance = 1.0
hole_diameter = 8.0
hole_grid_rows = 3
hole_grid_cols = 3
hole_spacing_x = 20.0
hole_spacing_y = 20.0
pocket_length = 30.0
pocket_width = 20.0
pocket_depth = 4.0
rib_height = 4.0
rib_width = 5.0
rib_length = 40.0

# Generate grid points centered on origin
half_cols = (hole_grid_cols - 1) / 2.0
half_rows = (hole_grid_rows - 1) / 2.0
hole_points = [
    ((col - half_cols) * hole_spacing_x, (row - half_rows) * hole_spacing_y)
    for row in range(hole_grid_rows)
    for col in range(hole_grid_cols)
]

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .faces(">Z").workplane()
    .box(frame_outer_length, frame_outer_width, frame_height, centered=(True, True, False), combine=True)
    .faces(">Z").workplane()
    .rect(frame_outer_length - 2 * frame_wall_thickness, frame_outer_width - 2 * frame_wall_thickness)
    .cutBlind(-frame_height)
    .faces(">Z").workplane()
    .rect(pocket_length, pocket_width)
    .cutBlind(-pocket_depth)
    .edges("|Z").chamfer(bevel_distance)
    .pushPoints(hole_points)
    .hole(hole_diameter)
    .faces("<Z").workplane()
    .rect(rib_length, rib_width)
    .extrude(rib_height, combine=True)
)
