import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = cq.Workplane('XY').box(m.thickness, m.height, m.thickness).translate((0, m.height/2, 0))
        horizontal = cq.Workplane('XY').box(m.width, m.thickness, m.thickness).translate((m.width/2, 0, 0))
        base = vertical.union(horizontal)
        # Mounting holes on vertical leg (>Y face)
        base = (
            base.faces('>Y')
            .workplane()
            .rect(m.mount_hole_spacing, m.mount_hole_spacing, forConstruction=True)
            .vertices()
            .hole(m.mount_hole_diameter)
        )
        # Mounting holes on horizontal leg (>X face)
        base = (
            base.faces('>X')
            .workplane()
            .rect(m.mount_hole_spacing, m.mount_hole_spacing, forConstruction=True)
            .vertices()
            .hole(m.mount_hole_diameter)
        )
        # Recessed pocket on horizontal top surface (>Z face)
        base = (
            base.faces('>Z')
            .workplane()
            .center(m.width/2 - m.pocket_width/2, 0)
            .rect(m.pocket_width, m.pocket_length)
            .cutBlind(-m.pocket_depth)
        )
        # Through hole on vertical side (>Y face)
        base = (
            base.faces('>Y')
            .workplane()
            .center(0, 0)
            .hole(m.vertical_hole_diameter)
        )
        # Triangular gusset between legs
        gusset = (
            cq.Workplane('XY')
            .workplane()
            .moveTo(0, 0)
            .lineTo(m.thickness, 0)
            .lineTo(0, m.thickness)
            .close()
            .extrude(m.thickness)
        )
        base = base.union(gusset)
        # Chamfer outer edges
        base = base.edges('|Z').chamfer(m.chamfer)
        self.model = base

measures = Measures(
    width=80.0,
    height=80.0,
    thickness=10.0,
    pocket_depth=7.0,
    pocket_width=30.0,
    pocket_length=40.0,
    vertical_hole_diameter=9.0,
    mount_hole_diameter=5.0,
    mount_hole_spacing=20.0,
    chamfer=0.8,
)

result = LBracket(cq.Workplane('XY'), measures).model