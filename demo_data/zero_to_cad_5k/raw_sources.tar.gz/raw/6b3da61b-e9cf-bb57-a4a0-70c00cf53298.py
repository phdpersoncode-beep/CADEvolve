import cadquery as cq
import math

# Gear parameters
module = 2.0
num_teeth = 30
pressure_angle = 20.0
gear_thickness = 8.0
addendum = module
dedendum = 1.25 * module
pitch_diameter = module * num_teeth
outer_radius = (pitch_diameter / 2) + addendum
root_radius = (pitch_diameter / 2) - dedendum

# Hub parameters
hub_diameter = 30.0
hub_height = 15.0
hub_radius = hub_diameter / 2.0

# Thread parameters (internal female thread)
thread_major_diameter = 10.0
thread_pitch = 2.0
thread_depth = 0.8
thread_length = 12.0
thread_minor_diameter = thread_major_diameter - 2 * thread_depth
thread_minor_radius = thread_minor_diameter / 2.0
thread_major_radius = thread_minor_radius + thread_depth

# Chamfer size
chamfer_size = 0.5

# Create gear tooth profile as alternating outer/root radii polygon
points = []
for i in range(num_teeth * 2):
    angle = i * math.pi / num_teeth
    radius = outer_radius if i % 2 == 0 else root_radius
    x = radius * math.cos(angle)
    y = radius * math.sin(angle)
    points.append((x, y))

gear_profile = (
    cq.Workplane("XY")
    .polyline(points)
    .close()
)

gear_body = gear_profile.extrude(gear_thickness)

# Hub cylinder
hub_body = cq.Workplane("XY").circle(hub_radius).extrude(hub_height)

# Assemble gear on top of hub
assembled = hub_body.union(gear_body.translate((0, 0, hub_height)))

# Internal clearance cylinder for thread
assembled = assembled.faces(">Z").workplane().circle(thread_minor_radius).cutBlind(thread_length)

# Thread tooth profile (right triangle) for helical cut
thread_profile = (
    cq.Workplane("XY")
    .polyline([
        (thread_minor_radius, 0),
        (thread_major_radius, 0),
        (thread_minor_radius, thread_depth),
    ])
    .close()
)

# Helical cut using twistExtrude (positional args)
thread_cut = (
    thread_profile
    .twistExtrude(thread_length, 360.0 * thread_length / thread_pitch)
    .translate((0, 0, hub_height - thread_length))
)

# Subtract thread from assembled part
result = assembled.cut(thread_cut)

# Apply chamfer to outer gear edges
result = result.edges("|Z").chamfer(chamfer_size)
