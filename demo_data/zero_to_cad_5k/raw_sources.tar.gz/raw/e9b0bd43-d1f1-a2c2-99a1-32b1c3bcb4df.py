import cadquery as cq

plate_length = 80.0
plate_width = 60.0
plate_thickness = 5.0
corner_radius = 3.0
edge_roll_radius = 1.0
bolt_hole_diameter = 6.0
bolt_hole_counterbore_d = 10.0
bolt_hole_counterbore_depth = 3.0
mount_hole_diameter = 4.0
mount_hole_offset = 10.0
rib_height = 8.0
rib_thickness = 4.0
rib_spacing = 20.0

result = (
    cq.Workplane("XY")
    .rect(plate_length, plate_width)
    .extrude(plate_thickness)
)
result = result.edges("|Z").fillet(edge_roll_radius)
result = result.edges("<<Z").fillet(corner_radius)

hole_positions = [
    (-plate_length/2 + mount_hole_offset, -plate_width/2 + mount_hole_offset),
    ( plate_length/2 - mount_hole_offset, -plate_width/2 + mount_hole_offset),
    (-plate_length/2 + mount_hole_offset,  plate_width/2 - mount_hole_offset),
    ( plate_length/2 - mount_hole_offset,  plate_width/2 - mount_hole_offset),
]
result = (
    result
    .faces("+Z")
    .workplane()
    .pushPoints(hole_positions)
    .hole(mount_hole_diameter)
)
result = (
    result
    .faces("+Z")
    .workplane()
    .hole(bolt_hole_diameter)
    .center(0, 0)
    .hole(bolt_hole_counterbore_d, depth=bolt_hole_counterbore_depth)
)

start_x = -plate_length/2 + mount_hole_offset + rib_spacing
rib_profile = cq.Workplane("XY", origin=(0, 0, plate_thickness)).center(start_x, 0).rect(rib_thickness, plate_width - 2*mount_hole_offset).extrude(rib_height)
num_ribs = int((plate_length - 2*mount_hole_offset) // rib_spacing)
rib_union = rib_profile
for i in range(1, num_ribs):
    rib_union = rib_union.union(rib_profile.translate((i * rib_spacing, 0, 0)))
result = result.union(rib_union)
result = result.faces(">Z").edges().chamfer(0.5)
