import cadquery as cq
channel_length = 80.0
channel_width = 30.0
channel_depth = 20.0
wall_thickness = 2.0
chamfer_size = 0.5

groove_width = 12.0
groove_depth = 1.0

outer = cq.Workplane('XY').box(channel_length, channel_width, channel_depth, centered=(True, True, False))
inner = cq.Workplane('XY').box(channel_length, channel_width - 2*wall_thickness, channel_depth - wall_thickness, centered=(True, True, False)).translate((0,0,wall_thickness))
channel = outer.cut(inner)
channel = channel.edges('|Z').chamfer(chamfer_size)
interior_bottom_z = wall_thickness
groove = cq.Workplane('XY').box(channel_length, groove_width, groove_depth, centered=(True, True, False)).translate((0,0,interior_bottom_z))
channel = channel.cut(groove)
result = channel
