import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    width=80.0,
    length=30.0,
    thickness=3.0,
    notch_width=20.0,
    notch_depth=8.0,
    hole1_x=20.0,
    hole2_x=60.0,
    hole_diameter=5.0,
    chamfer=1.0,
)

base = cq.Workplane('XY').box(m.width, m.length, m.thickness)

notched = base.faces('>Y').workplane(centerOption='CenterOfMass').rect(m.notch_width, m.thickness).cutBlind(-m.notch_depth)

with_holes = notched.faces('>Z').workplane().pushPoints([(m.hole1_x - m.width/2, 0), (m.hole2_x - m.width/2, 0)]).hole(m.hole_diameter)

chamfered = with_holes.edges('|Z and >Y').chamfer(m.chamfer)

final = chamfered.faces('<Z').workplane().center(0, 0).rect(m.width/2, m.thickness/2).cutBlind(-1.0)

result = final
