import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, m):
        self.wp = wp
        self.m = m
        self.model = self.build()
    def build(self):
        m = self.m
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.base_length, 0),
                (m.base_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.vertical_length),
                (0, m.vertical_length),
            ])
            .close()
            .extrude(m.thickness)
        )
        gusset = (
            cq.Workplane("XY")
            .rect(m.gusset_width, m.gusset_height)
            .extrude(m.thickness)
        )
        solid = base.union(gusset)
        with_hole = (
            solid.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.base_length/2, m.thickness/2)
            .hole(m.hole_diameter)
        )
        final = with_hole.faces(">Z").edges().fillet(m.fillet_radius)
        return final

measures = Measures(
    base_length=80.0,
    vertical_length=60.0,
    thickness=10.0,
    gusset_width=30.0,
    gusset_height=20.0,
    hole_diameter=12.0,
    fillet_radius=2.0,
)

result = LBracket(cq.Workplane("XY"), measures).model