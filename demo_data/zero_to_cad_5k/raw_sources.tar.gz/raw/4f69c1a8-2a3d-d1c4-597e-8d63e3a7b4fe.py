import cadquery as cq
panel_width=80.0
panel_height=60.0
panel_thickness=3.0

def panel_profile():
    w=panel_width/2.0
    h=panel_height/2.0
    tab_width=20.0
    tab_height=5.0
    return (cq.Workplane('XY')
        .moveTo(-w,-h)
        .lineTo(w,-h)
        .lineTo(w,h-tab_height)
        .lineTo(w+tab_width,h-tab_height)
        .lineTo(w+tab_width,h)
        .threePointArc((w+tab_width/2, h+tab_height), (w,h))
        .lineTo(-w,h)
        .lineTo(-w,-h)
        .close())

result = panel_profile().extrude(panel_thickness)
