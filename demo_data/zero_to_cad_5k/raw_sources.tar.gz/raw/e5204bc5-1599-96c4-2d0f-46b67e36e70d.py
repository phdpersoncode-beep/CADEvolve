import cadquery as cq
from math import acos, degrees

# Parameters
linear_width = 55.0
depth = 12.0
height = 14.0
arc_outer_diameter = 92.0
fillet_radius = 2.5
hole_diameter = 6.0
hole_offset_width = 27.5
hole_offset_depth = 6.0

# Derived parameters
arc_outer_radius = 0.5 * arc_outer_diameter
arc_center_diameter = arc_outer_diameter - depth
arc_center_radius = 0.5 * arc_center_diameter
arc_center_angle = degrees(acos((2 * arc_center_radius**2 - linear_width**2) / (2 * arc_center_radius**2)))
arc_secant_angle = 0.5 * (180 - arc_center_angle)

# Path for sweep (arc)
path = (
    cq.Workplane("XY")
    .radiusArc((linear_width, 0.0), arc_center_radius)
    .wire()
)

# Build block by sweeping a rectangular profile along the arc
result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -arc_secant_angle, 0))
    .rect(depth, height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(fillet_radius)
    .faces(">Z")
    .workplane()
    .center(hole_offset_width, hole_offset_depth)
    .hole(hole_diameter)
)
