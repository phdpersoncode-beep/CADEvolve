import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, dims):
        self.model = wp
        self.dims = dims
        self.build()

    def build(self):
        d = self.dims
        # L-shaped profile with stepped shoulder on horizontal side
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(d.vertical_width, 0)
            .lineTo(d.vertical_width, d.vertical_height)
            .lineTo(d.vertical_width + d.step_width, d.vertical_height)
            .lineTo(d.vertical_width + d.step_width, d.vertical_height + d.step_height)
            .lineTo(0, d.vertical_height + d.step_height)
            .close()
        )
        # Extrude to thickness
        base = profile.extrude(d.thickness)
        # Chamfer outer edges (45 degree by using equal distance)
        chamfered = base.edges().chamfer(d.chamfer)
        # Blind tapped hole near base on vertical leg
        result = (
            chamfered
            .faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(d.hole_offset_x, d.hole_offset_y)
            .hole(d.hole_diameter, depth=d.hole_depth)
        )
        self.model = result

# Dimensions (max 100 units)
measures = Measures(
    vertical_width=20.0,
    vertical_height=60.0,
    step_width=15.0,
    step_height=12.0,
    thickness=10.0,
    chamfer=2.0,
    hole_offset_x=5.0,
    hole_offset_y=5.0,
    hole_diameter=6.0,
    hole_depth=12.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
