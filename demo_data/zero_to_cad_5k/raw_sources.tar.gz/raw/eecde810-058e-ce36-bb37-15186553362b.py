import cadquery as cq
bracket_width = 60.0
bracket_height = 30.0
bracket_thickness = 8.0
rib_width = 4.0
rib_height = 20.0
rib_count = 4
rib_spacing = (bracket_width - rib_width) / (rib_count + 1)
rib_extrude = 2.0
hole_diameter = 6.0
hole_head_diameter = 10.0
hole_head_depth = 3.0
hole_offset_x = 20.0
hole_offset_y = 0.0
chamfer_distance = 2.0
back_pocket_width = 30.0
back_pocket_height = 10.0
back_pocket_depth = 2.0
mount_hole_diameter = 4.0
mount_spacing = 45.0
base = (
    cq.Workplane("XY")
    .rect(bracket_width, bracket_height)
    .extrude(bracket_thickness)
    .faces(">Z")
    .edges()
    .chamfer(chamfer_distance)
)
ribs = (
    base
    .faces(">Z")
    .workplane()
    .rarray(rib_spacing, 0, rib_count, 1)
    .rect(rib_width, rib_height)
    .extrude(rib_extrude)
)
hole_feature = (
    ribs
    .workplane(centerOption="CenterOfMass")
    .center(hole_offset_x - bracket_width/2, hole_offset_y)
    .cboreHole(hole_diameter, hole_head_diameter, hole_head_depth)
)
pocket = (
    hole_feature
    .faces("<Z")
    .workplane()
    .rect(back_pocket_width, back_pocket_height)
    .cutBlind(back_pocket_depth)
)
mounts = (
    pocket
    .faces("<Z")
    .workplane()
    .rarray(mount_spacing, 0, 2, 1)
    .hole(mount_hole_diameter)
)
result = mounts
