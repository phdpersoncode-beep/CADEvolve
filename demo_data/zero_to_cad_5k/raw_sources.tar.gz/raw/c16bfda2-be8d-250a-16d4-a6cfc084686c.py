import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        points = [
            (0, 0),
            (m.leg_length_horizontal, 0),
            (m.leg_length_horizontal, m.web_thickness),
            (m.web_thickness, m.web_thickness),
            (m.web_thickness, m.leg_length_vertical),
            (0, m.leg_length_vertical),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(points)
            .close()
            .extrude(m.web_thickness)
            .faces(">Z")
            .edges()
            .chamfer(m.chamfer)
        )
        boss_x = m.web_thickness + (m.leg_length_horizontal - m.web_thickness) / 2
        boss_y = m.web_thickness / 2
        base = (
            base.faces(">Z")
            .workplane()
            .center(boss_x, boss_y)
            .circle(m.boss_diameter / 2)
            .extrude(m.boss_height)
        )
        hole_x = m.web_thickness / 2
        for i in range(m.num_holes):
            hole_y = m.hole_offset + i * m.hole_spacing
            base = (
                base.faces(">Z")
                .workplane()
                .center(hole_x, hole_y)
                .hole(m.hole_diameter)
            )
        self.model = base

measures = Measures(
    leg_length_horizontal=60.0,
    leg_length_vertical=50.0,
    web_thickness=6.0,
    chamfer=2.0,
    boss_diameter=5.0,
    boss_height=8.0,
    hole_diameter=4.0,
    hole_spacing=20.0,
    hole_offset=10.0,
    num_holes=2,
)

result = LBracket(cq.Workplane("XY"), measures).model