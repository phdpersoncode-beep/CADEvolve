import cadquery as cq

outer_width = 80.0
outer_height = 60.0
channel_length = 40.0
wall_thickness = 5.0
shell_thickness = 2.0
slot_width = 20.0
slot_height = 15.0
slot_depth = 30.0
chamfer_size = 1.0

outer_block = cq.Workplane('XY').box(outer_width, outer_height, channel_length)
core_block = cq.Workplane('XY').box(outer_width - 2*wall_thickness, outer_height - wall_thickness, channel_length).translate((0, wall_thickness/2, 0))
U_shape = outer_block.cut(core_block)
U_chamfered = U_shape.edges().chamfer(chamfer_size)
U_shelled = U_chamfered.shell(shell_thickness)
slot_center_y = - (outer_height/2) + wall_thickness + slot_height/2
result = (U_shelled
    .faces('>X')
    .workplane()
    .center(0, slot_center_y)
    .rect(slot_width, slot_height)
    .cutBlind(-slot_depth)
)
