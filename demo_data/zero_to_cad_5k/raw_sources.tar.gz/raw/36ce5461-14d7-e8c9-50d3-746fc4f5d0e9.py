import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.leg_length_long, 0),
            (m.leg_length_long, m.leg_width),
            (m.leg_width, m.leg_width),
            (m.leg_width, m.leg_width + m.leg_length_short),
            (0, m.leg_width + m.leg_length_short),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.thickness)
        )
        # Chamfer outer vertical edges on +X and +Y faces
        base = base.edges(">X and |Z").chamfer(m.chamfer_size)
        base = base.edges(">Y and |Z").chamfer(m.chamfer_size)
        gusset = (
            cq.Workplane("XY")
            .center(m.leg_width / 2, m.leg_width / 2)
            .rect(m.leg_width, m.leg_width)
            .extrude(m.gusset_thickness)
        )
        self.model = base.union(gusset)
        self.model = (
            self.model.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.hole_offset, m.hole_offset)
            .hole(m.hole_diameter)
        )
        self.model = (
            self.model.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.mount_offset_long, m.mount_offset_long)
            .cboreHole(m.mount_clearance, m.mount_cbore_diameter, m.mount_cbore_depth)
        )
        self.model = (
            self.model.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.mount_offset_short, m.mount_offset_short)
            .cboreHole(m.mount_clearance, m.mount_cbore_diameter, m.mount_cbore_depth)
        )
        rib = (
            cq.Workplane("XY")
            .center(m.leg_width/2, m.leg_width + m.leg_length_short/2)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.thickness)
        )
        self.model = self.model.union(rib)

measures = Measures(
    leg_length_long=70.0,
    leg_length_short=50.0,
    leg_width=20.0,
    thickness=2.0,
    gusset_thickness=2.0,
    chamfer_size=5.0,
    hole_diameter=6.0,
    hole_pitch=1.0,
    hole_offset=5.0,
    mount_clearance=5.0,
    mount_cbore_diameter=7.5,
    mount_cbore_depth=2.0,
    mount_offset_long=15.0,
    mount_offset_short=15.0,
    rib_width=10.0,
    rib_height=5.0,
)

result = LBracket(cq.Workplane("XY"), measures).model