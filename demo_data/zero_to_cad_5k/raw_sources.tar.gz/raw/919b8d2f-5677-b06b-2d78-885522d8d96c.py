import cadquery as cq
from math import acos, degrees

class Measures:
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

m = Measures(
    block_width = 60.0,
    block_depth = 15.0,
    block_height = 12.0,
    arc_outer_diameter = 100.0,
    chamfer_distance = 1.0,
    boss_diameter = 20.0,
    boss_height = 8.0,
    sensor_hole_diameter = 5.0,
    sensor_hole_depth = 5.0,
    boss_offset_width = 30.0,
    boss_offset_depth = 7.5,
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.block_depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.block_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.block_width, 0.0), m.arc_center_radius)
    .wire()
)

base = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_depth, m.block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_distance)
)

boss = (
    base
    .faces(">Z")
    .workplane()
    .center(m.boss_offset_width, m.boss_offset_depth)
    .circle(m.boss_diameter / 2)
    .extrude(m.boss_height)
)

sensor_hole = (
    boss
    .faces(">Z")
    .workplane()
    .center(m.boss_offset_width, m.boss_offset_depth)
    .hole(m.sensor_hole_diameter, depth=m.sensor_hole_depth)
)

result = sensor_hole