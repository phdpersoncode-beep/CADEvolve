import cadquery as cq

base_width = 60.0
base_height = 30.0
base_thickness = 8.0
arm_radius = 12.0
arm_offset = 5.0
hole_diameter = 6.0
counterbore_diameter = 10.0
counterbore_depth = 6.0
chamfer_distance = 1.0
pocket_width = 8.0
pocket_spacing = 12.0
pocket_depth = 4.0
pocket_count = 3

base = (
    cq.Workplane("XY")
    .rect(base_width, base_height)
    .extrude(base_thickness)
    .edges()
    .chamfer(chamfer_distance)
)

arm_center_x = base_width/2 + arm_offset
arm_center_y = 0.0
arm = (
    cq.Workplane("XY")
    .center(arm_center_x, arm_center_y)
    .circle(arm_radius)
    .extrude(base_thickness)
)

combined = base.union(arm)

counterbore_center_x = base_width/4
counterbore_center_y = 0.0
counterbore_cyl = (
    cq.Workplane("XY")
    .center(counterbore_center_x, counterbore_center_y)
    .circle(counterbore_diameter/2)
    .extrude(counterbore_depth)
)
through_hole = (
    cq.Workplane("XY")
    .center(counterbore_center_x, counterbore_center_y)
    .circle(hole_diameter/2)
    .extrude(base_thickness)
)

with_counterbore = combined.cut(counterbore_cyl).cut(through_hole)

result = with_counterbore
for i in range(pocket_count):
    x_offset = -base_width/2 + pocket_spacing/2 + i*pocket_spacing
    result = (
        result.faces(">Z").workplane()
        .center(x_offset, 0)
        .rect(pocket_width, base_height - 2*arm_radius)
        .cutBlind(-pocket_depth)
    )
