import cadquery as cq

profile_leg_long = 80.0
profile_leg_short = 50.0
profile_leg_width = 30.0
profile_depth = 40.0
wall_thickness = 4.0
fillet_radius = 3.0
chamfer_size = 1.0
relief_length = 20.0
relief_width = 15.0
relief_depth = 30.0

base = (
    cq.Workplane("XY")
    .polyline([
        (0, 0),
        (profile_leg_long, 0),
        (profile_leg_long, profile_leg_width),
        (profile_leg_width, profile_leg_width),
        (profile_leg_width, profile_leg_short + profile_leg_width),
        (0, profile_leg_short + profile_leg_width),
        (0, 0)
    ])
    .close()
    .extrude(profile_depth)
    .edges("|Z")
    .fillet(fillet_radius)
    .shell(-wall_thickness)
    .edges("|Z")
    .chamfer(chamfer_size)
)

result = (
    base
    .faces(">Z")
    .workplane(offset=profile_depth / 2)
    .center(profile_leg_width / 2, profile_leg_short + profile_leg_width / 2)
    .rect(relief_length, relief_width)
    .cutBlind(-relief_depth)
)
