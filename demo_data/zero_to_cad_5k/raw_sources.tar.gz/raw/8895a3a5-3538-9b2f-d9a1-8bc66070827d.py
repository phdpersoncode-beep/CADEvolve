import cadquery as cq
from types import SimpleNamespace as Measures

class LBracketSupport:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # base L shape sketch points
        pts = [
            (0, 0),
            (m.vertical_leg_length, 0),
            (m.vertical_leg_length, m.thickness),
            (m.thickness, m.thickness),
            (m.thickness, m.horizontal_leg_length + m.thickness),
            (0, m.horizontal_leg_length + m.thickness),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.depth)
        )
        # reinforcing rib on bottom face
        rib_center_x = m.thickness / 2
        rib_center_y = m.thickness + m.horizontal_leg_length / 2
        rib = (
            cq.Workplane("XY")
            .rect(m.rib_width, m.horizontal_leg_length)
            .translate((rib_center_x, rib_center_y, 0))
            .extrude(m.rib_height)
        )
        body = base.union(rib)
        # counterbore holes on vertical leg outer face (+Y)
        hole_x1 = m.vertical_leg_length * 0.3
        hole_x2 = m.vertical_leg_length * 0.7
        body = (
            body.faces(">Y")
            .workplane()
            .pushPoints([[hole_x1, 0], [hole_x2, 0]])
            .cboreHole(m.counterbore_hole_diameter, m.counterbore_diameter, m.counterbore_depth)
        )
        # fillet inner corner edges
        body = body.edges("<Y and <X and |Z").fillet(m.fillet_radius)
        self.model = body

measures = Measures(
    vertical_leg_length=70.0,
    horizontal_leg_length=50.0,
    thickness=8.0,
    depth=10.0,
    rib_width=6.0,
    rib_height=4.0,
    counterbore_hole_diameter=5.0,
    counterbore_diameter=8.0,
    counterbore_depth=3.0,
    fillet_radius=2.0,
)

result = LBracketSupport(cq.Workplane("XY"), measures).model
