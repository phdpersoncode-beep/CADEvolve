import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.build()
        self.model = self.result

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_leg_length),
                (m.thickness, m.vertical_leg_length),
                (m.horizontal_leg_length, m.vertical_leg_length),
                (m.horizontal_leg_length, m.vertical_leg_length - m.thickness),
                (m.horizontal_leg_length - m.thickness, m.vertical_leg_length - m.thickness),
                (m.horizontal_leg_length - m.thickness, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
        )
        shoulder = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.thickness / 2, m.vertical_leg_length - m.step_shoulder_height / 2)
            .rect(m.step_shoulder_width, m.step_shoulder_height)
            .extrude(m.step_shoulder_thickness)
        )
        tapped_hole = (
            base.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.thickness / 2, m.vertical_leg_length / 2)
            .cboreHole(m.tapped_hole_clearance, m.tapped_hole_diameter, m.tapped_hole_depth)
        )
        slot_cut = (
            base.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.horizontal_leg_length / 2, m.thickness / 2)
            .rect(m.slot_width, m.slot_height)
            .cutBlind(-m.thickness)
        )
        gusset = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.gusset_length, 0),
                (0, m.gusset_length)
            ])
            .close()
            .extrude(m.thickness)
        )
        combined = base.union(shoulder).union(gusset).cut(slot_cut).cut(tapped_hole)
        self.result = combined.edges("|Z").chamfer(m.chamfer_distance)

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=70.0,
    thickness=10.0,
    step_shoulder_width=30.0,
    step_shoulder_height=15.0,
    step_shoulder_thickness=8.0,
    tapped_hole_diameter=6.0,
    tapped_hole_clearance=8.0,
    tapped_hole_depth=8.0,
    slot_width=12.0,
    slot_height=6.0,
    gusset_length=20.0,
    chamfer_distance=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model