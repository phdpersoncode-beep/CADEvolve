import cadquery as cq
from types import SimpleNamespace as Measures

class RibbedLBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()
    def build(self):
        m = self.measures
        points = []
        for i in range(m.rib_count):
            x0 = i * m.rib_spacing
            if i == 0:
                points.append((x0, 0))
            points.append((x0 + m.rib_spacing / 2, -m.rib_height))
            points.append((x0 + m.rib_spacing, 0))
        points.append((m.horizontal_length, m.leg_thickness))
        points.append((m.leg_thickness, m.leg_thickness))
        points.append((m.leg_thickness, m.vertical_height + m.leg_thickness))
        points.append((0, m.vertical_height + m.leg_thickness))
        base = (
            cq.Workplane('XY')
            .polyline(points)
            .close()
            .extrude(m.leg_thickness)
        )
        with_holes = (
            base.faces('>X')
            .workplane(centerOption='CenterOfBoundBox')
            .move(m.leg_thickness/2, m.leg_thickness + m.hole_spacing/2)
            .rarray(0, m.hole_spacing, 1, m.hole_count)
            .cboreHole(m.bolt_clearance, m.cbore_diameter, m.cbore_depth)
        )
        final = with_holes.edges('|Z').chamfer(m.chamfer_size)
        self.model = final

measures = Measures(
    horizontal_length=72.0,
    vertical_height=60.0,
    leg_thickness=10.0,
    bolt_clearance=5.0,
    cbore_diameter=8.0,
    cbore_depth=3.0,
    hole_spacing=30.0,
    hole_count=2,
    rib_spacing=12.0,
    rib_count=6,
    rib_height=4.0,
    chamfer_size=1.0,
)

result = RibbedLBracket(cq.Workplane('XY'), measures).model