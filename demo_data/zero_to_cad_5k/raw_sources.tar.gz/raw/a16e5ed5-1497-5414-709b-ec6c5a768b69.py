import cadquery as cq

# Parameters
outer_diameter = 80.0
plate_thickness = 10.0
edge_chamfer = 1.0
boss_diameter = 20.0
boss_height = 5.0
groove_width = 5.0
groove_depth = 6.0
groove_fillet = 2.0
clearance_hole_dia = 6.4
clearance_hole_radius = 30.0
num_holes = 4
rib_width = 3.0
rib_height = 4.0
rib_length = 20.0

# Base plate
result = cq.Workplane('XY').circle(outer_diameter/2).extrude(plate_thickness)

# Peripheral groove cut (ring) on plate top
groove_outer_radius = outer_diameter/2 - edge_chamfer - groove_width/2
groove_inner_radius = groove_outer_radius - groove_width
result = result.faces('>Z').workplane().circle(groove_outer_radius).circle(groove_inner_radius).cutBlind(-groove_depth)
# Fillet on bottom edges of groove
result = result.faces('<<Z').edges().fillet(groove_fillet)

# Clearance holes (M6 clearance) on plate top
result = result.faces('>Z').workplane().polarArray(radius=clearance_hole_radius, count=num_holes, startAngle=0, angle=360).hole(clearance_hole_dia)

# Ribs for stiffness (four ribs around perimeter) on plate top
rib_radius = outer_diameter/2 - rib_width - edge_chamfer
result = result.faces('>Z').workplane().polarArray(radius=rib_radius, count=4, startAngle=0, angle=360).rect(rib_length, rib_width).extrude(rib_height)

# Central boss on underside of plate
result = result.faces('<Z').workplane().circle(boss_diameter/2).extrude(boss_height)

# Chamfer outer edge for safety
result = result.edges('>Z and >X').chamfer(edge_chamfer)
