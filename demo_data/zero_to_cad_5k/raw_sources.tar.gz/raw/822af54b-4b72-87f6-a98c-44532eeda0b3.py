import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base_bar = (
            cq.Workplane('XY')
            .box(m.base_length, m.wall_thickness, m.bracket_depth)
            .translate((m.base_length / 2, m.wall_thickness / 2, 0))
        )
        upright_bar = (
            cq.Workplane('XY')
            .box(m.wall_thickness, m.upright_height, m.bracket_depth)
            .translate((m.wall_thickness / 2, m.upright_height / 2, 0))
        )
        outer = base_bar.union(upright_bar)
        outer = outer.edges('|Z').chamfer(m.chamfer_distance)
        pocket_cut = (
            outer.faces('>X')
            .workplane()
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        start_x = -m.base_length / 2 + (m.base_length - (m.hole_count - 1) * m.hole_spacing) / 2
        points = [(start_x + i * m.hole_spacing, 0) for i in range(m.hole_count)]
        holes_cut = (
            pocket_cut.faces('<Z')
            .workplane()
            .pushPoints(points)
            .hole(m.hole_diameter)
        )
        self.result = holes_cut

measures = Measures(
    base_length=80.0,
    upright_height=70.0,
    bracket_depth=10.0,
    wall_thickness=3.0,
    pocket_width=20.0,
    pocket_height=25.0,
    pocket_depth=2.0,
    hole_diameter=4.0,
    hole_spacing=12.0,
    hole_count=5,
    chamfer_distance=0.5,
)

result = LBracket(cq.Workplane('XY'), measures).result