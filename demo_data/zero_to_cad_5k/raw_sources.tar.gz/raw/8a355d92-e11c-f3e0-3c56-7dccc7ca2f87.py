import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_leg_length),
                (0, m.vertical_leg_length),
            ])
            .close()
            .extrude(m.material_thickness)
        )
        shelled = base.shell(m.wall_thickness)
        filleted = shelled.edges().fillet(m.inner_fillet_radius)
        pocket_center_x = m.horizontal_leg_length - m.pocket_offset_from_end - m.pocket_length / 2
        pocket = (
            filleted.faces(">Y")
            .workplane()
            .moveTo(pocket_center_x, m.leg_thickness / 2)
            .rect(m.pocket_width, m.pocket_length)
            .cutBlind(m.pocket_depth)
        )
        hole_positions_vert = [
            (m.leg_thickness / 2, m.vertical_leg_length - m.hole_margin),
            (m.leg_thickness / 2, m.hole_margin),
        ]
        with_holes_vert = (
            pocket.faces(">X")
            .workplane()
            .pushPoints(hole_positions_vert)
            .hole(m.mount_hole_diameter)
        )
        hole_positions_horiz = [
            (m.horizontal_leg_length - m.hole_margin, m.leg_thickness / 2),
            (m.hole_margin, m.leg_thickness / 2),
        ]
        final = (
            with_holes_vert.faces(">Y")
            .workplane()
            .pushPoints(hole_positions_horiz)
            .hole(m.mount_hole_diameter)
        )
        self.model = final

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=60.0,
    leg_thickness=12.0,
    material_thickness=12.0,
    wall_thickness=2.0,
    inner_fillet_radius=1.5,
    pocket_width=7.0,
    pocket_length=30.0,
    pocket_offset_from_end=10.0,
    pocket_depth=10.0,
    mount_hole_diameter=5.0,
    hole_margin=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
