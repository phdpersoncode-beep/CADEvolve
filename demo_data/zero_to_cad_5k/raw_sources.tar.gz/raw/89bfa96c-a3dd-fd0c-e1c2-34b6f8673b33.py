import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        total_width = m.leg_thickness + m.horizontal_length
        total_height = m.leg_thickness + m.vertical_height
        pts = [
            (0, 0),
            (m.leg_thickness, 0),
            (m.leg_thickness, m.vertical_height),
            (m.leg_thickness + m.horizontal_length, m.vertical_height),
            (m.leg_thickness + m.horizontal_length, m.vertical_height + m.leg_thickness),
            (0, m.vertical_height + m.leg_thickness),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.bracket_thickness)
            .translate((-total_width/2, -total_height/2, 0))
        )
        chamfered = base.edges().chamfer(m.chamfer_size)
        # Back-side pocket to reduce weight and add complexity
        pocket = (
            chamfered.faces("<Z")
            .workplane()
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        part = pocket
        x_center = -m.horizontal_length/2 + m.leg_thickness/2
        start_y = -m.vertical_height/2 + m.hole_offset
        part = (
            part.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(x_center, start_y)
            .rarray(0, m.hole_spacing, 1, 5)
            .hole(m.clearance_hole_diameter)
        )
        self.model = part

measures = Measures(
    leg_thickness=10.0,
    vertical_height=60.0,
    horizontal_length=80.0,
    bracket_thickness=8.0,
    chamfer_size=1.0,
    pocket_width=30.0,
    pocket_height=20.0,
    pocket_depth=4.0,
    clearance_hole_diameter=4.0,
    hole_spacing=12.0,
    hole_offset=10.0,
)

result = LBracket(cq.Workplane("XY"), measures).model