import cadquery as cq
import math
from types import SimpleNamespace as Measures

m = Measures(
    chord_width = 50.0,
    block_depth = 12.0,
    block_height = 15.0,
    outer_diameter = 100.0,
    chamfer_size = 2.0,
    hole_diameter = 4.0,
    blind_depth = 8.0,
    rows = 2,
    columns = 3,
    row_spacing = 12.0,
    column_spacing = 15.0,
)

m.outer_radius = 0.5 * m.outer_diameter
m.inner_radius = m.outer_radius - m.block_depth
m.arc_center_angle = math.degrees(math.acos((2 * m.inner_radius**2 - m.chord_width**2) / (2 * m.inner_radius**2)))
m.arc_secant_angle = 0.5 * (180.0 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.chord_width, 0.0), m.inner_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_depth, m.block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_size)
    .faces(">Z")
    .workplane()
    .rarray(m.column_spacing, m.row_spacing, m.columns, m.rows, center=True)
    .hole(m.hole_diameter, depth=m.blind_depth)
)
