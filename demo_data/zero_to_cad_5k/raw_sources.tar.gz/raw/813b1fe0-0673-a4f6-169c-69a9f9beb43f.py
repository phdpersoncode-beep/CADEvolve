import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # L shape profile
        self.model = (
            self.model
            .polyline([
                (0, 0),
                (m.long_leg_length, 0),
                (m.long_leg_length, m.bracket_thickness),
                (m.bracket_thickness, m.bracket_thickness),
                (m.bracket_thickness, m.short_leg_height),
                (0, m.short_leg_height),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        # Flange on short leg outer side
        flange = (
            cq.Workplane("XY")
            .box(m.bracket_thickness, m.short_leg_height, m.flange_height)
            .translate((m.bracket_thickness/2, m.short_leg_height/2, m.bracket_thickness + m.flange_height/2))
        )
        self.model = self.model.union(flange)
        # Keyway on short leg outer face (-X)
        self.model = (
            self.model
            .faces("<X")
            .workplane()
            .center(m.short_leg_height/2, 0)
            .rect(m.keyway_width, m.bracket_thickness)
            .cutBlind(m.keyway_depth)
        )
        # Holes pattern on long leg top face (>Z)
        self.model = (
            self.model
            .faces(">Z")
            .workplane()
            .center(m.long_leg_length - m.hole_offset, 0)
            .rarray(m.hole_spacing_x, m.hole_spacing_y, 2, 2)
            .hole(m.hole_diameter)
        )
        # Chamfer outer edges
        self.model = self.model.edges().chamfer(m.chamfer_size)

measures = Measures(
    long_leg_length=70.0,
    short_leg_height=40.0,
    bracket_thickness=8.0,
    flange_height=9.0,
    keyway_width=4.0,
    keyway_depth=6.0,
    hole_diameter=4.0,
    hole_spacing_x=20.0,
    hole_spacing_y=12.0,
    hole_offset=15.0,
    chamfer_size=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model