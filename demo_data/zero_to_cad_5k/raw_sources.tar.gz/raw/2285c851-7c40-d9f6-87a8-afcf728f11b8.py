import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
leg_length = 80.0
leg_height = 70.0
bracket_thickness = 10.0
extrude_depth = 10.0
inner_offset = bracket_thickness
hole_diameter = 5.0
cbore_diameter = 8.0
cbore_depth = 3.0
hole_spacing = 20.0
hole_rows = 2
hole_cols = 2
hole_offset_x = inner_offset + 10.0
hole_offset_y = leg_height - inner_offset - ((hole_rows-1)*hole_spacing)/2
chamfer_size = 1.0
rib_thickness = 3.0
rib_extension = bracket_thickness + 5.0

measures = Measures(
    leg_length=leg_length,
    leg_height=leg_height,
    bracket_thickness=bracket_thickness,
    extrude_depth=extrude_depth,
    inner_offset=inner_offset,
    hole_diameter=hole_diameter,
    cbore_diameter=cbore_diameter,
    cbore_depth=cbore_depth,
    hole_spacing=hole_spacing,
    hole_rows=hole_rows,
    hole_cols=hole_cols,
    hole_offset_x=hole_offset_x,
    hole_offset_y=hole_offset_y,
    chamfer_size=chamfer_size,
    rib_thickness=rib_thickness,
    rib_extension=rib_extension,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        # L profile sketch
        profile = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.bracket_thickness),
                (m.bracket_thickness, m.bracket_thickness),
                (m.bracket_thickness, m.leg_height),
                (0, m.leg_height),
                (0, 0)
            ])
            .close()
        )
        solid = profile.extrude(m.extrude_depth)
        solid = solid.edges().chamfer(m.chamfer_size)
        # Reinforcement rib on inner vertical face
        rib = (
            solid.faces('<<Y')
            .workplane()
            .center(m.bracket_thickness/2, m.rib_extension/2)
            .rect(m.rib_thickness, m.rib_extension)
            .extrude(m.extrude_depth)
        )
        solid = solid.union(rib)
        # Counterbore hole array on vertical leg top surface
        holes = (
            solid.faces('>Z')
            .workplane()
            .center(m.hole_offset_x, m.hole_offset_y)
            .rect(m.hole_spacing, m.hole_spacing, forConstruction=True)
            .vertices()
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.model = holes

result = LBracket(cq.Workplane('XY'), measures).model