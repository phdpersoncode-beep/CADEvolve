import cadquery as cq
from types import SimpleNamespace as Measures

class SupportBracket:
    def __init__(self, workplane, measures):
        self.wp = workplane
        self.m = measures
        self.build()

    def build(self):
        m = self.m
        outer = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_width, 0),
                (m.leg_width, m.leg_length + m.leg_width),
                (m.leg_length + m.leg_width, m.leg_length + m.leg_width),
                (m.leg_length + m.leg_width, m.leg_length + m.leg_width + m.leg_width),
                (0, m.leg_length + m.leg_width + m.leg_width),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        bracket = outer.fillet(m.fillet_radius).shell(-m.wall_thickness)
        vertical_holes = [
            (m.leg_width / 2, m.leg_length + m.leg_width - m.hole_offset - i * m.hole_spacing)
            for i in range(m.hole_count)
        ]
        horizontal_holes = [
            (m.leg_length + m.leg_width - m.hole_offset - i * m.hole_spacing, m.leg_width / 2)
            for i in range(m.hole_count)
        ]
        all_holes = vertical_holes + horizontal_holes
        bracket = (
            bracket.faces(">Z")
            .workplane()
            .pushPoints(all_holes)
            .cboreHole(m.hole_clearance_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.result = bracket

measures = Measures(
    leg_length=80.0,
    leg_width=20.0,
    thickness=10.0,
    wall_thickness=2.0,
    fillet_radius=2.0,
    hole_count=3,
    hole_spacing=22.0,
    hole_offset=15.0,
    hole_clearance_diameter=5.0,
    cbore_diameter=7.0,
    cbore_depth=2.0,
)

bracket_part = SupportBracket(cq.Workplane("XY"), measures)
result = bracket_part.result
