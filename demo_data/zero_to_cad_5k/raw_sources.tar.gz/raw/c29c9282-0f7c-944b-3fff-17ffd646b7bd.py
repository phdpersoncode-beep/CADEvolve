import cadquery as cq, math
plate_diameter = 90.0
plate_thickness = 8.0
bevel_distance = 1.0
hole_diameter = 6.0
countersink_angle = 82.0
hole_center_radius = 30.0
hole_count = 6
rib_width = 10.0
rib_height = 4.0
rib_offset = 5.0
hub_diameter = 20.0
hub_thickness = 2.0
rim_thickness = 5.0
rim_height = 2.0
pocket_diameter = 12.0
pocket_depth = 3.0
slot_width = 8.0
slot_length = 120.0
csk_depth = (hole_diameter/2.0)/math.tan(math.radians(countersink_angle/2.0))
base = (
    cq.Workplane('XY')
    .circle(plate_diameter/2.0)
    .extrude(plate_thickness)
)
base = (
    base
    .faces('>Z')
    .workplane()
    .polarArray(hole_center_radius, 0, 360, hole_count)
    .cskHole(hole_diameter, countersink_angle, csk_depth)
)
result = (
    base
    .faces('>Z')
    .workplane()
    .circle(hub_diameter/2.0)
    .extrude(hub_thickness)
)
rib_pts = [(rib_offset, rib_offset), (-rib_offset, rib_offset), (rib_offset, -rib_offset), (-rib_offset, -rib_offset)]
result = (
    result
    .faces('<Z')
    .workplane()
    .pushPoints(rib_pts)
    .rect(rib_width, rib_height)
    .extrude(-rib_height)
)
rim = (
    cq.Workplane('XY')
    .circle(plate_diameter/2.0)
    .circle((plate_diameter/2.0)-rim_thickness)
    .extrude(rim_height)
)
result = result.union(rim)
result = (
    result
    .faces('>Z')
    .workplane()
    .circle(pocket_diameter/2.0)
    .cutBlind(-pocket_depth)
)
result = (
    result
    .faces('>Z')
    .workplane()
    .rect(slot_length, slot_width)
    .rotate((0,0,0), (0,0,1), 45)
    .cutBlind(-plate_thickness)
)
result = (
    result
    .faces('>Z')
    .edges()
    .chamfer(bevel_distance)
)
