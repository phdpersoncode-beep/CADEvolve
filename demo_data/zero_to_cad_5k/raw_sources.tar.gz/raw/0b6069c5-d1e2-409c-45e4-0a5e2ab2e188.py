import cadquery as cq

base_length = 80.0
base_width = 50.0
base_thickness = 5.0
rib_margin = 5.0
rib_width = 30.0
rib_height = 8.0
rib_length = base_length - 2 * rib_margin
slot_width = 8.0
slot_depth = rib_height
chamfer_bottom = 0.5
fillet_vertical = 0.6
screw_dia = 4.0
screw_head_dia = 7.0
screw_head_depth = 2.0
screw_spacing_len = (rib_length - 10) / 2
screw_spacing_wid = (rib_width - 10) / 2

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges("<Z").chamfer(chamfer_bottom)
    .faces(">Z")
    .workplane()
    .box(rib_length, rib_width, rib_height, centered=(True, True, False), combine=True)
    .faces(">Z[1]")
    .workplane()
    .rect(slot_width, rib_width - 4.0)
    .cutBlind(-slot_depth)
    .edges("|Z").fillet(fillet_vertical)
    .faces(">Z")
    .workplane(offset=-0.2)
    .pushPoints([
        (-rib_length/2 + screw_spacing_len, -rib_width/2 + screw_spacing_wid),
        (0, -rib_width/2 + screw_spacing_wid),
        (rib_length/2 - screw_spacing_len, -rib_width/2 + screw_spacing_wid),
        (-rib_length/2 + screw_spacing_len, 0),
        (0, 0),
        (rib_length/2 - screw_spacing_len, 0),
        (-rib_length/2 + screw_spacing_len, rib_width/2 - screw_spacing_wid),
        (0, rib_width/2 - screw_spacing_wid),
        (rib_length/2 - screw_spacing_len, rib_width/2 - screw_spacing_wid)
    ])
    .cboreHole(screw_dia, screw_head_dia, screw_head_depth)
)
