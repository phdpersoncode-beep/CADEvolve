import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L shape via sketch with a fillet at the inner corner
        p0 = (0, 0)
        p1 = (m.horizontal_leg_length, 0)
        p2 = (m.horizontal_leg_length, m.bracket_thickness)
        p3 = (m.bracket_thickness, m.bracket_thickness)
        p4 = (m.bracket_thickness, m.bracket_thickness + m.fillet_radius)
        p5 = (m.fillet_radius, m.bracket_thickness + m.fillet_radius)
        arc_mid = (0, m.bracket_thickness + m.fillet_radius)
        arc_end = (0, m.bracket_thickness)
        base = (
            cq.Workplane("XY")
            .moveTo(*p0)
            .lineTo(*p1)
            .lineTo(*p2)
            .lineTo(*p3)
            .lineTo(*p4)
            .lineTo(*p5)
            .threePointArc(arc_mid, arc_end)
            .close()
            .extrude(m.bracket_thickness)
        )
        # Recessed pocket on the vertical leg front face (>Y)
        pocket = (
            base.faces('>Y')
            .workplane()
            .center(m.bracket_thickness / 2, m.vertical_leg_height / 2)
            .rect(m.bracket_thickness, m.pocket_width)
            .cutBlind(-m.pocket_depth)
        )
        # Through hole near the outer corner on the top face (>Z)
        result = (
            pocket.faces('>Z')
            .workplane()
            .center(m.horizontal_leg_length - m.hole_offset, m.hole_offset)
            .hole(m.hole_diameter)
        )
        self.model = result

# Parameter definitions (max dimension 100)
horizontal_leg_length = 80.0
vertical_leg_height = 80.0
bracket_thickness = 10.0
fillet_radius = 12.0
pocket_width = 30.0
pocket_depth = 6.0
hole_diameter = 5.0
hole_offset = 15.0

measures = Measures(
    horizontal_leg_length=horizontal_leg_length,
    vertical_leg_height=vertical_leg_height,
    bracket_thickness=bracket_thickness,
    fillet_radius=fillet_radius,
    pocket_width=pocket_width,
    pocket_depth=pocket_depth,
    hole_diameter=hole_diameter,
    hole_offset=hole_offset,
)

bracket = LBracket(cq.Workplane('XY'), measures)
result = bracket.model
