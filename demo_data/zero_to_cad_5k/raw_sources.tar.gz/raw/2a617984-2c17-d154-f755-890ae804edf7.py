import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.horiz_length, 0),
            (m.horiz_length, m.leg_width),
            (m.leg_width, m.leg_width),
            (m.leg_width, m.vert_length + m.leg_width),
            (0, m.vert_length + m.leg_width),
            (0, 0),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.thickness)
        )
        # Chamfer side edges (vertical) only
        chamfered = base.edges("|Z").chamfer(m.chamfer)
        # Pocket in horizontal leg
        pocketed = (
            chamfered.faces(">Z")
            .workplane()
            .center(m.horiz_length - m.pocket_offset - m.pocket_width/2, m.leg_width/2)
            .rect(m.pocket_width, m.pocket_depth)
            .cutBlind(-m.thickness)
        )
        # Clearance hole in vertical leg
        final = (
            pocketed.faces(">Z")
            .workplane()
            .center(m.leg_width/2, m.vert_length/2 + m.leg_width/2)
            .hole(m.clearance_hole_diameter)
        )
        self.model = final

measures = Measures(
    horiz_length=60.0,
    vert_length=50.0,
    leg_width=20.0,
    thickness=5.0,
    clearance_hole_diameter=6.0,
    chamfer=4.0,
    pocket_offset=10.0,
    pocket_width=15.0,
    pocket_depth=10.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
