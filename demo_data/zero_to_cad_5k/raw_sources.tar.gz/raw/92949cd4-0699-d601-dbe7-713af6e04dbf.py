import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        l_profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.base_length, 0)
            .lineTo(m.base_length, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.upright_height)
            .lineTo(0, m.upright_height)
            .close()
        )
        body = l_profile.extrude(m.thickness)
        body = (
            body.edges()
            .filter(lambda e: abs(e.Center().x - m.thickness) < 0.01 and abs(e.Center().y - m.thickness) < 0.01)
            .fillet(m.fillet_radius)
        )
        pocket = (
            cq.Workplane("XY")
            .moveTo(m.thickness, m.thickness)
            .rect(m.pocket_width, m.pocket_width)
            .extrude(-m.thickness)
        )
        body = body.cut(pocket)
        body = body.edges("<<Z").chamfer(m.chamfer_distance)
        hole_positions = [
            (m.base_length / 4, m.thickness / 2),
            (3 * m.base_length / 4, m.thickness / 2),
            (m.thickness / 2, m.upright_height / 3),
            (m.thickness / 2, 2 * m.upright_height / 3),
        ]
        body = (
            body.faces(">Z")
            .workplane()
            .pushPoints(hole_positions)
            .cboreHole(m.hole_clearance, m.hole_cbore_diameter, m.hole_cbore_depth)
        )
        rib = (
            cq.Workplane("XY")
            .moveTo(m.base_length / 2, m.thickness / 2)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.thickness)
        )
        body = body.union(rib)
        self.model = body

measures = Measures(
    base_length=70.0,
    upright_height=30.0,
    thickness=5.0,
    pocket_width=10.0,
    fillet_radius=1.5,
    chamfer_distance=0.5,
    hole_clearance=4.0,
    hole_cbore_diameter=6.0,
    hole_cbore_depth=2.0,
    rib_width=10.0,
    rib_height=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model