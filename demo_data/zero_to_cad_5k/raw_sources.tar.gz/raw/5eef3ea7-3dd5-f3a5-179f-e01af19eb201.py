import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.vertical_leg_length)
            .lineTo(0, m.vertical_leg_length)
            .close()
            .extrude(m.bracket_thickness)
        )
        # Central gusset (triangular reinforcement)
        gusset = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.gusset_width, 0)
            .lineTo(0, m.gusset_width)
            .close()
            .extrude(m.bracket_thickness)
        )
        # Combine base and gusset
        solid = base.union(gusset)
        # Through holes on horizontal arm
        hx1 = m.hole_offset_from_corner
        hx2 = m.hole_offset_from_corner + m.hole_spacing
        # Through holes on vertical arm
        vy1 = m.hole_offset_from_corner
        vy2 = m.hole_offset_from_corner + m.hole_spacing
        solid = (
            solid
            .faces(">Z")
            .workplane()
            .pushPoints([
                (hx1, m.leg_width / 2),
                (hx2, m.leg_width / 2),
                (m.leg_width / 2, vy1),
                (m.leg_width / 2, vy2),
            ])
            .hole(m.hole_diameter)
        )
        # Fillet interior corner (re‑entrant edge)
        solid = solid.edges("<X and <Y and |Z").fillet(m.interior_fillet_radius)
        # Small chamfer on outer edges for safety
        solid = solid.edges("((>X and |Z) or (>Y and |Z))").chamfer(m.chamfer_distance)
        self.model = solid

# Define parameters respecting max dimension 100 units
measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=80.0,
    leg_width=10.0,
    bracket_thickness=8.0,
    gusset_width=12.0,
    hole_diameter=5.0,
    hole_offset_from_corner=20.0,
    hole_spacing=30.0,
    interior_fillet_radius=2.0,
    chamfer_distance=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model