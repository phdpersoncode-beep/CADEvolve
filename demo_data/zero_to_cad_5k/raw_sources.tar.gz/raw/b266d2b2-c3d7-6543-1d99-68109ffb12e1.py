import cadquery as cq
import math
from types import SimpleNamespace as Measures

m = Measures(
    linear_width=60.0,
    depth=12.0,
    height=12.0,
    arc_outer_diameter=100.0,
    chamfer=0.8,
    boss_diameter=20.0,
    boss_height=8.0,
    blind_hole_diameter=4.2,
    blind_hole_depth=6.0,
    mounting_hole_diameter=5.0,
    mounting_hole_offset=15.0
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = math.degrees(math.acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

swept = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer)
    .edges(">Z")
    .chamfer(m.chamfer)
)

# Boss on top surface
boss = (
    swept.faces(">Z").workplane()
    .center(0, 0)
    .circle(m.boss_diameter / 2)
    .extrude(m.boss_height)
)

# Combine base and boss
base = swept.union(boss)

# Mounting holes on top surface, placed symmetrically about center
mounting = (
    base.faces(">Z").workplane()
    .center(-m.mounting_hole_offset, 0)
    .hole(m.mounting_hole_diameter)
    .center(2 * m.mounting_hole_offset, 0)
    .hole(m.mounting_hole_diameter)
)

# Blind tapped hole in boss (centered)
result = (
    mounting.faces(">Z").workplane()
    .center(0, 0)
    .hole(m.blind_hole_diameter, depth=m.blind_hole_depth)
)
