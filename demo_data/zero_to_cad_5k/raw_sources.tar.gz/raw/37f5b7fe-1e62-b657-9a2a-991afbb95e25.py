import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.leg_height),
                (m.thickness, m.leg_height),
                (m.thickness, m.thickness),
                (m.leg_length, m.thickness),
                (m.leg_length, 0),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        base = base.edges("|Z").chamfer(m.chamfer_size)
        vertical_hole_positions = [
            (m.thickness / 2, m.vertical_hole_offset),
            (m.thickness / 2, m.vertical_hole_offset + m.vertical_hole_spacing),
        ]
        vertical_holes = (
            base.faces(">Z").workplane()
            .pushPoints(vertical_hole_positions)
            .cboreHole(
                m.vertical_hole_clearance,
                m.vertical_hole_cbore_diameter,
                m.vertical_hole_cbore_depth,
            )
        )
        boss_origin_x = m.thickness + m.boss_offset_x
        boss_origin_y = m.thickness / 2
        with_boss = (
            vertical_holes.faces(">Z").workplane()
            .move(boss_origin_x, boss_origin_y)
            .rect(m.boss_width, m.thickness)
            .cutBlind(-m.boss_depth)
        )
        boss_hole = (
            with_boss.faces(">Z").workplane()
            .move(boss_origin_x, boss_origin_y)
            .pushPoints([(0, 0)])
            .cboreHole(
                m.boss_hole_clearance,
                m.boss_hole_cbore_diameter,
                m.boss_hole_cbore_depth,
            )
        )
        gusset = (
            cq.Workplane("XY")
            .box(m.gusset_thickness, m.thickness, m.gusset_thickness)
            .translate((m.gusset_thickness / 2, m.thickness / 2, m.gusset_thickness / 2))
        )
        result = boss_hole.union(gusset)
        self.model = result

measures = Measures(
    leg_height=80.0,
    leg_length=70.0,
    thickness=8.0,
    vertical_hole_spacing=50.0,
    vertical_hole_offset=15.0,
    vertical_hole_clearance=5.5,
    vertical_hole_cbore_diameter=7.0,
    vertical_hole_cbore_depth=3.0,
    boss_width=30.0,
    boss_depth=4.0,
    boss_offset_x=10.0,
    boss_hole_clearance=4.5,
    boss_hole_cbore_diameter=6.0,
    boss_hole_cbore_depth=2.0,
    gusset_thickness=4.0,
    chamfer_size=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model