import cadquery as cq

plate_length = 100.0
plate_width = 60.0
plate_thickness = 10.0
wall_thickness = 2.0
groove_width = 40.0
groove_depth = 8.0
chamfer_distance = 0.5

rib_count = 3
rib_width = 4.0
rib_height = groove_depth - wall_thickness
rib_spacing = plate_length / (rib_count + 1)

hole_count = 4
hole_diameter = 3.0
hole_spacing = plate_length / (hole_count + 1)
hole_depth = groove_depth - wall_thickness

base = cq.Workplane("XY").box(plate_length, plate_width, plate_thickness, centered=(True, True, False))

groove = (base
          .faces(">Z")
          .workplane()
          .polyline([(-groove_width/2, 0), (0, -groove_depth), (groove_width/2, 0)])
          .close()
          .cutBlind(-groove_depth)
          .edges("|Z and <<X")
          .chamfer(chamfer_distance))

ribs = (cq.Workplane("XY")
        .workplane(offset=plate_thickness - groove_depth)
        .rarray(rib_spacing, 0, rib_count, 1)
        .rect(rib_width, groove_width - 2*wall_thickness)
        .extrude(rib_height))

groove_with_ribs = groove.union(ribs)

holes = (groove_with_ribs
         .faces(">Z")
         .workplane()
         .rarray(hole_spacing, 0, hole_count, 1)
         .hole(hole_diameter, depth=hole_depth))

result = holes