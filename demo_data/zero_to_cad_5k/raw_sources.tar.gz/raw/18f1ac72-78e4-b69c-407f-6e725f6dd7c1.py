import cadquery as cq

plate_length = 100.0
plate_width = 100.0
plate_thickness = 8.0
rib_width = 5.0
rib_height = 2.0
hole_diameter = 6.0
hole_depth = 4.0
hole_rows = 2
hole_cols = 5
hole_spacing_x = 16.0
hole_spacing_y = 12.0
edge_chamfer = 0.5

base = cq.Workplane("XY").rect(plate_length, plate_width).extrude(plate_thickness)

rib = (
    cq.Workplane("XY", origin=(0, 0, plate_thickness))
    .rect(plate_length, plate_width)
    .extrude(rib_height)
    .faces(">Z")
    .workplane()
    .rect(plate_length - 2 * rib_width, plate_width - 2 * rib_width)
    .cutBlind(rib_height)
)

combined = base.union(rib)

pts = []
start_x = -((hole_cols - 1) * hole_spacing_x) / 2
start_y = -((hole_rows - 1) * hole_spacing_y) / 2
for i in range(hole_cols):
    for j in range(hole_rows):
        pts.append((start_x + i * hole_spacing_x, start_y + j * hole_spacing_y))

hole_wp = combined.faces(">Z").workplane()
hole_wp = hole_wp.pushPoints(pts).circle(hole_diameter / 2).cutBlind(hole_depth)

result = hole_wp.edges("|Z").chamfer(edge_chamfer)
