import cadquery as cq
import math

flange_width = 60.0
flange_length = 80.0
flange_thickness = 8.0
taper_length = 30.0
taper_angle_deg = 30.0
hole_diameter = 6.0
hole_spacing = 20.0
hole_offset_y = 30.0
hole_depth = 5.0
chamfer_size = 1.0
rib_thickness = 4.0
rib_width = 30.0
rib_offset = 5.0

taper_angle_rad = math.radians(taper_angle_deg)
taper_rise = taper_length * math.tan(taper_angle_rad)

base = (
    cq.Workplane("XY")
    .polyline([
        (0, 0),
        (flange_width, 0),
        (flange_width, flange_length),
        (flange_width + taper_length, flange_length + taper_rise),
        (0, flange_length),
    ])
    .close()
)
result = base.extrude(flange_thickness)

rib_start_x = (flange_width - rib_width) / 2
rib = (
    cq.Workplane("XY")
    .center(rib_start_x + rib_width/2, rib_offset)
    .rect(rib_width, rib_thickness)
    .extrude(flange_thickness)
)
result = result.union(rib)

for x_offset in [-hole_spacing, 0, hole_spacing]:
    result = (
        result.faces(">Z")
        .workplane()
        .center(x_offset, hole_offset_y)
        .hole(hole_diameter, depth=hole_depth)
    )

result = result.edges("|Z").filter(lambda e: e.Center().x > flange_width).chamfer(chamfer_size)
