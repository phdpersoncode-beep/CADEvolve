import cadquery as cq

blade_chord = 20.0
naca_thickness = 0.12
hub_radius = 15.0
hub_length = 6.0
mount_hole_dia = 4.0
tip_radius = 45.0
sweep_z_offset = 10.0
fillet_radius = 1.0
balance_pocket_depth = 3.0
balance_pocket_width = 4.0
balance_pocket_length = 6.0

n_points = 31

def naca_airfoil_points(chord, t, n):
    pts = []
    for i in range(n):
        x = chord * i / (n - 1)
        yt = 5 * t * chord * (
            0.2969 * (x / chord) ** 0.5
            - 0.1260 * (x / chord)
            - 0.3516 * (x / chord) ** 2
            + 0.2843 * (x / chord) ** 3
            - 0.1015 * (x / chord) ** 4
        )
        pts.append((x, yt))
    upper = pts
    lower = [(x, -y) for x, y in reversed(pts)]
    return upper + lower

airfoil_pts = naca_airfoil_points(blade_chord, naca_thickness, n_points)

start = (hub_radius, 0, 0)
mid = ((hub_radius + tip_radius) / 2, 0, sweep_z_offset)
end = (tip_radius, 0, 0)

path = (cq.Workplane('XZ')
        .spline([start, mid, end])
        .wire())

blade = (cq.Workplane('XY')
         .polyline(airfoil_pts)
         .close()
         .sweep(path, isFrenet=True, makeSolid=True))

hub = (cq.Workplane('YZ')
       .circle(hub_radius)
       .extrude(hub_length)
       .hole(mount_hole_dia)
       .translate((-hub_length/2, 0, 0)))

part = hub.union(blade)

pocket = (cq.Workplane('XY')
          .rect(balance_pocket_width, balance_pocket_length)
          .extrude(balance_pocket_depth)
          .translate((tip_radius - balance_pocket_depth/2, 0, 0)))

part = part.cut(pocket)

part = part.edges().fillet(fillet_radius)

result = part