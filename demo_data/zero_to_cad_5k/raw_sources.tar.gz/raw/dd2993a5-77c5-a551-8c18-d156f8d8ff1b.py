import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

params = Measures(
    linear_width=60.0,
    depth=15.0,
    height=20.0,
    outer_diameter=90.0,
    pocket_width=30.0,
    pocket_length=40.0,
    pocket_depth=3.0,
    through_hole_diameter=6.0,
    fillet_vertical=2.0,
    fillet_top=1.5
)

params.outer_radius = 0.5 * params.outer_diameter
params.inner_diameter = params.outer_diameter - params.depth
params.inner_radius = 0.5 * params.inner_diameter
params.center_angle = degrees(
    acos((2 * params.inner_radius**2 - params.linear_width**2) / (2 * params.inner_radius**2))
)
params.secant_angle = 0.5 * (180.0 - params.center_angle)

arc_path = (
    cq.Workplane('XY')
    .radiusArc((params.linear_width, 0.0), params.inner_radius)
    .wire()
)

block = (
    cq.Workplane('XY')
    .transformed(rotate=(90, -params.secant_angle, 0))
    .rect(params.depth, params.height)
    .sweep(arc_path, transition='round')
    .edges('|Z')
    .fillet(params.fillet_vertical)
    .edges('>Z')
    .fillet(params.fillet_top)
)

pocketed = (
    block
    .faces('>Z')
    .workplane()
    .center(0, -params.linear_width/2 + params.depth/2)
    .rect(params.pocket_width, params.pocket_length)
    .extrude(-params.pocket_depth, combine='cut')
    .center(0, -params.pocket_length/2 + params.pocket_depth/2)
    .circle(params.pocket_width/4)
    .cutBlind(-params.pocket_depth)
)

result = (
    pocketed
    .faces('>Z')
    .workplane()
    .center(0, 0)
    .hole(params.through_hole_diameter)
)
