import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, ms):
        self.wp = wp
        self.ms = ms
        self.build()

    def build(self):
        m = self.ms
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg, 0),
                (m.horizontal_leg, m.leg_width),
                (m.leg_width, m.leg_width),
                (m.leg_width, m.vertical_leg),
                (0, m.vertical_leg),
                (0, 0),
            ])
            .close()
        )
        solid = base.extrude(m.thickness)
        pocket = (
            solid.faces(">Z")
            .workplane()
            .move(m.recess_offset_x, m.recess_offset_y)
            .rect(m.recess_width, m.recess_length, centered=False)
            .cutBlind(-m.recess_depth)
        )
        hole_points = [(0, m.hole_bottom_offset + i * m.hole_spacing) for i in range(3)]
        holes = (
            pocket.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints(hole_points)
            .hole(m.hole_diameter)
        )
        result = holes
        result = result.faces(">X").edges().chamfer(m.chamfer)
        result = result.faces(">Y").edges().chamfer(m.chamfer)
        self.result = result

measures = Measures(
    vertical_leg=70.0,
    horizontal_leg=80.0,
    leg_width=12.0,
    thickness=10.0,
    recess_width=30.0,
    recess_length=20.0,
    recess_depth=4.0,
    recess_offset_x=10.0,
    recess_offset_y=6.0,
    hole_diameter=5.0,
    hole_spacing=20.0,
    hole_bottom_offset=15.0,
    chamfer=2.0,
)

bracket = LBracket(cq.Workplane("XY"), measures)
result = bracket.result
