import cadquery as cq
from types import SimpleNamespace as Measures
overall_width = 80.0
vertical_height = 80.0
leg_width = 20.0
thickness = 10.0
hole_diameter = 5.5
chamfer_distance = 1.0
slot_width = 12.0
slot_length = 40.0
hole_spacing = (vertical_height - 2 * leg_width) / 6
base = (
    cq.Workplane('XY')
    .polyline([
        (0, 0),
        (overall_width, 0),
        (overall_width, leg_width),
        (leg_width, leg_width),
        (leg_width, vertical_height),
        (0, vertical_height),
        (0, 0)
    ])
    .close()
    .extrude(thickness)
)
chamfered = base.edges().chamfer(chamfer_distance)
with_holes = (
    chamfered
    .faces('>X')
    .workplane()
    .move(0, -vertical_height / 2 + leg_width + hole_spacing / 2)
    .rarray(0, hole_spacing, 1, 7)
    .hole(hole_diameter)
)
with_slot = (
    with_holes
    .faces('>Y')
    .workplane(centerOption='CenterOfBoundBox')
    .rect(slot_length, slot_width)
    .cutBlind(thickness)
)
result = with_slot
