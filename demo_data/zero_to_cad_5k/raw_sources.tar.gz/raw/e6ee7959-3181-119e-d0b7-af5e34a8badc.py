import cadquery as cq

# Core dimensions (max 100 units)
bracket_length = 80.0
bracket_height = 40.0
base_thickness = 8.0
wall_thickness = 2.0
rib_width = 15.0
rib_height = 20.0
rib_thickness = 4.0
slot_width = 8.0
slot_length = 30.0
slot_depth = 6.0
slot_spacing = 20.0
chamfer_size = 0.5
pocket_width = 20.0
pocket_height = 15.0
pocket_depth = wall_thickness * 0.8

# Base rectangular block
base = (
    cq.Workplane("XY")
    .rect(bracket_length, bracket_height)
    .extrude(base_thickness)
)

# Thin-walled shell
shelled = base.shell(-wall_thickness)

# Reinforcing rib on +X outer face
rib = (
    shelled.faces(">X")
    .workplane()
    .center(0, 0)
    .rect(rib_width, rib_height)
    .extrude(rib_thickness)
)

assembly = shelled.union(rib)

# Shallow pocket on front face
assembly = (
    assembly.faces("<Y")
    .workplane()
    .center(0, 0)
    .rect(pocket_width, pocket_height)
    .cutBlind(pocket_depth)
)

# Two blind slots on +X side
assembly = (
    assembly.faces(">X")
    .workplane()
    .center(-slot_spacing / 2, 0)
    .rect(slot_width, slot_length)
    .cutBlind(slot_depth)
)
assembly = (
    assembly.faces(">X")
    .workplane()
    .center(slot_spacing / 2, 0)
    .rect(slot_width, slot_length)
    .cutBlind(slot_depth)
)

# Chamfer on top perimeter edges for safety
assembly = assembly.faces(">Z").edges().chamfer(chamfer_size)

result = assembly