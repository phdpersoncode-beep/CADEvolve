import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    plate_width=80.0,
    plate_depth=40.0,
    base_thickness=5.0,
    step_height=10.0,
    step_width=60.0,
    step_depth=30.0,
    hole_diameter=6.0,
    countersink_diameter=12.0,
    countersink_angle=82.0,
    chamfer_distance=1.0,
    rib_thickness=2.0,
    rib_width=10.0,
    rib_spacing=15.0
)

base = (
    cq.Workplane("XY")
    .box(m.plate_width, m.plate_depth, m.base_thickness)
    .translate((0, 0, 0.5 * m.base_thickness))
)

step = (
    cq.Workplane("XY")
    .box(m.step_width, m.step_depth, m.step_height)
    .translate((0, 0, m.base_thickness + 0.5 * m.step_height))
)

plate = base.union(step)

# Countersunk hole centered on step
plate = (
    plate
    .faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .cskHole(m.hole_diameter, m.countersink_diameter, m.countersink_angle, depth=m.step_height)
)

# Chamfer vertical perimeter edges
plate = (
    plate
    .edges("|Z")
    .chamfer(m.chamfer_distance)
)

# Underside ribs for stiffness
rib_count = int((m.plate_width - 2 * m.rib_spacing) // m.rib_spacing) + 1
rib_positions = [(-m.plate_width/2 + m.rib_spacing + i*m.rib_spacing) for i in range(rib_count)]

ribs = cq.Workplane("XY")
for x in rib_positions:
    ribs = ribs.union(
        cq.Workplane("XY")
        .box(m.rib_thickness, m.rib_width, m.base_thickness)
        .translate((x, 0, 0.5 * m.base_thickness))
    )

result = plate.union(ribs)
