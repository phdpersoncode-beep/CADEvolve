import cadquery as cq

leaf_width = 80.0
leaf_height = 40.0
leaf_thickness = 5.0
boss_diameter = 12.0
boss_height = 8.0
slot_width = 8.0
slot_offset_from_edge = 5.0
slot_depth = leaf_thickness + 0.5
chamfer_distance = 0.8
rib_width = 6.0
rib_height = 3.0
rib_spacing = 12.0
hole_diameter = 4.0
hole_spacing = 30.0

# Base leaf plate
base = (
    cq.Workplane("XY")
    .rect(leaf_width, leaf_height)
    .extrude(leaf_thickness)
)

# Central cylindrical boss
boss = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(boss_diameter / 2)
    .extrude(boss_height)
)

part = base.union(boss)

# Side slot for cable routing on +X face
part = (
    part
    .faces(">X")
    .workplane()
    .center(slot_width / 2 + slot_offset_from_edge, 0)
    .rect(slot_width, leaf_height - 2 * slot_offset_from_edge)
    .cutBlind(-slot_depth)
)

# Mounting holes on back (-Z) face
part = (
    part
    .faces("-Z")
    .workplane()
    .pushPoints([(-hole_spacing/2, 0), (hole_spacing/2, 0)])
    .hole(hole_diameter)
)

# Reinforcement ribs on back face, protruding outward
rib_count_x = int((leaf_width - 2 * rib_spacing) // rib_spacing) + 1
rib_positions = []
for i in range(rib_count_x):
    x = -leaf_width/2 + rib_spacing + i * rib_spacing
    y = -leaf_height/2 + rib_spacing
    rib_positions.append((x, y))

ribs = (
    cq.Workplane("XY")
    .pushPoints(rib_positions)
    .rect(rib_width, rib_height)
    .extrude(-rib_height)
)

part = part.union(ribs)

# Chamfer outer edges for safety
result = part.edges().chamfer(chamfer_distance)
