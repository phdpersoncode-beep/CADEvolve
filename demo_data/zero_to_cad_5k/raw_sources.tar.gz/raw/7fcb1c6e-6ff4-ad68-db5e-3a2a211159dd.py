import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_len, 0),
                (m.horizontal_leg_len, m.leg_width),
                (m.leg_width, m.leg_width),
                (m.leg_width, m.vertical_leg_len + m.leg_width),
                (0, m.vertical_leg_len + m.leg_width),
            ])
            .close()
            .extrude(m.leg_width)
            .edges()
            .chamfer(m.chamfer_dist)
        )
        rib = (
            base.faces(">Z")
            .workplane()
            .center(m.horizontal_leg_len / 2, m.leg_width / 2)
            .rect(m.rib_length_x, m.rib_width_y)
            .extrude(m.rib_height)
        )
        result = (
            rib.faces(">Z")
            .workplane()
            .center(m.hole_offset, m.hole_offset)
            .hole(m.hole_diameter, depth=m.hole_depth)
        )
        self.model = result

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

measures = Measures(
    leg_width=20.0,
    vertical_leg_len=60.0,
    horizontal_leg_len=80.0,
    rib_height=15.0,
    rib_length_x=40.0,
    rib_width_y=20.0,
    chamfer_dist=6.0,
    hole_diameter=8.0,
    hole_depth=9.0,
    hole_offset=10.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
