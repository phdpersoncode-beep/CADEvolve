import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horiz_leg_length, 0),
                (m.horiz_leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vert_leg_height),
                (0, m.vert_leg_height),
                (0, 0),
            ])
            .close()
            .extrude(m.leg_width)
        )
        cavity = (
            base.faces(">Z").workplane()
            .center(
                m.leg_thickness + (m.horiz_leg_length - m.leg_thickness) / 2,
                m.leg_thickness / 2,
            )
            .rect(m.cavity_width, m.cavity_height)
            .cutBlind(-m.cavity_depth)
        )
        cbore = (
            cavity.faces(">Z").workplane()
            .center(m.leg_thickness/2, m.vert_leg_height/2)
            .cboreHole(m.cbore_diameter, m.cbore_diameter_cbore, m.cbore_depth)
        )
        mounting = (
            cbore.faces(">Z").workplane()
            .center(m.leg_thickness/2, m.vert_leg_height/2)
            .rect(m.vert_leg_height*0.6, m.leg_thickness*0.6, forConstruction=True)
            .vertices()
            .hole(m.mount_hole_diameter)
        )
        result = mounting.edges().chamfer(m.chamfer_distance)
        self.model = result

measures = Measures(
    horiz_leg_length=80.0,
    vert_leg_height=60.0,
    leg_thickness=10.0,
    leg_width=10.0,
    cavity_width=40.0,
    cavity_height=6.0,
    cavity_depth=4.0,
    cbore_diameter=9.0,
    cbore_diameter_cbore=13.0,
    cbore_depth=5.0,
    mount_hole_diameter=5.0,
    chamfer_distance=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model