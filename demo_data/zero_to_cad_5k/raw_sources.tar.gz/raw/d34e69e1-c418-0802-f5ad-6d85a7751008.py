import cadquery as cq

bracket_length = 80.0
bracket_width = 30.0
bracket_thickness = 8.0
rib_height = 12.0
rib_thickness = 4.0
hole_diameter = 5.0
hole_offset = 15.0
hole_spacing = 20.0
chamfer_size = 0.8

base = cq.Workplane('XY').rect(bracket_length, bracket_width).extrude(bracket_thickness)

rib = base.faces('>Z').workplane().rect(bracket_length, rib_thickness).extrude(rib_height)

solid = base.union(rib)

end_face = solid.faces('>X')

hole_positions = [
    (bracket_length/2 - hole_offset, -hole_spacing/2),
    (bracket_length/2 - hole_offset, 0),
    (bracket_length/2 - hole_offset, hole_spacing/2)
]

for x, y in hole_positions:
    end_face = end_face.workplane(centerOption='CenterOfMass').center(x - 0, y).hole(hole_diameter)

result = end_face.edges('|Z').chamfer(chamfer_size)
