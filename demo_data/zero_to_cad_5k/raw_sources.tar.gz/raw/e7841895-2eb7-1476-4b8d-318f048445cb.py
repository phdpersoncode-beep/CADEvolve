import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.thickness),
                (m.leg_width + m.inner_chamfer, m.thickness),
                (m.leg_width + m.inner_chamfer, m.thickness + m.inner_chamfer),
                (m.leg_width, m.thickness + m.inner_chamfer),
                (m.leg_width, m.vertical_length),
                (0, m.vertical_length),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        with_hole = (
            base.faces(">Z").workplane()
            .center(m.leg_width / 2, m.thickness + m.inner_chamfer + m.clearance_hole_offset)
            .hole(m.clearance_hole_diameter)
        )
        if m.add_rib:
            rib = (
                cq.Workplane("XY")
                .center(
                    (m.horizontal_length + m.leg_width) / 2,
                    m.thickness / 2,
                )
                .rect(
                    m.horizontal_length - m.leg_width - m.inner_chamfer,
                    m.leg_width / 2,
                )
                .extrude(m.thickness)
            )
            with_hole = with_hole.union(rib)
        self.model = with_hole

measures = Measures(
    horizontal_length=80.0,
    vertical_length=80.0,
    leg_width=15.0,
    thickness=3.0,
    inner_chamfer=4.0,
    clearance_hole_diameter=12.0,
    clearance_hole_offset=25.0,
    add_rib=True,
)

result = LBracket(cq.Workplane("XY"), measures).model
