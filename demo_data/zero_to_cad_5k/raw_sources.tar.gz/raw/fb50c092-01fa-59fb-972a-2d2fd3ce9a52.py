import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Create L shape by union of two rectangular legs
        vertical = (
            cq.Workplane("XY")
            .box(m.leg_width, m.leg_length_long, m.bracket_thickness)
            .translate((m.leg_width/2, m.leg_length_long/2, m.bracket_thickness/2))
        )
        horizontal = (
            cq.Workplane("XY")
            .box(m.leg_length_short + m.leg_width, m.leg_width, m.bracket_thickness)
            .translate((m.leg_width + (m.leg_length_short + m.leg_width)/2, m.leg_width/2, m.bracket_thickness/2))
        )
        base = vertical.union(horizontal)
        # Shell to achieve 3 mm wall thickness
        shelled = base.shell(-m.shell_thickness)
        # Mounting holes after shell
        verts = []
        for i in range(m.hole_count_long):
            y = m.hole_offset_long + i * m.hole_spacing_long
            verts.append((m.leg_width/2, y))
        horiz = []
        for i in range(m.hole_count_short):
            x = m.leg_width + m.hole_offset_short + i * m.hole_spacing_short
            horiz.append((x, m.leg_width/2))
        drilled = shelled.faces('>Z').workplane().pushPoints(verts + horiz).hole(m.hole_diameter)
        # Reinforcing ribs
        rib_vert = (
            cq.Workplane("XY")
            .center(m.leg_width/2, m.leg_length_long/2)
            .polyline([(0, 0), (m.rib_width, 0), (0, m.rib_height)])
            .close()
            .extrude(m.rib_thickness)
        )
        rib_horiz = (
            cq.Workplane("XY")
            .center(m.leg_width + m.leg_length_short/2, m.leg_width/2)
            .polyline([(0, 0), (0, m.rib_width), (-m.rib_height, 0)])
            .close()
            .extrude(m.rib_thickness)
        )
        reinforced = drilled.union(rib_vert).union(rib_horiz)
        result = reinforced.edges().chamfer(m.chamfer)
        self.model = result

measures = Measures(
    leg_length_long=80.0,
    leg_length_short=50.0,
    leg_width=20.0,
    bracket_thickness=12.0,
    rib_width=5.0,
    rib_height=15.0,
    rib_thickness=6.0,
    hole_diameter=5.0,
    hole_spacing_long=30.0,
    hole_spacing_short=20.0,
    hole_offset_long=20.0,
    hole_offset_short=15.0,
    hole_count_long=2,
    hole_count_short=2,
    chamfer=0.5,
    shell_thickness=3.0,
)

result = LBracket(cq.Workplane("XY"), measures).model