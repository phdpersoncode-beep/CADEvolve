import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.leg_thickness, 0),
                (m.leg_thickness, m.leg_height - m.leg_thickness),
                (m.leg_thickness + m.leg_length, m.leg_height - m.leg_thickness),
                (m.leg_thickness + m.leg_length, m.leg_height),
                (0, m.leg_height),
            ])
            .close()
            .extrude(m.leg_thickness)
        )
        self.model = base
        outer_end_x = m.leg_thickness + m.leg_length
        hole_x1 = outer_end_x - m.mount_hole_offset_from_end
        hole_x2 = hole_x1 - m.mount_hole_spacing
        hole_y = m.leg_height - m.leg_thickness / 2
        self.model = (
            self.model.faces('>Z')
            .workplane()
            .pushPoints([(hole_x1, hole_y), (hole_x2, hole_y)])
            .hole(m.mount_hole_diameter)
        )
        dovetail = (
            cq.Workplane('YZ')
            .center(0, - (m.leg_height / 2 - m.dovetail_offset_from_top - m.dovetail_length / 2))
            .polyline([
                (0, -m.dovetail_bottom_width / 2),
                (0,  m.dovetail_bottom_width / 2),
                (m.dovetail_length,  m.dovetail_top_width / 2),
                (m.dovetail_length, -m.dovetail_top_width / 2),
            ])
            .close()
            .extrude(m.dovetail_depth)
        )
        self.model = self.model.cut(dovetail)
        self.model = self.model.edges('>X').chamfer(m.chamfer_size)
        self.model = self.model.edges('>Y').chamfer(m.chamfer_size)

measures = Measures(
    leg_thickness=8.0,
    leg_height=80.0,
    leg_length=60.0,
    dovetail_length=30.0,
    dovetail_depth=6.0,
    dovetail_top_width=12.0,
    dovetail_bottom_width=6.0,
    dovetail_offset_from_top=40.0,
    mount_hole_diameter=4.0,
    mount_hole_spacing=40.0,
    mount_hole_offset_from_end=15.0,
    chamfer_size=1.0,
)

result = LBracket(cq.Workplane('XY'), measures).model
