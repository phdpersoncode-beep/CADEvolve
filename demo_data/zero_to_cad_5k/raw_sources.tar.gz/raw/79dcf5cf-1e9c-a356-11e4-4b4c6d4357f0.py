import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_length, 0)
            .lineTo(m.horizontal_length, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.vertical_length)
            .lineTo(0, m.vertical_length)
            .close()
        )
        solid = profile.extrude(m.depth)
        solid = solid.edges("|Z and (not >X) and (not >Y)").fillet(m.fillet_radius)
        solid = solid.faces(">Y").workplane().center(m.thickness/2, m.thickness + m.vertical_length/2).hole(m.vertical_hole_diameter)
        slot_center_x = m.horizontal_length/2
        slot_center_y = m.thickness/2
        solid = solid.faces(">Y").workplane().center(slot_center_x, slot_center_y).rect(m.slot_width, m.slot_length).cutBlind(-m.depth)
        solid = solid.edges("|Z and (>X or >Y)").chamfer(m.chamfer_distance)
        self.model = solid

measures = Measures(
    horizontal_length=50.0,
    vertical_length=70.0,
    thickness=10.0,
    depth=12.0,
    fillet_radius=2.0,
    vertical_hole_diameter=6.0,
    slot_width=3.0,
    slot_length=20.0,
    chamfer_distance=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model