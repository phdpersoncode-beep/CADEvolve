import cadquery as cq

leaf_width = 70.0
leaf_height = 30.0
leaf_thickness = 5.0
cavity_width = 40.0
cavity_height = 15.0
cavity_depth = 2.0
hole_diameter = 2.0
hole_spacing_x = 20.0
hole_spacing_y = 10.0
edge_chamfer = 1.0
rib_height = 1.0
rib_width = 5.0
rib_spacing = 15.0

# Base plate
base = (
    cq.Workplane("XY")
    .rect(leaf_width, leaf_height)
    .extrude(leaf_thickness)
)

# Reinforcing ribs on top surface
rib_count = int((leaf_width - rib_spacing) // rib_spacing)
for i in range(rib_count):
    x_offset = -leaf_width/2 + rib_spacing + i * rib_spacing
    rib = (
        cq.Workplane("XY")
        .center(x_offset, 0)
        .rect(rib_width, leaf_thickness)
        .extrude(rib_height)
    )
    base = base.union(rib)

# Central recessed cavity
result = (
    base
    .faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .rect(cavity_width, cavity_height)
    .cutBlind(-cavity_depth)
)

# Four equally spaced holes in a grid pattern
result = (
    result
    .faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .rarray(hole_spacing_x, hole_spacing_y, 2, 2)
    .hole(hole_diameter)
)

# Beveled outer edge (chamfer)
result = (
    result
    .faces(">Z")
    .edges()
    .chamfer(edge_chamfer)
)
