import cadquery as cq
import math

outer_radius = 100.0
central_angle_deg = 100.0
central_angle_rad = math.radians(central_angle_deg)
wall_thickness = 15.0
block_height = 40.0
block_thickness = 30.0
slot_width = 30.0
slot_height = 20.0
edge_chamfer = 2.0

inner_radius = outer_radius - wall_thickness
linear_width = 2 * outer_radius * math.sin(central_angle_rad / 2)
secant_angle = 0.5 * (180.0 - central_angle_deg)

path = (
    cq.Workplane("XY")
    .radiusArc((linear_width, 0), outer_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -secant_angle, 0))
    .rect(block_thickness, block_height)
    .sweep(path, transition="round")
    .cut(cq.Workplane("XY").cylinder(block_thickness, inner_radius))
    .edges("|Z")
    .chamfer(edge_chamfer)
    .faces("<Z")
    .workplane()
    .center(0, 0)
    .rect(slot_width, slot_height)
    .cutBlind(-block_thickness)
)
