import cadquery as cq
from types import SimpleNamespace as Measures

vertical_leg_length = 60.0
horizontal_leg_length = 80.0
leg_thickness = 15.0
bracket_thickness = 8.0
pocket_width = 40.0
pocket_depth = 12.0
pocket_offset = 10.0
fillet_radius = 5.0
hole_diameter = 6.0
hole_spacing = 30.0
hole_edge_offset = 10.0

measures = Measures(
    vertical_leg_length=vertical_leg_length,
    horizontal_leg_length=horizontal_leg_length,
    leg_thickness=leg_thickness,
    bracket_thickness=bracket_thickness,
    pocket_width=pocket_width,
    pocket_depth=pocket_depth,
    pocket_offset=pocket_offset,
    fillet_radius=fillet_radius,
    hole_diameter=hole_diameter,
    hole_spacing=hole_spacing,
    hole_edge_offset=hole_edge_offset,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        self.model = (
            cq.Workplane("XY")
            .lineTo(m.leg_thickness, 0)
            .lineTo(m.leg_thickness, m.bracket_thickness)
            .lineTo(m.leg_thickness + m.horizontal_leg_length, m.bracket_thickness)
            .lineTo(m.leg_thickness + m.horizontal_leg_length, m.bracket_thickness + m.leg_thickness)
            .lineTo(m.leg_thickness, m.bracket_thickness + m.leg_thickness)
            .lineTo(m.leg_thickness, m.bracket_thickness + m.leg_thickness + m.vertical_leg_length)
            .lineTo(0, m.bracket_thickness + m.leg_thickness + m.vertical_leg_length)
            .close()
            .extrude(m.bracket_thickness)
        )
        self.model = (
            self.model.edges()
            .filter(lambda e: abs(e.Center().x - m.leg_thickness) < 0.01 and abs(e.Center().y - m.bracket_thickness) < 0.01)
            .fillet(m.fillet_radius)
        )
        self.model = (
            self.model.faces(">Y")
            .workplane()
            .center(m.leg_thickness + m.pocket_offset + m.pocket_width/2, m.bracket_thickness/2)
            .rect(m.pocket_width, m.bracket_thickness)
            .cutBlind(-m.pocket_depth)
        )
        self.model = (
            self.model.faces(">X")
            .workplane()
            .center(m.leg_thickness/2, m.bracket_thickness + m.leg_thickness + m.vertical_leg_length/2)
            .rarray(m.hole_spacing, 0, 2, 1)
            .hole(m.hole_diameter)
        )

result = LBracket(cq.Workplane("XY"), measures).model