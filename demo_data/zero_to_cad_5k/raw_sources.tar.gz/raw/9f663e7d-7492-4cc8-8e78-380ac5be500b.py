import cadquery as cq
import math
from types import SimpleNamespace as Measures

params = Measures(
    outer_diameter = 80.0,
    inner_diameter = 30.0,
    base_thickness = 5.0,
    rib_height = 2.0,
    rib_outer_diameter = 70.0,
    rib_inner_diameter = 40.0,
    central_hole_diameter = 12.0
)

p = params

washer = (
    cq.Workplane("XZ")
    .polyline([
        (p.outer_diameter/2, 0),
        (p.outer_diameter/2, p.base_thickness),
        (p.rib_outer_diameter/2, p.base_thickness),
        (p.rib_outer_diameter/2, p.base_thickness + 2.0),
        (p.rib_inner_diameter/2, p.base_thickness + 2.0),
        (p.rib_inner_diameter/2, p.base_thickness),
        (p.inner_diameter/2, p.base_thickness),
        (p.inner_diameter/2, 0)
    ])
    .close()
    .revolve()
)

result = washer
