import cadquery as cq

leg1_length = 80.0
leg2_length = 80.0
leg_width = 30.0
wall_thickness = 3.0
channel_depth = 20.0
fillet_radius = 4.0
sensor_hole_diameter = 8.0
sensor_counterbore_diameter = 14.0
sensor_counterbore_depth = 4.0
sensor_hole_depth = channel_depth - wall_thickness - 0.5
sensor_offset_along_leg = 20.0

outer = (
    cq.Workplane('XY')
    .polyline([
        (0, 0),
        (leg1_length, 0),
        (leg1_length, leg_width),
        (leg_width, leg_width),
        (leg_width, leg2_length),
        (0, leg2_length),
        (0, 0)
    ])
    .close()
    .extrude(channel_depth)
)

result = (
    outer
    .shell(-wall_thickness)
    .edges('|Z')
    .fillet(fillet_radius)
    .faces('>Z')
    .workplane()
    .center(leg1_length - sensor_offset_along_leg, leg_width/2)
    .cboreHole(sensor_hole_diameter, sensor_hole_depth, sensor_counterbore_diameter, sensor_counterbore_depth)
)
