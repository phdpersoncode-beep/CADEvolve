import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()

    def build(self):
        m = self.m
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.long_leg, 0),
                (m.long_leg, m.arm_thickness),
                (m.arm_thickness, m.arm_thickness),
                (m.arm_thickness, m.short_leg),
                (0, m.short_leg),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
        )
        # add 12 mm radius concave fillets at outer corners using cylindrical cuts
        corner_positions = [
            (0, 0),
            (m.long_leg, 0),
            (0, m.short_leg)
        ]
        for cx, cy in corner_positions:
            cutter = (
                cq.Workplane('XY')
                .center(cx, cy)
                .circle(m.fillet_radius)
                .extrude(m.thickness + 2)
            )
            base = base.cut(cutter)
        rib = (
            base.faces('>Z')
            .workplane()
            .center(m.arm_thickness/2, m.short_leg - m.rib_length/2)
            .rect(m.rib_width, m.rib_length)
            .extrude(m.rib_height)
        )
        bracket = base.union(rib)
        hole_start_x = m.long_leg - m.arm_thickness - ((m.hole_count - 1) * m.hole_spacing) / 2
        bracket = (
            bracket.faces('>Z')
            .workplane()
            .center(hole_start_x, m.arm_thickness/2)
            .rarray(m.hole_spacing, 0, m.hole_count, 1)
            .hole(m.hole_diameter)
        )
        self.model = bracket

measures = Measures(
    long_leg=80.0,
    short_leg=50.0,
    arm_thickness=20.0,
    thickness=8.0,
    fillet_radius=12.0,
    rib_height=5.0,
    rib_width=15.0,
    rib_length=30.0,
    hole_diameter=4.0,
    hole_spacing=12.0,
    hole_count=5
)

result = LBracket(cq.Workplane('XY'), measures).model