import cadquery as cq
from types import SimpleNamespace as Measures

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        c = m.chamfer_size
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_leg_length - c),
                (c, m.vertical_leg_length),
                (m.web_width, m.vertical_leg_length),
                (m.web_width + m.horizontal_leg_length - c, m.vertical_leg_length),
                (m.web_width + m.horizontal_leg_length, m.vertical_leg_length - c),
                (m.web_width + m.horizontal_leg_length, m.web_width),
                (m.web_width + m.horizontal_leg_length - c, 0),
                (m.horizontal_leg_length, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.web_thickness)
        )
        pocket_center_x = m.web_width + m.horizontal_leg_length / 2
        pocket_center_y = m.web_width / 2
        base = (
            base
            .faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .moveTo(pocket_center_x, pocket_center_y)
            .rect(m.pocket_width, m.web_width)
            .cutBlind(-m.pocket_depth)
        )
        base = (
            base
            .faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints([
                (m.web_width / 2, m.vertical_leg_length * 0.25),
                (m.web_width / 2, m.vertical_leg_length * 0.75)
            ])
            .cboreHole(m.hole_clearance, m.countersink_diameter, m.countersink_depth)
        )
        base = (
            base
            .faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints([
                (m.web_width + m.horizontal_leg_length * 0.25, m.web_width / 2),
                (m.web_width + m.horizontal_leg_length * 0.75, m.web_width / 2)
            ])
            .cboreHole(m.hole_clearance, m.countersink_diameter, m.countersink_depth)
        )
        self.model = base

measures = Measures(
    vertical_leg_length=60.0,
    horizontal_leg_length=80.0,
    web_width=6.0,
    web_thickness=6.0,
    chamfer_size=5.0,
    pocket_depth=6.0,
    pocket_width=30.0,
    hole_clearance=6.0,
    countersink_diameter=8.0,
    countersink_depth=2.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
