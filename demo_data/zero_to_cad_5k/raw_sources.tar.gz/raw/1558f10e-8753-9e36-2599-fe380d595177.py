import cadquery as cq
import math

# Parameters
outer_radius = 45.0
inner_radius = 20.0
shroud_height = 30.0
wall_thickness = 3.0
split_gap = 0.5
chamfer_size = 1.0
bolt_hole_dia = 4.0
num_bolts = 6
bolt_pattern_radius = 35.0
rib_dia = 10.0
rib_height = 10.0

# Create outer cylinder
outer = cq.Workplane('XY').circle(outer_radius).extrude(shroud_height)
# Create inner cylinder and cut to form hollow shroud
inner = cq.Workplane('XY').circle(inner_radius).extrude(shroud_height)
base = outer.cut(inner)
# Split the shroud with a thin slab to create two halves
split_slab = cq.Workplane('XY').box(split_gap, outer_radius * 4, shroud_height)
base = base.cut(split_slab)
# Chamfer edges on the mating faces (edges with normal in -X direction)
base = base.edges("<X").chamfer(chamfer_size)
# Bolt hole pattern on the top outer surface
bolt_points = [
    (bolt_pattern_radius * math.cos(math.radians(i * 360 / num_bolts)),
     bolt_pattern_radius * math.sin(math.radians(i * 360 / num_bolts)))
    for i in range(num_bolts)
]
base = (
    base.faces(">Z")
    .workplane()
    .pushPoints(bolt_points)
    .hole(bolt_hole_dia)
)
# Central reinforcement boss attached to inner wall
boss = (
    cq.Workplane('XY')
    .center(inner_radius - wall_thickness / 2, 0)
    .circle(rib_dia / 2)
    .extrude(rib_height)
    .translate((0, 0, shroud_height / 2 - rib_height / 2))
)
base = base.union(boss)
result = base