import cadquery as cq
leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 5.0
rib_width = 18.0
rib_height = 2.0
pin_diameter = 6.0
relief_hole_diameter = 4.0
relief_spacing_ratio = 0.4
chamfer_distance = 1.0
base = (cq.Workplane('XY')
        .rect(leaf_length, leaf_width)
        .extrude(leaf_thickness))
rib = (cq.Workplane('XY')
       .rect(leaf_length, rib_width)
       .extrude(rib_height, taper=-2))
result = base.union(rib)
result = result.faces('>Z').workplane().hole(pin_diameter)
result = (result.faces('>Z')
          .workplane()
          .rarray(xSpacing=leaf_length*relief_spacing_ratio, ySpacing=0, xCount=2, yCount=1)
          .hole(relief_hole_diameter))
result = (result.faces('<Z')
          .workplane()
          .rarray(xSpacing=leaf_length*relief_spacing_ratio, ySpacing=0, xCount=2, yCount=1)
          .hole(relief_hole_diameter))
result = result.edges('|Z').chamfer(chamfer_distance)
