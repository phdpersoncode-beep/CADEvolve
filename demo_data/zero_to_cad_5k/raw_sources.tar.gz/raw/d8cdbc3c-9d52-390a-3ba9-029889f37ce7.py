import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # vertical leg solid
        vertical = (
            cq.Workplane("XY")
            .box(m.vertical_leg_thickness, m.vertical_leg_length, m.bracket_thickness)
            .translate((m.vertical_leg_thickness/2, m.vertical_leg_length/2, 0))
        )
        # horizontal leg solid
        horizontal = (
            cq.Workplane("XY")
            .box(m.horizontal_leg_length, m.horizontal_leg_thickness, m.bracket_thickness)
            .translate((m.vertical_leg_thickness + m.horizontal_leg_length/2, m.horizontal_leg_thickness/2, 0))
        )
        # combine legs
        base = vertical.union(horizontal)
        # rounded outer edges
        filleted = base.edges("|Z").fillet(m.edge_fillet_radius)
        # pilot hole on horizontal leg
        piloted = (
            filleted.faces(">Z")
            .workplane()
            .center(m.vertical_leg_thickness + m.pilot_hole_offset, m.horizontal_leg_thickness/2)
            .hole(m.pilot_hole_diameter)
        )
        # relief cut on outer edge of horizontal leg
        relieved = (
            piloted.faces(">Z")
            .workplane()
            .center(
                m.vertical_leg_thickness + m.horizontal_leg_length - m.relief_offset - m.relief_width/2,
                m.horizontal_leg_thickness/2,
            )
            .rect(m.relief_width, m.relief_depth)
            .cutBlind(-m.relief_depth)
        )
        # mounting holes on vertical leg
        hole_points = [
            (m.vertical_leg_thickness/2, m.mount_hole_spacing * i) for i in range(1, m.mount_hole_count + 1)
        ]
        final = (
            relieved.faces(">Z")
            .workplane()
            .pushPoints(hole_points)
            .hole(m.mount_hole_diameter)
        )
        self.model = final

measures = Measures(
    vertical_leg_length=80.0,
    vertical_leg_thickness=10.0,
    horizontal_leg_length=60.0,
    horizontal_leg_thickness=10.0,
    bracket_thickness=8.0,
    edge_fillet_radius=1.0,
    pilot_hole_diameter=3.0,
    pilot_hole_offset=12.0,
    relief_width=15.0,
    relief_depth=5.0,
    relief_offset=5.0,
    mount_hole_diameter=4.0,
    mount_hole_spacing=20.0,
    mount_hole_count=3,
)

result = LBracket(cq.Workplane("XY"), measures).model
