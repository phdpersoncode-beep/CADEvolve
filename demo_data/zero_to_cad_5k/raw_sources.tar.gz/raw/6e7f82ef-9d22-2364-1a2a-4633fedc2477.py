import cadquery as cq
body_outer_dia = 60
body_length = 60
shoulder_outer_dia = 70
shoulder_length = 15
wall_thickness = 5
fillet_radius = 2
pilot_port_dia = 12
pilot_port_offset = 30
pilot_port_height = 40
pilot_port_depth = 20
gasket_seat_dia = 55
gasket_seat_depth = 5
outer_profile = (
    cq.Workplane('XZ')
    .moveTo(0, 0)
    .lineTo(body_outer_dia/2, 0)
    .lineTo(body_outer_dia/2, body_length)
    .lineTo(shoulder_outer_dia/2, body_length + shoulder_length)
    .lineTo(0, body_length + shoulder_length)
    .close()
)
body_solid = outer_profile.revolve()
base = body_solid.shell(-wall_thickness)
base = base.edges().fillet(fillet_radius)
port_cyl = cq.Solid.makeCylinder(pilot_port_dia/2, pilot_port_depth)
port_cyl = port_cyl.rotate((0,0,0), (0,1,0), 90)
port_cyl = port_cyl.translate((pilot_port_offset, pilot_port_height, 0))
base = base.cut(port_cyl)
base = base.faces('>Z').workplane().circle(gasket_seat_dia/2).cutBlind(gasket_seat_depth)
result = base