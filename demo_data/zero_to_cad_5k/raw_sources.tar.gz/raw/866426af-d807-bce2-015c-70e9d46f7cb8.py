import cadquery as cq

# Parameters (max dimension 100 units)
base_radius = 30.0
base_height = 10.0
rim_thickness = 5.0
rim_height = 8.0
screw_hole_diameter = 3.0
screw_hole_depth = 12.0
inner_hole_circle_radius = 15.0
outer_hole_circle_radius = 25.0
fillet_radius = 1.0
chamfer_dist = 0.5

# Build 2D profile on XZ plane for revolve
profile = (
    cq.Workplane("XZ")
    .moveTo(base_radius, 0)
    .lineTo(base_radius, base_height)
    .lineTo(base_radius + rim_thickness, base_height)
    .lineTo(base_radius + rim_thickness, base_height + rim_height)
    .lineTo(base_radius, base_height + rim_height)
    .close()
)

# Revolve profile and add features
result = (
    profile
    .revolve()
    .edges(">Z").fillet(fillet_radius)
    .edges("<Z").chamfer(chamfer_dist)
    .faces(">Z")
    .workplane()
    .polarArray(radius=inner_hole_circle_radius, count=8, startAngle=0, angle=45.0)
    .hole(screw_hole_diameter, screw_hole_depth)
    .workplane()
    .polarArray(radius=outer_hole_circle_radius, count=8, startAngle=0, angle=45.0)
    .hole(screw_hole_diameter, screw_hole_depth)
)
