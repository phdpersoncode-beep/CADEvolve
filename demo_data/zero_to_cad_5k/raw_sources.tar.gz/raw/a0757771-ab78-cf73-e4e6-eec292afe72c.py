import cadquery as cq
leaf_width = 50
leaf_height = 30
leaf_thickness = 8
pin_hole_diameter = 5
rib_count = 5
rib_width = 6
rib_height = 2
rib_thickness = 2
chamfer_dist = 0.8
rib_spacing = (leaf_width - rib_count * rib_width) / (rib_count + 1)
result = (
    cq.Workplane("XY")
    .rect(leaf_width, leaf_height)
    .extrude(leaf_thickness)
)
result = result.faces(">Z").workplane().hole(pin_hole_diameter)
rib_plane = result.faces(">Z").workplane().rarray(rib_spacing + rib_width, 0, rib_count, 1, center=True)
result = rib_plane.rect(rib_width, rib_height).extrude(rib_thickness).union(result)
result = result.faces(">Z").edges().chamfer(chamfer_dist)
