import cadquery as cq

# Parameters
channel_length = 80.0
outer_radius = 30.0
wall_thickness = 4.0
inner_radius = outer_radius - wall_thickness
ridge_height = 2.0
ridge_thickness = ridge_height
ridge_width = 6.0
ridge_pitch = 12.0
hole_diameter = 5.0
hole_offset_from_top = 15.0
chamfer_size = 0.8

# Base pipe channel via revolve
profile = (
    cq.Workplane("XZ")
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius, 0)
    .lineTo(outer_radius, channel_length)
    .lineTo(inner_radius, channel_length)
    .close()
)
channel = profile.revolve()

# Chamfer outer top edge of the pipe for safety
channel = channel.edges('>>Z[0]').chamfer(chamfer_size)

# Helical ridge using twist extrusion
turns = channel_length / ridge_pitch
twist_angle = 360.0 * turns
ridge_profile = (
    cq.Workplane("XY")
    .center(inner_radius + ridge_thickness/2, 0)
    .rect(ridge_thickness, ridge_width)
)
ridge = ridge_profile.twistExtrude(channel_length, twist_angle)

channel_with_ridge = channel.union(ridge)

# Discharge hole as a radial cut
hole_cylinder = (
    cq.Workplane("YZ")
    .center(0, channel_length - hole_offset_from_top)
    .circle(hole_diameter/2)
    .extrude(wall_thickness + 2)
    .translate((inner_radius + wall_thickness/2, 0, 0))
)
result = channel_with_ridge.cut(hole_cylinder)
