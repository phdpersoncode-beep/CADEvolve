import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (0, m.vertical_leg_length),
                (m.leg_thickness, m.vertical_leg_length),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness + m.horizontal_leg_length, m.leg_thickness),
                (m.leg_thickness + m.horizontal_leg_length, 0)
            ])
            .close()
            .extrude(m.leg_thickness)
        )
        rib_vert = (
            base.faces('<X')
            .workplane(centerOption='CenterOfBoundBox')
            .rect(m.rib_width, m.leg_thickness)
            .extrude(m.leg_thickness)
        )
        rib_horiz = (
            base.faces('<Y')
            .workplane(centerOption='CenterOfBoundBox')
            .rect(m.leg_thickness, m.rib_width)
            .extrude(m.leg_thickness)
        )
        solid = base.union(rib_vert).union(rib_horiz)
        solid = solid.edges().chamfer(m.chamfer_distance)
        solid = (
            solid.faces('>Z')
            .workplane()
            .center(m.leg_thickness / 2, m.vertical_hole_offset)
            .hole(m.clearance_hole_diameter)
        )
        for x_pos in [m.mount_offset, m.mount_offset + m.mount_spacing]:
            solid = (
                solid.faces('>Z')
                .workplane()
                .center(x_pos, m.leg_thickness / 2)
                .cboreHole(m.mount_hole_clearance, m.mount_cbore_diameter, m.mount_cbore_depth)
            )
        self.model = solid

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

measures = Measures(
    vertical_leg_length=70.0,
    horizontal_leg_length=80.0,
    leg_thickness=6.0,
    rib_width=30.0,
    chamfer_distance=0.8,
    clearance_hole_diameter=9.0,
    vertical_hole_offset=30.0,
    mount_offset=25.0,
    mount_spacing=40.0,
    mount_hole_clearance=5.0,
    mount_cbore_diameter=8.0,
    mount_cbore_depth=2.0,
)

result = cq.Workplane('XY').part(LBracket, measures)
