import cadquery as cq

length = 80.0
beam_height = 60.0
web_thickness = 6.0
flange_width = 40.0
flange_thickness = 8.0
fillet_radius = 2.0
boss_width = 20.0
boss_height = 10.0
boss_hole_dia = 4.0
hole_dia = 5.0
hole_spacing = 30.0
hole_count = 3

half_section_pts = [
    (0, -beam_height/2),
    (web_thickness/2, -beam_height/2),
    (web_thickness/2, beam_height/2 - flange_thickness),
    (flange_width/2, beam_height/2 - flange_thickness),
    (flange_width/2, beam_height/2),
    (0, beam_height/2),
    (0, -beam_height/2)
]

result = (
    cq.Workplane("XY")
    .polyline(half_section_pts)
    .close()
    .extrude(length)
    .faces(">Y")
    .edges()
    .fillet(fillet_radius)
    .faces("<Z")
    .workplane()
    .center(0, (beam_height/2 - flange_thickness/2))
    .rect(boss_width, boss_width)
    .extrude(boss_height)
    .faces("<Z")
    .workplane()
    .center(0, (beam_height/2 - flange_thickness/2 + boss_height/2))
    .hole(boss_hole_dia)
    .faces("<Y")
    .workplane(centerOption="CenterOfMass")
    .rarray(hole_spacing, 0, hole_count, 1)
    .hole(hole_dia)
)
