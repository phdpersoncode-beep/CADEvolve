import cadquery as cq

outer_diameter = 80.0
plate_thickness = 8.0
central_hole_diameter = 30.0
blind_hole_depth = 5.0
vent_hole_diameter = 8.0
vent_hole_radius = 30.0
emboss_diameter = 5.0
emboss_height = 2.0
emboss_grid_rows = 5
emboss_grid_cols = 5
emboss_spacing = 10.0
edge_chamfer = 1.0

# Base washer plate
base = (
    cq.Workplane("XY")
    .circle(outer_diameter / 2)
    .extrude(plate_thickness)
)

# Central blind hole (recessed, not through)
blind = (
    cq.Workplane("XY")
    .circle(central_hole_diameter / 2)
    .extrude(blind_hole_depth)
)
base = base.cut(blind)

# Four vent holes placed around the central blind hole
base = (
    base
    .faces(">Z")
    .workplane()
    .polarArray(count=4, startAngle=0, angle=360, radius=vent_hole_radius)
    .hole(vent_hole_diameter)
)

# Chamfer outer rim for safety
base = base.edges(">Z").chamfer(edge_chamfer)

# Surface embossments: grid of small cylindrical bosses
emboss = (
    base
    .faces(">Z")
    .workplane()
    .rarray(emboss_spacing, emboss_spacing, emboss_grid_cols, emboss_grid_rows, center=True)
    .circle(emboss_diameter / 2)
    .extrude(emboss_height)
)

result = base.union(emboss)
