import cadquery as cq

# Parameters
plate_diameter = 80.0
plate_thickness = 8.0
slot_width = 20.0
slot_height = 8.0
outer_radius = plate_diameter / 2.0
boss_diameter = 30.0
boss_height = 12.0
counterbore_diameter = 12.0
counterbore_depth = 6.0
through_hole_diameter = 6.0
mount_hole_diameter = 6.0
mount_spacing = 60.0
knurl_pitch = 5.0
knurl_rows = 6
knurl_columns = 6
knurl_depth = 1.0
knurl_overlap = 0.2

# Base washer plate with rectangular slot (composite sketch)
base_plate = (
    cq.Workplane("XY")
    .sketch()
    .circle(outer_radius)
    .slot(slot_width, slot_height, mode="s", angle=0)
    .finalize()
    .extrude(plate_thickness)
)

# Central boss created separately and fused to base
boss = (
    cq.Workplane("XY")
    .workplane(offset=plate_thickness)
    .circle(boss_diameter / 2.0)
    .extrude(boss_height)
)

assembled = base_plate.union(boss)

# Counterbore and through clearance hole on boss top
with_counterbore = (
    assembled
    .faces(">Z")
    .workplane()
    .hole(counterbore_diameter, depth=counterbore_depth)
    .hole(through_hole_diameter)
)

# Mounting holes through bottom of plate
with_mounts = (
    with_counterbore
    .faces("<Z")
    .workplane()
    .rarray(mount_spacing, 0, 2, 1, center=True)
    .hole(mount_hole_diameter)
)

# Top Z position of boss surface
top_z = plate_thickness + boss_height

# Generate knurl grid slightly penetrating the top surface
knurl_grid = (
    cq.Workplane("XY")
    .workplane(offset=top_z - knurl_overlap)
    .rarray(knurl_pitch, knurl_pitch, knurl_columns, knurl_rows, center=True)
    .rect(knurl_pitch * 0.7, knurl_pitch * 0.7)
    .extrude(knurl_depth + knurl_overlap)
)

# Mask to keep knurl within boss perimeter
mask = (
    cq.Workplane("XY")
    .workplane(offset=top_z)
    .circle(boss_diameter / 2.0 - knurl_pitch / 2.0)
    .extrude(knurl_depth + knurl_overlap)
)

knurl = knurl_grid.intersect(mask)

result = with_mounts.union(knurl)
