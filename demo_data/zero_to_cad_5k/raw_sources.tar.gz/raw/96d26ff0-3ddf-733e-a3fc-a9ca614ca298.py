import cadquery as cq
from types import SimpleNamespace as Measures

leg_length_long = 80.0
leg_length_short = 50.0
bracket_thickness = 10.0
bracket_height = 15.0
shell_thickness = 2.0
chamfer_size = 1.0
hole_clearance_diameter = 4.5
hole_edge_offset = 5.0
hole_count_per_leg = 3

measures = Measures(
    leg_length_long=leg_length_long,
    leg_length_short=leg_length_short,
    bracket_thickness=bracket_thickness,
    bracket_height=bracket_height,
    shell_thickness=shell_thickness,
    chamfer_size=chamfer_size,
    hole_clearance_diameter=hole_clearance_diameter,
    hole_edge_offset=hole_edge_offset,
    hole_count_per_leg=hole_count_per_leg,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.leg_length_long, 0),
            (m.leg_length_long, m.bracket_thickness),
            (m.bracket_thickness, m.bracket_thickness),
            (m.bracket_thickness, m.leg_length_short + m.bracket_thickness),
            (0, m.leg_length_short + m.bracket_thickness),
            (0, 0),
        ]
        solid = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.bracket_height)
        )
        solid = solid.shell(m.shell_thickness)
        solid = solid.edges("|Z").chamfer(m.chamfer_size)
        long_spacing = (m.leg_length_long - 2 * m.hole_edge_offset) / (m.hole_count_per_leg - 1)
        long_points = [
            (m.hole_edge_offset + i * long_spacing, m.bracket_thickness / 2)
            for i in range(m.hole_count_per_leg)
        ]
        short_spacing = (m.leg_length_short - 2 * m.hole_edge_offset) / (m.hole_count_per_leg - 1)
        short_points = [
            (m.bracket_thickness / 2, m.bracket_thickness + m.hole_edge_offset + i * short_spacing)
            for i in range(m.hole_count_per_leg)
        ]
        all_points = long_points + short_points
        solid = (
            solid.faces("+Z").first()
            .workplane()
            .pushPoints(all_points)
            .hole(m.hole_clearance_diameter)
        )
        self.model = solid

result = LBracket(cq.Workplane("XY"), measures).model