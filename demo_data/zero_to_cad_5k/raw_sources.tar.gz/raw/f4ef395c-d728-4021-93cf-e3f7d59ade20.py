import cadquery as cq

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # base profile
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_length + m.material_thickness, 0),
                (m.horizontal_leg_length + m.material_thickness, m.material_thickness),
                (m.material_thickness, m.material_thickness),
                (m.material_thickness, m.vertical_leg_length + m.material_thickness),
                (0, m.vertical_leg_length + m.material_thickness),
            ])
            .close()
            .extrude(m.material_thickness)
        )
        # clearance hole on outer vertical leg
        with_hole = (
            profile.faces(">X")
            .workplane()
            .center(m.horizontal_leg_length / 2, m.vertical_leg_length / 2)
            .hole(m.clearance_hole_diameter)
        )
        # slot on inner horizontal leg
        with_slot = (
            with_hole.faces("<Y")
            .workplane()
            .center(m.horizontal_leg_length / 2, m.material_thickness / 2)
            .rect(m.slot_length, m.slot_width)
            .cutBlind(-m.material_thickness)
        )
        # chamfer outer edges
        result = (
            with_slot.edges("|Z")
            .chamfer(m.chamfer_size)
        )
        self.result = result

# define measures
measures = cq.Workplane().newObject([])  # dummy placeholder

# actual measures using SimpleNamespace for convenience
from types import SimpleNamespace as Measures
measures = Measures(
    horizontal_leg_length=50.0,
    vertical_leg_length=70.0,
    material_thickness=5.0,
    clearance_hole_diameter=9.0,
    slot_width=4.0,
    slot_length=20.0,
    chamfer_size=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).result