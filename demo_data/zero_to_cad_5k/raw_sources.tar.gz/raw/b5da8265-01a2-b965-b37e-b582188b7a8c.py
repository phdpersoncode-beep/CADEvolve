import cadquery as cq
BS = cq.selectors.BoxSelector
outer_diameter = 80.0
inner_diameter = 30.0
gasket_thickness = 10.0
groove_width = 6.0
groove_depth = 2.0
vent_hole_diameter = 2.0
vent_hole_count = 12
vent_hole_radius = (outer_diameter/2 - groove_width/2) * 0.7
chamfer_size = 0.5
profile = (
    cq.Workplane('XY')
    .moveTo(outer_diameter/2, 0)
    .line(0, gasket_thickness)
    .line(-groove_width, 0)
    .line(0, -groove_depth)
    .line(-(inner_diameter/2 - groove_width), 0)
    .line(0, -gasket_thickness + groove_depth)
    .line(inner_diameter/2, 0)
    .close()
)
solid = profile.revolve()
solid = solid.edges(BS((-outer_diameter/2-0.1, -100, -100), (outer_diameter/2+0.1, 100, 100))).chamfer(chamfer_size)
solid = solid.faces('>Z').first().workplane().polarArray(radius=vent_hole_radius, count=vent_hole_count, angle=360, startAngle=0).hole(vent_hole_diameter)
result = solid