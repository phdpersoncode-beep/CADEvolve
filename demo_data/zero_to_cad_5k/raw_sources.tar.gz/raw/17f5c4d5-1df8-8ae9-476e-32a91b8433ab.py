import cadquery as cq

trough_length = 80.0
trough_width = 40.0
trough_height = 30.0
wall_thickness = 2.0
fillet_radius = 3.0
rib_thickness = 4.0
rib_height = 12.0
rib_spacing = 12.0
cable_hole_diameter = 6.0

base = (
    cq.Workplane("XY")
    .box(trough_length, trough_width, trough_height, centered=(True, True, False))
    .shell(-wall_thickness)
    .faces(">Z")
    .workplane()
    .rect(trough_length - 2 * wall_thickness, trough_width - 2 * wall_thickness)
    .cutBlind(-wall_thickness * 2)
    .edges("<Z")
    .fillet(fillet_radius)
)

rib_length = trough_width - 2 * wall_thickness
rib_profile = (
    cq.Workplane("XZ")
    .polyline([
        (0, 0),
        (rib_thickness, 0),
        (rib_thickness, rib_height - rib_thickness),
        (rib_thickness / 2, rib_height),
        (0, rib_height - rib_thickness),
    ])
    .close()
    .extrude(rib_length)
)

available_length = trough_length - 2 * wall_thickness
rib_count = int((available_length + rib_spacing) // rib_spacing)
first_x = -available_length / 2 + rib_spacing / 2
x_positions = [first_x + i * rib_spacing for i in range(rib_count)]

rib_instances = [rib_profile.translate((x, -rib_length / 2, wall_thickness)) for x in x_positions]

combined = base
for rib in rib_instances:
    combined = combined.union(rib)

final_part = (
    combined
    .faces(">Y")
    .workplane()
    .hole(cable_hole_diameter)
)

result = final_part