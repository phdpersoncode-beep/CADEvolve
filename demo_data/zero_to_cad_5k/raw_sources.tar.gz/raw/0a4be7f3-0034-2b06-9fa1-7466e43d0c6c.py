import cadquery as cq

# Parameters
bracket_outer_radius = 40.0
wall_thickness = 5.0
bracket_height = 30.0
countersink_diameter = 10.0
countersink_angle = 82.0
hole_diameter = 5.0
hole_spacing = 30.0
tab_width = 25.0
tab_height = 12.0
tab_depth = 4.0
tab_notch_radius = 3.0
rib_width = 6.0
rib_height = 15.0
rib_thickness = 3.0
chamfer_size = 1.0

# Base profile and revolve
profile = (
    cq.Workplane('XZ')
    .lineTo(bracket_outer_radius - wall_thickness, 0)
    .lineTo(bracket_outer_radius - wall_thickness, bracket_height)
    .lineTo(bracket_outer_radius, bracket_height)
    .lineTo(bracket_outer_radius, 0)
    .close()
)
body = profile.revolve()

# Chamfer all edges for safety
body = body.edges().chamfer(chamfer_size)

# Recessed rectangular tab on the end face (+Z)
body = (
    body.faces('>Z')
    .workplane()
    .rect(tab_width, tab_height)
    .cutBlind(-tab_depth)
)
# Circular notch inside the tab pocket
body = (
    body.faces('>Z')
    .workplane()
    .center(0, 0)
    .circle(tab_notch_radius)
    .cutBlind(-tab_depth)
)

# Countersunk mounting holes on the same end face
hole_positions = [(-hole_spacing/2, 0), (hole_spacing/2, 0)]
body = (
    body.faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .cskHole(hole_diameter, countersink_diameter, countersink_angle)
)

# Reinforcing rib attached to outer cylindrical surface
rib = (
    cq.Workplane('XY')
    .box(rib_thickness, rib_height, rib_width)
    .translate((bracket_outer_radius, 0, 0))
    .edges()
    .chamfer(chamfer_size)
)
body = body.union(rib)

result = body