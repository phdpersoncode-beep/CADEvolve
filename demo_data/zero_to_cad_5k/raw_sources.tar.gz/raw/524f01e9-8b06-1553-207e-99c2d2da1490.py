import cadquery as cq
import math
from types import SimpleNamespace as Measures

m = Measures(
    block_height = 12.0,
    block_thickness = 5.0,
    arc_radius = 30.0,
    arc_angle_deg = 100.0,
    fillet_vert = 1.0,
    fillet_top = 0.8,
    screw_diameter = 3.0,
    screw_head_diameter = 6.0,
    screw_head_height = 2.5,
    screw_recess_depth = 4.0
)

m.chord = 2 * m.arc_radius * math.sin(math.radians(m.arc_angle_deg / 2))
m.secant_angle = (180.0 - m.arc_angle_deg) / 2.0

path = (
    cq.Workplane("XY")
    .radiusArc((m.chord, 0.0), m.arc_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.secant_angle, 0))
    .rect(m.block_thickness, m.block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(m.fillet_vert)
    .edges(">Z")
    .fillet(m.fillet_top)
    .faces('>Z')
    .workplane()
    .center(0, 0)
    .cboreHole(m.screw_diameter, m.screw_head_diameter, m.screw_head_height, depth=m.screw_recess_depth)
)
