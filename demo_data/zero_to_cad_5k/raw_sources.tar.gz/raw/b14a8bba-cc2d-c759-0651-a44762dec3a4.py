import cadquery as cq

# Parameters
bracket_length = 80.0
bracket_height = 30.0
bracket_depth = 8.0
flange_radius = 10.0
hole_diameter = 5.0
hole_spacing = 12.0
hole_offset_y = 10.0
chamfer_size = 1.0
rib_width = 6.0
rib_height = 4.0
rib_protrude = -2.0
rib_spacing = 20.0

mid_y = bracket_height / 2.0
profile = (
    cq.Workplane('XY')
    .moveTo(-bracket_length / 2.0, 0)
    .lineTo(bracket_length / 2.0, 0)
    .lineTo(bracket_length / 2.0, mid_y - flange_radius)
    .threePointArc((bracket_length / 2.0 + flange_radius, mid_y), (bracket_length / 2.0, mid_y + flange_radius))
    .lineTo(bracket_length / 2.0, bracket_height)
    .lineTo(-bracket_length / 2.0, bracket_height)
    .close()
)

base = profile.extrude(bracket_depth)

rib = (
    cq.Workplane('XY')
    .rect(rib_width, rib_height)
    .extrude(rib_protrude)
)

rib_pattern = (
    base.faces("<Z")
    .workplane()
    .rarray(rib_spacing, 0, int((bracket_length - 2 * rib_spacing) / rib_spacing) + 1, 1, center=True)
    .add(rib)
    .union()
)

flange_face = rib_pattern.faces("+X")
holes = (
    flange_face.workplane(offset=bracket_depth - 0.01)
    .center(0, hole_offset_y)
    .rarray(hole_spacing, 0, 5, 1, center=True)
    .hole(hole_diameter)
)

result = (
    holes.edges("|Z and <Y")
    .chamfer(chamfer_size)
)
