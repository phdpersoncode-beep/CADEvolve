import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, m):
        self.wp = wp
        self.m = m
        self.build()
    def build(self):
        m = self.m
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.height),
                (m.thickness, m.height),
                (m.thickness, m.thickness),
                (m.thickness + m.length, m.thickness),
                (m.thickness + m.length, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.depth)
            .edges("|Z")
            .fillet(m.fillet_radius)
            .faces(">Z")
            .workplane()
            .center(m.slot_center_x, m.slot_center_y)
            .rect(m.slot_width, m.slot_length)
            .cutBlind(m.depth)
            .faces(">Z")
            .workplane()
            .center(m.blind_center_x, m.blind_center_y)
            .hole(m.blind_diameter, m.blind_depth)
        )
        self.model = base

measures = Measures(
    height=70.0,
    length=80.0,
    thickness=8.0,
    depth=12.0,
    fillet_radius=3.0,
    slot_width=5.0,
    slot_length=30.0,
    slot_center_x=40.0,
    slot_center_y=4.0,
    blind_diameter=6.0,
    blind_depth=8.0,
    blind_center_x=20.0,
    blind_center_y=4.0,
)

result = LBracket(cq.Workplane("XY"), measures).model