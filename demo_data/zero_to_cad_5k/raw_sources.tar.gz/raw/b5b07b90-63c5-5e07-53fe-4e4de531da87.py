import cadquery as cq
from types import SimpleNamespace as Measures

horizontal_length = 60.0
vertical_height = 80.0
leg_thickness = 12.0
bracket_thickness = 8.0
hole_clearance = 5.5
hole_spacing_y = 12.0
hole_start_offset = 20.0
hole_column_offset = 18.0
slot_width = 20.0
slot_length = 30.0
slot_depth = 4.0
chamfer_size = 1.0

measures = Measures(
    horizontal_length=horizontal_length,
    vertical_height=vertical_height,
    leg_thickness=leg_thickness,
    bracket_thickness=bracket_thickness,
    hole_clearance=hole_clearance,
    hole_spacing_y=hole_spacing_y,
    hole_start_offset=hole_start_offset,
    hole_column_offset=hole_column_offset,
    slot_width=slot_width,
    slot_length=slot_length,
    slot_depth=slot_depth,
    chamfer_size=chamfer_size,
)

class LBracket:
    def __init__(self, workplane, m):
        self.model = workplane
        self.m = m
        self.build()

    def build(self):
        m = self.m
        self.model = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_height),
                (0, m.vertical_height),
                (0, 0),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        self.model = (
            self.model.faces('>Z')
            .workplane()
            .center(m.horizontal_length/2, m.leg_thickness/2)
            .rect(m.slot_width, m.slot_length)
            .cutBlind(-m.slot_depth)
        )
        hole_points = []
        x1 = m.leg_thickness/2
        for i in range(4):
            y = m.hole_start_offset + i * m.hole_spacing_y
            hole_points.append((x1, y))
        x2 = x1 + m.hole_column_offset
        for i in range(3):
            y = m.hole_start_offset + m.hole_spacing_y/2 + i * m.hole_spacing_y
            hole_points.append((x2, y))
        self.model = (
            self.model.faces('>Z')
            .workplane()
            .pushPoints(hole_points)
            .hole(m.hole_clearance)
        )
        self.model = (
            self.model.edges('|Z')
            .chamfer(m.chamfer_size)
        )

result = LBracket(cq.Workplane("XY"), measures).model
