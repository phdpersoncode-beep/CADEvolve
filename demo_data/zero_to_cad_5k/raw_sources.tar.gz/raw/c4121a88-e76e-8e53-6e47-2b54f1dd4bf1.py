import cadquery as cq
import math

# Parameters
flange_diameter = 80.0
flange_radius = flange_diameter / 2.0
flange_thickness = 8.0
rim_thickness = 2.0
boss_diameter = 20.0
boss_radius = boss_diameter / 2.0
boss_height = 6.0
hole_diameter = 3.0
hole_count = 6
hole_pitch_radius = 30.0
tab_width = 15.0
tab_height = 10.0
chamfer_distance = 0.5

# Base composite sketch (circle + rectangular tab)
base = (
    cq.Workplane('XY')
    .sketch()
    .circle(flange_radius)
    .rect(tab_width, tab_height)
    .finalize()
    .extrude(flange_thickness)
)

# Shell to create thin-walled flange with defined rim thickness
shelled = base.shell(-rim_thickness)

# Central boss added on top of inner cavity
boss = (
    cq.Workplane('XY')
    .circle(boss_radius)
    .extrude(boss_height)
)

# Combine shelled flange with boss
combined = shelled.union(boss)

# Generate hole positions around a circle
hole_positions = []
for i in range(hole_count):
    angle = 2 * math.pi * i / hole_count
    x = hole_pitch_radius * math.cos(angle)
    y = hole_pitch_radius * math.sin(angle)
    hole_positions.append((x, y))

# Drill holes through entire part
with_holes = (
    combined
    .faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)

# Apply chamfer to outer rim and boss top edge
final = (
    with_holes
    .edges('>>Z and (not |Z)')
    .chamfer(chamfer_distance)
    .edges('>Z')
    .chamfer(chamfer_distance)
)

result = final