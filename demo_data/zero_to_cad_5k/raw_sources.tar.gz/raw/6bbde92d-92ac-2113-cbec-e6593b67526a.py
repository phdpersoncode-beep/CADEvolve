import cadquery as cq

# Parameters
rotor_diameter = 80.0
rotor_width = 20.0
rim_thickness = 8.0
shell_thickness = 2.0
rib_height = 6.0
rib_width = 4.0
rib_thickness = 2.0
rib_count = 12
fillet_radius = 1.0
chamfer_distance = 0.5

# Base solid (full cylinder)
outer_radius = rotor_diameter / 2.0
base_cylinder = cq.Workplane('XY').circle(outer_radius).extrude(rotor_width)

# Shell operation to create thin-walled rotor
shell = base_cylinder.shell(shell_thickness)

# Single rib positioned on outer surface
rib = (
    cq.Workplane('XY')
    .box(rib_thickness, rib_width, rib_height)
    .translate((outer_radius - shell_thickness/2 - rib_thickness/2, 0, 0))
)

# Add ribs around circumference
result = shell
for i in range(1, rib_count):
    angle = i * 360.0 / rib_count
    rotated_rib = rib.rotate((0, 0, 0), (0, 0, 1), angle)
    result = result.union(rotated_rib)

# Chamfer outer rim edges for safety
result = result.edges('|Z').chamfer(chamfer_distance)
