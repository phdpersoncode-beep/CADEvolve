import cadquery as cq
leaf_length = 80
leaf_width = 30
leaf_thickness = 8
pocket_length = 40
pocket_width = leaf_width - 6
pocket_depth = 2
pin_hole_diameter = 6
counterbore_diameter = 10
counterbore_depth = 2
tab_length = 15
tab_width = 8
fillet_radius = 2
# base plate
base = (cq.Workplane("XY")
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)
# side tab
tab = (cq.Workplane("XY")
    .center(-leaf_length/2 + tab_length/2, 0)
    .rect(tab_length, tab_width)
    .extrude(leaf_thickness)
)
# combine and clean
combined = base.union(tab).combine()
# fillet outer edges
combined = combined.edges().fillet(fillet_radius)
# cut recessed pocket
combined = (combined
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(pocket_length, pocket_width)
    .cutBlind(-pocket_depth)
)
# counterbore hole
combined = (combined
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .hole(counterbore_diameter, depth=counterbore_depth)
)
# through pin hole
combined = (combined
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .hole(pin_hole_diameter)
)
result = combined
