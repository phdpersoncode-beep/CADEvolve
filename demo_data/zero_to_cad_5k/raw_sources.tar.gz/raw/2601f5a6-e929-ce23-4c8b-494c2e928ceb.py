import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_leg_length),
                (0, m.vertical_leg_length)
            ])
            .close()
            .extrude(m.bracket_depth)
            .edges('|Z')
            .fillet(m.fillet_radius)
        )
        # add holes on vertical leg through top face
        base = (
            base.faces('>Z')
            .workplane()
            .center(m.leg_thickness / 2, m.hole_initial_offset)
            .rarray(m.hole_spacing, 0, m.hole_count, 1)
            .hole(m.hole_diameter)
        )
        # reinforcing rib at inner corner
        rib = (
            cq.Workplane('XY')
            .moveTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness + m.rib_length, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness + m.rib_length)
            .close()
            .extrude(m.rib_thickness)
        )
        result = base.union(rib).edges('>X or <X or >Y or <Y').chamfer(m.chamfer_distance)
        self.model = result

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=60.0,
    leg_thickness=12.0,
    bracket_depth=10.0,
    fillet_radius=5.0,
    rib_length=20.0,
    rib_thickness=6.0,
    hole_diameter=6.0,
    hole_count=3,
    hole_spacing=15.0,
    hole_initial_offset=15.0,
    chamfer_distance=0.5,
)

result = LBracket(cq.Workplane('XY'), measures).model