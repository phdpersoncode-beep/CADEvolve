import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        self.model = (
            cq.Workplane("XY")
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.vertical_height)
            .lineTo(m.horizontal_length, m.vertical_height)
            .lineTo(m.horizontal_length, m.vertical_height + m.thickness)
            .lineTo(0, m.vertical_height + m.thickness)
            .close()
            .extrude(m.thickness)
        )
        margin = m.thickness
        usable_length = m.horizontal_length - 2 * margin
        hole_spacing = usable_length / (m.hole_count - 1)
        hole_count = int(m.hole_count)
        # generate positions centered on first hole at -usable_length/2
        points = [(i * hole_spacing - usable_length / 2, 0) for i in range(hole_count)]
        self.model = (
            self.model
            .faces(">Z")
            .workplane()
            .center(0, -m.vertical_height/2)
            .center(-m.horizontal_length/2 + margin, 0)
            .pushPoints(points)
            .hole(m.hole_diameter)
        )
        self.model = self.model.faces(">X").edges().chamfer(m.chamfer_dist)

measures = Measures(
    thickness=10.0,
    vertical_height=70.0,
    horizontal_length=50.0,
    hole_count=7,
    hole_diameter=6.5,
    chamfer_dist=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
