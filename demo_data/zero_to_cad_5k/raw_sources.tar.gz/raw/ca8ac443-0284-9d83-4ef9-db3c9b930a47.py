import cadquery as cq
import math

# Parameters
flange_length = 80.0
flange_width = 60.0
flange_thickness = 5.0
teeth_per_side = 3
rib_base_width = 4.0
rib_height = 6.0
fillet_radius = 1.5
hole_diameter = 6.5
hole_rows = 2
holes_per_row = 5
edge_margin = 12.0

# Derived parameters
segment_len_x = flange_length / (teeth_per_side + 1)
segment_len_y = flange_width / (teeth_per_side + 1)
half_len = flange_length / 2.0
half_wid = flange_width / 2.0
hole_pitch_y = flange_width - 2 * edge_margin
hole_spacing_x = (flange_length - 2 * edge_margin) / (holes_per_row - 1)

# Base plate (bottom at Z=0)
base = cq.Workplane("XY").box(flange_length, flange_width, flange_thickness, centered=(True, True, False))

# Helper to create a triangular tooth given three points in XY
def make_tooth(points):
    return (
        cq.Workplane("XY")
        .polyline(points)
        .close()
        .extrude(flange_thickness)
    )

teeth = cq.Workplane("XY")
# Bottom edge teeth
for i in range(teeth_per_side):
    x = -half_len + (i + 1) * segment_len_x
    pts = [
        (x - rib_base_width/2, -half_wid),
        (x + rib_base_width/2, -half_wid),
        (x, -half_wid - rib_height)
    ]
    teeth = teeth.union(make_tooth(pts))
# Right edge teeth
for i in range(teeth_per_side):
    y = -half_wid + (i + 1) * segment_len_y
    pts = [
        (half_len, y - rib_base_width/2),
        (half_len, y + rib_base_width/2),
        (half_len + rib_height, y)
    ]
    teeth = teeth.union(make_tooth(pts))
# Top edge teeth
for i in range(teeth_per_side):
    x = -half_len + (i + 1) * segment_len_x
    pts = [
        (x - rib_base_width/2, half_wid),
        (x + rib_base_width/2, half_wid),
        (x, half_wid + rib_height)
    ]
    teeth = teeth.union(make_tooth(pts))
# Left edge teeth
for i in range(teeth_per_side):
    y = -half_wid + (i + 1) * segment_len_y
    pts = [
        (-half_len, y - rib_base_width/2),
        (-half_len, y + rib_base_width/2),
        (-half_len - rib_height, y)
    ]
    teeth = teeth.union(make_tooth(pts))

# Combine base and teeth (they intersect in the plane, yielding a single solid)
flange = base.union(teeth)

# Apply fillet to external tooth tip edges (vertical edges where Z is max)
flange = flange.edges(">Z").fillet(fillet_radius)

# Add clearance holes (grid pattern)
for row in range(hole_rows):
    y = -hole_pitch_y/2 + row * hole_pitch_y
    for col in range(holes_per_row):
        x = - (flange_length - 2*edge_margin)/2 + col * hole_spacing_x
        flange = flange.faces('>Z').workplane().pushPoints([(x, y)]).hole(hole_diameter)

result = flange
