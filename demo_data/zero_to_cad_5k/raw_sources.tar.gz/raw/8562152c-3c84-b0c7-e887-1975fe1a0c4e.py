import cadquery as cq
import math
outer_flat_distance = 80.0
flange_thickness = 10.0
rim_thickness = 3.0
central_hole_diameter = 20.0
clearance_hole_diameter = 13.0
hole_circle_radius = 30.0
chamfer_distance = 2.0
hex_radius = outer_flat_distance / math.sqrt(3)
inner_hex_radius = hex_radius - rim_thickness
base = (cq.Workplane("XY")
        .polygon(6, hex_radius)
        .extrude(flange_thickness))
recess = (base
          .faces(">Z")
          .workplane()
          .polygon(6, inner_hex_radius)
          .cutBlind(flange_thickness * 0.6))
through_hole = (recess
               .faces(">Z")
               .workplane()
               .hole(central_hole_diameter, depth=flange_thickness))
peripheral = (through_hole
              .faces(">Z")
              .workplane()
              .pushPoints([(
                  hole_circle_radius * math.cos(math.radians(angle)),
                  hole_circle_radius * math.sin(math.radians(angle))
              ) for angle in range(0, 360, 45)])
              .hole(clearance_hole_diameter, depth=flange_thickness))
result = (peripheral
          .edges("|Z")
          .chamfer(chamfer_distance))