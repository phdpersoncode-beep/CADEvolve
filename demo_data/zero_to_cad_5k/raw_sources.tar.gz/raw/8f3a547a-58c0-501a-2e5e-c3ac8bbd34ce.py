import cadquery as cq

channel_length = 80.0
channel_width = 40.0
channel_height = 30.0
wall_thickness = 3.0
fillet_radius = 2.0
chamfer_size = 0.5
hole_diameter = 5.0
hole_spacing = 20.0

outer = (
    cq.Workplane("XY")
    .box(channel_length, channel_width, channel_height, centered=(True, True, False))
)

inner = (
    cq.Workplane("XY")
    .transformed(offset=(0, 0, wall_thickness))
    .box(
        channel_length,
        channel_width - 2 * wall_thickness,
        channel_height - 2 * wall_thickness,
        centered=(True, True, False),
    )
)

result = (
    outer.cut(inner)
    .edges(">Z")
    .fillet(fillet_radius)
    .edges("<Z")
    .chamfer(chamfer_size)
    .faces(">Z")
    .workplane()
    .rarray(hole_spacing, 0, 2, 1)
    .hole(hole_diameter)
)
