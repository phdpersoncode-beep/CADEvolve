import cadquery as cq

chute_height = 80.0
chute_inner_radius = 10.0
wall_thickness = 5.0
chute_outer_radius = chute_inner_radius + wall_thickness
lip_height = 5.0
lip_fillet_radius = 2.0
set_screw_hole_dia = 4.0
set_screw_hole_depth = 12.0
set_screw_head_dia = 7.0
set_screw_head_depth = 2.5
hole_center_radius = chute_inner_radius - wall_thickness/2

profile = (
    cq.Workplane("XZ")
    .polyline([
        (chute_inner_radius, 0),
        (chute_inner_radius, chute_height - lip_height),
        (chute_outer_radius, chute_height - lip_height),
        (chute_outer_radius, chute_height),
        (chute_inner_radius, chute_height),
    ])
    .close()
)

hole_cylinder = (
    cq.Workplane("XZ")
    .center(hole_center_radius, chute_height - lip_height/2)
    .circle(set_screw_hole_dia/2)
    .extrude(set_screw_hole_depth)
)

head_cone = (
    cq.Solid.makeCone(set_screw_head_dia/2, set_screw_hole_dia/2, set_screw_head_depth)
    .translate((hole_center_radius, 0, chute_height - lip_height/2 - set_screw_head_depth/2))
)

result = (
    profile
    .revolve()
    .edges()
    .fillet(lip_fillet_radius)
    .cut(hole_cylinder)
    .cut(head_cone)
)
