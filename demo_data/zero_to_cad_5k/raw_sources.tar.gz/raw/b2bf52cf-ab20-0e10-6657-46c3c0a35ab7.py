import cadquery as cq

# Primary dimensions (max 100 units)
part_length = 80.0
part_width = 50.0
part_height = 30.0
shoulder_step_height = 10.0
shoulder_width = 30.0
wall_thickness = 3.0
fillet_radius = 1.0
chamfer_distance = 0.5
hole_diameter = 8.0
hole_offset_from_side = 15.0
channel_width = 12.0
channel_depth = 4.0

# Base block (full width, lower region)
base = (
    cq.Workplane("XY")
    .box(part_length, part_width, part_height - shoulder_step_height, centered=(True, True, False))
)

# Stepped shoulder (reduced width on top)
shoulder = (
    cq.Workplane("XY")
    .box(part_length, shoulder_width, shoulder_step_height, centered=(True, True, False))
    .translate((0, 0, part_height - shoulder_step_height))
)

solid = base.union(shoulder)

# Side channel pocket on +Y face
solid = (
    solid
    .faces(">Y")
    .workplane()
    .center(0, 0)
    .rect(part_length - 2 * wall_thickness, channel_width)
    .cutBlind(-channel_depth)
)

# Chamfer top edges of stepped region before fillet
solid = solid.edges(">Z and |Y").chamfer(chamfer_distance)

# Fillet vertical edges
solid = solid.edges("|Z").fillet(fillet_radius)

# Hole center Y coordinate
hole_center_y = -part_width/2 + wall_thickness + hole_offset_from_side

result = (
    solid
    .faces(">Z")
    .workplane()
    .center(0, hole_center_y)
    .hole(hole_diameter)
)
