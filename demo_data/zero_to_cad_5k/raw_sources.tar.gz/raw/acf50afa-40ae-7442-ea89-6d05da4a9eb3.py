import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.leg_height)
            .lineTo(m.leg_length, m.leg_height)
            .lineTo(m.leg_length, m.leg_height + m.thickness)
            .lineTo(0, m.leg_height + m.thickness)
            .close()
            .extrude(m.thickness)
        )
        rib = (
            cq.Workplane("XY")
            .moveTo(m.thickness, m.leg_height)
            .lineTo(m.thickness + m.rib_width, m.leg_height)
            .lineTo(m.thickness, m.leg_height + m.rib_height)
            .close()
            .extrude(m.thickness)
        )
        bracket = base.union(rib)
        bracket = (
            bracket.faces(">Z")
            .workplane()
            .moveTo(m.thickness + m.hole_margin, m.leg_height + m.thickness / 2)
            .rarray(m.hole_spacing, 0, 4, 1)
            .hole(m.hole_clearance_diameter)
        )
        bracket = bracket.edges("|Z").chamfer(m.chamfer)
        self.model = bracket

measures = Measures(
    leg_length=80.0,
    leg_height=60.0,
    thickness=8.0,
    rib_width=30.0,
    rib_height=6.0,
    hole_clearance_diameter=7.0,
    hole_margin=10.0,
    hole_spacing=17.0,
    chamfer=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model