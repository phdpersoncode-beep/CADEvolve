import cadquery as cq

class LBracket:
    def __init__(self, workplane, m):
        self.wp = workplane
        self.m = m
        self.build()
    def build(self):
        m = self.m
        pts = [
            (0, 0),
            (m.long_leg, 0),
            (m.long_leg, m.base_thickness),
            (m.step_back, m.base_thickness),
            (m.step_back, m.base_thickness + m.step_extra),
            (0, m.base_thickness + m.step_extra)
        ]
        self.model = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.bracket_depth)
        )
        self.model = self.model.edges().fillet(m.inner_fillet)
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .center(m.long_leg, m.base_thickness + m.step_extra/2)
            .hole(m.tapped_dia)
        )
        self.model = (
            self.model.faces(">Z")
            .workplane()
            .pushPoints([
                (m.long_leg/3, m.base_thickness/2),
                (2*m.long_leg/3, m.base_thickness/2)
            ])
            .hole(m.mount_hole_dia)
        )
        self.model = self.model.edges().chamfer(m.chamfer)

class Measures:
    pass

m = Measures()
m.long_leg = 80.0
m.base_thickness = 10.0
m.step_extra = 5.0
m.step_back = 30.0
m.bracket_depth = 8.0
m.inner_fillet = 1.0
m.tapped_dia = 6.0
m.mount_hole_dia = 4.0
m.chamfer = 0.5

result = LBracket(cq.Workplane("XY"), m).model
