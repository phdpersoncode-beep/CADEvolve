import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
leg_height = 80.0
leg_width = 60.0
bracket_thickness = 10.0
extrude_thickness = 12.0
hole_diameter = 5.0
hole_edge_distance = 15.0
hole_spacing = 30.0
rib_height = 30.0
rib_thickness = 5.0
rib_depth = 8.0
chamfer_size = 1.0

class LBracket:
    def __init__(self, workplane, measures):
        self.wp = workplane
        self.m = measures
        self.model = None
        self.build()

    def build(self):
        m = self.m
        # Base L profile sketch (non‑trivial composite)
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.leg_height)
            .lineTo(m.bracket_thickness, m.leg_height)
            .lineTo(m.bracket_thickness, m.bracket_thickness)
            .lineTo(m.leg_width, m.bracket_thickness)
            .lineTo(m.leg_width, 0)
            .close()
            .extrude(m.extrude_thickness)
        )
        # Chamfer outer edges for safety
        base = base.edges("|Z").chamfer(m.chamfer_size)
        # Mounting holes on vertical leg (top surface)
        vertical_hole_y_start = m.leg_height - m.hole_edge_distance - (m.hole_spacing / 2)
        vertical_hole_points = [
            (m.bracket_thickness / 2, vertical_hole_y_start + i * m.hole_spacing)
            for i in range(2)
        ]
        base = (
            base.faces(">Z").workplane()
            .pushPoints(vertical_hole_points)
            .hole(m.hole_diameter)
        )
        # Mounting holes on horizontal leg (top surface)
        horizontal_hole_x_start = m.hole_edge_distance + (m.hole_spacing / 2)
        horizontal_hole_points = [
            (horizontal_hole_x_start + i * m.hole_spacing, m.bracket_thickness / 2)
            for i in range(2)
        ]
        base = (
            base.faces(">Z").workplane()
            .pushPoints(horizontal_hole_points)
            .hole(m.hole_diameter)
        )
        # Rib on inner side of vertical leg
        rib_center_offset = (m.leg_height / 2) - (m.extrude_thickness / 2)  # not used, placeholder
        rib_offset_y = (m.leg_height / 2) - (m.rib_height / 2)
        rib = (
            base.faces(">X").workplane()
            .move(0, rib_offset_y - (m.leg_height / 2))
            .rect(m.rib_thickness, m.rib_height)
            .extrude(m.rib_depth)
        )
        # Union rib with base
        result = base.union(rib)
        self.model = result

# Assemble measures namespace
measures = Measures(
    leg_height=leg_height,
    leg_width=leg_width,
    bracket_thickness=bracket_thickness,
    extrude_thickness=extrude_thickness,
    hole_diameter=hole_diameter,
    hole_edge_distance=hole_edge_distance,
    hole_spacing=hole_spacing,
    rib_height=rib_height,
    rib_thickness=rib_thickness,
    rib_depth=rib_depth,
    chamfer_size=chamfer_size,
)

result = LBracket(cq.Workplane("XY"), measures).model