import cadquery as cq

# dimensions (units max 100)
base_length = 80.0
base_width = 60.0
base_thickness = 6.0
outer_fillet_radius = 2.0
bottom_fillet_radius = 1.0
frame_outer_length = 70.0
frame_outer_width = 50.0
frame_height = 8.0
frame_wall_thickness = 4.0
inner_fillet_radius = 1.5
pocket_length = 30.0
pocket_width = 20.0
pocket_depth = 6.0
hole_diameter = 4.0
hole_offset = frame_wall_thickness + 2.0

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges("|Z").fillet(outer_fillet_radius)
    .faces("<Z").fillet(bottom_fillet_radius)
    .faces(">Z")
    .workplane()
    .rect(frame_outer_length, frame_outer_width)
    .extrude(frame_height)
    .faces(">Z")
    .workplane()
    .rect(frame_outer_length - 2 * frame_wall_thickness, frame_outer_width - 2 * frame_wall_thickness)
    .cutBlind(-frame_height)
    .faces(">Z")
    .workplane()
    .rect(pocket_length, pocket_width)
    .cutBlind(-pocket_depth)
    .edges("|Z").fillet(inner_fillet_radius)
    .faces(">Z")
    .workplane()
    .pushPoints([
        ( frame_outer_length/2 - hole_offset,  frame_outer_width/2 - hole_offset),
        (-frame_outer_length/2 + hole_offset,  frame_outer_width/2 - hole_offset),
        ( frame_outer_length/2 - hole_offset, -frame_outer_width/2 + hole_offset),
        (-frame_outer_length/2 + hole_offset, -frame_outer_width/2 + hole_offset),
        (0,  frame_outer_width/2 - hole_offset),
        (0, -frame_outer_width/2 + hole_offset),
        ( frame_outer_length/2 - hole_offset, 0),
        (-frame_outer_length/2 + hole_offset, 0),
    ])
    .circle(hole_diameter/2)
    .cutBlind(-frame_height)
)
