import cadquery as cq

outer_radius = 40
inner_radius = 10
thickness = 10
taper_angle = 5
hole_diameter = 12
hole_radius = 20
chamfer_len = 1

profile = (
    cq.Sketch()
    .circle(outer_radius)
    .circle(inner_radius)
    .clean()
)

base = (
    cq.Workplane('XY')
    .placeSketch(profile)
    .extrude(thickness, taper=-taper_angle)
)

with_holes = (
    base
    .faces('>Z')
    .workplane()
    .pushPoints([
        (hole_radius, 0),
        (0, hole_radius),
        (-hole_radius, 0),
        (0, -hole_radius)
    ])
    .hole(hole_diameter)
)

result = (
    with_holes
    .faces('>Z')
    .edges()
    .chamfer(chamfer_len)
)
