import cadquery as cq
from math import acos, degrees

class Measures:
    pass

m = Measures()

# Primary dimensions (scaled, max 100 units)
m.linear_width = 60.0
m.depth = 12.0
m.height = 12.0
m.arc_outer_diameter = 90.0
m.vertical_fillet = 2.0
m.top_fillet = 2.5
m.arc_edge_fillet = 4.0

# Counterbore hole parameters
m.hole = Measures()
m.hole.bolt_diameter = 4.0
m.hole.head_diameter = 7.0
m.hole.head_height = 3.0
m.hole.offset_x = 0.0
m.hole.offset_y = 5.0

# Derived geometry
m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

# Arc path for sweep
path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

# Build block, apply fillets, add pocket, then counterbore
result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(m.vertical_fillet)
    .edges(">Z")
    .fillet(m.top_fillet)
    .edges(">Y")
    .fillet(m.arc_edge_fillet)
    # Pocket cutout in the upper half
    .faces(">Z")
    .workplane()
    .center(0, m.height/4)
    .rect(m.depth/2, m.height/2)
    .cutBlind(-m.depth/2)
    # Counterbored mounting hole on top surface
    .faces(">Z")
    .workplane()
    .center(m.hole.offset_x, m.hole.offset_y)
    .cboreHole(m.hole.bolt_diameter, m.hole.head_diameter, m.hole.head_height)
)
