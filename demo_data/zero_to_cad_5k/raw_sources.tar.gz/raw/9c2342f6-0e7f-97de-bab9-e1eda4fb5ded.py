import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.leg_x, 0)
            .lineTo(m.leg_x, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.leg_y)
            .lineTo(0, m.leg_y)
            .close()
        )
        solid = base.extrude(m.depth)
        solid = solid.edges('|Z').fillet(m.fillet_radius)
        solid = solid.edges('>Z').chamfer(m.chamfer)
        solid = (
            solid.faces('>Y')
            .workplane(centerOption='CenterOfBoundBox')
            .moveTo(m.leg_x/2, m.thickness/2)
            .cboreHole(m.hole_clearance, m.hole_dia, m.hole_depth)
        )
        solid = (
            solid.faces('>X')
            .workplane(centerOption='CenterOfBoundBox')
            .moveTo(m.thickness/2, m.leg_y/2)
            .cboreHole(m.hole_clearance, m.hole_dia, m.hole_depth)
        )
        if m.gusset:
            gusset = (
                cq.Workplane('XY')
                .moveTo(0, 0)
                .lineTo(m.leg_x/2, 0)
                .lineTo(0, m.leg_y/2)
                .close()
                .extrude(m.gusset_thickness)
            )
            solid = solid.union(gusset)
        self.model = solid

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

measures = Measures(
    leg_x=70.0,
    leg_y=60.0,
    thickness=10.0,
    depth=12.0,
    fillet_radius=3.0,
    chamfer=1.0,
    hole_clearance=5.0,
    hole_dia=6.0,
    hole_depth=4.0,
    gusset=True,
    gusset_thickness=4.0,
)

result = cq.Workplane('XY').part(LBracket, measures)
