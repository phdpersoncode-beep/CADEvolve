import cadquery as cq
polar_array_doc = cq.Workplane.polarArray.__doc__
result = (
    cq.Workplane('XY')
    .box(10,10,5)
    .edges('|Z')
    .fillet(0.5)
    .faces('>Z')
    .hole(2)
)
