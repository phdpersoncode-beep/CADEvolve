import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        long_leg = (
            cq.Workplane("XY")
            .box(m.long_leg_length, m.bracket_width, m.thickness)
            .translate((m.long_leg_length / 2, m.bracket_width / 2, 0))
        )
        short_leg = (
            cq.Workplane("XY")
            .box(m.bracket_width, m.short_leg_length, m.thickness)
            .translate((m.bracket_width / 2, m.short_leg_length / 2, 0))
        )
        base = long_leg.union(short_leg)
        rib = (
            base.faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .moveTo(m.long_leg_length / 2, 0)
            .rect(m.rib_width, m.thickness)
            .extrude(-m.rib_depth)
        )
        combined = base.union(rib)
        hole_positions = [
            (0, -m.short_leg_length / 2 + m.hole_offset + i * m.hole_spacing)
            for i in range(m.hole_count)
        ]
        combined = (
            combined.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        result = combined.edges("|Z").chamfer(m.chamfer)
        self.model = result

measures = Measures(
    long_leg_length=80.0,
    short_leg_length=50.0,
    bracket_width=30.0,
    thickness=6.0,
    rib_width=5.0,
    rib_depth=8.0,
    hole_diameter=3.0,
    hole_count=5,
    hole_spacing=8.0,
    hole_offset=10.0,
    chamfer=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model
