import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width = 50.0,
    depth = 15.0,
    height = 12.0,
    arc_outer_diameter = 100.0,
    top_fillet = 2.0,
    vertical_fillet = 1.5,
    edge_chamfer = 0.5,
    boss_diameter = 20.0,
    boss_height = 10.0,
    pneumatic_hole_diameter = 6.0,
    mounting_hole_diameter = 4.0,
    mounting_hole_spacing = 30.0,
    mounting_hole_offset = 8.0,
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("<Z")
    .chamfer(m.edge_chamfer)
    .edges("|Z")
    .fillet(m.vertical_fillet)
    .edges(">Z")
    .fillet(m.top_fillet)
    .faces(">Z").first().workplane()
    .center(0, 0)
    .circle(m.boss_diameter / 2)
    .extrude(m.boss_height)
    .faces(">Z").first().workplane()
    .hole(m.pneumatic_hole_diameter)
    .faces("<Y").first().workplane()
    .pushPoints([(-m.mounting_hole_spacing/2, m.mounting_hole_offset), (m.mounting_hole_spacing/2, m.mounting_hole_offset)])
    .hole(m.mounting_hole_diameter)
)
