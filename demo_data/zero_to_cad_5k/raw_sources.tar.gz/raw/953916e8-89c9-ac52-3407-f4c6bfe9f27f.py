import cadquery as cq
import math
hub_radius = 15.0
hub_thickness = 6.0
flange_outer_radius = 45.0
flange_thickness = 10.0
bore_diameter = 10.0
chamfer_distance = 2.0
bolt_hole_diameter = 5.0
bolt_head_diameter = 8.0
bolt_head_depth = 2.0
bolt_circle_radius = 30.0
rib_width = 5.0
rib_length = 30.0
rib_thickness = 2.0
profile = (
    cq.Workplane("XZ")
    .moveTo(hub_radius, 0)
    .lineTo(hub_radius, hub_thickness)
    .lineTo(flange_outer_radius, hub_thickness)
    .lineTo(flange_outer_radius, flange_thickness)
    .lineTo(hub_radius, flange_thickness)
    .close()
)
flange = profile.revolve()
central_bore = (
    cq.Workplane("XY")
    .circle(bore_diameter / 2)
    .extrude(flange_thickness)
    .edges("not(|Z)")
    .chamfer(chamfer_distance)
)
flange = flange.cut(central_bore)
bolt_positions = [
    (bolt_circle_radius * math.cos(i * 2 * math.pi / 3), bolt_circle_radius * math.sin(i * 2 * math.pi / 3))
    for i in range(3)
]
flange = (
    flange.faces(">Z")
    .workplane()
    .pushPoints(bolt_positions)
    .hole(bolt_hole_diameter)
)
flange = (
    flange.faces(">Z")
    .workplane()
    .pushPoints(bolt_positions)
    .circle(bolt_head_diameter / 2)
    .cutBlind(bolt_head_depth)
)
rib = (
    cq.Workplane("XY")
    .rect(rib_width, rib_length)
    .extrude(rib_thickness)
    .translate((hub_radius + rib_length / 2, 0, hub_thickness))
)
result = flange
for i in range(4):
    angle = i * 90
    rib_i = rib.rotate((0, 0, 0), (0, 0, 1), angle)
    result = result.union(rib_i)
