import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L shape
        base = (
            self.model
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.leg_height),
                (0, m.leg_height)
            ])
            .close()
            .extrude(m.base_thickness)
        )
        # Boss solid (added on top of base)
        boss = (
            base
            .faces('>Z')
            .workplane()
            .center(
                m.leg_length - m.boss_offset - m.boss_width / 2,
                m.leg_thickness / 2,
            )
            .rect(m.boss_width, m.boss_depth)
            .extrude(m.boss_height)
        )
        # Union base and boss
        self.model = base.union(boss)
        # Tapped hole in boss
        self.model = (
            self.model
            .faces('>Z')
            .workplane()
            .center(
                m.leg_length - m.boss_offset - m.boss_width / 2,
                m.leg_thickness / 2,
            )
            .cboreHole(m.boss_hole_clearance, m.boss_hole_diameter, m.boss_hole_depth)
        )
        # Mounting holes on vertical leg
        hole_positions = [
            (m.leg_thickness / 2, m.leg_height * 0.25),
            (m.leg_thickness / 2, m.leg_height * 0.75)
        ]
        self.model = (
            self.model
            .faces('>Z')
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.mount_hole_diameter)
        )
        # Triangular rib solid (full thickness to ensure merge)
        rib = (
            self.model
            .faces('<Z')
            .workplane()
            .polyline([
                (0, 0),
                (m.rib_width, 0),
                (0, m.rib_height)
            ])
            .close()
            .extrude(m.base_thickness)
        )
        # Inner corner reinforcement block solid
        block_w = m.leg_thickness / 2
        block_d = m.leg_thickness / 2
        block = (
            self.model
            .faces('<Z')
            .workplane()
            .center(block_w / 2, block_d / 2)
            .rect(block_w, block_d)
            .extrude(m.base_thickness)
        )
        # Union all additive features
        self.model = self.model.union(rib).union(block)
        # Chamfer outer edges
        self.model = self.model.edges('|Z').chamfer(m.chamfer)

def part(self, part_class, measures):
    p = part_class(self, measures)
    return self.newObject(p.model.objects)

cq.Workplane.part = part

measures = Measures(
    leg_length=70.0,
    leg_height=80.0,
    leg_thickness=8.0,
    base_thickness=6.0,
    boss_width=20.0,
    boss_depth=6.0,
    boss_height=15.0,
    boss_offset=10.0,
    boss_hole_clearance=4.0,
    boss_hole_diameter=6.5,
    boss_hole_depth=12.0,
    mount_hole_diameter=5.0,
    rib_width=6.0,
    rib_height=6.0,
    chamfer=0.8,
)

result = cq.Workplane('XY').part(LBracket, measures)
