import cadquery as cq
beam_height = 60.0
beam_width = 50.0
web_thickness = 5.0
flange_thickness = 8.0
cutout_width = 30.0
cutout_height = 12.0
cutout_depth = 4.0
chamfer_distance = 1.0
half_height = beam_height / 2.0
half_width = beam_width / 2.0
half_web = web_thickness / 2.0
pts = [
    (0.0, -half_height),
    (half_web, -half_height),
    (half_web, -half_height + flange_thickness),
    (half_width, -half_height + flange_thickness),
    (half_width, half_height - flange_thickness),
    (half_web, half_height - flange_thickness),
    (half_web, half_height),
    (0.0, half_height)
]
half_beam = (
    cq.Workplane("XZ")
    .polyline(pts)
    .close()
    .revolve(180.0)
)
cutout_box = (
    cq.Workplane("XY")
    .box(cutout_depth, cutout_width, cutout_height)
    .translate((half_width - cutout_depth/2.0, 0.0, -half_height + flange_thickness/2.0))
)
result = (
    half_beam
    .cut(cutout_box)
    .edges("|Z and >X")
    .chamfer(chamfer_distance)
)
