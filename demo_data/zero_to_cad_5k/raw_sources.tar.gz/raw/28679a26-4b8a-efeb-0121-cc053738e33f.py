import cadquery as cq
from math import acos, degrees

class Measures:
    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

m = Measures(
    linear_width=60.0,
    depth=12.0,
    height=15.0,
    arc_outer_diameter=100.0,
    chamfer_distance=1.2,
    keyway_width=8.0,
    keyway_depth=20.0,
    keyway_offset=0.0
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

base = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_distance)
)

result = (
    base
    .faces(">Z")
    .workplane()
    .center(m.keyway_offset, 0)
    .rect(m.keyway_width, m.keyway_depth)
    .cutThruAll()
)
