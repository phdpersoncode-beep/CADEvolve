import cadquery as cq
import math

outer_radius = 45.0
inner_radius = 30.0
bracket_height = 60.0
rib_height = 10.0
rib_thickness = 5.0
hole_diameter = 6.0
hole_depth = 20.0
hole_angle_offset = 30.0
chamfer_size = 1.0

profile = (
    cq.Workplane('XY')
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius, 0)
    .lineTo(outer_radius, bracket_height - rib_height)
    .lineTo(outer_radius + rib_thickness, bracket_height - rib_height)
    .lineTo(outer_radius + rib_thickness, bracket_height)
    .lineTo(inner_radius, bracket_height)
    .close()
    .revolve()
)

hole_radius_offset = inner_radius + (outer_radius - inner_radius) / 2.0
hole_positions = [
    (
        hole_radius_offset * math.cos(math.radians(hole_angle_offset)),
        hole_radius_offset * math.sin(math.radians(hole_angle_offset))
    ),
    (
        hole_radius_offset * math.cos(math.radians(hole_angle_offset + 180)),
        hole_radius_offset * math.sin(math.radians(hole_angle_offset + 180))
    ),
]

bracket_with_holes = (
    profile
    .workplane(offset=bracket_height)
    .pushPoints(hole_positions)
    .hole(hole_diameter, depth=hole_depth)
)

result = (
    bracket_with_holes
    .edges()
    .chamfer(chamfer_size)
)
