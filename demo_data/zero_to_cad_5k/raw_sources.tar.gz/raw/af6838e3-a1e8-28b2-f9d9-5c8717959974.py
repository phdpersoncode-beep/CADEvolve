import cadquery as cq

major_radius = 30.0
channel_width = 6.0
channel_height = 4.0
fillet_radius = 0.8
sensor_hole_dia = 3.0
sensor_angle_deg = 60.0

profile = (
    cq.Workplane("XZ")
    .moveTo(major_radius, -channel_height/2)
    .lineTo(major_radius, channel_height/2)
    .lineTo(major_radius + channel_width, channel_height/2)
    .lineTo(major_radius + channel_width, -channel_height/2)
    .close()
)

torus_channel = profile.revolve()

torus_with_fillet = torus_channel.edges().fillet(fillet_radius)

hole = (
    cq.Workplane("XZ")
    .circle(sensor_hole_dia/2)
    .extrude(channel_width * 1.5)
    .rotate((0, 0, 0), (0, 1, 0), 90)
    .rotate((0, 0, 0), (0, 0, 1), sensor_angle_deg)
    .translate((major_radius + channel_width/2, 0, 0))
)

result = torus_with_fillet.cut(hole)
