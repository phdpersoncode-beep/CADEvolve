import cadquery as cq
import math

# Parameters
base_radius = 20.0
tooth_height = 5.0
num_teeth = 10
gear_thickness = 10.0
central_bore_dia = 4.0
offset_hole_dia = 4.0
offset_hole_radius = 14.0
offset_hole_count = 6
chamfer_size = 1.0

pitch = 2 * math.pi * base_radius / num_teeth
tooth_width = pitch * 0.6

# Base circle profile
base_profile = cq.Workplane('XY').circle(base_radius)

# Single tooth profile positioned outward
single_tooth_profile = (
    cq.Workplane('XY')
    .rect(tooth_width, tooth_height)
    .translate((base_radius + tooth_height / 2.0, 0))
)

# Replicate teeth around gear
teeth_profiles = (
    single_tooth_profile
    .polarArray(radius=base_radius + tooth_height / 2.0, count=num_teeth, startAngle=0, angle=360.0/num_teeth)
)

# Combine base circle with teeth into a single 2D profile
combined_profile = base_profile.add(teeth_profiles)

# Extrude to create solid gear
gear_solid = combined_profile.extrude(gear_thickness)

# Central bore
gear_central = gear_solid.faces('>Z').workplane().hole(central_bore_dia)

# Offset holes pattern
offset_positions = [
    (offset_hole_radius * math.cos(2 * math.pi * i / offset_hole_count),
     offset_hole_radius * math.sin(2 * math.pi * i / offset_hole_count))
    for i in range(offset_hole_count)
]
gear_offsets = (
    gear_central
    .faces('>Z')
    .workplane()
    .pushPoints(offset_positions)
    .hole(offset_hole_dia)
)

# Chamfer top outer rim edge
result = (
    gear_offsets
    .faces('>Z')
    .edges()
    .chamfer(chamfer_size)
)
