import cadquery as cq
import math

# Parameters
arc_angle_deg = 105.0
arc_radius = 45.0  # radius of the arc centre line (units <=100)
block_depth = 20.0
block_height = 15.0
thread_diameter = 6.0
thread_depth = 8.0
chamfer_size = 1.0
engrave_text = "ARC"
engrave_fontsize = 10.0
engrave_depth = 0.5

# Derived geometry
arc_angle_rad = math.radians(arc_angle_deg)
linear_width = 2 * arc_radius * math.sin(arc_angle_rad / 2)
center_radius = arc_radius
secant_angle = (180.0 - arc_angle_deg) / 2.0

# Build the sweeping path (arc)
path = (
    cq.Workplane("XY")
    .radiusArc((linear_width, 0.0), center_radius)
    .wire()
)

# Main block swept along arc with features
model = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -secant_angle, 0))
    .rect(block_depth, block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(1.5)
    .edges(">Z")
    .fillet(0.8)
    .faces(">Z")
    .workplane()
    # Threaded insert pocket (simple cylindrical pocket)
    .center(0, 0)
    .hole(thread_diameter, thread_depth)
    .edges("<<Z")
    .chamfer(chamfer_size)
    # Laser‑etched identification on top surface
    .faces(">Z")
    .workplane()
    .text(engrave_text, fontsize=engrave_fontsize, distance=engrave_depth, cut=True)
)

result = model