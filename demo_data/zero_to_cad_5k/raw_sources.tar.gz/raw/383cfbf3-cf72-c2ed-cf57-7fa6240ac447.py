import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 2.0
fold_height = 4.0
fold_tab_length = 48.0
pin_radius = 2.0
tip_fillet_radius = 0.1
rib_width = 5.0
rib_length_factor = 0.8
rib_height = leaf_thickness / 2.0
chamfer_dist = 0.2

base = cq.Workplane('XY').rect(leaf_length, leaf_width).extrude(leaf_thickness)
base = base.faces('>Z').workplane().hole(pin_radius * 2)

tab = cq.Workplane('XY').rect(fold_tab_length, fold_height).extrude(leaf_thickness)
tab = tab.translate((0, leaf_width / 2.0 + fold_height / 2.0, 0))
tab = tab.rotate((0, leaf_width / 2.0, leaf_thickness), (1, 0, 0), 90)

rib_length = leaf_length * rib_length_factor
rib = cq.Workplane('XY').rect(rib_length, rib_width).extrude(rib_height)
rib = rib.translate((0, 0, -rib_height))

result = base.union(tab).union(rib)
result = result.faces('>Z').edges().chamfer(chamfer_dist)
result = result.faces('>X').edges().fillet(tip_fillet_radius)
