import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        plate_x = m.horizontal_length + m.leg_width
        plate_y = m.vertical_length + m.leg_width
        base = (
            cq.Workplane("XY")
            .box(plate_x, plate_y, m.thickness)
            .translate((plate_x / 2, plate_y / 2, 0))
        )
        cut = (
            cq.Workplane("XY")
            .box(m.horizontal_length, m.vertical_length, m.thickness + 0.1)
            .translate((m.leg_width + m.horizontal_length / 2, m.leg_width + m.vertical_length / 2, 0))
        )
        l_shape = base.cut(cut)
        # Fillet inner concave vertical edge
        l_shape = (
            l_shape.edges("|Z and <X")
            .fillet(m.inner_fillet_radius)
        )
        # Fillet inner concave horizontal edge
        l_shape = (
            l_shape.edges("|Z and <Y")
            .fillet(m.inner_fillet_radius)
        )
        # Add through hole on horizontal leg
        hole_x = m.leg_width + m.hole_offset_along_horiz
        hole_y = m.leg_width / 2
        l_shape = (
            l_shape.faces(">Z")
            .workplane()
            .center(hole_x, hole_y)
            .hole(m.hole_diameter)
        )
        # Reinforcing rib on vertical leg
        rib = (
            cq.Workplane("XY")
            .rect(m.rib_width, m.rib_height)
            .extrude(m.thickness)
            .translate((m.rib_offset_x, m.rib_offset_y, 0))
        )
        self.model = l_shape.union(rib)

measures = Measures(
    horizontal_length=70.0,
    vertical_length=50.0,
    leg_width=15.0,
    thickness=6.0,
    inner_fillet_radius=5.0,
    hole_diameter=6.0,
    hole_offset_along_horiz=30.0,
    rib_width=10.0,
    rib_height=20.0,
    rib_offset_x=5.0,
    rib_offset_y=20.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
