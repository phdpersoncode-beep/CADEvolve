import cadquery as cq

# Parameters
chute_leg_height = 45.0
chute_outer_diameter = 68.0
chute_wall_thickness = 3.0
chute_bottom_thickness = 4.0
chute_chamfer_distance = 5.0
mount_hole_diameter = 5.0
mount_hole_offset = 12.0
rib_height = 10.0
rib_width = 6.0
rib_thickness = 2.0

# Derived radius
r_outer = chute_outer_diameter / 2.0

# Outer profile for revolve
outer_profile = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(0, chute_leg_height)
    .lineTo(r_outer, chute_leg_height)
    .lineTo(r_outer, chute_bottom_thickness)
    .lineTo(0, chute_bottom_thickness)
    .close()
)

solid = outer_profile.revolve()

hollow = solid.shell(-chute_wall_thickness)

chamfered = (
    hollow
    .faces(">Z")
    .edges()
    .chamfer(chute_chamfer_distance)
)

# Rib positioned with overlap for solid fusion
rib = (
    cq.Workplane('YZ')
    .rect(rib_height, rib_width)
    .extrude(rib_thickness)
    .translate((r_outer - rib_thickness/2.0, 0, chute_leg_height / 2.0))
)

with_rib = chamfered.union(rib)

with_hole = (
    with_rib
    .faces("<Z")
    .workplane()
    .center(mount_hole_offset, 0)
    .hole(mount_hole_diameter)
)

result = with_hole