import cadquery as cq
import math

# Parameters
arc_outer_diameter = 80.0
arc_thickness = 12.0
block_height = 20.0
linear_width = 50.0
fillet_radius = 5.0
hole_diameter = 6.0
hole_offset_width = 20.0
hole_offset_height = 8.0
pocket_width = 14.0
pocket_height = 10.0
pocket_depth = 6.0
pocket_offset_width = 15.0
pocket_offset_height = 5.0
chamfer_distance = 1.0

# Derived measures
arc_outer_radius = 0.5 * arc_outer_diameter
arc_center_diameter = arc_outer_diameter - arc_thickness
arc_center_radius = 0.5 * arc_center_diameter
arc_center_angle = math.degrees(math.acos((2 * arc_center_radius**2 - linear_width**2) / (2 * arc_center_radius**2)))
arc_secant_angle = 0.5 * (180.0 - arc_center_angle)

# Sweep path (arc)
path = (
    cq.Workplane("XY")
    .radiusArc((linear_width, 0.0), arc_center_radius)
    .wire()
)

# Cross‑section profile: rectangle
profile = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -arc_secant_angle, 0))
    .rect(arc_thickness, block_height)
)

# Sweep the profile along the arc path
swept = profile.sweep(path, transition="round")

# Apply fillet approximating a 75° angular fillet
filleted = swept.edges("|Z").fillet(fillet_radius)

# Add rectangular pocket and chamfer its edges
with_pocket = (
    filleted
    .faces(">Z")
    .workplane()
    .center(pocket_offset_width - linear_width/2, pocket_offset_height - block_height/2)
    .rect(pocket_width, pocket_height)
    .cutBlind(pocket_depth)
    .edges()
    .chamfer(chamfer_distance)
)

# Add through hole
result = (
    with_pocket
    .faces(">Z")
    .workplane()
    .center(hole_offset_width - linear_width/2, hole_offset_height - block_height/2)
    .hole(hole_diameter)
)
