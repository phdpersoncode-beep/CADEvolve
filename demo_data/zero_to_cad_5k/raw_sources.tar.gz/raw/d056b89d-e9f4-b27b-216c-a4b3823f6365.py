import cadquery as cq
leg_width=30.0
thickness=10.0
notch_w=5.0
notch_d=3.0
profile_coords = [
    (0,0),
    (leg_width,0),
    (leg_width,thickness),
    (leg_width-notch_w,thickness),
    (leg_width-notch_w,thickness-notch_d),
    (notch_w,thickness-notch_d),
    (notch_w,thickness),
    (0,thickness),
    (0,0)
]
result = (
    cq.Workplane('XY')
    .polyline(profile_coords)
    .close()
    .workplane()
    .transformed(offset=cq.Vector(0, leg_width, 0), rotate=(0,90,0))
    .polyline(profile_coords)
    .close()
    .loft()
)
