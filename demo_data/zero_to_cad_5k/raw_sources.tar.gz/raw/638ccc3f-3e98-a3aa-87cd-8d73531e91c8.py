import cadquery as cq
from math import acos, degrees

# Parameters
linear_width = 55.0
depth = 12.0
height = 10.0
arc_outer_diameter = 90.0
vertical_fillet_radius = 1.2
top_fillet_radius = 1.0
outer_fillet_radius = 2.0
hole_pitch = 20.0
hole_count = 4
hole_diameter = 4.0
hole_head_diameter = 7.0
hole_head_height = 4.0
pocket_width = 8.0
pocket_height = 6.0
pocket_depth = 4.0
pocket_offset_along = 30.0
pocket_offset_side = 3.0

# Derived measures
arc_outer_radius = 0.5 * arc_outer_diameter
arc_center_radius = arc_outer_radius - depth
# law of cosines for central angle of the secant that spans linear_width
arc_center_angle = degrees(acos((2 * arc_center_radius**2 - linear_width**2) / (2 * arc_center_radius**2)))
arc_secant_angle = 0.5 * (180.0 - arc_center_angle)

# Path for sweep (arc)
path = (
    cq.Workplane("XY")
    .radiusArc((linear_width, 0.0), arc_center_radius)
    .wire()
)

# Sweep the rectangular section along the arc
swept = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -arc_secant_angle, 0))
    .rect(depth, height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(vertical_fillet_radius)
    .edges(">Z")
    .fillet(top_fillet_radius)
    .edges()
    .fillet(outer_fillet_radius)
)

# Add a side pocket (notch) for functional purpose
with_pocket = (
    swept.faces(">Z")
    .workplane()
    .center(pocket_offset_along - linear_width/2, pocket_offset_side - depth/2)
    .rect(pocket_width, pocket_height)
    .cutBlind(pocket_depth)
)

# Add a series of tapped holes along the top surface
result = with_pocket
for i in range(hole_count):
    offset = -linear_width/2 + (i + 1) * hole_pitch
    result = (
        result.faces(">Z")
        .workplane()
        .center(offset, 0)
        .cboreHole(hole_diameter, hole_head_diameter, hole_head_height)
    )
