import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    base_flat_width=55.0,
    base_thickness=8.0,
    hex_radius=55.0/(2*0.8660254037844386),
    boss_radius=8.0,
    boss_height=6.0,
    pilot_hole_diameter=2.0,
    pilot_cbore_diameter=4.0,
    pilot_cbore_depth=2.0,
    pilot_spacing=12.0,
    array_rows=3,
    array_cols=3,
    chamfer=1.0
)

hex_base = (
    cq.Workplane("XY")
    .polygon(6, m.hex_radius * 2)  # polygon expects distance across vertices, use diameter = 2*radius
    .extrude(m.base_thickness)
    .faces(">Z")
    .workplane()
    .circle(m.boss_radius)
    .extrude(m.boss_height)
    .edges("<<Z")
    .chamfer(m.chamfer)
)

# create pilot holes pattern on top face of base (above boss)
pilot_plane = hex_base.faces(">Z").workplane()

# Generate grid of points centered, offset by half spacing
row_offset = -(m.array_rows-1)*m.pilot_spacing/2
col_offset = -(m.array_cols-1)*m.pilot_spacing/2
points = []
for i in range(m.array_rows):
    for j in range(m.array_cols):
        points.append((col_offset + j*m.pilot_spacing, row_offset + i*m.pilot_spacing))

pilot_holes = (
    pilot_plane
    .pushPoints(points)
    .cboreHole(m.pilot_hole_diameter, m.pilot_cbore_diameter, m.pilot_cbore_depth)
)

result = pilot_holes
