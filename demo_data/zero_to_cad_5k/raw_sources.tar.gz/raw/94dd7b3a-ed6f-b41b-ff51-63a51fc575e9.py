import cadquery as cq

length = 80.0
flange_width = 50.0
flange_thickness = 5.0
web_height = 30.0
web_thickness = 3.0
hole_diameter = 4.0
hole_spacing = 20.0
slot_width = 4.0
slot_height = 12.0
chamfer_size = 1.0

half_i_pts = [
    (0, (flange_thickness + web_height + flange_thickness) / 2),
    (flange_width / 2, (flange_thickness + web_height + flange_thickness) / 2),
    (flange_width / 2, (flange_thickness + web_height + flange_thickness) / 2 - flange_thickness),
    (web_thickness / 2, (flange_thickness + web_height + flange_thickness) / 2 - flange_thickness),
    (web_thickness / 2, -(flange_thickness + web_height + flange_thickness) / 2 + flange_thickness),
    (flange_width / 2, -(flange_thickness + web_height + flange_thickness) / 2 + flange_thickness),
    (flange_width / 2, -(flange_thickness + web_height + flange_thickness) / 2),
    (0, -(flange_thickness + web_height + flange_thickness) / 2)
]

base_beam = (
    cq.Workplane("XY")
    .polyline(half_i_pts)
    .mirrorY()
    .extrude(length)
)

chamfered_beam = (
    base_beam
    .edges("|Z")
    .chamfer(chamfer_size)
)

# Add mounting holes on top flange (centered on each flange)
holes = (
    chamfered_beam
    .faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .pushPoints([
        (-flange_width/2 + flange_thickness/2, 0),
        (flange_width/2 - flange_thickness/2, 0)
    ])
    .hole(hole_diameter)
)

# Central slot through web from both side faces
slot = (
    holes
    .faces(">X")
    .workplane(centerOption="CenterOfMass")
    .rect(slot_width, (flange_thickness + web_height + flange_thickness))
    .cutBlind(-length)
)

result = slot