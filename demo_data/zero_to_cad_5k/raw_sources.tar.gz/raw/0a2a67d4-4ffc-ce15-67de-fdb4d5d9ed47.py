import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 4.0
rib_width = 12.0
rib_extra_height = 2.0
cutout_width = 8.0
cutout_offset_from_end = 20.0
chamfer_distance = 1.0
mount_hole_diameter = 5.0
mount_hole_spacing = 30.0
mount_hole_offset = 10.0

base_plate = (
    cq.Workplane('XY')
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)

central_rib = (
    cq.Workplane('XY')
    .rect(leaf_length, rib_width)
    .extrude(leaf_thickness + rib_extra_height)
)

plate_with_rib = base_plate.union(central_rib)

with_slot = (
    plate_with_rib
    .faces('>Z')
    .workplane()
    .center(leaf_length/2 - cutout_offset_from_end - cutout_width/2, 0)
    .rect(cutout_width, leaf_width)
    .cutBlind(leaf_thickness + rib_extra_height)
)

with_holes = (
    with_slot
    .faces('>Z')
    .workplane()
    .pushPoints([(-mount_hole_spacing/2, mount_hole_offset), (mount_hole_spacing/2, mount_hole_offset)])
    .hole(mount_hole_diameter)
)

result = (
    with_holes
    .edges('|Z')
    .chamfer(chamfer_distance)
)
