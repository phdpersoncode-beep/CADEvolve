import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    leg_length=30.0,
    web_thickness=3.0,
    relief_cut_depth=6.0,
    relief_cut_width=3.0,
    hole_diameter=5.0,
    hole_offset=6.0,
    chamfer=0.5,
    gusset_thickness=2.0,
    include_gusset=True,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        hor = (
            cq.Workplane("XY")
            .box(m.leg_length, m.web_thickness, m.web_thickness)
            .translate((m.leg_length / 2, 0, 0))
        )
        vert = (
            cq.Workplane("XY")
            .box(m.web_thickness, m.leg_length, m.web_thickness)
            .translate((0, m.leg_length / 2, 0))
        )
        base = hor.union(vert)
        base = (
            base.faces(">X")
            .workplane()
            .rect(m.relief_cut_width, m.web_thickness)
            .cutBlind(-m.relief_cut_depth)
        )
        base = (
            base.faces(">Z")
            .workplane()
            .pushPoints([(m.hole_offset, m.hole_offset)])
            .hole(m.hole_diameter)
        )
        base = base.edges("|Z").chamfer(m.chamfer)
        if m.include_gusset:
            gusset = (
                cq.Workplane("XY")
                .polyline([
                    (0, 0),
                    (m.gusset_thickness, 0),
                    (0, m.gusset_thickness),
                ])
                .close()
                .extrude(m.web_thickness)
                .translate((m.gusset_thickness / 2, m.gusset_thickness / 2, 0))
            )
            base = base.union(gusset)
        self.model = base

result = LBracket(cq.Workplane("XY"), m).model
