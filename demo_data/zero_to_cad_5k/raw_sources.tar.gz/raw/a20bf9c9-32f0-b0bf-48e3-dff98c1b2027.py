import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L shape sketch and extrusion
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_length + m.leg_width, 0)
            .lineTo(m.leg_length + m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.leg_height)
            .lineTo(0, m.leg_height)
            .close()
            .extrude(m.thickness)
        )
        # Add mounting holes on horizontal leg (pattern)
        holes = (
            base.faces("<Z")
            .workplane(centerOption="CenterOfBoundBox")
            .moveTo(m.leg_length / 2, -m.thickness / 2 + m.hole_edge_margin)
            .rect(m.hole_spacing, m.hole_spacing, forConstruction=True)
            .vertices()
            .cboreHole(m.hole_clearance, m.hole_cbore_diameter, m.hole_cbore_depth)
        )
        # Recessed boss on vertical leg front face
        boss = (
            holes.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.boss_offset_x, m.boss_offset_z)
            .rect(m.boss_width, m.boss_height)
            .cutBlind(-m.boss_depth)
        )
        # Mounting hole inside boss
        final = (
            boss.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.boss_offset_x, m.boss_offset_z)
            .hole(m.boss_hole_diameter)
            .edges("|Z")
            .chamfer(m.chamfer)
        )
        self.model = final

measures = Measures(
    leg_height=80.0,
    leg_length=60.0,
    leg_width=15.0,
    thickness=8.0,
    hole_clearance=4.0,
    hole_cbore_diameter=6.0,
    hole_cbore_depth=2.0,
    hole_spacing=30.0,
    hole_edge_margin=5.0,
    boss_offset_x=7.5,
    boss_offset_z=30.0,
    boss_width=10.0,
    boss_height=20.0,
    boss_depth=4.0,
    boss_hole_diameter=3.0,
    chamfer=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model