import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, m):
        self.wp = wp
        self.m = m
        self.build()

    def build(self):
        m = self.m
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_height),
                (0, m.vertical_height),
                (0, 0)
            ])
            .close()
            .extrude(m.bracket_depth)
            .edges()
            .chamfer(m.chamfer_distance)
        )
        hole_face = base.faces('>Y')
        hole_wp = hole_face.workplane(centerOption='CenterOfBoundBox')
        hole_positions = [
            (m.horizontal_length/2 - m.mount_hole_spacing/2, m.leg_thickness/2),
            (m.horizontal_length/2 + m.mount_hole_spacing/2, m.leg_thickness/2)
        ]
        base = hole_wp.pushPoints(hole_positions).cboreHole(
            m.mount_hole_diameter, m.mount_cbore_diameter, m.mount_cbore_depth
        )
        cutout_face = base.faces('>Y')
        num_rows = m.cutout_rows
        spacing = (
            (m.vertical_height - 2 * m.cutout_margin - num_rows * m.cutout_height)
            / (num_rows - 1) if num_rows > 1 else 0
        )
        base = (
            cutout_face.workplane(centerOption='CenterOfBoundBox')
            .move(0, (m.vertical_height - m.leg_thickness) / 2)
            .rarray(0, spacing, 1, num_rows)
            .rect(m.cutout_width, m.cutout_height)
            .cutThruAll()
        )
        self.model = base

measures = Measures(
    horizontal_length=80.0,
    vertical_height=70.0,
    leg_thickness=12.0,
    bracket_depth=10.0,
    chamfer_distance=1.0,
    mount_hole_diameter=5.0,
    mount_cbore_diameter=8.0,
    mount_cbore_depth=2.0,
    mount_hole_spacing=30.0,
    cutout_width=6.0,
    cutout_height=8.0,
    cutout_rows=4,
    cutout_margin=5.0,
)

result = LBracket(cq.Workplane('XY'), measures).model