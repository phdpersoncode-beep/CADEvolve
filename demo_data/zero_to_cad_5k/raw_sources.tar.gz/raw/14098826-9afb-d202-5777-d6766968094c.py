import cadquery as cq

# Parameters
outer_diameter = 80.0
thickness = 10.0
hub_diameter = 30.0
central_recess_depth = 4.0
fillet_radius = 2.0
hole_diameter = 4.6
hole_circle_radius = (hub_diameter/2.0 + outer_diameter/2.0) / 2.0
hole_count = 6
rib_width = 6.0
rib_thickness = 3.0
chamfer_distance = 1.0
recess_margin = 5.0

half_outer_radius = outer_diameter / 2.0
half_hub_radius = hub_diameter / 2.0

# Base flange profile (XZ) with composite shape
profile = (
    cq.Workplane('XZ')
    .moveTo(half_outer_radius, 0)
    .lineTo(half_hub_radius, 0)
    .threePointArc((half_hub_radius - 1.0, thickness / 2.0), (half_hub_radius, thickness))
    .lineTo(half_outer_radius, thickness)
    .close()
)
flange = profile.revolve()

# Rectangular central recess with fillet on its perimeter (fillet applied before cut)
recess_width = (half_hub_radius - recess_margin) * 2.0
pocket = (
    cq.Workplane('XY')
    .center(0, 0)
    .rect(recess_width, recess_width)
    .extrude(-central_recess_depth)
    .edges('|Z')
    .fillet(fillet_radius)
)
flange = flange.cut(pocket)

# Six M4 clearance holes on top face
flange = (
    flange.faces('>Z')
    .workplane()
    .circle(hole_circle_radius)
    .polarArray(hole_circle_radius, 0, 360, hole_count)
    .hole(hole_diameter)
)

# Four ribs for stiffness, spaced every 90 degrees
rib_base = (
    cq.Workplane('XY')
    .center(half_hub_radius, 0)
    .rect(rib_width, rib_thickness)
    .extrude(thickness)
)
rib_pattern = rib_base
for i in range(1, 4):
    angle = 90 * i
    rib_pattern = rib_pattern.union(rib_base.rotate((0, 0, 0), (0, 0, 1), angle))
flange = flange.union(rib_pattern)

# Chamfer outer rim for safety
flange = flange.edges('>Z').chamfer(chamfer_distance)

result = flange