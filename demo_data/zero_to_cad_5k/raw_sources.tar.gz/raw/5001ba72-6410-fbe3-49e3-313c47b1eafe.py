import cadquery as cq

gear_height = 12.0
outer_radius = 35.0
bore_diameter = 6.0
num_teeth = 28
tooth_width = 4.0
tooth_depth = 6.0
tooth_slant = 10.0
mounting_hole_dia = 4.0
mounting_radius = outer_radius * 0.6
mounting_count = 6
chamfer_dist = 0.5

# Base disc
base = (
    cq.Workplane('XY')
    .circle(outer_radius)
    .extrude(gear_height)
)
# Central bore
base = base.faces('>Z').workplane().hole(bore_diameter)
# Teeth pattern before extrusion
teeth = (
    cq.Workplane('XY')
    .rect(tooth_width, tooth_depth)
    .rotate((0, 0, 0), (0, 0, 1), tooth_slant / 2)
    .translate((outer_radius - tooth_depth / 2, 0, 0))
    .polarArray(radius=outer_radius - tooth_depth / 2, startAngle=0, angle=360, count=num_teeth)
    .extrude(gear_height + 0.2)
)
gear = base.cut(teeth)
# Mounting holes pattern before extrusion
mount_holes = (
    cq.Workplane('XY')
    .circle(mounting_hole_dia / 2)
    .polarArray(radius=mounting_radius, startAngle=0, angle=360, count=mounting_count)
    .extrude(gear_height + 0.2)
)
gear = gear.cut(mount_holes)
# Chamfer edges on the top face perimeter
gear = gear.faces('>Z').edges().chamfer(chamfer_dist)

result = gear
