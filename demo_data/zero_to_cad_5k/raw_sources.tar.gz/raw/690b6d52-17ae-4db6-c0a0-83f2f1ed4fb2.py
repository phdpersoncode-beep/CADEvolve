import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # create L-shaped profile
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness, m.vertical_leg_length)
            .lineTo(0, m.vertical_leg_length)
            .close()
        )
        solid = (
            profile.extrude(m.bracket_thickness)
            .edges("<Z or >Z")
            .fillet(m.internal_fillet_radius)
        )
        # add boss at outer corner (0,0)
        boss = (
            cq.Workplane("XY")
            .center(0, 0)
            .circle(m.boss_diameter / 2)
            .extrude(m.boss_height)
        )
        solid = solid.union(boss)
        # add through hole on horizontal leg
        hole_center_x = m.horizontal_leg_length / 2
        solid = (
            solid.faces(">Z")
            .workplane()
            .center(hole_center_x, m.leg_thickness / 2)
            .hole(m.through_hole_diameter)
        )
        # add two counterbore mounting holes on vertical leg
        vertical_hole_y = m.vertical_leg_length * 0.75
        spacing = m.leg_thickness * 1.5
        solid = (
            solid.faces(">Z")
            .workplane()
            .center(m.leg_thickness / 2, vertical_hole_y)
            .cboreHole(m.mount_hole_clearance, m.mount_hole_cbore_diameter, m.mount_hole_cbore_depth)
            .center(-spacing, 0)
            .cboreHole(m.mount_hole_clearance, m.mount_hole_cbore_diameter, m.mount_hole_cbore_depth)
        )
        # add internal rib on vertical leg for stiffness
        rib = (
            cq.Workplane("XY")
            .moveTo(m.leg_thickness * 0.8, m.vertical_leg_length * 0.4)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.bracket_thickness)
        )
        solid = solid.union(rib)
        self.model = solid

measures = Measures(
    horizontal_leg_length=70.0,
    vertical_leg_length=60.0,
    leg_thickness=8.0,
    bracket_thickness=10.0,
    internal_fillet_radius=2.0,
    boss_diameter=6.0,
    boss_height=6.0,
    through_hole_diameter=4.0,
    mount_hole_clearance=4.5,
    mount_hole_cbore_diameter=7.0,
    mount_hole_cbore_depth=2.5,
    rib_width=5.0,
    rib_height=30.0,
)

result = LBracket(cq.Workplane("XY"), measures).model