import cadquery as cq

outer_length = 70
outer_width = 40
height = 80
wall_thickness = 2

base = cq.Workplane('XY').box(outer_length, outer_width, height)
holder_shell = base.faces('+Z').shell(wall_thickness)
result = holder_shell
