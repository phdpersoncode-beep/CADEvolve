import cadquery as cq

outer_dia = 80
body_len = 70
wall_thk = 5
seal_pocket_dia = 40
seal_pocket_depth = 20
vent_slot_len = 30
vent_slot_wid = 8
vent_fillet_rad = 2
nut_hole_dia = 15
counterbore_dia = 30
counterbore_depth = 12
flange_dia = 100
flange_thk = 5
chamfer_dist = 1

outer_rad = outer_dia / 2.0
inner_rad = outer_rad - wall_thk
flange_rad = flange_dia / 2.0

total_height = body_len + flange_thk

outer_body = (
    cq.Workplane("XY")
    .circle(outer_rad)
    .extrude(body_len)
)

inner_cut = (
    cq.Workplane("XY")
    .circle(inner_rad)
    .extrude(body_len)
)

body = outer_body.cut(inner_cut)

flange = (
    cq.Workplane("XY")
    .circle(flange_rad)
    .extrude(flange_thk)
    .translate((0, 0, body_len))
)

body_with_flange = body.union(flange)

seal_pocket = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(seal_pocket_dia / 2.0)
    .extrude(seal_pocket_depth)
    .translate((0, 0, body_len - seal_pocket_depth))
)

vent_slot = (
    cq.Workplane("YZ", origin=(outer_rad - wall_thk / 2.0, 0, body_len / 2.0))
    .sketch()
    .rect(vent_slot_len, vent_slot_wid)
    .vertices()
    .fillet(vent_fillet_rad)
    .finalize()
    .extrude(-wall_thk)
)

counterbore_cut = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(counterbore_dia / 2.0)
    .extrude(counterbore_depth)
)

nut_hole_cut = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(nut_hole_dia / 2.0)
    .extrude(total_height)
)

result = (
    body_with_flange
    .cut(seal_pocket)
    .cut(vent_slot)
    .cut(counterbore_cut)
    .cut(nut_hole_cut)
    .faces(">Z")
    .edges()
    .chamfer(chamfer_dist)
)
