import cadquery as cq
import math

outer_diameter = 80.0
inner_diameter_small = 30.0
inner_diameter_large = 40.0
thickness = 12.0
step_height = 4.0
shell_thickness = 1.0
chamfer_size = 0.5
mount_hole_diameter = 5.0
mount_hole_count = 4
mount_hole_offset = outer_diameter / 2 - 10.0

inner_radius_small = inner_diameter_small / 2.0
inner_radius_large = inner_diameter_large / 2.0
outer_radius = outer_diameter / 2.0

profile = (
    cq.Workplane("XZ")
    .polyline([
        (inner_radius_small, 0),
        (inner_radius_small, thickness - step_height),
        (inner_radius_large, thickness - step_height),
        (inner_radius_large, thickness),
        (outer_radius, thickness),
        (outer_radius, 0)
    ])
    .close()
)

solid = profile.revolve()

chamfered = solid.edges(">Z").chamfer(chamfer_size)

washer = chamfered.shell(shell_thickness)

boss = (
    cq.Workplane("XY")
    .circle(outer_radius - shell_thickness - 1)
    .circle(outer_radius - shell_thickness - 3)
    .extrude(1.0)
)

washer_with_boss = washer.union(boss)

hole_positions = [
    (mount_hole_offset * math.cos(i * 2 * math.pi / mount_hole_count),
     mount_hole_offset * math.sin(i * 2 * math.pi / mount_hole_count))
    for i in range(mount_hole_count)
]

result = (
    washer_with_boss
    .faces(">Z")
    .workplane()
    .pushPoints(hole_positions)
    .hole(mount_hole_diameter)
)
