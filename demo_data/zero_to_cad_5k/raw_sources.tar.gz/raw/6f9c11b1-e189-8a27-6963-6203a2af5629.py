import cadquery as cq
from math import sin, radians, degrees
from types import SimpleNamespace as NS

# Parameters
o = NS(
    arc_center_radius=40.0,
    arc_angle_deg=115.0,
    block_thickness=10.0,
    block_height=12.0,
    chamfer=0.8,
    set_screw_diameter=4.0,
    set_screw_head_diameter=7.0,
    set_screw_head_height=4.0,
    bolt_diameter=4.2,
    bolt_head_diameter=8.0,
    bolt_head_height=4.0,
    bolt_spacing=30.0,
    bolt_offset=15.0
)

# Derived values
o.arc_center_angle = o.arc_angle_deg
o.chord_length = 2 * o.arc_center_radius * sin(radians(o.arc_center_angle) / 2)
o.arc_secant_angle = 0.5 * (180.0 - o.arc_center_angle)

# Path for sweep
path = (
    cq.Workplane("XY")
    .radiusArc((o.chord_length, 0.0), o.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -o.arc_secant_angle, 0))
    .rect(o.block_thickness, o.block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(o.chamfer)
    .edges("<Z")
    .chamfer(o.chamfer / 2)
    # Recessed set screw on inner flat face
    .faces("-X")
    .workplane()
    .center(0, 0)
    .cboreHole(o.set_screw_diameter, o.set_screw_head_diameter, o.set_screw_head_height)
    # Two mounting bolt holes symmetric about center on same face
    .rarray(o.bolt_spacing, 0, 2, 1)
    .cboreHole(o.bolt_diameter, o.bolt_head_diameter, o.bolt_head_height)
)
