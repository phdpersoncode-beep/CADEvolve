import cadquery as cq

# Parameters
length = 80.0
width = 40.0
thickness = 8.0
rib_height = 4.0
rib_width = 6.0
rib_spacing = 12.0
hole_diameter = 12.0
hole_offset_x = 30.0
hole_offset_y = 0.0
chamfer_distance = thickness * 0.57735
notch_width = 15.0
notch_depth = 10.0
mount_hole_diameter = 5.0
mount_hole_offset = 10.0
pocket_width = 30.0
pocket_depth = 20.0
pocket_depth_z = 3.0

# Base plate (extruded from XY plane, bottom at Z=0)
base = (
    cq.Workplane("XY")
    .box(length, width, thickness, centered=(True, True, False))
)

# 30-degree chamfer on outer vertical edges
base = base.edges("|Z").chamfer(chamfer_distance)

# Notch on one short side for clearance
base = (
    base.faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .center(-length/2 + notch_width/2, 0)
    .rect(notch_width, notch_depth)
    .cutBlind(-thickness)
)

# Clearance hole through bracket
base = (
    base.faces(">Z")
    .workplane()
    .center(hole_offset_x - length/2, hole_offset_y)
    .hole(hole_diameter)
)

# Mounting holes pattern (four corners)
mount_positions = [
    (-length/2 + mount_hole_offset, -width/2 + mount_hole_offset),
    (-length/2 + mount_hole_offset, width/2 - mount_hole_offset),
    (length/2 - mount_hole_offset, -width/2 + mount_hole_offset),
    (length/2 - mount_hole_offset, width/2 - mount_hole_offset),
]
for x, y in mount_positions:
    base = (
        base.faces(">Z")
        .workplane()
        .center(x, y)
        .hole(mount_hole_diameter)
    )

# Top recessed pocket
base = (
    base.faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(pocket_width, pocket_depth)
    .cutBlind(-pocket_depth_z)
)

# Back plate attached to bottom of base
back_plate = (
    cq.Workplane("XY")
    .box(length, width, rib_height, centered=(True, True, False))
    .translate((0, 0, -rib_height))
)

# Rib pattern on top of back plate (extends upward into base for solid union)
num_ribs = int((width - rib_spacing) // (rib_width + rib_spacing))
ribs = cq.Workplane("XY")
for i in range(num_ribs):
    y_off = -width/2 + rib_spacing + i * (rib_width + rib_spacing) + rib_width/2
    rib = (
        cq.Workplane("XZ")
        .center(0, y_off)
        .rect(length, rib_width)
        .extrude(rib_height + 1.0)  # slight penetration into base for fusion
    )
    ribs = ribs.union(rib)

# Combine all components into final part
result = base.union(back_plate).union(ribs)
