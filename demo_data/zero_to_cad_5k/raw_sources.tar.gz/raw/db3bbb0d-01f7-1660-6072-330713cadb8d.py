import cadquery as cq
box = cq.Workplane('XY').box(20,20,20)
result = box.edges('|Z and >X').chamfer(2)
