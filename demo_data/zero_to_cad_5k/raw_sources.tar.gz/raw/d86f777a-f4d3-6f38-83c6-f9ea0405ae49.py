import cadquery as cq

base_width = 80.0
base_depth = 60.0
base_thickness = 5.0
base_chamfer = 1.0
frame_thickness = 6.0
frame_height = 15.0
frame_chamfer = 0.8
top_fillet = 0.5
screw_hole_diameter = 4.0
screw_hole_radius = screw_hole_diameter / 2.0
num_holes = 6
hole_margin = 8.0

# Base plate
base = (
    cq.Workplane("XY")
    .box(base_width, base_depth, base_thickness, centered=(True, True, False))
    .edges("|Z")
    .chamfer(base_chamfer)
)

# L-shaped frame leg 1 (horizontal)
leg1 = (
    cq.Workplane("XY")
    .transformed(offset=(0, -base_depth/2 + frame_thickness/2, base_thickness))
    .box(base_width, frame_thickness, frame_height, centered=(True, True, False))
    .edges("|Z")
    .chamfer(frame_chamfer)
    .faces(">Z")
    .edges()
    .fillet(top_fillet)
)

# L-shaped frame leg 2 (vertical)
leg2 = (
    cq.Workplane("XY")
    .transformed(offset=(-base_width/2 + frame_thickness/2, 0, base_thickness))
    .box(frame_thickness, base_depth, frame_height, centered=(True, True, False))
    .edges("|Z")
    .chamfer(frame_chamfer)
    .faces(">Z")
    .edges()
    .fillet(top_fillet)
)

# Combine base and frame
result = base.union(leg1).union(leg2)

# Compute screw hole positions
spacing_x = (base_width - 2 * hole_margin) / (num_holes - 1)
points_leg1 = [
    (-base_width/2 + hole_margin + i * spacing_x, -base_depth/2 + frame_thickness/2)
    for i in range(num_holes)
]
spacing_y = (base_depth - 2 * hole_margin) / (num_holes - 1)
points_leg2 = [
    (-base_width/2 + frame_thickness/2, -base_depth/2 + hole_margin + i * spacing_y)
    for i in range(num_holes)
]
all_points = points_leg1 + points_leg2

# Add screw holes through the frame height
result = (
    result
    .faces(">Z")
    .workplane()
    .pushPoints(all_points)
    .circle(screw_hole_radius)
    .cutBlind(-frame_height)
)
