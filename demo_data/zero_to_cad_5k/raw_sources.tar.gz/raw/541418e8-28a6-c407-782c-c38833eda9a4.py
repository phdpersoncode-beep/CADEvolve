
import cadquery as cq
import math

outer_diameter = 80.0
inner_diameter = 30.0
washer_thickness = 5.0
chamfer_distance = 0.15
star_points = 5
star_outer_factor = 0.85
star_inner_factor = 0.4
tab_width = 8.0
tab_height = 4.0
tab_depth = washer_thickness
mount_hole_diameter = 4.0
mount_hole_offset = 25.0

outer_radius = outer_diameter / 2.0
inner_radius = inner_diameter / 2.0
star_outer_radius = inner_radius * star_outer_factor
star_inner_radius = inner_radius * star_inner_factor

def generate_star_points(num_points, outer_r, inner_r):
    pts = []
    angle_step = 360.0 / (num_points * 2)
    for i in range(num_points * 2):
        r = outer_r if i % 2 == 0 else inner_r
        angle_deg = i * angle_step
        angle_rad = math.radians(angle_deg)
        x = r * math.cos(angle_rad)
        y = r * math.sin(angle_rad)
        pts.append((x, y))
    return pts

star_pts = generate_star_points(star_points, star_outer_radius, star_inner_radius)

# Core washer via revolve (axis along Y)
washer_core = (
    cq.Workplane("XZ")
    .moveTo(outer_radius, 0)
    .lineTo(outer_radius, washer_thickness)
    .lineTo(inner_radius, washer_thickness)
    .lineTo(inner_radius, 0)
    .close()
    .revolve()
)

# Add four rectangular tabs around the outer perimeter
for angle in [0, 90, 180, 270]:
    tab = (
        cq.Workplane("XY")
        .center(outer_radius - tab_height / 2, 0)
        .rect(tab_width, tab_depth)
        .extrude(tab_height)
        .rotate((0, 0, 0), (0, 0, 1), angle)
    )
    washer_core = washer_core.union(tab)

# Add mounting countersunk holes on each tab using cylinders
for angle in [0, 90, 180, 270]:
    hole_cyl = (
        cq.Workplane("XY")
        .center(mount_hole_offset, 0)
        .circle(mount_hole_diameter / 2)
        .extrude(washer_thickness * 2)
        .rotate((0, 0, 0), (0, 0, 1), angle)
    )
    washer_core = washer_core.cut(hole_cyl)

# Star cutout through entire thickness
star_solid = (
    cq.Workplane("XY")
    .polyline(star_pts)
    .close()
    .extrude(washer_thickness)
)
washer_core = washer_core.cut(star_solid)

# Apply chamfer to cylindrical outer and inner edges (parallel to Y)
washer_core = washer_core.edges("|Y").chamfer(chamfer_distance)

result = washer_core
