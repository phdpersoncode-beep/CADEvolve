import cadquery as cq
import math

# Parameters
outer_diameter = 100.0
plate_thickness = 6.0
star_points = 5
star_outer_radius = 35.0
star_inner_radius = 15.0
blind_hole_diameter = 9.0
blind_hole_depth = plate_thickness * 0.8
chamfer_size = 0.8
mount_hole_diameter = 6.0
mount_hole_radius = outer_diameter/2 - 12.0
rib_width = 8.0
rib_depth = plate_thickness * 0.5
rib_spacing_angle = 30.0

# Base circular plate
result = (
    cq.Workplane("XY")
    .circle(outer_diameter/2)
    .extrude(plate_thickness)
)

# Star cutout (through)
angle_step = math.pi / star_points
pts = []
for i in range(2*star_points):
    r = star_outer_radius if i % 2 == 0 else star_inner_radius
    angle = i * angle_step
    pts.append((r*math.cos(angle), r*math.sin(angle)))
star_cut = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .extrude(-plate_thickness)
)
result = result.cut(star_cut)

# Central blind hole
result = (
    result.faces(">Z").workplane()
    .hole(blind_hole_diameter, blind_hole_depth)
)

# Peripheral mounting holes (4 equally spaced)
mount_pts = []
for i in range(4):
    angle = math.radians(i*90)
    mount_pts.append((mount_hole_radius*math.cos(angle), mount_hole_radius*math.sin(angle)))
result = (
    result.faces(">Z").workplane()
    .pushPoints(mount_pts)
    .hole(mount_hole_diameter)
)

# Top surface rectangular pockets (radial pattern) for stiffness
num_pockets = int(360 / rib_spacing_angle)
for i in range(num_pockets):
    angle = math.radians(i * rib_spacing_angle)
    offset = outer_diameter/2 - rib_width/2 - 5
    x = offset * math.cos(angle)
    y = offset * math.sin(angle)
    result = (
        result.faces(">Z").workplane()
        .center(x, y)
        .rect(rib_width, rib_width)
        .cutBlind(rib_depth)
    )

# Chamfer all suitable edges for safety
result = result.edges().chamfer(chamfer_size)
