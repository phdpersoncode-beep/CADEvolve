import cadquery as cq
import math

# Parameters
arc_outer_diameter = 100.0
arc_width = 50.0
block_depth = 15.0
block_height = 12.0
chamfer_size = 1.5
hole_diameter = 6.0
hole_center_offset = 15.0

# Derived dimensions
arc_outer_radius = 0.5 * arc_outer_diameter
arc_center_diameter = arc_outer_diameter - block_depth
arc_center_radius = 0.5 * arc_center_diameter
arc_center_angle = math.degrees(math.acos((2 * arc_center_radius**2 - arc_width**2) / (2 * arc_center_radius**2)))
arc_secant_angle = 0.5 * (180.0 - arc_center_angle)

# Sweep path: an arc segment
path = (
    cq.Workplane("XY")
    .radiusArc((arc_width, 0.0), arc_center_radius)
    .wire()
)

# Build the arc block
block = (
    cq.Workplane("XY")
    .transformed(rotate=(90.0, -arc_secant_angle, 0.0))
    .rect(block_depth, block_height)
    .sweep(path, transition="round")
)

# Apply shallow chamfer on the outward flat face (>X direction)
block = (
    block
    .faces(">X")
    .edges("|Z")
    .chamfer(chamfer_size)
)

# Add blind tapped hole on the same flat face
hole_depth = block_height - chamfer_size - 1.0
block = (
    block
    .faces(">X")
    .workplane()
    .center(hole_center_offset, 0)
    .hole(hole_diameter, hole_depth)
)

result = block
