import cadquery as cq

# Parameters
bracket_length = 70.0
bracket_width = 30.0
bracket_thickness = 8.0
slot_width = 12.0
slot_depth = 20.0
slot_chamfer = 1.0
hole_clearance_dia = 5.5
hole_offset_from_end = 25.0
rib_height = 6.0
rib_thickness = 4.0
outer_chamfer = 0.8

# Base plate
result = (cq.Workplane('XY')
          .rect(bracket_length, bracket_width)
          .extrude(bracket_thickness)
)
# Latch slot cut from the end face (-X direction)
slot_center_x = -bracket_length/2 + slot_depth/2
result = (result
          .faces('<X')
          .workplane()
          .center(slot_center_x, 0)
          .rect(slot_width, bracket_width)
          .cutBlind(-bracket_thickness)
)
# Chamfer on slot opening edges (top face edges of the cut)
result = (result
          .edges('>Z and (|X or |Y)')
          .chamfer(slot_chamfer)
)
# Clearance hole for M5 pin
hole_center_x = -bracket_length/2 + hole_offset_from_end
result = (result
          .faces('>Z')
          .workplane()
          .center(hole_center_x, 0)
          .hole(hole_clearance_dia)
)
# Reinforcing rib on the back face (+Y side)
result = (result
          .faces('>Y')
          .workplane()
          .center(0, 0)
          .rect(bracket_length, rib_height)
          .extrude(rib_thickness)
)
# Global chamfer for safety on outer edges
result = (result
          .edges('>Z or >X or >Y')
          .chamfer(outer_chamfer)
)
