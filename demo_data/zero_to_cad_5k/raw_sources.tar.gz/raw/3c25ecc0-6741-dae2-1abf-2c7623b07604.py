import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # create L profile sketch
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.vertical_leg_height)
            .lineTo(m.horizontal_leg_length, m.vertical_leg_height)
            .lineTo(m.horizontal_leg_length, m.vertical_leg_height - m.leg_thickness)
            .lineTo(m.leg_thickness, m.vertical_leg_height - m.leg_thickness)
            .lineTo(m.leg_thickness, 0)
            .close()
        )
        # extrude to give thickness
        self.model = profile.extrude(m.bracket_thickness)
        # add vertical leg clearance holes pattern (8 holes)
        hole_face = self.model.faces(">Z")
        # shift to vertical face centerline (front face of vertical leg)
        vertical_face = self.model.faces(">Y")
        # workplane on vertical face, align with inner side of leg
        (self.model
         .faces(">Y")
         .workplane(origin=(m.leg_thickness/2, 0, 0), centerOption="CenterOfBoundBox")
         .moveTo(m.leg_thickness/2, m.vertical_leg_height/2)
         .rarray(m.hole_spacing, 0, 8, 1)
         .hole(m.hole_clearance_diameter)
        )
        # optional gusset reinforcement inside corner
        if m.include_gusset:
            gusset = (
                cq.Workplane("XY")
                .moveTo(0, m.vertical_leg_height - m.gusset_height)
                .lineTo(m.gusset_width, m.vertical_leg_height - m.gusset_height)
                .lineTo(m.gusset_width, m.vertical_leg_height)
                .close()
                .extrude(m.gusset_thickness)
                .translate((0, 0, m.bracket_thickness/2 - m.gusset_thickness/2))
            )
            self.model = self.model.union(gusset)
        # chamfer outer edges for safety
        self.model = self.model.edges(">Z or >X or >Y").chamfer(m.edge_chamfer)

# Define measures
measures = Measures(
    vertical_leg_height=80.0,
    horizontal_leg_length=60.0,
    leg_thickness=8.0,
    bracket_thickness=10.0,
    hole_clearance_diameter=4.0,
    hole_spacing=10.0,
    include_gusset=True,
    gusset_width=20.0,
    gusset_height=20.0,
    gusset_thickness=3.0,
    edge_chamfer=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model