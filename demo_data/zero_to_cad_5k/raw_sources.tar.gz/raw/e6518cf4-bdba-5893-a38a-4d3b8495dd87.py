import cadquery as cq
from types import SimpleNamespace as Measures

horizontal_leg_length = 80.0
vertical_leg_length = 70.0
thickness = 10.0
vertical_thickness = thickness  # leg thickness same
rib_length = 60.0
rib_thickness = 8.0
rib_height = 12.0
clearance_hole_diameter = 12.0
chamfer_dist = 1.0

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.thickness)
            .lineTo(m.vertical_thickness, m.thickness)
            .lineTo(m.vertical_thickness, m.vertical_leg_length + m.thickness)
            .lineTo(0, m.vertical_leg_length + m.thickness)
            .close()
            .extrude(m.thickness)
        )
        rib = (
            base.faces(">Z")
            .workplane()
            .center(m.horizontal_leg_length / 2, m.thickness / 2)
            .rect(m.rib_length, m.rib_thickness)
            .extrude(m.rib_height)
        )
        hole = (
            rib.faces(">Z")
            .workplane()
            .center(m.vertical_thickness / 2, m.vertical_leg_length / 2)
            .hole(m.clearance_hole_diameter)
        )
        result = (
            hole.edges("|Z")
            .chamfer(m.chamfer_dist)
        )
        self.model = result

measures = Measures(
    horizontal_leg_length=horizontal_leg_length,
    vertical_leg_length=vertical_leg_length,
    thickness=thickness,
    vertical_thickness=vertical_thickness,
    rib_length=rib_length,
    rib_thickness=rib_thickness,
    rib_height=rib_height,
    clearance_hole_diameter=clearance_hole_diameter,
    chamfer_dist=chamfer_dist,
)

result = LBracket(cq.Workplane("XY"), measures).model
