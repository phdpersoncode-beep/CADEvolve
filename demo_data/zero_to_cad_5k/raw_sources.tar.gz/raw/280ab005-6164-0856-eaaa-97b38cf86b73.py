import cadquery as cq

bracket_length = 60.0
bracket_width = 35.0
bracket_thickness = 8.0
edge_chamfer = 1.0
boss_diameter = 12.0
boss_height = 6.0
set_screw_hole_diameter = 4.0
mounting_hole_diameter = 5.0
mounting_hole_offset = 10.0
rib_width = 5.0
rib_height = bracket_thickness / 2.0
rib_offset = bracket_thickness / 4.0

base = (
    cq.Workplane("XY")
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
    .edges()
    .chamfer(edge_chamfer)
)

boss = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(boss_diameter / 2.0)
    .extrude(boss_height)
)

part = base.union(boss)

part = (
    part
    .faces(">Z")
    .workplane()
    .hole(set_screw_hole_diameter)
)

mounting_points = [
    (-bracket_length / 2 + mounting_hole_offset, bracket_width / 2 - mounting_hole_offset),
    (bracket_length / 2 - mounting_hole_offset, bracket_width / 2 - mounting_hole_offset),
    (-bracket_length / 2 + mounting_hole_offset, -bracket_width / 2 + mounting_hole_offset),
    (bracket_length / 2 - mounting_hole_offset, -bracket_width / 2 + mounting_hole_offset),
]

part = (
    part
    .faces(">Z")
    .workplane()
    .pushPoints(mounting_points)
    .hole(mounting_hole_diameter)
)

rib = (
    cq.Workplane("XY")
    .rect(bracket_length - 20.0, rib_width)
    .extrude(rib_height)
    .translate((0, bracket_width / 2 - rib_width / 2, rib_offset))
)

part = part.union(rib)

part = (
    part
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(boss_diameter * 0.5, boss_diameter * 0.5)
    .cutBlind(boss_height / 2)
)

result = part
