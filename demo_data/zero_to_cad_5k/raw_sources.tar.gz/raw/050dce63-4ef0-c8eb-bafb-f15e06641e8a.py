import cadquery as cq
from types import SimpleNamespace as Measures

class RevolvedLBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()
    def build(self):
        m = self.m
        profile = (
            cq.Workplane('XZ')
            .moveTo(0, 0)
            .lineTo(m.hor_thick, 0)
            .lineTo(m.hor_thick, m.hor_len)
            .lineTo(m.vert_thick, m.hor_len + m.shoulder_len)
            .lineTo(m.vert_thick, m.hor_len + m.shoulder_len + m.vert_len)
            .lineTo(0, m.hor_len + m.shoulder_len + m.vert_len)
            .close()
        )
        solid = profile.revolve()
        # inner rectangular pocket cut from axis side
        pocket = (
            cq.Workplane('XY')
            .box(m.pocket_width, m.pocket_height, m.pocket_depth)
            .translate((m.pocket_depth/2, m.hor_len/2, 0))
        )
        solid = solid.cut(pocket)
        # blind holes on outer cylindrical face
        for i in range(4):
            y_pos = m.hole_start + i * m.hole_spacing
            hole = (
                cq.Workplane('YZ')
                .cylinder(m.hole_depth, m.hole_radius)
                .translate((m.vert_thick - m.hole_depth/2, y_pos, 0))
            )
            solid = solid.cut(hole)
        self.model = solid

measures = Measures(
    hor_len=40.0,
    hor_thick=20.0,
    shoulder_len=10.0,
    vert_len=30.0,
    vert_thick=12.0,
    pocket_width=12.0,
    pocket_height=20.0,
    pocket_depth=8.0,
    hole_radius=3.0,
    hole_depth=8.0,
    hole_spacing=8.0,
    hole_start=30.0,
)

result = RevolvedLBracket(cq.Workplane('XY'), measures).model
