import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
base_length = 80.0
base_thickness = 8.0
leg_height = 60.0
leg_thickness = 8.0
wall_thickness = 2.0
pocket_width = 30.0
pocket_height = 20.0
clearance_hole_diameter = 5.0
chamfer_distance = 2.0

measures = Measures(
    base_length=base_length,
    base_thickness=base_thickness,
    leg_height=leg_height,
    leg_thickness=leg_thickness,
    wall_thickness=wall_thickness,
    pocket_width=pocket_width,
    pocket_height=pocket_height,
    clearance_hole_diameter=clearance_hole_diameter,
    chamfer_distance=chamfer_distance,
)

class LBracket:
    def __init__(self, workplane, m):
        self.model = workplane
        self.m = m
        self.build()
    def build(self):
        m = self.m
        pts = [
            (0, 0),
            (m.base_length, 0),
            (m.base_length, m.base_thickness),
            (m.leg_thickness, m.base_thickness),
            (m.leg_thickness, m.leg_height),
            (0, m.leg_height),
        ]
        solid = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.base_thickness)
            .shell(m.wall_thickness)
        )
        solid = solid.edges("|Z").chamfer(m.chamfer_distance)
        solid = (
            solid.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.pocket_width, m.pocket_height)
            .cutThruAll()
        )
        solid = (
            solid.faces("<Z")
            .workplane()
            .pushPoints([
                (m.base_length*0.25, m.base_thickness*0.25),
                (m.base_length*0.75, m.base_thickness*0.25),
                (m.base_length*0.25, m.leg_height - m.base_thickness*0.25),
                (m.base_length*0.75, m.leg_height - m.base_thickness*0.25),
            ])
            .hole(m.clearance_hole_diameter)
        )
        self.model = solid

result = LBracket(cq.Workplane("XY"), measures).model
