import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # vertical leg
        vertical = (
            cq.Workplane("XY")
            .rect(m.leg_thickness, m.vertical_height, centered=False)
            .extrude(m.thickness)
        )
        # horizontal leg positioned at base of vertical leg
        horizontal = (
            cq.Workplane("XY")
            .move(m.leg_thickness, 0)
            .rect(m.horizontal_length, m.leg_thickness, centered=False)
            .extrude(m.thickness)
        )
        base = vertical.union(horizontal)
        # gusset reinforcement between legs
        gusset = (
            cq.Workplane("XY")
            .move(m.leg_thickness, 0)
            .lineTo(m.leg_thickness + m.gusset_width, m.gusset_height)
            .lineTo(m.leg_thickness, m.gusset_height)
            .close()
            .extrude(m.thickness)
        )
        model = base.union(gusset)
        # chamfer outer edges
        model = model.edges("|Z and >Y").chamfer(m.chamfer)
        # clearance holes on outer face of horizontal leg
        holes_wp = (
            model.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.leg_thickness + m.horizontal_length/2, 0)
        )
        holes = (
            holes_wp
            .rarray(m.hole_spacing_x, m.hole_spacing_y, 4, 2)
            .hole(m.clearance_hole_diameter)
        )
        self.model = holes

# Define measures
measures = Measures(
    leg_thickness=10.0,
    vertical_height=60.0,
    horizontal_length=80.0,
    thickness=8.0,
    gusset_width=20.0,
    gusset_height=15.0,
    chamfer=1.0,
    clearance_hole_diameter=5.0,
    hole_spacing_x=15.0,
    hole_spacing_y=12.0,
)

result = LBracket(cq.Workplane("XY"), measures).model