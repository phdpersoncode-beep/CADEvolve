import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 5.0
slot_length = 12.0
slot_width = 4.0
slot_spacing = 6.0
num_slots = 4
clearance_diameter = 6.0
boss_diameter = 10.0
boss_height = 4.0
fillet_radius = 1.5
chamfer_distance = 0.5

# Base leaf extruded plate
base = (
    cq.Workplane("XY")
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)

# Linear slot pattern on front face
result = (
    base
    .faces(">Z")
    .workplane()
    .rect(slot_length, slot_width)
    .rarray(slot_length + slot_spacing, 0, num_slots, 1)
    .cutBlind(-leaf_thickness)
)

# Central clearance hole through leaf
result = (
    result
    .faces(">Z")
    .workplane()
    .hole(clearance_diameter)
)

# Small cylindrical boss on rear face for hinge pin
result = (
    result
    .faces("<Z")
    .workplane()
    .center(-leaf_length/2 + boss_diameter/2 + 2.0, 0)
    .circle(boss_diameter/2)
    .extrude(boss_height)
)

# Fillet on back edges for safety
result = (
    result
    .faces("<Z")
    .edges()
    .fillet(fillet_radius)
)

# Chamfer vertical outer edges
result = (
    result
    .edges("|Z")
    .chamfer(chamfer_distance)
)
