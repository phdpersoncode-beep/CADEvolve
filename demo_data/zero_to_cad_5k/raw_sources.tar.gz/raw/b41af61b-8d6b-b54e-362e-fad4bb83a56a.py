import cadquery as cq

# Dimensions (max 100 units scale)
base_length = 80.0
base_width = 60.0
base_height = 20.0

rib_thickness = 5.0
rib_height = 12.0

vent_hole_diameter = 4.0
vent_spacing_x = 12.0
vent_spacing_y = 12.0
vent_margin = 8.0

edge_chamfer = 0.5

# Core box base
core = cq.Workplane("XY").box(base_length, base_width, base_height, centered=True)

# Vent hole grid on top surface
num_x = int((base_length - 2*vent_margin) // vent_spacing_x) + 1
num_y = int((base_width - 2*vent_margin) // vent_spacing_y) + 1
points = []
for i in range(num_x):
    x = -base_length/2 + vent_margin + i*vent_spacing_x
    for j in range(num_y):
        y = -base_width/2 + vent_margin + j*vent_spacing_y
        points.append((x, y))

core = (
    core
    .workplane(offset=base_height/2)
    .pushPoints(points)
    .hole(vent_hole_diameter)
)

# Ribs on each side
rib_pos_y = (base_width/2) + (rib_thickness/2)
rib_y_plus = (
    cq.Workplane("XY")
    .box(base_length, rib_thickness, rib_height, centered=True)
    .translate((0, rib_pos_y, (rib_height - base_height)/2))
)

rib_y_minus = (
    cq.Workplane("XY")
    .box(base_length, rib_thickness, rib_height, centered=True)
    .translate((0, -rib_pos_y, (rib_height - base_height)/2))
)

rib_pos_x = (base_length/2) + (rib_thickness/2)
rib_x_plus = (
    cq.Workplane("XY")
    .box(rib_thickness, base_width, rib_height, centered=True)
    .translate((rib_pos_x, 0, (rib_height - base_height)/2))
)

rib_x_minus = (
    cq.Workplane("XY")
    .box(rib_thickness, base_width, rib_height, centered=True)
    .translate((-rib_pos_x, 0, (rib_height - base_height)/2))
)

# Combine core and ribs
result = core.union(rib_y_plus).union(rib_y_minus).union(rib_x_plus).union(rib_x_minus)

# Chamfer vertical edges for mold safety
result = result.edges("|Z").chamfer(edge_chamfer)
