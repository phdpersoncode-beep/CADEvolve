import cadquery as cq

# Parameters
mold_length = 80.0
mold_width = 50.0
mold_height = 20.0

cavity_depth = 12.0
cavity_margin = 5.0
cavity_height = 15.0

rib_width = 8.0
rib_height = 6.0
rib_thickness = 4.0
rib_fillet_radius = 1.0

hole_diameter = 5.0
hole_spacing = 30.0

chamfer_distance = 0.8

# Base block
base = cq.Workplane('XY').box(mold_length, mold_width, mold_height, centered=(True, True, False))

# Cavity cutout on top surface (centered)
cavity = (
    cq.Workplane('XY', origin=(0, 0, mold_height))
    .rect(cavity_depth, cavity_depth)
    .extrude(-cavity_height)
    .edges('|Z')
    .chamfer(chamfer_distance)
)

# Rib on +Y side face with fillet on top edges
rib = (
    base.faces('>Y')
    .workplane()
    .moveTo(-rib_width/2, -rib_height/2)
    .lineTo(rib_width/2, -rib_height/2)
    .lineTo(rib_width/2, rib_height/2 - rib_fillet_radius)
    .threePointArc((rib_width/2 + rib_fillet_radius, rib_height/2), (rib_width/2 - rib_fillet_radius, rib_height/2))
    .lineTo(-rib_width/2, rib_height/2)
    .close()
    .extrude(rib_thickness)
    .faces('>Z')
    .edges()
    .fillet(rib_fillet_radius)
)

# Vent holes on top surface
vent_holes = (
    base.faces('>Z')
    .workplane()
    .pushPoints([(-hole_spacing/2, -hole_spacing/2), (hole_spacing/2, -hole_spacing/2),
                (-hole_spacing/2, hole_spacing/2), (hole_spacing/2, hole_spacing/2)])
    .hole(hole_diameter)
)

# Assemble final part
result = base.union(rib).cut(cavity).union(vent_holes)
