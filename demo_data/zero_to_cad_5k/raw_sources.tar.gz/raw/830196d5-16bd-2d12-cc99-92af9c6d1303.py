import cadquery as cq
insert_length = 80.0
insert_width = 50.0
insert_height = 30.0
wall_thickness = 3.0
rib_height = 5.0
rib_width = 4.0
rib_spacing = 10.0
chamfer_distance = 0.5
mount_hole_diameter = 4.0
mount_hole_offset = 12.0
inner_radius = 2.0
outer = cq.Workplane('XY').box(insert_width, insert_length, insert_height, centered=True)
inner = cq.Workplane('XY').box(insert_width-2*wall_thickness, insert_length-2*wall_thickness, insert_height-2*wall_thickness, centered=True)
inner = inner.edges().fillet(inner_radius)
core = outer.cut(inner)
num_ribs = int((insert_height-2*wall_thickness)//rib_spacing)
# ribs on +X face
result = (
    core
    .faces('>X')
    .workplane()
    .rarray(0, rib_spacing, 1, num_ribs)
    .rect(rib_width, rib_height)
    .extrude(rib_width)
)
# ribs on -X face
result = (
    result
    .faces('<X')
    .workplane()
    .rarray(0, rib_spacing, 1, num_ribs)
    .rect(rib_width, rib_height)
    .extrude(rib_width)
)
# mounting holes on top face
result = (
    result
    .faces('>Z')
    .workplane()
    .pushPoints([(-mount_hole_offset, 0), (mount_hole_offset, 0)])
    .hole(mount_hole_diameter)
)
result = result.edges().chamfer(chamfer_distance)
