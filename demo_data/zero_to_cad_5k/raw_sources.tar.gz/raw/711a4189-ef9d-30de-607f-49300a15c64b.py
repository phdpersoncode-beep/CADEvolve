import cadquery as cq
beam_length = 80.0
beam_height = 40.0
beam_width = 60.0
flange_thickness = 5.0
web_thickness = 4.0
rib_thickness = 3.0
rib_margin = 10.0
chamfer_size = 0.5
half_width = (beam_width / 2.0) - (web_thickness / 2.0)
pts = [
    (0, -beam_height / 2.0),
    (half_width, -beam_height / 2.0),
    (half_width, -beam_height / 2.0 + flange_thickness),
    (web_thickness / 2.0, -beam_height / 2.0 + flange_thickness),
    (web_thickness / 2.0, beam_height / 2.0 - flange_thickness),
    (half_width, beam_height / 2.0 - flange_thickness),
    (half_width, beam_height / 2.0),
    (0, beam_height / 2.0)
]
result = (cq.Workplane("front")
          .polyline(pts)
          .mirrorY()
          .extrude(beam_length))
rib_length = beam_length - 2 * rib_margin
rib_width = web_thickness
rib = (result.faces(">Z").workplane()
       .rect(rib_length, rib_width)
       .extrude(rib_thickness)
       .translate((0, 0, chamfer_size)))
result = result.union(rib)
result = result.edges().chamfer(chamfer_size)
