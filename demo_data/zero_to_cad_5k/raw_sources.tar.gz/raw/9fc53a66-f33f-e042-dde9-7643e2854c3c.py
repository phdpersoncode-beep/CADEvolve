import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()
        self.apply_inner_fillet()
        self.add_vertical_holes()
        self.add_reinforcement_rib()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .box(m.leg_width, m.thickness, m.vertical_length, centered=False)
        )
        horizontal = (
            cq.Workplane("XY")
            .box(m.horizontal_length, m.thickness, m.thickness, centered=False)
        )
        self.model = vertical.union(horizontal)

    def apply_inner_fillet(self):
        m = self.measures
        inner_edge = (
            self.model.edges()
            .filter(lambda e: abs(e.positionAt(0).x - m.leg_width) < 1e-6 and abs(e.positionAt(0).z - m.thickness) < 1e-6)
        )
        self.model = inner_edge.fillet(m.inner_fillet_radius)

    def add_vertical_holes(self):
        m = self.measures
        z_center = m.vertical_length / 2.0
        offsets = [-m.hole_spacing / 2.0, m.hole_spacing / 2.0]
        points = [(m.thickness / 2.0, z_center + off) for off in offsets]
        self.model = (
            self.model.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints(points)
            .hole(m.hole_diameter)
        )

    def add_reinforcement_rib(self):
        m = self.measures
        rib = (
            cq.Workplane("XY")
            .box(m.rib_width, m.thickness, m.rib_height, centered=False)
            .translate((m.horizontal_length - m.rib_width, 0, m.thickness))
        )
        self.model = self.model.union(rib)

measures = Measures(
    leg_width=30.0,
    thickness=10.0,
    vertical_length=80.0,
    horizontal_length=60.0,
    inner_fillet_radius=3.0,
    hole_diameter=5.0,
    hole_spacing=30.0,
    rib_width=20.0,
    rib_height=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
