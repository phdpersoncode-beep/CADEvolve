import cadquery as cq
outer = cq.Workplane('XY').rect(40,20).extrude(10)
outer = outer.faces('>Z').edges().chamfer(1)
inner = cq.Workplane('XY').rect(30,10).extrude(10)
result = outer.cut(inner)
