import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, m):
        self.wp = wp
        self.m = m
        self.model = None
        self.build()

    def build(self):
        m = self.m
        # Create L-shaped outline using polyline
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.long_leg, 0),
                (m.long_leg, m.leg_width),
                (m.leg_width, m.leg_width),
                (m.leg_width, m.short_leg),
                (0, m.short_leg),
            ])
            .close()
            .extrude(m.thickness)
        )
        # Chamfer outer edges for safety
        profile = profile.edges("|Z").chamfer(m.chamfer)
        # Relief cut inside corner
        relief = (
            profile.faces(">Z")
            .workplane(origin=(m.leg_width + m.relief_offset, m.leg_width + m.relief_offset))
            .rect(m.relief_width, m.relief_height)
            .cutBlind(-m.thickness)
        )
        # Nut pocket (hexagonal) on long leg
        nut = (
            relief.faces(">Z")
            .workplane()
            .move(m.nut_center, m.leg_width/2)
            .polygon(6, m.nut_flat_distance)
            .cutBlind(-m.nut_depth)
        )
        # Through screw hole for mounting
        final = (
            nut.faces(">Z")
            .workplane()
            .move(m.screw_offset_x, m.screw_offset_y)
            .hole(m.screw_diameter)
        )
        self.model = final

# Define measures respecting max dimension 100
measures = Measures(
    long_leg=80.0,
    short_leg=50.0,
    leg_width=30.0,
    thickness=8.0,
    chamfer=1.0,
    relief_offset=5.0,
    relief_width=20.0,
    relief_height=12.0,
    nut_center=30.0,
    nut_flat_distance=7.0,
    nut_depth=4.0,
    screw_offset_x=60.0,
    screw_offset_y=15.0,
    screw_diameter=4.5,
)

result = LBracket(cq.Workplane("XY"), measures).model
