import cadquery as cq
import math

gear_max_dim = 100.0
gear_thickness = gear_max_dim * 0.1
gear_outer_radius = gear_max_dim * 0.3
hub_radius = gear_max_dim * 0.1
hub_height = gear_thickness * 0.4
tooth_count = 8
tooth_angle = 360.0 / tooth_count
tooth_depth = gear_max_dim * 0.07
tooth_base_width = 2 * gear_outer_radius * math.sin(math.radians(tooth_angle / 2.0))
chamfer_distance = gear_max_dim * 0.02

base = cq.Workplane("XY").circle(gear_outer_radius).extrude(gear_thickness)
hub = cq.Workplane("XY").circle(hub_radius).extrude(hub_height).translate((0, 0, gear_thickness))
gear_body = base.union(hub)

tooth = (cq.Workplane("XY")
         .box(tooth_base_width, tooth_depth, gear_thickness)
         .translate((gear_outer_radius + tooth_depth / 2.0, 0, 0)))

result_gear = gear_body
for i in range(tooth_count):
    rotated_tooth = tooth.rotate((0, 0, 0), (0, 0, 1), i * tooth_angle)
    result_gear = result_gear.union(rotated_tooth)

result = result_gear.edges("|Z").chamfer(chamfer_distance)
