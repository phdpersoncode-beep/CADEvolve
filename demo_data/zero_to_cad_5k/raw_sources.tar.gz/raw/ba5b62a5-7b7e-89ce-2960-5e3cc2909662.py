import cadquery as cq

# parameters
base_radius = 30.0  # radius of main body
base_height = 10.0  # height of base cylinder
lip_outer_radius = 45.0  # outer radius of raised lip
lip_inner_radius = 35.0  # inner radius of lip (creates annular lip)
lip_height = 8.0
chamfer_dist = 0.5
hole_diameter = 5.0  # M5 (~5mm)
hole_pattern_radius = (lip_inner_radius + lip_outer_radius) / 2.0

# create 2D profile for revolve on XZ plane
profile = (
    cq.Workplane("XZ")
    .moveTo(base_radius, 0)                          # start at base outer edge
    .lineTo(base_radius, base_height)                # up base height
    .lineTo(lip_outer_radius, base_height)           # outward to lip outer radius
    .lineTo(lip_outer_radius, base_height + lip_height)  # up lip height
    .lineTo(lip_inner_radius, base_height + lip_height)  # inward to inner lip radius
    .lineTo(lip_inner_radius, base_height)           # down to base height
    .lineTo(base_radius, base_height)                # back to base radius
    .close()                                          # close profile
)

# revolve the profile around Z axis to create the mounting base
result = (
    profile
    .revolve()
    .edges("<Z")
    .chamfer(chamfer_dist)
    .faces(">Z")
    .workplane()
    .polarArray(hole_pattern_radius, 0, 360, 6)
    .hole(hole_diameter)
)
