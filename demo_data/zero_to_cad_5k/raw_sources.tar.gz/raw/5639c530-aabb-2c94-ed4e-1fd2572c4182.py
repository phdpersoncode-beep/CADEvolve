import cadquery as cq

bracket_width = 70.0
bracket_height = 50.0
bracket_thickness = 8.0
step_depth = 30.0
step_height = 12.0
hole_diameter = 8.0
hole_depth = 6.0
counterbore_diameter = 12.0
counterbore_depth = 2.0
mount_hole_diameter = 4.0
rib_thickness = 3.0
rib_height = 5.0
chamfer_size = 0.8
cable_cut_width = 10.0
cable_cut_height = bracket_height / 2.0
cable_cut_depth = bracket_thickness

base = (
    cq.Workplane("XY")
    .rect(bracket_width, bracket_height)
    .extrude(bracket_thickness)
)

base = (
    base
    .faces("<X")
    .workplane()
    .center(0, 0)
    .rect(cable_cut_width, cable_cut_height)
    .cutBlind(-cable_cut_depth)
)

step = (
    cq.Workplane("XY")
    .rect(step_depth, step_height)
    .extrude(bracket_thickness + 1)
    .translate((0, bracket_height/2 - step_height/2, 0))
)
base = base.cut(step)

base = (
    base
    .faces(">Y")
    .workplane()
    .center(0, 0)
    .hole(counterbore_diameter, depth=counterbore_depth)
)

base = (
    base
    .faces(">Y")
    .workplane()
    .center(0, 0)
    .hole(hole_diameter, depth=hole_depth)
)

base = (
    base
    .faces("<X")
    .workplane()
    .center(0, bracket_height/4)
    .hole(mount_hole_diameter)
    .center(0, -bracket_height/2)
    .hole(mount_hole_diameter)
)

base = (
    base
    .faces(">X")
    .workplane()
    .center(0, bracket_height/4)
    .hole(mount_hole_diameter)
    .center(0, -bracket_height/2)
    .hole(mount_hole_diameter)
)

base = base.edges().chamfer(chamfer_size)

rib = (
    cq.Workplane("XY")
    .rect(rib_thickness, rib_height)
    .extrude(bracket_thickness)
    .translate((-bracket_width/2 + rib_thickness/2, -bracket_height/2 + rib_height/2, 0))
)
base = base.union(rib)

rib2 = rib.translate((bracket_width - rib_thickness, 0, 0))
result = base.union(rib2)
