import cadquery as cq
from types import SimpleNamespace as Measures

# Define key dimensions
m = Measures(
    plate_width=70.0,
    plate_depth=45.0,
    plate_thickness=10.0,
    outer_corner_radius=5.0,
    pocket_width=30.0,
    pocket_depth=20.0,
    pocket_recess_depth=4.0,
    bolt_hole_diameter=4.0,
    bolt_cbore_diameter=6.5,
    bolt_cbore_depth=4.0,
    mount_hole_diameter=3.0,
    mount_hole_spacing=20.0,
    mount_hole_edge_dist=8.0,
    chamfer_distance=0.5,
    rib_width=5.0,
    rib_height=3.0,
    rib_spacing=12.0
)

# Base plate with rounded outer edge
base = (
    cq.Workplane("XY")
    .rect(m.plate_width, m.plate_depth)
    .extrude(m.plate_thickness)
    .edges("<<Z")
    .fillet(m.outer_corner_radius)
)

# Recessed pocket for bolt (central)
base = (
    base
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .cboreHole(m.bolt_hole_diameter, m.bolt_cbore_diameter, m.bolt_cbore_depth)
)

# Central recessed pocket milled (non‑through) for bolt head clearance
base = (
    base
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(m.pocket_width, m.pocket_depth)
    .cutBlind(m.pocket_recess_depth)
)

# Mounting holes pattern on side edges
mount_y = m.plate_thickness / 2
base = (
    base
    .faces(">Z")
    .workplane()
    .pushPoints([
        (-m.mount_hole_spacing/2, 0),
        (m.mount_hole_spacing/2, 0)
    ])
    .hole(m.mount_hole_diameter)
)

# Add reinforcing ribs on bottom face
rib_count = int((m.plate_width - 2*m.mount_hole_edge_dist) // m.rib_spacing) + 1
rib_positions = [
    -m.plate_width/2 + m.mount_hole_edge_dist + i*m.rib_spacing
    for i in range(rib_count)
]
base = (
    base
    .faces("<Z")
    .workplane()
    .pushPoints([(x, 0) for x in rib_positions])
    .rect(m.rib_width, m.plate_depth - 2*m.mount_hole_edge_dist)
    .extrude(m.rib_height)
)

# Chamfer bottom edges for safety
result = (
    base
    .edges("<<Z")
    .chamfer(m.chamfer_distance)
)
