import cadquery as cq

# Dimensions (max 100 units)
length_i = 80.0
flange_width = 50.0
web_height = 30.0
flange_thick = 6.0
web_thick = 4.0
slot_width = 3.0  # fits within web thickness
slot_height = 8.0
chamfer_dist = 1.0
hole_dia = 5.0
hole_offset = 12.0

# I‑section profile points (counter‑clockwise)
p0 = (-flange_width/2, 0)
p1 = (flange_width/2, 0)
p2 = (flange_width/2, flange_thick)
p3 = (web_thick/2, flange_thick)
p4 = (web_thick/2, flange_thick + web_height)
p5 = (-web_thick/2, flange_thick + web_height)
p6 = (-web_thick/2, flange_thick)
p7 = (-flange_width/2, flange_thick)
pts = [p0, p1, p2, p3, p4, p5, p6, p7]

result = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .extrude(length_i)
    .faces(">Z")
    .workplane()
    .center(0, flange_thick + web_height/2)
    .rect(slot_width, slot_height)
    .cutThruAll()
    .edges("(>X or <X) and |Z")
    .chamfer(chamfer_dist)
    .faces(">Z")
    .workplane()
    .pushPoints([
        (-flange_width/2 + hole_offset, flange_thick/2),
        (flange_width/2 - hole_offset, flange_thick/2)
    ])
    .hole(hole_dia)
)
