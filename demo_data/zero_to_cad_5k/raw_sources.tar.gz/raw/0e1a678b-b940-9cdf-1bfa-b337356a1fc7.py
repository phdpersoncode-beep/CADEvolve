import cadquery as cq

bracket_length = 80.0
bracket_width = 40.0
bracket_thickness = 8.0
cavity_depth = 6.0
cavity_margin = 10.0
hole_diameter = 6.0
num_holes = 4
rib_height = 3.0
rib_width = 6.0
chamfer_distance = 1.0

# Base plate
base = (
    cq.Workplane('XY')
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
)

# Central recessed cavity cut
cavity = (
    base
    .faces('>Z')
    .workplane()
    .rect(bracket_length - 2 * cavity_margin, bracket_width - 2 * cavity_margin)
    .cutBlind(-cavity_depth)
)

# Rib positions (offset from center)
rib_offset = (bracket_width / 2) - cavity_margin - (rib_width / 2)

# Upper ribs (additive)
rib1 = (
    cq.Workplane('XY')
    .center(0, rib_offset)
    .rect(bracket_length - 2 * cavity_margin, rib_width)
    .extrude(rib_height)
    .translate((0, 0, bracket_thickness - rib_height))
)

rib2 = (
    cq.Workplane('XY')
    .center(0, -rib_offset)
    .rect(bracket_length - 2 * cavity_margin, rib_width)
    .extrude(rib_height)
    .translate((0, 0, bracket_thickness - rib_height))
)

# Combine base with ribs
with_ribs = cavity.union(rib1).union(rib2)

# Hole spacing across width of cavity region
hole_spacing = (bracket_width - 2 * cavity_margin) / (num_holes - 1)

# Add through holes pattern
with_holes = (
    with_ribs
    .faces('>Z')
    .workplane()
    .rarray(hole_spacing, 0, num_holes, 1, center=True)
    .hole(hole_diameter)
)

# Chamfer outer edges for safety
result = (
    with_holes
    .edges('|Z')
    .chamfer(chamfer_distance)
)
