import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

# Parameters (max dimension 100 units)
m = Measures(
    chord_length=60.0,          # width of the block along chord
    thickness=12.0,            # depth (radial thickness of block)
    height=15.0,               # vertical height of block
    outer_diameter=100.0,      # overall arc diameter (controls curvature)
    chamfer_size=2.0,          # size of 120° chamfer
    keyway_width=6.0,
    keyway_length=30.0,
    keyway_offset=20.0,        # offset from center along chord direction
    hole_diameter=4.0,
    hole_head_diameter=7.0,
    hole_head_height=3.5,
    hole1_offset=15.0,
    hole2_offset=45.0
)

# Derived geometry
m.arc_outer_radius = 0.5 * m.outer_diameter
m.arc_center_diameter = m.outer_diameter - m.thickness
m.arc_center_radius = 0.5 * m.arc_center_diameter
# central angle of the chord within the inner radius
m.arc_center_angle = degrees(
    acos((2 * m.arc_center_radius**2 - m.chord_length**2) / (2 * m.arc_center_radius**2))
)
# angle between radius and secant line to chord midpoint
m.arc_secant_angle = 0.5 * (180.0 - m.arc_center_angle)

# Create sweep path (arc)
path = (
    cq.Workplane("XY")
    .radiusArc((m.chord_length, 0.0), m.arc_center_radius)
    .wire()
)

# Build the arc block by sweeping a rectangular profile
result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.thickness, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_size)  # 120° chamfer approximated by distance
    # Keyway slot on top surface
    .faces(">Z")
    .workplane()
    .center(m.keyway_offset, 0)
    .rect(m.keyway_width, m.keyway_length)
    .cutBlind(-m.thickness)
    # Mounting holes (counterbore)
    .faces(">Z")
    .workplane()
    .center(m.hole1_offset, 0)
    .cboreHole(m.hole_diameter, m.hole_head_diameter, m.hole_head_height)
    .center(-m.hole1_offset, 0)  # return to origin
    .center(m.hole2_offset, 0)
    .cboreHole(m.hole_diameter, m.hole_head_diameter, m.hole_head_height)
)
