import cadquery as cq
solid = cq.Workplane('XY').box(40,40,20)
result = solid.shell(3)
