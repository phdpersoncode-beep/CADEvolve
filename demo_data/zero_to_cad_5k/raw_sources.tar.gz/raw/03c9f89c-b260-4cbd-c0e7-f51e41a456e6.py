import cadquery as cq
base = cq.Workplane('XY').box(70,70,8)
result = base.faces('>Z').edges().chamfer(0.5)
