import cadquery as cq
from types import SimpleNamespace as Measures

# Parameter definitions
leg_a_length = 70.0
leg_b_length = 50.0
wall_thickness = 5.0
bracket_thickness = 6.0
chamfer_size = 2.0
boss_diameter = 15.0
boss_height = 8.0
hole_diameter = 5.0
hole_spacing = 30.0
hole_offset = 15.0

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_a_length, 0),
                (m.leg_a_length, m.wall_thickness),
                (m.wall_thickness, m.wall_thickness),
                (m.wall_thickness, m.leg_b_length),
                (0, m.leg_b_length),
                (0, 0),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        boss = (
            cq.Workplane("XY")
            .center(0, 0)
            .circle(m.boss_diameter / 2)
            .extrude(m.boss_height)
        )
        part = base.union(boss)
        part = (
            part.faces(">Z")
            .workplane()
            .pushPoints([
                (m.leg_a_length / 2, m.wall_thickness / 2 + m.hole_offset),
                (m.leg_a_length / 2, m.wall_thickness / 2 + m.hole_offset + m.hole_spacing),
            ])
            .hole(m.hole_diameter)
        )
        part = part.faces(">X").edges().chamfer(m.chamfer_size)
        part = part.faces(">Y").edges().chamfer(m.chamfer_size)
        self.model = part

measures = Measures(
    leg_a_length=leg_a_length,
    leg_b_length=leg_b_length,
    wall_thickness=wall_thickness,
    bracket_thickness=bracket_thickness,
    chamfer_size=chamfer_size,
    boss_diameter=boss_diameter,
    boss_height=boss_height,
    hole_diameter=hole_diameter,
    hole_spacing=hole_spacing,
    hole_offset=hole_offset,
)

result = LBracket(cq.Workplane("XY"), measures).model
