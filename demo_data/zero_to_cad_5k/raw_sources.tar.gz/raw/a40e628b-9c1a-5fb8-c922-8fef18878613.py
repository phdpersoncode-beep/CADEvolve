import cadquery as cq

L_length = 80.0
V_height = 60.0
bracket_thickness = 10.0
rib_height = 20.0
rib_thickness = 4.0
chamfer_dist = 2.0
hole_diameter = 3.2
hole_spacing_x = 15.0
hole_spacing_y = 15.0
hole_rows = 3
hole_cols = 2

points = [
    (0, 0),
    (L_length + bracket_thickness, 0),
    (L_length + bracket_thickness, bracket_thickness),
    (bracket_thickness, bracket_thickness),
    (bracket_thickness, V_height),
    (0, V_height),
]

base = (
    cq.Workplane('XY')
    .polyline(points)
    .close()
    .extrude(bracket_thickness)
)

base = base.edges('|Z').chamfer(chamfer_dist)

rib = (
    cq.Workplane('XY')
    .workplane(offset=bracket_thickness)
    .center(bracket_thickness/2, V_height/2)
    .rect(rib_thickness, rib_height)
    .extrude(bracket_thickness)
)

solid = base.union(rib)

hole_origin_x = bracket_thickness/2
hole_origin_y = V_height - ((hole_rows-1)*hole_spacing_y)/2
result = (
    solid
    .faces('>Z')
    .workplane()
    .center(hole_origin_x, hole_origin_y)
    .rarray(hole_spacing_x, hole_spacing_y, hole_cols, hole_rows)
    .hole(hole_diameter)
)
