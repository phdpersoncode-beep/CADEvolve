import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_leg_length),
                (m.thickness, m.vertical_leg_length),
                (m.thickness, m.thickness),
                (m.horizontal_leg_length, m.thickness),
                (m.horizontal_leg_length, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
            .edges("|Z")
            .chamfer(m.chamfer_size)
        )
        rib = (
            base.faces("<X")
            .workplane()
            .move(0, m.rib_offset_from_bottom)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_thickness)
        )
        model = base.union(rib)
        model = (
            model.faces(">X")
            .workplane()
            .move(m.thickness/2 + m.hole_offset_from_edge, m.hole_offset_from_bottom)
            .rarray(m.hole_spacing, 0, 4, 1)
            .hole(m.hole_diameter)
        )
        self.model = model

measures = Measures(
    vertical_leg_length=80.0,
    horizontal_leg_length=60.0,
    thickness=8.0,
    rib_height=30.0,
    rib_width=10.0,
    rib_thickness=4.0,
    rib_offset_from_bottom=20.0,
    hole_diameter=6.0,
    hole_spacing=20.0,
    hole_offset_from_edge=2.0,
    hole_offset_from_bottom=10.0,
    chamfer_size=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model