import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        # vertical leg box
        vertical = (
            cq.Workplane('XY')
            .box(m.thickness, m.vertical_leg, m.width)
            .translate((0, m.vertical_leg/2, 0))
        )
        # horizontal leg box
        horizontal = (
            cq.Workplane('XY')
            .box(m.horizontal_leg, m.thickness, m.width)
            .translate((m.horizontal_leg/2, 0, 0))
        )
        base = vertical.union(horizontal)
        # gusset triangular reinforcement
        gusset = (
            cq.Workplane('XY')
            .polyline([
                (0, m.thickness),
                (m.thickness, m.thickness),
                (0, m.thickness + m.gusset_height)
            ])
            .close()
            .extrude(m.width)
            .translate((0, 0, 0))
        )
        model = base.union(gusset)
        # chamfer outer edges
        model = model.edges(">X or >Y").chamfer(m.chamfer)
        # countersunk holes on vertical leg
        hole_positions_y = [m.edge_margin + i * m.hole_spacing for i in range(m.hole_count)]
        for y in hole_positions_y:
            model = (
                model.faces('>Y')
                .workplane(centerOption='CenterOfBoundBox')
                .center(0, y - m.vertical_leg/2)
                .cboreHole(m.hole_diameter, m.countersink_diameter, m.countersink_depth)
            )
        self.model = model

measures = Measures(
    vertical_leg=80.0,
    horizontal_leg=70.0,
    thickness=8.0,
    width=20.0,
    gusset_height=12.0,
    chamfer=1.0,
    hole_count=3,
    hole_spacing=20.0,
    edge_margin=12.0,
    hole_diameter=5.0,
    countersink_diameter=9.0,
    countersink_depth=3.0,
)

result = LBracket(cq.Workplane('XY'), measures).model