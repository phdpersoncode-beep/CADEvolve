import cadquery as cq
from types import SimpleNamespace as Measures

class LBracketRevolve:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane('XZ')
            .moveTo(m.boss_radius, 0)
            .lineTo(m.boss_radius + m.thickness, 0)
            .lineTo(m.boss_radius + m.thickness + m.horizontal_extension, 0)
            .lineTo(m.boss_radius + m.thickness + m.horizontal_extension, m.vertical_height)
            .lineTo(m.boss_radius + m.thickness, m.vertical_height)
            .lineTo(m.boss_radius + m.thickness, m.fillet_z_start)
            .threePointArc(
                (m.boss_radius + m.thickness, m.fillet_z_start - m.fillet_radius),
                (m.boss_radius, m.fillet_z_start - m.fillet_radius)
            )
            .lineTo(m.boss_radius, 0)
            .close()
        )
        solid = profile.revolve()
        # Add internal gusset for reinforcement
        gusset = (
            cq.Workplane('XZ')
            .moveTo(m.boss_radius, 0)
            .lineTo(m.boss_radius + m.thickness, 0)
            .lineTo(m.boss_radius + m.thickness, m.fillet_z_start)
            .close()
            .extrude(m.gusset_thickness)
        )
        solid = solid.union(gusset)
        # Create four mounting holes on outer cylindrical surface using cut cylinders
        outer_radius = m.boss_radius + m.thickness + m.horizontal_extension
        hole_z_positions = [
            m.hole_low_z,
            m.hole_low_z + m.hole_spacing,
            m.hole_high_z,
            m.hole_high_z + m.hole_spacing,
        ]
        for z in hole_z_positions:
            cyl = (
                cq.Workplane('XY')
                .circle(m.hole_diameter / 2)
                .extrude(outer_radius * 2)
                .rotate((0, 0, 0), (0, 1, 0), 90)
                .translate((outer_radius, 0, z))
            )
            solid = solid.cut(cyl)
        self.model = solid

measures = Measures(
    boss_radius=8.0,
    thickness=6.0,
    horizontal_extension=20.0,
    vertical_height=60.0,
    fillet_radius=2.0,
    fillet_z_start=30.0,
    gusset_thickness=4.0,
    hole_diameter=4.0,
    hole_spacing=12.0,
    hole_low_z=10.0,
    hole_high_z=40.0,
)

result = LBracketRevolve(cq.Workplane('XY'), measures).model