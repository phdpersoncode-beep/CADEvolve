import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # base L shape sketch
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_leg_length + m.leg_thickness),
                (0, m.vertical_leg_length + m.leg_thickness),
                (0, 0),
            ])
            .close()
            .extrude(m.bracket_depth)
        )
        # slot for keyway cut in vertical leg (outer face)
        slot = (
            cq.Workplane("XY")
            .box(m.slot_width, m.slot_height, m.leg_thickness)
            .translate((m.leg_thickness/2, m.leg_thickness + m.slot_bottom_offset + m.slot_height/2, 0))
        )
        base = base.cut(slot)
        # mounting holes on horizontal leg
        hole_y = m.leg_thickness/2
        start_x = m.leg_thickness + m.mount_hole_offset
        points = [(start_x + i * m.mount_hole_spacing, hole_y) for i in range(m.mount_hole_count)]
        base = (
            base.faces(">Z")
            .workplane()
            .pushPoints(points)
            .hole(m.mount_hole_diameter)
        )
        # triangular gusset reinforcement at inner corner
        gusset = (
            cq.Workplane("XY")
            .polyline([
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness + m.gusset_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness + m.gusset_length),
                (m.leg_thickness, m.leg_thickness),
            ])
            .close()
            .extrude(m.bracket_depth)
        )
        base = base.union(gusset)
        # chamfer outer edges
        base = base.edges("|Z").chamfer(m.chamfer_distance)
        self.model = base

# Parameter definitions
horizontal_leg_length = 60.0
vertical_leg_length = 80.0
leg_thickness = 12.0
bracket_depth = 8.0
slot_width = 6.0
slot_height = 30.0
slot_bottom_offset = 20.0
mount_hole_diameter = 5.0
mount_hole_spacing = 30.0
mount_hole_offset = 15.0
mount_hole_count = 2
gusset_length = 20.0
chamfer_distance = 1.0

measures = Measures(
    horizontal_leg_length=horizontal_leg_length,
    vertical_leg_length=vertical_leg_length,
    leg_thickness=leg_thickness,
    bracket_depth=bracket_depth,
    slot_width=slot_width,
    slot_height=slot_height,
    slot_bottom_offset=slot_bottom_offset,
    mount_hole_diameter=mount_hole_diameter,
    mount_hole_spacing=mount_hole_spacing,
    mount_hole_offset=mount_hole_offset,
    mount_hole_count=mount_hole_count,
    gusset_length=gusset_length,
    chamfer_distance=chamfer_distance,
)

result = LBracket(cq.Workplane("XY"), measures).model