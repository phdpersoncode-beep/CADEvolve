import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, m):
        self.wp = workplane
        self.m = m
        self.model = None
        self.build()

    def build(self):
        m = self.m
        # Base L profile and extrusion
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_thickness, 0),
                (m.leg_thickness, m.leg_height),
                (m.leg_thickness + m.base_length, m.leg_height),
                (m.leg_thickness + m.base_length, m.leg_height + m.leg_thickness),
                (0, m.leg_height + m.leg_thickness),
                (0, 0),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        # Fillet internal corner
        base = base.edges("(>>Y and <<X) or (>>X and <<Y)").fillet(m.fillet_radius)
        # Rib on vertical leg front face (+Y)
        rib = (
            base.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_thickness)
        )
        # Clearance holes pattern on top face (+Z)
        holes = (
            rib.faces(">Z")
            .workplane()
            .rarray(m.hole_spacing_x, m.hole_spacing_y, 2, 3)
            .hole(m.hole_diameter)
        )
        self.model = holes

# Parameter definitions (max dimension 100)
measures = Measures(
    leg_height=70.0,
    leg_thickness=30.0,
    base_length=60.0,
    bracket_thickness=6.0,
    fillet_radius=12.0,
    rib_width=20.0,
    rib_height=30.0,
    rib_thickness=4.0,
    hole_diameter=3.0,
    hole_spacing_x=30.0,
    hole_spacing_y=25.0,
)

result = LBracket(cq.Workplane("XY"), measures).model