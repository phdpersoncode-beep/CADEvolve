import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 6.0
tab_length = 12.0
tab_width = 10.0
slot_length = 20.0
slot_width = 3.0
slot_spacing = 5.0
num_slots = 4
hole_diameter = 6.0
bevel_dist = 0.5
rib_height = 2.0
rib_thickness = 2.0

base = (
    cq.Workplane('XY')
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)

tab = (
    cq.Workplane('XY')
    .center(leaf_length/2 - tab_length/2, 0)
    .rect(tab_length, tab_width)
    .extrude(leaf_thickness)
)

leaf = base.union(tab)

rib_spacing = leaf_width / (num_slots + 1)
for i in range(1, num_slots + 1):
    rib = (
        cq.Workplane('XY')
        .center(-leaf_length/2 + leaf_thickness/2 + rib_thickness/2, -leaf_width/2 + i * rib_spacing)
        .rect(rib_thickness, rib_height)
        .extrude(leaf_thickness)
    )
    leaf = leaf.union(rib)

slot_start_x = -leaf_length/2 + leaf_thickness + 5.0
for i in range(num_slots):
    y = -leaf_width/2 + (i + 0.5) * (slot_width + slot_spacing)
    slot = (
        cq.Workplane('XY')
        .center(slot_start_x + i * (slot_length + slot_spacing), y)
        .rect(slot_length, slot_width)
        .extrude(leaf_thickness + 0.01)
    )
    leaf = leaf.cut(slot)

center_hole = (
    cq.Workplane('XY')
    .center(0, 0)
    .circle(hole_diameter/2)
    .extrude(leaf_thickness + 0.01)
)
leaf = leaf.cut(center_hole)

# Bevel-like recessed pocket on back face
leaf = (
    leaf.faces('<Z')
    .workplane()
    .rect(leaf_length - 2*bevel_dist, leaf_width - 2*bevel_dist)
    .cutBlind(-bevel_dist)
)

result = leaf
