import cadquery as cq
from types import SimpleNamespace as Measures

# Parameter definitions
horizontal_length = 80.0  # max dimension 100
vertical_length = 60.0
leg_thickness = 10.0
leg_width = 8.0  # extrusion thickness (Z)
rib_width = 6.0
rib_height = 8.0
rib_extra_thickness = 2.0
washer_seat_diameter = 20.0
washer_seat_depth = 2.0
blind_hole_diameter = 6.0
blind_hole_depth = 12.0
blind_hole_offset_x = 30.0
blind_hole_offset_y = 30.0
chamfer_size = 1.0

measures = Measures(
    horizontal_length=horizontal_length,
    vertical_length=vertical_length,
    leg_thickness=leg_thickness,
    leg_width=leg_width,
    rib_width=rib_width,
    rib_height=rib_height,
    rib_extra_thickness=rib_extra_thickness,
    washer_seat_diameter=washer_seat_diameter,
    washer_seat_depth=washer_seat_depth,
    blind_hole_diameter=blind_hole_diameter,
    blind_hole_depth=blind_hole_depth,
    blind_hole_offset_x=blind_hole_offset_x,
    blind_hole_offset_y=blind_hole_offset_y,
    chamfer_size=chamfer_size,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile sketch
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_length, 0)
            .lineTo(m.horizontal_length, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness, m.vertical_length + m.leg_thickness)
            .lineTo(0, m.vertical_length + m.leg_thickness)
            .close()
            .extrude(m.leg_width)
        )
        # Rib on horizontal leg (centered along its length)
        rib = (
            base.faces(">Z")
            .workplane()
            .center(m.horizontal_length/2, m.leg_thickness/2)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_extra_thickness)
        )
        # Washer seat recessed pocket on vertical leg, near inner corner
        washer_seat = (
            rib.faces("<Z")
            .workplane(offset=-m.rib_extra_thickness)
            .center(-m.horizontal_length/2 + m.leg_thickness/2, m.vertical_length/2)
            .circle(m.washer_seat_diameter/2)
            .cutBlind(m.washer_seat_depth)
        )
        # Two blind holes on vertical leg
        holes = (
            washer_seat.faces("<Z")
            .workplane(offset=-m.rib_extra_thickness)
            .center(-m.horizontal_length/2 + m.leg_thickness/2, 0)
            .pushPoints([
                (m.blind_hole_offset_x, m.blind_hole_offset_y),
                (m.blind_hole_offset_x, -m.blind_hole_offset_y),
            ])
            .hole(m.blind_hole_diameter, depth=m.blind_hole_depth)
        )
        # Apply chamfer to outer edges
        result = (
            holes.edges(">Z or <Z")
            .chamfer(m.chamfer_size)
        )
        self.model = result

# Build part
result = LBracket(cq.Workplane("XY"), measures).model
