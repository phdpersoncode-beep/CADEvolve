
import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, measures):
        self.model = wp
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.arm_width, 0),
                (m.arm_width, m.overall_height),
                (m.overall_width, m.overall_height),
                (m.overall_width, m.overall_height - m.thickness),
                (m.arm_width, m.overall_height - m.thickness),
                (m.arm_width, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
        )
        base = (
            base
            .faces(">Z")
            .workplane()
            .center(m.arm_width/2, m.bearing_pocket_offset_y)
            .hole(m.bearing_pocket_diameter, m.bearing_pocket_depth)
        )
        base = (
            base
            .faces(">Z")
            .workplane()
            .center(m.arm_width/2, m.tapped_hole_offset_y)
            .hole(m.tapped_hole_diameter)
        )
        base = (
            base
            .faces(">Z")
            .workplane()
            .center(m.horizontal_hole_center_x, m.horizontal_hole_offset_y)
            .hole(m.clearance_hole_diameter)
            .center(m.clearance_hole_spacing, 0)
            .hole(m.clearance_hole_diameter)
        )
        # gusset reinforcement at inner corner
        gusset = (
            cq.Workplane("XY")
            .box(m.gusset_width, m.gusset_depth, m.thickness)
            .translate((m.arm_width + m.gusset_width/2, m.overall_height - m.thickness/2, m.thickness/2))
        )
        base = base.union(gusset)
        base = base.edges("|Z").chamfer(m.edge_chamfer)
        self.model = base

measures = Measures(
    overall_width=80.0,
    overall_height=60.0,
    thickness=10.0,
    arm_width=20.0,
    bearing_pocket_diameter=22.0,
    bearing_pocket_depth=8.0,
    bearing_pocket_offset_y=30.0,
    tapped_hole_diameter=8.0,
    tapped_hole_offset_y=45.0,
    clearance_hole_diameter=5.0,
    clearance_hole_spacing=30.0,
    horizontal_hole_center_x=35.0,
    horizontal_hole_offset_y=15.0,
    gusset_width=5.0,
    gusset_depth=5.0,
    edge_chamfer=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
