import cadquery as cq

hub_radius = 30.0
hub_thickness = 15.0
recess_width = 20.0
recess_depth = 5.0
bore_diameter = 10.0
tooth_count = 10
tooth_thickness = 2.0
tooth_height = 12.0
chamfer_dist = 1.0

base = (
    cq.Workplane("XY")
    .circle(hub_radius)
    .extrude(hub_thickness)
    .faces(">Z")
    .edges()
    .chamfer(chamfer_dist)
)

recessed = (
    base
    .faces(">Z")
    .workplane()
    .rect(recess_width, recess_depth)
    .cutBlind(-recess_depth)
)

bored = recessed.hole(bore_diameter)

result = (
    bored
    .faces(">Z")
    .workplane()
    .rect(tooth_thickness, tooth_height)
    .polarArray(count=tooth_count, radius=hub_radius - tooth_thickness/2, startAngle=0, angle=360)
    .cutBlind(-hub_thickness)
)
