import cadquery as cq
base = cq.Workplane('XY').box(30,20,5)
result = base.edges().chamfer(1)
