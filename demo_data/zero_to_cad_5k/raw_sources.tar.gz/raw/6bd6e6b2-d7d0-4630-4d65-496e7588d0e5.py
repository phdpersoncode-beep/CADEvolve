import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()
    def build(self):
        m = self.measures
        leg_width = m.leg_width
        leg_thickness = m.leg_thickness
        depth = m.depth
        vertical_leg_length = m.vertical_leg_length
        horizontal_leg_length = m.horizontal_leg_length
        slot_width = m.slot_width
        slot_height = m.slot_height
        notch_width = m.notch_width
        notch_height = m.notch_height
        notch_offset_x = m.notch_offset_x
        notch_offset_y = m.notch_offset_y
        edge_margin = m.edge_margin
        hole_diameter = m.hole_diameter
        hole_rows = m.hole_rows
        hole_columns = m.hole_columns
        hole_row_spacing = (vertical_leg_length - 2*edge_margin)/(hole_rows-1) if hole_rows>1 else 0
        hole_col_spacing = (leg_width - 2*edge_margin)/(hole_columns-1) if hole_columns>1 else 0
        chamfer_dist = leg_thickness * 0.1
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (leg_width, 0),
                (leg_width, vertical_leg_length),
                (leg_width + horizontal_leg_length, vertical_leg_length),
                (leg_width + horizontal_leg_length, vertical_leg_length + leg_thickness),
                (leg_width, vertical_leg_length + leg_thickness),
                (leg_width, 0)
            ])
            .close()
            .extrude(depth)
        )
        slot = (
            cq.Workplane("XY")
            .center(leg_width + horizontal_leg_length/2, vertical_leg_length + leg_thickness/2)
            .rect(slot_width, slot_height)
            .extrude(depth)
        )
        notch = (
            cq.Workplane("XY")
            .center(notch_offset_x, notch_offset_y)
            .rect(notch_width, notch_height)
            .extrude(depth)
        )
        shape = base.cut(slot).cut(notch)
        shape = shape.faces(">Z").workplane().center(leg_width/2, edge_margin).rarray(hole_col_spacing, hole_row_spacing, hole_columns, hole_rows).hole(hole_diameter)
        shape = shape.edges("|Z").chamfer(chamfer_dist)
        self.model = shape

measures = Measures(
    leg_width=20.0,
    leg_thickness=8.0,
    depth=12.0,
    vertical_leg_length=80.0,
    horizontal_leg_length=60.0,
    slot_width=12.0,
    slot_height=6.0,
    notch_width=8.0,
    notch_height=4.0,
    notch_offset_x=5.0,
    notch_offset_y=10.0,
    edge_margin=5.0,
    hole_diameter=5.2,
    hole_rows=4,
    hole_columns=2,
)

result = LBracket(cq.Workplane("XY"), measures).model