import cadquery as cq
import math

outer_radius = 40.0
thickness = 10.0
inner_radius = outer_radius - thickness
bracket_length = 30.0
hole_diameter = 12.0
counterbore_diameter = 20.0
counterbore_depth = 8.0
fillet_radius = 2.0
pocket_depth = 5.0
pocket_width = 12.0
pocket_height = 14.0

base_profile = (
    cq.Workplane("XZ")
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius, 0)
    .lineTo(outer_radius, bracket_length)
    .close()
)
solid = base_profile.revolve()
solid = solid.edges().fillet(fillet_radius)

def counterbore_at_angle(angle):
    x = outer_radius * math.cos(angle)
    y = outer_radius * math.sin(angle)
    large = (
        cq.Workplane("XY")
        .center(x, y)
        .circle(counterbore_diameter / 2)
        .extrude(counterbore_depth)
    )
    small = (
        cq.Workplane("XY")
        .center(x, y)
        .circle(hole_diameter / 2)
        .extrude(bracket_length + 2)
    )
    return large.union(small)

holes = counterbore_at_angle(0).union(counterbore_at_angle(math.pi))
solid = solid.cut(holes)

pocket = (
    cq.Workplane("XY", origin=(0, 0, bracket_length / 2))
    .center(inner_radius - pocket_depth / 2, 0)
    .rect(pocket_width, pocket_height)
    .extrude(pocket_depth)
)
solid = solid.cut(pocket)

result = solid