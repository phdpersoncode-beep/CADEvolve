import cadquery as cq
import math
from types import SimpleNamespace as Measures

# Primary dimensions (max 100 units scale)
m = Measures(
    outer_diameter=80.0,
    depth=12.0,
    height=15.0,
    linear_width=40.0,
    inner_fillet_radius=2.0,
    chamfer_angle=65.0,
    chamfer_base=2.0,
    hole_spacing=20.0,
    hole_offset=10.0,
    bolt_diameter=4.0,
    head_diameter=7.0,
    head_height=4.0,
)

# Derived measures
m.outer_radius = 0.5 * m.outer_diameter
m.inner_radius = m.outer_radius - m.depth
m.arc_center_angle = math.degrees(
    math.acos(
        (2 * m.inner_radius ** 2 - m.linear_width ** 2) / (2 * m.inner_radius ** 2)
    )
)
m.arc_secant_angle = 0.5 * (180.0 - m.arc_center_angle)
# Chamfer distances for ~65° angle
m.chamfer_dist1 = m.chamfer_base
m.chamfer_dist2 = m.chamfer_base * math.tan(math.radians(m.chamfer_angle))

# Build arc path
path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.inner_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    # 65° chamfer on outer vertical edges
    .edges("|Z")
    .chamfer(m.chamfer_dist1, m.chamfer_dist2)
    # Fillet on inner curved edges (apply to all edges, geometry will keep functional features)
    .edges()
    .fillet(m.inner_fillet_radius)
    # Counterbore holes on top face
    .faces(">Z")
    .workplane()
    .center(-m.hole_offset, -m.hole_spacing / 2)
    .cboreHole(m.bolt_diameter, m.head_diameter, m.head_height)
    .center(0, m.hole_spacing)
    .cboreHole(m.bolt_diameter, m.head_diameter, m.head_height)
)
