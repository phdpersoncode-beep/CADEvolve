import cadquery as cq

# Parameters
clip_length = 80.0
clip_height = 30.0
clip_thickness = 8.0
wall_thickness = 2.0
rib_count = 4
rib_width = 6.0
rib_height = 10.0
rib_fillet = 0.5
edge_chamfer = 0.8

# Derived dimensions
cavity_width = clip_length - 2 * wall_thickness
cavity_depth = clip_thickness - 2 * wall_thickness
spacing = (clip_length - 2 * wall_thickness - rib_count * rib_width) / (rib_count - 1)
rib_depth = cavity_depth * 0.6
cavity_y_max = cavity_depth / 2
rib_y_offset = 0.1
rib_center_y = cavity_y_max - rib_depth / 2 + rib_y_offset

# Base outer block with chamfered vertical edges
outer = (
    cq.Workplane("XY")
    .box(clip_length, clip_thickness, clip_height)
    .edges("|Z")
    .chamfer(edge_chamfer)
)
# Remove interior to create thin walls
cavity = cq.Workplane("XY").box(cavity_width, cavity_depth, clip_height)
base = outer.cut(cavity)

# Create rib solids attached to inner wall
ribs = cq.Workplane("XY")
for i in range(rib_count):
    x_pos = -clip_length / 2 + wall_thickness + rib_width / 2 + i * (rib_width + spacing)
    y_pos = rib_center_y
    z_pos = -clip_height / 2 + wall_thickness + rib_height / 2
    rib = (
        cq.Workplane("XY")
        .box(rib_width, rib_depth, rib_height)
        .translate((x_pos, y_pos, z_pos))
    )
    ribs = ribs.union(rib)
# Fuse ribs and fillet their top edges
ribs = ribs.combineSolids().edges().fillet(rib_fillet)

# Combine ribs with base walls into single solid
result = base.union(ribs).combineSolids()
