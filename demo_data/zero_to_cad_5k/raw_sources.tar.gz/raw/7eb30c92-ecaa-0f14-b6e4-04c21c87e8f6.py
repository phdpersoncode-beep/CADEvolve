import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        self.model = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.vertical_height, 0),
                (m.vertical_height, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.horizontal_length),
                (0, m.horizontal_length),
            ])
            .close()
            .extrude(m.depth)
        )
        rib_count = int((m.vertical_height - m.rib_margin_top - m.rib_margin_bottom) / (m.rib_width + m.rib_spacing))
        self.model = (
            self.model
            .faces('>X')
            .workplane(centerOption='CenterOfBoundBox')
            .center(0, m.rib_margin_bottom + m.rib_width/2)
            .rarray(0, m.rib_width + m.rib_spacing, 1, rib_count)
            .rect(m.rib_width, m.rib_depth)
            .cutBlind(-m.rib_thickness)
        )
        self.model = (
            self.model
            .faces('>Z')
            .workplane()
            .center(m.thickness/2, m.vertical_height/2)
            .rarray(0, m.hole_spacing, 1, 4)
            .cboreHole(m.hole_clearance, m.hole_cbore_diameter, m.hole_cbore_depth)
        )
        self.model = self.model.faces('>Z').edges().chamfer(m.chamfer_distance)

measures = Measures(
    vertical_height=70.0,
    horizontal_length=80.0,
    thickness=8.0,
    depth=10.0,
    rib_width=5.0,
    rib_depth=4.0,
    rib_thickness=2.0,
    rib_spacing=6.0,
    rib_margin_top=5.0,
    rib_margin_bottom=5.0,
    hole_spacing=12.0,
    hole_clearance=4.0,
    hole_cbore_diameter=6.5,
    hole_cbore_depth=2.0,
    chamfer_distance=1.0,
)

result = LBracket(cq.Workplane('XY'), measures).model
