import cadquery as cq

# Parameters
length = 80
width = 40
thickness = 10
wall_thickness = 2
central_hole_dia = 20
mount_hole_dia = 6
mount_offset = 8
chamfer_distance = 1.6
pocket_margin = 2
pocket_depth = 4
rib_width = 8
rib_depth = 3
rib_height = 5
rib_spacing = 20
top_tab_width = 30
top_tab_thickness = 2

# Base block with central and mounting holes
base = (
    cq.Workplane("XY")
    .rect(length, width)
    .extrude(thickness)
    .faces(">Z")
    .workplane()
    .hole(central_hole_dia)
    .faces(">Z")
    .workplane()
    .pushPoints([
        ( length/2 - mount_offset,  width/2 - mount_offset),
        (-length/2 + mount_offset,  width/2 - mount_offset),
        (-length/2 + mount_offset, -width/2 + mount_offset),
        ( length/2 - mount_offset, -width/2 + mount_offset),
    ])
    .hole(mount_hole_dia)
)

# Chamfer 30° on top perimeter edges
chamfered = base.faces(">Z").edges().chamfer(chamfer_distance)

# Create thin-walled shell
shelled = chamfered.shell(wall_thickness)

# Interior weight reduction pocket (central area)
interior_pocket = (
    shelled
    .faces("<Z")
    .workplane()
    .rect(length - 2*mount_offset - 2*pocket_margin, width - 2*mount_offset - 2*pocket_margin)
    .cutBlind(-pocket_depth)
)

# Internal reinforcement ribs cut into the +Y and -Y side walls
rib_pattern = (
    interior_pocket
    .faces(">Y")
    .workplane(centerOption="CenterOfMass")
    .rect(rib_width, rib_depth)
    .cutBlind(-rib_height)
    .faces("<Y")
    .workplane(centerOption="CenterOfMass")
    .rect(rib_width, rib_depth)
    .cutBlind(-rib_height)
)

# Add a reinforcing tab on the top face (adds material)
result = (
    rib_pattern
    .faces(">Z")
    .workplane()
    .rect(top_tab_width, top_tab_width)
    .extrude(top_tab_thickness)
)
