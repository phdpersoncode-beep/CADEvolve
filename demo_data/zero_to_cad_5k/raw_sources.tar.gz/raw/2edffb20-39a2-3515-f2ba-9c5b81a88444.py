import cadquery as cq

# Parameters
base_radius = 30.0
base_height = 10.0
tooth_width = 5.0
tooth_depth = 8.0
tooth_height = 5.0
num_teeth = 12
pitch_angle = 360.0 / num_teeth
offset_angle = pitch_angle / 2.0
slot_width = 3.0
slot_radial_depth = tooth_depth / 2.0
slot_axial_depth = tooth_height / 2.0
central_hole_diameter = 6.0
chamfer_dist = 0.5

total_height = base_height + tooth_height

# Base cylinder
base = cq.Workplane('XY').circle(base_radius).extrude(base_height)

# First set of teeth
teeth1 = (
    cq.Workplane('XY')
    .center(base_radius, 0)
    .rect(tooth_width, tooth_depth)
    .polarArray(radius=base_radius, startAngle=0, angle=360, count=num_teeth)
    .extrude(tooth_height)
)

# Second set of teeth, offset by half pitch
teeth2 = (
    cq.Workplane('XY')
    .center(base_radius, 0)
    .rect(tooth_width, tooth_depth)
    .polarArray(radius=base_radius, startAngle=offset_angle, angle=360, count=num_teeth)
    .extrude(tooth_height)
)

# Combine base and teeth into a single solid
gear = base.union(teeth1).union(teeth2)

# Add intersecting shallow slots between teeth (cut only part of the height)
gear = (
    gear.faces('>Z')
    .workplane()
    .center(base_radius + tooth_depth / 2, 0)
    .rect(slot_width, slot_radial_depth)
    .polarArray(radius=base_radius + tooth_depth / 2, startAngle=offset_angle, angle=360, count=num_teeth)
    .cutBlind(-slot_axial_depth)
)

# Central bore hole for shaft
gear = gear.faces('<Z').workplane().hole(central_hole_diameter)

# Chamfer outer vertical edges for safety
gear = gear.edges('|Z').chamfer(chamfer_dist)

result = gear