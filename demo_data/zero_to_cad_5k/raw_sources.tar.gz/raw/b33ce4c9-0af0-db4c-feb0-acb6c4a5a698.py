import cadquery as cq
outer_radius = 85.0
inner_radius = 55.0
block_height = 20.0
rib_thickness = 5.0
rib_height = 5.0
rib_start = block_height * 0.3
profile = (
    cq.Workplane('XZ')
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius, 0)
    .lineTo(outer_radius, rib_start)
    .lineTo(outer_radius + rib_thickness, rib_start)
    .lineTo(outer_radius + rib_thickness, rib_start + rib_height)
    .lineTo(outer_radius, rib_start + rib_height)
    .lineTo(outer_radius, block_height)
    .lineTo(inner_radius, block_height)
    .close()
)
solid = profile.revolve()
num = solid.solids().size()
result = solid