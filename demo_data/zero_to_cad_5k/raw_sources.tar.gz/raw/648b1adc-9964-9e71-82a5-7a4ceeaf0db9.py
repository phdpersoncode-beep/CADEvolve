import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    strap_length=80.0,
    strap_width=15.0,
    strap_thickness=4.0,
    tab_width=10.0,
    tab_height=5.0,
    central_hole_diameter=6.0,
    perforation_diameter=2.0,
    perforation_spacing=12.0,
    perforation_count=5,
    edge_fillet_radius=1.0,
    chamfer_distance=0.2,
)

base = (
    cq.Workplane("XY")
    .rect(m.strap_length, m.strap_width)
    .pushPoints([(0, m.strap_width/2 + m.tab_height/2)])
    .rect(m.tab_width, m.tab_height)
    .extrude(m.strap_thickness)
)

base_chamfered = base.edges("|Z").chamfer(m.chamfer_distance)

base_filleted = base_chamfered.faces(">Z").edges("<X or >X").fillet(m.edge_fillet_radius)

with_hole = (
    base_filleted.faces(">Z").workplane()
    .hole(m.central_hole_diameter)
)

pattern = (
    with_hole.faces(">Z").workplane()
    .rarray(m.perforation_spacing, 0, m.perforation_count, 1, center=True)
    .hole(m.perforation_diameter)
)

result = pattern
