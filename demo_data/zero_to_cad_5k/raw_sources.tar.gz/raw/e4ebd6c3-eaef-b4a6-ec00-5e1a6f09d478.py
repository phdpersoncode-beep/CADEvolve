import cadquery as cq

class LBracket:
    def __init__(self, workplane, params):
        self.model = workplane
        self.p = params
        self.build()

    def build(self):
        p = self.p
        notch_w = p.notch_width
        notch_d = p.notch_depth
        lofted = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (p.thickness, 0),
                (p.thickness, p.leg_width - notch_d),
                (p.thickness - notch_w, p.leg_width - notch_d),
                (p.thickness - notch_w, p.leg_width),
                (0, p.leg_width),
            ])
            .close()
            .transformed(offset=(p.leg_length, 0, 0), rotate=(0, 90, 0))
            .polyline([
                (0, 0),
                (p.thickness, 0),
                (p.thickness, p.leg_length - notch_d),
                (p.thickness - notch_w, p.leg_length - notch_d),
                (p.thickness - notch_w, p.leg_length),
                (0, p.leg_length),
            ])
            .close()
            .loft(combine=True)
        )
        lofted = (
            lofted.faces('>X')
            .workplane()
            .hole(p.clearance_hole_diameter)
        )
        lofted = (
            lofted.edges('>X and >Z')
            .fillet(p.inner_fillet_radius)
        )
        self.model = lofted

class Params:
    pass

p = Params()
p.leg_length = 80.0
p.leg_width = 30.0
p.thickness = 10.0
p.notch_width = 5.0
p.notch_depth = 4.0
p.clearance_hole_diameter = 8.0
p.inner_fillet_radius = 1.0

result = LBracket(cq.Workplane('XY'), p).model