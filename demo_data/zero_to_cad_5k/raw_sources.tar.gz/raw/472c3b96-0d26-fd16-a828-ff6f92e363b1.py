import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.h_leg_length, 0)
            .lineTo(m.h_leg_length, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.v_leg_length)
            .lineTo(0, m.v_leg_length)
            .close()
        )
        solid = profile.extrude(m.thickness)
        solid = solid.edges().fillet(m.fillet)
        solid = (
            solid.faces(">X")
            .workplane()
            .moveTo(m.thickness/2, m.v_leg_length - m.slot_center_offset)
            .rect(m.slot_width, m.slot_height)
            .cutBlind(-m.thickness)
        )
        if m.gusset:
            gusset = (
                cq.Workplane("XY")
                .moveTo(m.leg_width, m.leg_width)
                .lineTo(m.leg_width + m.gusset_length, m.leg_width)
                .lineTo(m.leg_width, m.leg_width + m.gusset_length)
                .close()
                .extrude(m.thickness)
            )
            solid = solid.union(gusset)
        self.model = solid

measures = Measures(
    h_leg_length=70.0,
    v_leg_length=80.0,
    leg_width=12.0,
    thickness=12.0,
    fillet=5.0,
    slot_width=10.0,
    slot_height=2.0,
    slot_center_offset=20.0,
    gusset=True,
    gusset_length=20.0,
)

result = LBracket(cq.Workplane("XY"), measures).model