import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    block_width = 60.0,
    block_thickness = 12.0,
    block_height = 10.0,
    arc_diameter = 100.0,
    rib_width = 20.0,
    rib_height = 8.0,
    rib_thickness = 3.0,
    hole_spacing = 15.0,
    hole_count = 3,
    bolt_diameter = 4.0,
    head_diameter = 7.0,
    head_height = 3.5,
    chamfer_distance = 0.8,
    rib_fillet = 1.2,
    block_fillet = 1.0
)

m.arc_radius = 0.5 * m.arc_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_radius**2 - m.block_width**2) / (2 * m.arc_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

arc_path = (
    cq.Workplane("XY")
    .radiusArc((m.block_width, 0.0), m.arc_radius)
    .wire()
)

main_body = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_thickness, m.block_height)
    .sweep(arc_path, transition="round")
    .edges("|Z")
    .fillet(m.block_fillet)
    .edges("<Z")
    .chamfer(m.chamfer_distance)
)

rib = (
    main_body.faces(">Z")
    .workplane()
    .center(0, m.block_height/2 - m.rib_thickness/2)
    .rect(m.rib_width, m.rib_thickness)
    .extrude(m.rib_height)
    .edges("|Z")
    .fillet(m.rib_fillet)
)

hole_positions = (
    rib.faces(">Z")
    .workplane()
    .center(- (m.rib_width/2 - m.hole_spacing), 0)
    .rarray(m.hole_spacing, 0, m.hole_count, 1)
)

result = (
    rib
    .faces(">Z")
    .workplane()
    .center(- (m.rib_width/2 - m.hole_spacing), 0)
    .rarray(m.hole_spacing, 0, m.hole_count, 1)
    .cboreHole(m.bolt_diameter, m.head_diameter, m.head_height)
)
