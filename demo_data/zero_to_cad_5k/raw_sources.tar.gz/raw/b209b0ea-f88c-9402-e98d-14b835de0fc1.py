import cadquery as cq
from types import SimpleNamespace as Measures

params = Measures(
    length=70.0,
    width=30.0,
    thickness=5.0,
    corner_radius=2.0,
    chamfer=0.8,
    hole=Measures(
        offset=20.0,
        diameter=4.0,
        counterbore_dia=7.0,
        counterbore_depth=2.5
    ),
    rib=Measures(
        width=5.0,
        height=2.0,
        spacing=10.0,
        count=3
    )
)

p = params

base = (
    cq.Workplane('XY')
    .box(p.length, p.width, p.thickness)
    .translate((0, 0, p.thickness/2))
)

# Chamfer leading vertical edge for lid attachment
base = (
    base
    .faces('>X')
    .edges('|Z')
    .chamfer(p.chamfer)
)

# Fillet edges along Y direction on top face to create rounded corners
base = (
    base
    .faces('>Z')
    .edges('>Y or <Y')
    .fillet(p.corner_radius)
)

hole_center_x = -p.length/2 + p.hole.offset
base = (
    base
    .faces('>Z')
    .workplane()
    .center(hole_center_x, 0)
    .cboreHole(p.hole.diameter, p.hole.counterbore_dia, p.hole.counterbore_depth)
)

rib_pattern = (
    base
    .faces('<Z')
    .workplane()
    .rarray(p.rib.spacing, 0, p.rib.count, 1)
    .rect(p.rib.width, p.width - 2 * p.rib.width)
    .extrude(-p.rib.height)
)

result = base.union(rib_pattern)
