import cadquery as cq

cage_length = 80.0
outer_diameter = 70.0
wall_thickness = 5.0
inner_diameter = outer_diameter - 2 * wall_thickness
outer_radius = outer_diameter / 2.0
inner_radius = inner_diameter / 2.0
rib_width = 3.0
rib_height = (outer_radius - inner_radius) - 2.0
rib_spacing_angle = 30.0
fillet_radius = 4.0

# Outer cylinder with filleted top and bottom edges
outer_cyl = (
    cq.Workplane("XY")
    .circle(outer_radius)
    .extrude(cage_length)
    .edges(">Z")
    .fillet(fillet_radius)
    .edges("<Z")
    .fillet(fillet_radius)
)

# Inner void
inner_hole = (
    cq.Workplane("XY")
    .circle(inner_radius)
    .extrude(cage_length)
)

cage_base = outer_cyl.cut(inner_hole)

# Rib geometry positioned on inner wall
rib_center_offset = inner_radius + rib_height / 2.0
single_rib = (
    cq.Workplane("XY")
    .rect(rib_width, rib_height)
    .extrude(cage_length)
    .translate((rib_center_offset, 0, 0))
)

num_ribs = int(360.0 / rib_spacing_angle)

result = cage_base
for i in range(num_ribs):
    angle = i * rib_spacing_angle
    rib = single_rib.rotate((0, 0, 0), (0, 0, 1), angle)
    result = result.union(rib)
