import cadquery as cq

# Parameters
chute_length = 80.0   # overall length, max 100 units
chute_width = 30.0    # width of channel
chute_height = 20.0   # total height
wall_thickness = 2.0
inner_fillet_radius = 3.0
outer_chamfer = 0.5
# Snap‑fit boss parameters
boss_width = 12.0
boss_height = 6.0
boss_thickness = 4.0
snap_arm_width = 4.0
snap_arm_thickness = 1.5
snap_arm_depth = 2.0
snap_arm_offset = 2.0  # distance from top of boss to snap arm

# Base solid: rectangular block extruded along X
base = (
    cq.Workplane("XY")
    .box(chute_length, chute_width, chute_height, centered=(True, True, False))
    .shell(-wall_thickness)
    .edges("<<Z and |Y and >X")
    .fillet(inner_fillet_radius)
    .edges()
    .chamfer(outer_chamfer)
)

# Snap‑fit boss on the +X side wall
boss = (
    base
    .faces(">X")
    .workplane()
    .center(0, chute_height/2 - boss_height/2)
    .rect(boss_width, boss_height)
    .extrude(boss_thickness)
)

# Add a thin snap arm on the top of the boss
snap_arm = (
    boss
    .faces(">Z")
    .workplane()
    .center(0, -boss_height/2 + snap_arm_offset)
    .rect(snap_arm_width, snap_arm_thickness)
    .cutBlind(-snap_arm_depth)
)

result = base.union(snap_arm)
