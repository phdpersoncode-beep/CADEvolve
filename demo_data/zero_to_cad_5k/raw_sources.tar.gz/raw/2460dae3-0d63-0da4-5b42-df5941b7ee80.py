import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        self.model = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.long_leg_length, 0)
            .lineTo(m.long_leg_length, m.bracket_thickness)
            .lineTo(m.bracket_thickness, m.bracket_thickness)
            .lineTo(m.bracket_thickness, m.short_leg_length)
            .lineTo(0, m.short_leg_length)
            .close()
            .extrude(m.web_thickness)
            .edges("|Z")
            .chamfer(m.chamfer_distance)
            .faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.rib_protrusion, m.rib_length)
            .extrude(m.rib_protrusion)
            .faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.hole_offset, 0)
            .hole(m.clearance_hole_diameter)
        )

measures = Measures(
    long_leg_length=80.0,
    short_leg_length=50.0,
    bracket_thickness=9.0,
    web_thickness=9.0,
    rib_protrusion=14.0,
    rib_setback=5.0,
    clearance_hole_diameter=9.0,
    hole_offset=30.0,
    chamfer_distance=1.0,
)
measures.rib_length = measures.short_leg_length - 2 * measures.rib_setback
result = LBracket(cq.Workplane("XY"), measures).model