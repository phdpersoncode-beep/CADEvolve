import cadquery as cq
from types import SimpleNamespace as Measures

width = 80.0
height = 70.0
thickness = 8.0
rib_thickness = 4.0
rib_margin = 5.0
slot_width = 12.0
slot_length = 30.0
slot_depth = thickness - 2.0
blind_hole_diameter = 6.0
blind_hole_depth = 12.0
hole_offset_y = height/2 - 15.0
hole_offset_z = thickness/2
chamfer_size = 1.0

measures = Measures(
    width=width,
    height=height,
    thickness=thickness,
    rib_thickness=rib_thickness,
    rib_margin=rib_margin,
    slot_width=slot_width,
    slot_length=slot_length,
    slot_depth=slot_depth,
    blind_hole_diameter=blind_hole_diameter,
    blind_hole_depth=blind_hole_depth,
    hole_offset_y=hole_offset_y,
    hole_offset_z=hole_offset_z,
    chamfer_size=chamfer_size,
)

class LBracket:
    def __init__(self, workplane, m):
        self.wp = workplane
        self.m = m
        self.build()
    def build(self):
        m = self.m
        base = (
            self.wp.lineTo(m.width, 0)
            .lineTo(m.width, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.height)
            .lineTo(0, m.height)
            .close()
            .extrude(m.thickness)
            .edges('|Z')
            .chamfer(m.chamfer_size)
        )
        rib = (
            base.faces('>X').workplane()
            .center(m.rib_margin + m.rib_thickness/2, m.height/2)
            .rect(m.rib_thickness, m.height - 2*m.rib_margin)
            .extrude(m.rib_thickness)
        )
        slot = (
            rib.faces('>Z').workplane()
            .center(m.width/2 - m.slot_length/2, m.thickness/2)
            .rect(m.slot_width, m.slot_length)
            .cutBlind(m.slot_depth)
        )
        final = (
            slot.faces('<X').workplane()
            .center(m.hole_offset_z, m.hole_offset_y)
            .circle(m.blind_hole_diameter/2)
            .cutBlind(m.blind_hole_depth)
        )
        self.result = final

result = LBracket(cq.Workplane('XY'), measures).result
