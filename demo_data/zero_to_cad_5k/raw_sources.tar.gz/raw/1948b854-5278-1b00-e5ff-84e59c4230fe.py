
import cadquery as cq

outer_width = 40.0
outer_height = 60.0
wall_thickness = 4.0
clip_depth = 10.0
inner_radius = 2.0
hole_diameter = 12.0
hole_offset_x = wall_thickness + 8.0
hole_offset_y = wall_thickness + 12.0
chamfer_size = 1.0

def l_profile(width, height, thickness):
    pts = [
        (0, 0),
        (width, 0),
        (width, thickness),
        (thickness, thickness),
        (thickness, height),
        (0, height),
    ]
    return (
        cq.Workplane("XY")
        .polyline(pts)
        .close()
    )

profile = l_profile(outer_width, outer_height, wall_thickness)
clip_body = (
    profile
    .extrude(clip_depth)
    .edges("|Z")
    .fillet(inner_radius * 0.9)
)

hole = (
    cq.Workplane("XY")
    .center(hole_offset_x, hole_offset_y)
    .circle(hole_diameter / 2)
    .extrude(clip_depth + 2)
)

result = (
    clip_body
    .cut(hole)
    .edges()
    .chamfer(chamfer_size)
)
