import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # base L shape profile
        profile = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.vertical_leg_width, 0)
            .lineTo(m.vertical_leg_width, m.vertical_leg_height)
            .lineTo(m.vertical_leg_width + m.horizontal_leg_length, m.vertical_leg_height)
            .lineTo(m.vertical_leg_width + m.horizontal_leg_length, m.vertical_leg_height + m.horizontal_leg_width)
            .lineTo(m.vertical_leg_width, m.vertical_leg_height + m.horizontal_leg_width)
            .lineTo(m.vertical_leg_width, m.vertical_leg_height + m.horizontal_leg_width + m.vertical_leg_width)
            .lineTo(0, m.vertical_leg_height + m.horizontal_leg_width + m.vertical_leg_width)
            .close()
        )
        base = profile.extrude(m.thickness)
        # interior fillet
        base = base.edges("|Z and <X and >Y").fillet(m.corner_fillet_radius)
        # flanged holes on vertical leg
        hole_face = base.faces("<Y")
        hole_positions = [(-m.vertical_leg_width/2 + m.flange_hole_offset, m.vertical_leg_height/3),
                          (-m.vertical_leg_width/2 + m.flange_hole_offset, 2*m.vertical_leg_height/3)]
        for x, y in hole_positions:
            hole_face = hole_face.workplane(centerOption='CenterOfBoundBox')
            hole_face = hole_face.move(x, y)
            hole_face = hole_face.cboreHole(m.flange_hole_diameter, m.flange_cbore_diameter, m.flange_cbore_depth)
        # add reinforcing ribs on horizontal leg
        rib_profile = (
            cq.Workplane('XY')
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_thickness)
        )
        rib_positions = [m.vertical_leg_width + m.horizontal_leg_length/4, m.vertical_leg_height + m.horizontal_leg_width/2]
        ribs = cq.Workplane('XY')
        for i in range(3):
            offset = m.rib_spacing * i
            ribs = ribs.union(
                rib_profile.translate((rib_positions[0] + offset, rib_positions[1], m.thickness/2))
            )
        self.model = base.union(ribs)

measures = Measures(
    vertical_leg_height=70.0,
    vertical_leg_width=20.0,
    horizontal_leg_length=80.0,
    horizontal_leg_width=20.0,
    thickness=10.0,
    corner_fillet_radius=3.0,
    flange_hole_diameter=6.0,
    flange_cbore_diameter=10.0,
    flange_cbore_depth=4.0,
    flange_hole_offset=5.0,
    rib_width=8.0,
    rib_height=8.0,
    rib_thickness=5.0,
    rib_spacing=15.0,
)

result = LBracket(cq.Workplane('XY'), measures).model