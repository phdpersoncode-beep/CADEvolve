import cadquery as cq
from types import SimpleNamespace as Measures

leg_length_x = 70.0
leg_length_y = 70.0
leg_width = 12.0
thickness = 8.0
inner_radius = 3.0
rib_width = 20.0
rib_thickness = 6.0
hole_diameter = 6.0
hole_offset = 30.0
chamfer_dist = 1.0

class LBracket:
    def __init__(self, workplane, m):
        self.model = workplane
        self.m = m
        self.build()
    def build(self):
        m = self.m
        base = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.leg_length_x, 0)
            .lineTo(m.leg_length_x, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.leg_length_y)
            .lineTo(0, m.leg_length_y)
            .close()
            .extrude(m.thickness)
            .edges('|Z')
            .fillet(m.inner_radius)
        )
        rib = (
            cq.Workplane('XY')
            .box(m.rib_width, m.rib_thickness, m.thickness)
            .translate((m.leg_width/2, m.leg_width/2, 0))
        )
        bracket = base.union(rib)
        pts = [
            (m.leg_width/2, m.hole_offset),
            (m.hole_offset, m.leg_width/2)
        ]
        bracket = (
            bracket.faces('>Z')
            .workplane()
            .pushPoints(pts)
            .hole(m.hole_diameter)
        )
        bracket = bracket.edges('|Z').chamfer(m.chamfer_dist)
        self.model = bracket

measures = Measures(
    leg_length_x=leg_length_x,
    leg_length_y=leg_length_y,
    leg_width=leg_width,
    thickness=thickness,
    inner_radius=inner_radius,
    rib_width=rib_width,
    rib_thickness=rib_thickness,
    hole_diameter=hole_diameter,
    hole_offset=hole_offset,
    chamfer_dist=chamfer_dist,
)

result = LBracket(cq.Workplane('XY'), measures).model