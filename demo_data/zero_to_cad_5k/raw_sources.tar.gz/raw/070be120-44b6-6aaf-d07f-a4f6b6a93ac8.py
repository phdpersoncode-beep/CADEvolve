import cadquery as cq
from math import acos, degrees, pi
from types import SimpleNamespace as Measures

m = Measures(
    chord_width=55.0,
    block_thickness=12.0,
    block_height=18.0,
    outer_diameter=100.0,
    outer_fillet_radius=4.0,
    inner_fillet_radius=2.0,
    fillet_angle=85.0,
    hole_diameter=5.0,
    hole_depth=8.0,
    hole_offset_x=20.0,
    hole_offset_y=6.0,
)

m.outer_radius = 0.5 * m.outer_diameter
m.inner_diameter = m.outer_diameter - m.block_thickness
m.inner_radius = 0.5 * m.inner_diameter
m.center_angle = degrees(acos((2 * m.inner_radius**2 - m.chord_width**2) / (2 * m.inner_radius**2)))
m.secant_angle = 0.5 * (180 - m.center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.chord_width, 0.0), m.inner_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.secant_angle, 0))
    .rect(m.block_thickness, m.block_height)
    .sweep(path, transition="round")
    .edges("|Z")
    .fillet(m.inner_fillet_radius)
    .edges("<Z")
    .fillet(m.outer_fillet_radius)
    .faces("<Z")
    .workplane()
    .center(m.hole_offset_x, m.hole_offset_y)
    .hole(m.hole_diameter, depth=m.hole_depth)
)
