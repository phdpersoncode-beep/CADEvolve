import cadquery as cq

outer_diameter = 80.0
height = 60.0
wall_thickness = 5.0
keyhole_width = 30.0
keyhole_radius = 10.0
keyhole_depth = 8.0
mount_hole_dia = 5.0
mount_hole_spacing = 40.0
mount_hole_offset = 15.0

class ShellCylinderKeyholePart:
    def __init__(self):
        self.base = None
        self.result = None
    def build_base(self):
        self.base = (
            cq.Workplane("XY")
            .circle(outer_diameter / 2)
            .extrude(height)
        )
    def apply_shell(self):
        self.result = self.base.faces("+Z").shell(-wall_thickness)
    def cut_keyhole(self):
        rectangle = (
            cq.Workplane("XY")
            .center(0, keyhole_width / 2)
            .rect(keyhole_width, 2 * keyhole_radius)
            .extrude(keyhole_depth)
        )
        circle = (
            cq.Workplane("XY")
            .center(0, keyhole_width / 2 + keyhole_radius)
            .circle(keyhole_radius)
            .extrude(keyhole_depth)
        )
        keyhole_profile = rectangle.union(circle).translate((0, 0, height - wall_thickness))
        self.result = self.result.cut(keyhole_profile)
    def add_mounting_holes(self):
        self.result = (
            self.result
            .faces("-Z")
            .workplane()
            .pushPoints([
                (-mount_hole_spacing / 2, mount_hole_offset),
                (mount_hole_spacing / 2, mount_hole_offset),
            ])
            .hole(mount_hole_dia)
        )
    def build(self):
        self.build_base()
        self.apply_shell()
        self.cut_keyhole()
        self.add_mounting_holes()
        return self.result

part = ShellCylinderKeyholePart()
result = part.build()
