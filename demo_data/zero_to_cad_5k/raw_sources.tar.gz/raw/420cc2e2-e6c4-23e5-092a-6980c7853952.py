import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    base_width=70.0,
    base_depth=20.0,
    base_thickness=6.0,
    rib_height=12.0,
    rib_width=40.0,
    rib_thickness=4.0,
    hole_1=Measures(position=15.0, diameter=3.0, cbore_diameter=5.0, cbore_depth=3.0),
    hole_2=Measures(position=55.0, diameter=3.0, cbore_diameter=5.0, cbore_depth=3.0),
    chamfer=0.5
)

# Base plate
base = (
    cq.Workplane("XY")
    .box(m.base_width, m.base_depth, m.base_thickness)
    .translate((0, 0, m.base_thickness / 2))
)

# Reinforcing rib with a recessed slot
rib = (
    cq.Workplane("XY")
    .workplane(offset=m.base_thickness)
    .center(0, 0)
    .rect(m.rib_width, m.base_depth)
    .extrude(m.rib_height)
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(m.rib_width - 6, m.base_depth - 8)
    .cutBlind(-m.rib_height / 2)
)

# Combine base and rib
model = base.union(rib)

# Bevel (chamfer) perimeter edges
model = model.edges().chamfer(m.chamfer)

# Add cbore holes through the top surface
wp = model.faces(">Z").workplane()
wp = wp.pushPoints([(m.hole_1.position - m.base_width / 2, 0)])
wp = wp.cboreHole(m.hole_1.diameter, m.hole_1.cbore_diameter, m.hole_1.cbore_depth)
wp = wp.pushPoints([(m.hole_2.position - m.base_width / 2, 0)])
result = wp.cboreHole(m.hole_2.diameter, m.hole_2.cbore_diameter, m.hole_2.cbore_depth)
