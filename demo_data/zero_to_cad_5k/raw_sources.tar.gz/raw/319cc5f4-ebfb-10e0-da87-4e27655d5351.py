import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, m):
        self.wp = wp
        self.m = m
        self.model = None
        self.build()

    def build(self):
        m = self.m
        vert = (
            cq.Workplane("XY")
            .box(m.thickness, m.vert_len, m.thickness)
            .translate((m.thickness / 2, m.vert_len / 2, m.thickness / 2))
        )
        horiz = (
            cq.Workplane("XY")
            .box(m.horiz_len, m.thickness, m.thickness)
            .translate((m.horiz_len / 2, m.thickness / 2, m.thickness / 2))
        )
        base = vert.union(horiz)
        # fillet inner corner edge (vertical edge at inner corner)
        base = (
            base
            .edges()
            .filter(lambda e: abs(e.Center().x) < 1e-6 and abs(e.Center().y) < 1e-6)
            .fillet(m.fillet_rad)
        )
        rib_vert = (
            cq.Workplane("XY")
            .box(m.rib_width, m.vert_len, m.rib_height)
            .translate((m.thickness + m.rib_width / 2, m.vert_len / 2, m.thickness / 2))
        )
        rib_horiz = (
            cq.Workplane("XY")
            .box(m.horiz_len, m.rib_width, m.rib_height)
            .translate((m.horiz_len / 2, m.thickness + m.rib_width / 2, m.thickness / 2))
        )
        bracket = base.union(rib_vert).union(rib_horiz)
        slot = (
            bracket
            .faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.horiz_len / 2, m.thickness / 2)
            .rect(m.slot_width, m.slot_depth)
            .cutBlind(-m.slot_depth)
        )
        holes_vert = (
            slot
            .faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .center(0, m.vert_len / 2)
            .cboreHole(m.hole_dia, m.hole_cbore_dia, m.hole_cbore_depth)
        )
        result = (
            holes_vert
            .faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.horiz_len / 2, 0)
            .cboreHole(m.hole_dia, m.hole_cbore_dia, m.hole_cbore_depth)
        )
        self.model = result

params = Measures(
    vert_len=70.0,
    horiz_len=50.0,
    thickness=10.0,
    fillet_rad=5.0,
    rib_width=6.0,
    rib_height=3.0,
    slot_width=12.0,
    slot_depth=4.0,
    hole_dia=4.0,
    hole_cbore_dia=6.0,
    hole_cbore_depth=2.0,
)

result = LBracket(cq.Workplane("XY"), params).model