import cadquery as cq
import math

# Parameters
base_radius = 30.0          # gear body radius (max 100)
gear_thickness = 10.0       # axial thickness
num_teeth = 24               # number of gear teeth
tooth_depth = 5.0            # radial depth of tooth cut (inward)
balance_count = 8           # number of balance masses
balance_width = 6.0         # tangential width of each mass
balance_height = 4.0        # axial height of each mass
balance_depth = 5.0         # radial extrusion of each mass (total thickness)
chamfer_size = 0.8          # chamfer size for balance masses

# Derived dimensions
tooth_width = (2 * math.pi * base_radius) / num_teeth * 0.6

# Base gear cylinder
gear_body = cq.Workplane("XY").cylinder(gear_thickness, base_radius)

# Teeth cut volumes using polar array
teeth = (
    cq.Workplane("XY")
    .polarArray(radius=base_radius - tooth_depth/2, startAngle=0, count=num_teeth, angle=360)
    .rect(tooth_width, gear_thickness)
    .extrude(tooth_depth)
)

gear_with_teeth = gear_body.cut(teeth)

# Balance masses on outer rim, extruding both directions to intersect gear for solid union
balance_masses = (
    cq.Workplane("XY")
    .polarArray(radius=base_radius + balance_depth/2, startAngle=0, count=balance_count, angle=360)
    .rect(balance_width, balance_height)
    .extrude(balance_depth, both=True)
    .edges()
    .chamfer(chamfer_size)
)

result = gear_with_teeth.union(balance_masses)
