import cadquery as cq
from types import SimpleNamespace as Measures

leg1_length=80.0
leg2_length=60.0
leg_thickness=12.0
height=20.0

profile = (
    cq.Workplane('XY')
    .lineTo(leg1_length, 0)
    .lineTo(leg1_length, leg_thickness)
    .lineTo(leg_thickness, leg_thickness)
    .lineTo(leg_thickness, leg2_length)
    .lineTo(0, leg2_length)
    .close()
)
solid = profile.extrude(height)
result = solid
