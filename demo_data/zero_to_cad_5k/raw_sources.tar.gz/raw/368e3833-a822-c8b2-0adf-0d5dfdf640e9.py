import cadquery as cq
import math

num_teeth = 48
pitch_diameter = 60.0
module = pitch_diameter / num_teeth
addendum = module
dedendum = 1.25 * module
pitch_radius = pitch_diameter / 2.0
outer_radius = pitch_radius + addendum
inner_radius = pitch_radius - dedendum
gear_thickness = 10.0
bore_diameter = 12.0
chamfer_distance = 1.0
rim_fillet_radius = 1.0

half_tooth_angle = math.pi / num_teeth

base = cq.Workplane("XY").circle(inner_radius).extrude(gear_thickness)

tooth = (
    cq.Workplane("XY")
    .moveTo(inner_radius * math.cos(-half_tooth_angle), inner_radius * math.sin(-half_tooth_angle))
    .lineTo(outer_radius * math.cos(-half_tooth_angle), outer_radius * math.sin(-half_tooth_angle))
    .lineTo(outer_radius * math.cos(half_tooth_angle), outer_radius * math.sin(half_tooth_angle))
    .lineTo(inner_radius * math.cos(half_tooth_angle), inner_radius * math.sin(half_tooth_angle))
    .close()
    .extrude(gear_thickness)
)

gear_body = base
for i in range(num_teeth):
    angle_deg = i * 360.0 / num_teeth
    rotated = tooth.rotate((0, 0, 0), (0, 0, 1), angle_deg)
    gear_body = gear_body.union(rotated)

gear_body = gear_body.edges("|Z").fillet(rim_fillet_radius)

bore = cq.Workplane("XY").circle(bore_diameter / 2).extrude(gear_thickness).edges().chamfer(chamfer_distance)

gear = gear_body.cut(bore)

result = gear