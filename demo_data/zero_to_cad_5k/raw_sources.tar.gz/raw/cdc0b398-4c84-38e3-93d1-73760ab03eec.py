import cadquery as cq
beam_length = 80.0
flange_width = 60.0
flange_thickness = 8.0
web_height = 40.0
web_thickness = 6.0
fillet_radius = 2.0
counterbore_diam = 12.0
counterbore_depth = 6.0
total_height = web_height + 2 * flange_thickness
base = cq.Workplane("XY").rect(flange_width, total_height).extrude(beam_length)
inner_width = flange_width - 2 * web_thickness
cavity = cq.Workplane("XY").rect(inner_width, web_height).extrude(beam_length)
solid = base.cut(cavity)
solid = solid.edges("|Y").fillet(fillet_radius)
result = solid.faces(">Z").workplane().cboreHole(counterbore_diam, counterbore_diam*0.6, counterbore_depth)
