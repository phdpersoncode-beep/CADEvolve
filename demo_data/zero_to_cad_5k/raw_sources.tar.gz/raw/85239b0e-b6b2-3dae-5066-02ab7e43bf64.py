import cadquery as cq
from types import SimpleNamespace as Measures

vertical_height = 70.0
horizontal_length = 60.0
bracket_thickness = 8.0
fillet_radius = 5.0
rib_width_z = 4.0
rib_height_y = 10.0
rib_protrusion = 3.0
rib_spacing = 12.0
rib_offset_from_bottom = 15.0
hole_diameter = 6.0
hole_spacing = 20.0
hole_offset_from_corner = 20.0

measures = Measures(
    vertical_height=vertical_height,
    horizontal_length=horizontal_length,
    bracket_thickness=bracket_thickness,
    fillet_radius=fillet_radius,
    rib_width_z=rib_width_z,
    rib_height_y=rib_height_y,
    rib_protrusion=rib_protrusion,
    rib_spacing=rib_spacing,
    rib_offset_from_bottom=rib_offset_from_bottom,
    hole_diameter=hole_diameter,
    hole_spacing=hole_spacing,
    hole_offset_from_corner=hole_offset_from_corner,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = self.build()

    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.horizontal_length, 0),
            (m.horizontal_length, m.bracket_thickness),
            (m.bracket_thickness, m.bracket_thickness),
            (m.bracket_thickness, m.vertical_height),
            (0, m.vertical_height),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.bracket_thickness)
        )
        base = (
            base.edges()
            .filter(lambda e: abs(e.Center().x - m.bracket_thickness) < 0.1 and abs(e.Center().y - m.bracket_thickness) < 0.1)
            .fillet(m.fillet_radius)
        )
        # rib positions along Y on inner vertical surface
        rib_positions = []
        max_y = m.vertical_height - m.rib_offset_from_bottom
        count = int((max_y - m.rib_offset_from_bottom) // m.rib_spacing) + 1
        for i in range(count):
            y = m.rib_offset_from_bottom + i * m.rib_spacing
            if y + m.rib_height_y / 2 > m.vertical_height:
                break
            rib_positions.append(y)
        # generate ribs and union
        reinforced = base
        for y in rib_positions:
            rib = (
                cq.Workplane("XY")
                .transformed(offset=(m.bracket_thickness, y, 0))
                .rect(m.rib_width_z, m.rib_height_y)
                .extrude(m.rib_protrusion)
            )
            reinforced = reinforced.union(rib)
        # mounting holes on top face (>Z)
        hole_centers = []
        for i in range(2):
            x = m.hole_offset_from_corner + i * m.hole_spacing
            y = m.bracket_thickness / 2
            hole_centers.append((x, y))
        reinforced = (
            reinforced.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints(hole_centers)
            .hole(m.hole_diameter)
        )
        return reinforced

result = LBracket(cq.Workplane("XY"), measures).model
