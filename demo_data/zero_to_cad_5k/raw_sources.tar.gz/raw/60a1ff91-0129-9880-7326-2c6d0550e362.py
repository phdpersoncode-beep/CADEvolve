import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.leg_length_horizontal, 0)
            .lineTo(m.leg_length_horizontal, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_length_vertical)
            .lineTo(0, m.leg_length_vertical)
            .close()
        )
        bracket = profile.extrude(m.bracket_depth)
        rib = (
            cq.Workplane('XY')
            .moveTo(m.leg_thickness, m.leg_thickness)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_depth)
        )
        bracket = bracket.union(rib)
        bracket = (
            bracket.faces('>Z')
            .workplane(centerOption='CenterOfBoundBox')
            .center(m.leg_length_horizontal/2, m.leg_thickness/2)
            .hole(m.m8_dia, depth=m.bracket_depth)
        )
        slot_center_y = m.leg_length_vertical/2
        slot_center_x = m.leg_thickness/2
        bracket = (
            bracket.faces('>Z')
            .workplane(centerOption='CenterOfBoundBox')
            .center(slot_center_x, slot_center_y)
            .rect(m.set_screw_slot_width, m.set_screw_slot_length)
            .cutBlind(-m.bracket_depth)
        )
        bracket = bracket.faces('>Z').edges().fillet(m.fillet_radius)
        self.model = bracket

measures = Measures(
    leg_length_horizontal=80.0,
    leg_length_vertical=60.0,
    leg_thickness=8.0,
    bracket_depth=8.0,
    rib_width=12.0,
    rib_height=6.0,
    rib_depth=8.0,
    m8_dia=8.0,
    fillet_radius=2.0,
    set_screw_slot_width=4.0,
    set_screw_slot_length=12.0,
)

result = LBracket(cq.Workplane('XY'), measures).model