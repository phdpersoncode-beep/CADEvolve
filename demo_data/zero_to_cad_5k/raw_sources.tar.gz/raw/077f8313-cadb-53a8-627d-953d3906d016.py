import cadquery as cq

bracket_length = 70.0
bracket_width = 40.0
bracket_thickness = 6.0
chamfer_distance = 1.0
boss_diameter = 20.0
boss_height = 12.0
set_screw_hole_diameter = 4.0
mounting_hole_diameter = 5.0
mounting_hole_offset = 10.0
slot_length = 30.0
slot_width = 6.0
rib_width = 8.0
rib_height_z = 3.0
rib_spacing = 12.0

base = (
    cq.Workplane("XY")
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
    .edges()
    .chamfer(chamfer_distance)
)

slot_solid = (
    cq.Workplane("XY")
    .rect(slot_length, slot_width)
    .extrude(bracket_thickness)
)

base = base.cut(slot_solid)

mount_points = [
    (-bracket_length/2 + mounting_hole_offset, -bracket_width/2 + mounting_hole_offset),
    (bracket_length/2 - mounting_hole_offset, -bracket_width/2 + mounting_hole_offset),
    (-bracket_length/2 + mounting_hole_offset, bracket_width/2 - mounting_hole_offset),
    (bracket_length/2 - mounting_hole_offset, bracket_width/2 - mounting_hole_offset)
]

base = (
    base.faces(">Z")
    .workplane()
    .pushPoints(mount_points)
    .hole(mounting_hole_diameter)
)

rib_prototype = (
    cq.Workplane("XY")
    .rect(rib_width, bracket_width - 2*mounting_hole_offset)
    .extrude(rib_height_z)
    .translate((0, 0, bracket_thickness))
)

rib_count = int((bracket_length - rib_width) / (rib_spacing + rib_width)) + 1
ribs = cq.Workplane("XY")
for i in range(rib_count):
    x_offset = -bracket_length/2 + rib_width/2 + i * (rib_spacing + rib_width)
    ribs = ribs.union(rib_prototype.translate((x_offset, 0, 0)))

boss = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(boss_diameter/2)
    .extrude(boss_height)
)

boss = (
    boss.faces(">Z")
    .workplane()
    .hole(set_screw_hole_diameter)
)

result = base.union(ribs).union(boss)
