import cadquery as cq
import math

# Parameters
gear_outer_diameter = 80.0
gear_inner_diameter = 50.0
gear_height = 20.0
teeth_count = 18
chamfer_distance = 0.5

# Derived dimensions
outer_radius = gear_outer_diameter / 2.0
inner_radius = gear_inner_diameter / 2.0
wall_thickness = outer_radius - inner_radius
tooth_depth = wall_thickness * 0.8
# Tooth angular width (percentage of tooth pitch)
tooth_pitch_angle = 360.0 / teeth_count
tooth_width_angle = tooth_pitch_angle * 0.6
mid_radius = inner_radius + tooth_depth / 2.0
tooth_width = 2 * mid_radius * math.sin(math.radians(tooth_width_angle / 2.0))

# Base solid: outer cylinder minus inner cylinder (hollow blank)
outer_cylinder = cq.Workplane("XY").cylinder(gear_height, outer_radius)
inner_cylinder = cq.Workplane("XY").cylinder(gear_height, inner_radius)
gear_blank = outer_cylinder.cut(inner_cylinder)

# Tooth cut geometry using polar array
tooth_cut = (
    cq.Workplane("XY")
    .center(inner_radius + tooth_depth / 2.0, 0)
    .rect(tooth_width, tooth_depth)
    .polarArray(count=teeth_count, radius=0, startAngle=0, angle=360)
    .extrude(gear_height)
)

# Apply tooth cuts to gear blank
gear_with_teeth = gear_blank.cut(tooth_cut)

# Apply chamfer to vertical edges for safety
final_result = gear_with_teeth.edges("|Z").chamfer(chamfer_distance)

result = final_result