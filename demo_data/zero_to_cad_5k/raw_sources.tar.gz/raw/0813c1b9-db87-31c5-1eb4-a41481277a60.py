import cadquery as cq

bracket_length = 60
bracket_width = 40
bracket_thickness = 8
inner_notch_w = 15
inner_notch_h = 8
side_notch_w = 20
side_notch_depth = 12
chamfer_size = 2
hole_dia = 3.2
hole_spacing = 22
hole_offset = 10

base = (
    cq.Workplane("XY")
    .sketch()
    .rect(bracket_length, bracket_width)
    .rect(inner_notch_w, inner_notch_h, mode="s")
    .finalize()
    .extrude(bracket_thickness)
)

base = (
    base.faces(">X")
    .workplane()
    .center(0, 0)
    .rect(side_notch_w, bracket_width)
    .cutBlind(-side_notch_depth)
)

base = (
    base.edges("|Y")
    .chamfer(chamfer_size)
)

result = (
    base.faces(">Z")
    .workplane()
    .center(-bracket_length/2 + hole_offset + hole_dia/2, 0)
    .rarray(hole_spacing, 0, 3, 1)
    .hole(hole_dia)
)
