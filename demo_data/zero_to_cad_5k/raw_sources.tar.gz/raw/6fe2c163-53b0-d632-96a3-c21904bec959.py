import cadquery as cq

knob_diameter = 70
knob_height = 30
wall_thickness = 3
slot_width = 5
slot_depth = 12
chamfer_size = 2
hole_diameter = 4
hole_spacing = 20
rib_width = 8
rib_height = 6
rib_spacing = 12
rib_cut_depth = 1.5

def firstSolid(self):
    return self.newObject([self.findSolid()])

cq.Workplane.firstSolid = firstSolid

base = (
    cq.Workplane("XY")
    .rect(knob_diameter, knob_diameter)
    .extrude(knob_height)
    .shell(-wall_thickness)
)

chamfered = (
    base
    .faces(">Y")
    .edges("|Z")
    .chamfer(chamfer_size)
)

slot = (
    chamfered
    .faces(">X")
    .workplane()
    .center((knob_diameter/2) - wall_thickness - slot_depth/2, 0)
    .rect(slot_depth, slot_width)
    .cutBlind(-knob_height + 2*wall_thickness)
)

holes = (
    slot
    .faces("<X")
    .workplane()
    .pushPoints([
        (-(knob_diameter/2) + wall_thickness + hole_diameter/2, -hole_spacing/2),
        (-(knob_diameter/2) + wall_thickness + hole_diameter/2, hole_spacing/2)
    ])
    .hole(hole_diameter)
)

rib_cuts = (
    holes
    .faces("<X")
    .workplane()
    .pushPoints([
        (-(knob_diameter/2) + wall_thickness + rib_cut_depth/2, y)
        for y in range(-int(rib_spacing*2), int(rib_spacing*2)+1, rib_spacing)
    ])
    .rect(rib_width, rib_height)
    .cutBlind(rib_cut_depth)
)

result = rib_cuts