import cadquery as cq
L = 80.0
H = 60.0
flange_width = 70.0
flange_thickness = 5.0
web_thickness = 4.0
hole_diameter = 5.0
hole_spacing = 15.0
chamfer_dist = 0.8
half_width = flange_width / 2.0
pts = [
    (0, 0),
    (half_width - flange_thickness, 0),
    (half_width - flange_thickness, flange_thickness),
    (web_thickness, flange_thickness),
    (web_thickness, H - flange_thickness),
    (half_width - flange_thickness, H - flange_thickness),
    (half_width - flange_thickness, H),
    (0, H)
]
beam = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .mirrorY()
    .extrude(L)
)
usable_web_height = H - 2 * flange_thickness
hole_count = int(usable_web_height // hole_spacing)
if hole_count < 1:
    hole_count = 1
beam = (
    beam.faces(">Z")
    .workplane()
    .center(0, -usable_web_height/2 + hole_spacing/2)
    .rarray(0, hole_spacing, 1, hole_count)
    .hole(hole_diameter)
)
result = beam.edges().chamfer(chamfer_dist)
