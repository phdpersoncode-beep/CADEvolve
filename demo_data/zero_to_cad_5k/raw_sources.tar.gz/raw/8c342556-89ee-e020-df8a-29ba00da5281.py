import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    leg1_len=80.0,
    leg2_len=60.0,
    profile_thickness=8.0,
    fillet_radius=2.0,
    rib_depth=4.0,
    rib_height=6.0,
    rib_width=2.0,
    pocket_width=30.0,
    pocket_height=20.0,
    pocket_depth=4.0,
    chamfer=1.0,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg1_len, 0)
            .lineTo(m.leg1_len, m.profile_thickness)
            .lineTo(m.profile_thickness, m.profile_thickness)
            .lineTo(m.profile_thickness, m.leg2_len)
            .lineTo(0, m.leg2_len)
            .close()
            .extrude(m.profile_thickness)
        )
        rib = (
            base
            .faces(">X").first()
            .workplane()
            .rect(m.rib_depth, m.rib_height)
            .extrude(m.rib_width)
        )
        refined = (
            rib
            .edges("|Z and <X and >Y")
            .fillet(m.fillet_radius)
            .edges(">X or >Y or >Z")
            .chamfer(m.chamfer)
        )
        pocket = (
            refined
            .faces("+Z").first()
            .workplane()
            .moveTo(m.profile_thickness/2, m.profile_thickness/2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        self.model = pocket

result = LBracket(cq.Workplane("XY"), m).model
