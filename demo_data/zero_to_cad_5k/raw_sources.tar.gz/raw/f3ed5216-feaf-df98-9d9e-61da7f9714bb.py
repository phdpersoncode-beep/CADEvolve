import cadquery as cq

# Parameters
body_diameter = 60
body_length = 80
wall_thickness = 5
fin_height = 20
fin_thickness = 4
fin_length = 30
vent_diameter = 10
vent_z = 60
inlet_diameter = 25
inlet_length = 15
fillet_radius = 2
chamfer_distance = 1

# Base cylindrical body (solid)
body = (
    cq.Workplane("XZ")
    .lineTo(body_diameter / 2, 0)
    .lineTo(body_diameter / 2, body_length)
    .lineTo(0, body_length)
    .close()
    .revolve()
)

# Hollow the body
hollow_body = body.shell(-wall_thickness)

# Fin attached to outer surface
fin = (
    cq.Workplane("YZ")
    .center(body_diameter / 2 + wall_thickness / 2, body_length / 2)
    .rect(fin_height, fin_thickness)
    .extrude(fin_length)
)

# Combine body and fin
combined = hollow_body.union(fin)

# Chamfer outer radial edges (including fin outer edge)
combined_chamfered = combined.edges(">X").chamfer(chamfer_distance)

# Vent drill through side wall
vent_cut = (
    combined_chamfered
    .faces(">X")
    .workplane()
    .center(0, vent_z)
    .circle(vent_diameter / 2)
    .cutBlind(wall_thickness + 0.1)
)

# Inlet cylinder extending below the bottom face
inlet_cylinder = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(inlet_diameter / 2)
    .extrude(inlet_length)
    .translate((0, 0, -inlet_length))
)

# Union inlet with the vent-cut body
with_inlet = vent_cut.union(inlet_cylinder)

# Fillet the circular edge where inlet meets the body (top face edge)
result = with_inlet.faces(">Z").edges().fillet(fillet_radius)
