import cadquery as cq

bracket_length = 60.0
bracket_width = 30.0
bracket_thickness = 6.0
cutout_width = 20.0
cutout_height = 30.0
cutout_fillet = 2.0
end_margin = 5.0
hole_diameter = 6.4
countersink_diameter = 9.0
countersink_angle = 82.0
hole_spacing = 20.0
chamfer_edge = 0.5
rib_width = 8.0
rib_height = 3.0
rib_offset = 12.0
rib_depth = bracket_thickness/2

base = (
    cq.Workplane("XY")
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
)

cutout_sketch = (
    cq.Sketch()
    .rect(cutout_width, cutout_height)
    .vertices()
    .fillet(cutout_fillet)
)

main_with_cutout = (
    base
    .faces(">X")
    .workplane()
    .center(bracket_length/2 - end_margin - cutout_width/2, 0)
    .placeSketch(cutout_sketch)
    .cutBlind(bracket_thickness)
)

main = (
    main_with_cutout
    .faces(">X")
    .workplane()
    .center(bracket_length/2 - end_margin - cutout_width/2, 0)
    .rarray(0, hole_spacing, 1, 3)
    .cskHole(hole_diameter, countersink_diameter, countersink_angle, bracket_thickness)
)

rib_sketch = (
    cq.Sketch()
    .rect(rib_width, rib_height)
)

ribs_cut = (
    main
    .faces("<Z")
    .workplane(offset=-bracket_thickness/2)
    .pushPoints([
        (rib_offset, -bracket_width/2 + rib_height/2),
        (rib_offset, bracket_width/2 - rib_height/2)
    ])
    .placeSketch(rib_sketch)
    .cutBlind(rib_depth)
)

result = ribs_cut.edges(">X").chamfer(chamfer_edge)
