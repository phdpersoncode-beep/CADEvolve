import cadquery as cq
import math
from types import SimpleNamespace as Measures

measures = Measures(
    outer_diameter = 80.0,
    thickness = 5.0,
    rib_height = 2.0,
    rib_width = 6.0,
    central_hole = Measures(
        diameter = 10.0,
        cbore_diameter = 15.0,
        cbore_depth = 3.0
    ),
    peripheral_hole = Measures(
        offset_radius = 30.0,
        diameter = 5.0,
        cbore_diameter = 8.0,
        cbore_depth = 2.0,
        count = 4
    ),
    chamfer_distance = 1.0
)
m = measures

base = (
    cq.Workplane("XY")
    .circle(m.outer_diameter / 2)
    .extrude(m.thickness)
)

rib = (
    cq.Workplane("XY", origin=(0, 0, m.thickness))
    .circle(m.outer_diameter / 2)
    .circle(m.outer_diameter / 2 - m.rib_width)
    .extrude(m.rib_height)
)

washer = base.union(rib)

washer = (
    washer.faces(">Z").workplane()
    .cboreHole(
        m.central_hole.diameter,
        m.central_hole.cbore_diameter,
        m.central_hole.cbore_depth
    )
)

points = []
angle_step = 360.0 / m.peripheral_hole.count
for i in range(m.peripheral_hole.count):
    angle = angle_step * i
    x = m.peripheral_hole.offset_radius * math.cos(math.radians(angle))
    y = m.peripheral_hole.offset_radius * math.sin(math.radians(angle))
    points.append((x, y))

washer = (
    washer.faces(">Z").workplane()
    .pushPoints(points)
    .cboreHole(
        m.peripheral_hole.diameter,
        m.peripheral_hole.cbore_diameter,
        m.peripheral_hole.cbore_depth
    )
)

result = washer.edges(">>Z").chamfer(m.chamfer_distance)
