import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width=70.0,
    block_thickness=15.0,
    block_height=12.0,
    arc_outer_diameter=100.0,
    rib_width=30.0,
    rib_thickness=8.0,
    rib_height=6.0,
    blind_hole_diameter=4.0,
    blind_hole_count=5,
    blind_hole_spacing=10.0,
    blind_hole_depth=8.0,
    fillet=0.5,
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_outer_radius**2 - m.linear_width**2) / (2 * m.arc_outer_radius**2)))
m.arc_secant_angle = 0.5 * (180.0 - m.arc_center_angle)

path = (
    cq.Workplane('XY')
    .radiusArc((m.linear_width, 0.0), m.arc_outer_radius)
    .wire()
)

block = (
    cq.Workplane('XY')
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_thickness, m.block_height)
    .sweep(path, transition='round')
)

rib = (
    block.faces('>Z')
    .workplane()
    .rect(m.rib_width, m.rib_thickness)
    .extrude(m.rib_height)
    .edges()
    .fillet(m.fillet)
)

spacing = m.blind_hole_spacing
count = m.blind_hole_count
start = - (count - 1) * spacing / 2.0
hole_positions = [(start + i * spacing, 0) for i in range(count)]

result = (
    rib.faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .hole(m.blind_hole_diameter, depth=m.blind_hole_depth)
)
