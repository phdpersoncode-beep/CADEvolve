import cadquery as cq

flange_diameter = 80.0
flange_radius = flange_diameter / 2.0
flange_thickness = 10.0
flange_hole_diameter = 10.0
flange_hole_radius = flange_hole_diameter / 2.0
bolt_hole_diameter = 10.0
bolt_hole_offset = 30.0
gusset_width = 20.0
gusset_height = 30.0
gusset_overlap = 1.0
fillet_radius = 3.0
rib_width = 8.0
rib_height = 20.0
rib_thickness = 4.0

base_sketch = cq.Sketch().circle(flange_radius).circle(flange_hole_radius, mode='s')
flange = cq.Workplane('XY').placeSketch(base_sketch).extrude(flange_thickness)

gusset = (
    cq.Workplane('XY')
    .center(flange_radius + gusset_width/2 - gusset_overlap, gusset_height/2)
    .rect(gusset_width, gusset_height)
    .extrude(flange_thickness)
)

result = flange.union(gusset)

result = result.edges("|Z").fillet(fillet_radius)

bolt_positions = [
    (bolt_hole_offset, 0),
    (0, bolt_hole_offset),
    (-bolt_hole_offset, 0),
    (0, -bolt_hole_offset),
]
result = result.faces('>Z').workplane().pushPoints(bolt_positions).hole(bolt_hole_diameter)

rib1 = (
    cq.Workplane('XY')
    .center(-flange_radius/2, 0)
    .rect(rib_width, rib_height)
    .extrude(rib_thickness)
)
rib2 = (
    cq.Workplane('XY')
    .center(flange_radius/2, 0)
    .rect(rib_width, rib_height)
    .extrude(rib_thickness)
)
result = result.union(rib1).union(rib2)
