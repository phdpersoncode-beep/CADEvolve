import cadquery as cq
from types import SimpleNamespace as Measures

class LAngleBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Create quarter-section by revolving a displaced rectangle
        bracket = (
            cq.Workplane('XZ')
            .move(m.inner_radius, 0)
            .rect(m.thickness, m.outer_radius)
            .revolve(90)
            .edges("|Z and >X")
            .fillet(m.fillet_radius)
        )
        # Holes on +X leg (outer radial face)
        bracket = (
            bracket
            .faces('>X')
            .workplane()
            .pushPoints([
                (m.hole_offset, m.hole_offset),
                (m.hole_offset, m.hole_offset + m.hole_spacing)
            ])
            .hole(m.hole_diameter)
        )
        # Holes on +Y leg (tangential face)
        bracket = (
            bracket
            .faces('>Y')
            .workplane()
            .pushPoints([
                (m.hole_offset, m.hole_offset),
                (m.hole_offset + m.hole_spacing, m.hole_offset)
            ])
            .hole(m.hole_diameter)
        )
        self.model = bracket

# Define parameters within scale limits (max 100)
measures = Measures(
    outer_radius=70.0,
    thickness=10.0,
    inner_radius=60.0,
    fillet_radius=2.0,
    hole_diameter=6.0,
    hole_offset=20.0,
    hole_spacing=30.0,
)

result = LAngleBracket(cq.Workplane('XY'), measures).model
