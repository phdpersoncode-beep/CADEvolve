import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()

    def build(self):
        m = self.measures
        pts = []
        pts.append((0, 0))
        pts.append((0, m.total_height))
        pts.append((m.total_width, m.total_height))
        pts.append((m.total_width, m.total_height - m.plate_thickness))
        pts.append((m.plate_thickness, m.total_height - m.plate_thickness))
        pts.append((m.plate_thickness, 0))
        pts.append((0, 0))
        base = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.plate_thickness)
        )
        hole_pts = [
            (m.plate_thickness/2, m.total_height - m.hole_offset_from_top),
            (m.plate_thickness/2, m.total_height - m.hole_offset_from_top - m.hole_spacing)
        ]
        plate_with_holes = (
            base.faces(">Y")
            .workplane()
            .pushPoints(hole_pts)
            .hole(m.hole_diameter)
        )
        rib = (
            plate_with_holes.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .moveTo(m.rib_thickness/2, 0)
            .rect(m.rib_width, m.total_height - 2*m.rib_margin)
            .extrude(m.rib_thickness)
            .translate((m.rib_thickness/2, 0, 0))
        )
        combined = plate_with_holes.union(rib)
        self.model = combined.edges("|Z and >X").chamfer(m.edge_chamfer)

measures = Measures(
    total_width=80.0,
    total_height=70.0,
    plate_thickness=10.0,
    hole_diameter=5.0,
    hole_spacing=30.0,
    hole_offset_from_top=12.0,
    rib_width=8.0,
    rib_thickness=3.0,
    rib_margin=5.0,
    edge_chamfer=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model