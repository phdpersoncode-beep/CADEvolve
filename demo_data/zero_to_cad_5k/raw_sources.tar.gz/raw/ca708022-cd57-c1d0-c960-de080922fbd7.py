import cadquery as cq

# Parameter definitions
leg_a = 70.0  # horizontal leg length (including thickness)
leg_b = 50.0  # vertical leg length (including thickness)
leg_width = 15.0  # width of each leg (thickness of L arm)
thickness = 10.0  # extrusion depth (Z direction)
wall_clearance = 2.0
rib_depth = 5.0
rib_margin = 2.0
m8_clearance = 9.0
m8_tap_dia = 6.8
m8_tap_depth = thickness
through_hole_dia = 5.0
through_hole_spacing = 20.0

class LBracket:
    def __init__(self, wp, measures):
        self.model = wp
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        # Main L profile sketch
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_a, 0),
                (m.leg_a, m.leg_width),
                (m.leg_width, m.leg_width),
                (m.leg_width, m.leg_b + m.leg_width),
                (0, m.leg_b + m.leg_width)
            ])
            .close()
            .extrude(m.thickness)
        )
        # Internal rib block (centered in the inner corner)
        rib_width = m.leg_width - 2 * m.wall_clearance
        rib = (
            cq.Workplane("XY")
            .rect(rib_width, rib_width)
            .extrude(m.rib_depth)
            .translate((m.wall_clearance, m.wall_clearance, 0))
        )
        body = profile.union(rib)
        # Central tapped M8 hole
        body = (
            body.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.leg_width/2, m.leg_width/2)
            .cboreHole(m.m8_clearance, m.m8_tap_dia, m.m8_tap_depth)
        )
        # Through holes on horizontal leg (two)
        horiz_hole_y = m.leg_width/2
        horiz_hole_xs = [m.leg_a/3, 2*m.leg_a/3]
        body = (
            body.faces(">Z")
            .workplane()
            .pushPoints([(x, horiz_hole_y) for x in horiz_hole_xs])
            .hole(m.through_hole_dia)
        )
        # Through holes on vertical leg (two)
        vert_hole_x = m.leg_width/2
        vert_hole_ys = [m.leg_b/3 + m.leg_width, 2*m.leg_b/3 + m.leg_width]
        body = (
            body.faces(">Z")
            .workplane()
            .pushPoints([(vert_hole_x, y) for y in vert_hole_ys])
            .hole(m.through_hole_dia)
        )
        self.model = body

# Measures namespace
class Measures:
    pass
measures = Measures()
measures.leg_a = leg_a
measures.leg_b = leg_b
measures.leg_width = leg_width
measures.thickness = thickness
measures.wall_clearance = wall_clearance
measures.rib_depth = rib_depth
measures.m8_clearance = m8_clearance
measures.m8_tap_dia = m8_tap_dia
measures.m8_tap_depth = m8_tap_depth
measures.through_hole_dia = through_hole_dia

# Build the part
result = LBracket(cq.Workplane("XY"), measures).model
