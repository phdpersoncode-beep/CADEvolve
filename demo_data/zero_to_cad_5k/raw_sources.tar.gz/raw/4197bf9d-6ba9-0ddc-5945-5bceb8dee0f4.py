import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L shape sketch and extrusion
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.leg_height + m.thickness),
                (0, m.leg_height + m.thickness),
            ])
            .close()
            .extrude(m.thickness)
        )
        # Rib on outer face of horizontal leg (+X face)
        rib = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.rib_width, m.rib_length)
            .extrude(m.rib_thickness)
        )
        # Add a circular notch to rib to make composite profile
        rib = (
            rib.faces(">X[-1]")
            .workplane(centerOption="CenterOfBoundBox")
            .hole(m.rib_notch_dia, depth=m.rib_thickness)
        )
        # Central through-hole on top face
        part = (
            rib.faces(">Z")
            .workplane()
            .center(m.thickness/2, m.thickness/2)
            .hole(m.through_hole_dia)
        )
        # Blind tapped holes (two) on top face, offset left/right
        part = (
            part.faces(">Z")
            .workplane()
            .pushPoints([
                (m.thickness/2 - m.blind_spacing/2, m.thickness/2),
                (m.thickness/2 + m.blind_spacing/2, m.thickness/2),
            ])
            .hole(m.blind_hole_dia, depth=m.blind_hole_depth)
        )
        # Chamfer outer edges
        part = part.edges("<<Z or >>Z or <<X or >>X").chamfer(m.chamfer)
        self.model = part

# Parameter definitions
measures = Measures(
    leg_length=60.0,           # length of horizontal leg
    leg_height=80.0,           # height of vertical leg
    thickness=10.0,            # plate thickness (extrude depth)
    rib_width=8.0,             # rib width (Y direction on +X face)
    rib_length=30.0,           # rib length (Z direction on +X face)
    rib_thickness=5.0,         # rib extrusion thickness (X direction)
    rib_notch_dia=4.0,         # circular notch diameter in rib
    through_hole_dia=8.0,      # central through-hole diameter
    blind_hole_dia=5.0,        # blind tapped hole diameter
    blind_hole_depth=8.0,      # blind hole depth
    blind_spacing=20.0,        # spacing between blind holes
    chamfer=0.8,               # chamfer distance
)

result = LBracket(cq.Workplane("XY"), measures).model