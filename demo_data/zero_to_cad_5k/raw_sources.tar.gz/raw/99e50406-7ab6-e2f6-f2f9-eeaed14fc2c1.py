import cadquery as cq

leaf_width = 80
leaf_height = 50
leaf_thickness = 10
cutout_diameter = 24
cutout_offset_y = leaf_height - 15
hole_diameter = 4
hole_spacing_x = 20
hole_spacing_y = 15
hole_rows = 2
hole_columns = 3
chamfer_distance = 1
rib_width = 4
rib_height = leaf_height - 10
rib_spacing = 10
rib_count = int((leaf_width - 2 * rib_spacing) // (rib_width + rib_spacing))
if rib_count < 1:
    rib_count = 1
rib_x_offsets = [ -leaf_width/2 + rib_spacing + rib_width/2 + i*(rib_width + rib_spacing) for i in range(rib_count) ]

tab_width = 12
tab_height = 6
tab_hole_dia = 5

# Base leaf with cutout and clearance holes
base = (
    cq.Workplane("XY")
    .rect(leaf_width, leaf_height)
    .extrude(leaf_thickness)
    .faces(">Z")
    .workplane()
    .center(0, cutout_offset_y)
    .hole(cutout_diameter)
    .faces(">Z")
    .workplane()
    .rarray(hole_spacing_x, hole_spacing_y, hole_columns, hole_rows, center=True)
    .hole(hole_diameter)
    .edges("|Z")
    .chamfer(chamfer_distance)
)

# Reinforcement ribs positioned across leaf width
ribs = (
    cq.Workplane("XY")
    .pushPoints([(x, 0) for x in rib_x_offsets])
    .rect(rib_width, rib_height)
    .extrude(leaf_thickness)
)

# Tabs with clearance holes on each side
single_tab = (
    cq.Workplane("XY")
    .rect(tab_width, tab_height)
    .extrude(leaf_thickness)
    .faces(">Z")
    .workplane()
    .hole(tab_hole_dia)
)

tab_left = single_tab.translate((-leaf_width/2 + tab_width/2, -leaf_height/2 - tab_height/2, 0))
tab_right = single_tab.translate((leaf_width/2 - tab_width/2, -leaf_height/2 - tab_height/2, 0))

tabs = tab_left.union(tab_right)

# Assemble final part
result = base.union(ribs).union(tabs)
