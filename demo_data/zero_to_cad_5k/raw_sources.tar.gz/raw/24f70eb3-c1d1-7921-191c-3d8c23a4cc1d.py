import cadquery as cq

# Parameters
leg_height = 70.0
leg_length = 80.0
leg_thickness = 10.0
bracket_thickness = 8.0
tab_width = 30.0
tab_depth = 6.0
tab_offset_y = 20.0
counterbore_dia = 6.0
counterbore_cbore_dia = 10.0
counterbore_cbore_depth = 4.0
m5_clearance = 5.5
hole_spacing = 20.0
chamfer_size = 0.8

# Base L shape sketch
points = [
    (0, 0),
    (0, leg_height),
    (leg_thickness, leg_height),
    (leg_thickness, leg_thickness),
    (leg_length, leg_thickness),
    (leg_length, 0),
    (0, 0)
]

base = (
    cq.Workplane('XY')
    .polyline(points)
    .close()
    .extrude(bracket_thickness)
)

# Recessed tab pocket on top face
pocket = (
    base.faces('>Z')
    .workplane()
    .move(leg_thickness/2, leg_height - tab_offset_y)
    .rect(tab_width, tab_depth)
    .cutBlind(-tab_depth)
)

# Counterbore hole on horizontal leg
counterbore = (
    pocket.faces('>Y')
    .workplane()
    .move(leg_length - 20, leg_thickness/2)
    .cboreHole(counterbore_dia, counterbore_cbore_dia, counterbore_cbore_depth)
)

# Pattern of three M5 clearance holes on vertical leg front face
final = (
    counterbore.faces('>Y')
    .workplane()
    .rarray(0, hole_spacing, 1, 3)
    .hole(m5_clearance)
    .edges('>Z')
    .chamfer(chamfer_size)
)

result = final
