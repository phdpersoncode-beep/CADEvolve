import cadquery as cq

class Measures:
    def __init__(self):
        self.leg_length = 80.0
        self.leg_width = 30.0
        self.thickness = 6.0
        self.inner_fillet_radius = 4.0
        self.pocket_width = 20.0
        self.pocket_length = 30.0
        self.pocket_depth = 4.0
        self.mount_hole_diameter = 6.0
        self.mount_hole_offset = 10.0
        self.rib_height = 4.0
        self.rib_thickness = 3.0

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.leg_width),
                (m.leg_width, m.leg_width),
                (m.leg_width, m.leg_length),
                (0, m.leg_length),
            ])
            .close()
            .extrude(m.thickness)
        )
        base = (
            base.edges()
            .filter(lambda e: abs(e.Center().x - m.leg_width) < 0.1 and abs(e.Center().y - m.leg_width) < 0.1)
            .fillet(m.inner_fillet_radius)
        )
        base = (
            base.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.leg_width/2, m.leg_width/2)
            .rect(m.pocket_width, m.pocket_length)
            .cutBlind(m.pocket_depth)
        )
        base = (
            base.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints([
                (m.mount_hole_offset, m.mount_hole_offset),
                (m.mount_hole_offset, m.leg_width - m.mount_hole_offset),
                (m.leg_length - m.mount_hole_offset, m.mount_hole_offset),
                (m.leg_length - m.mount_hole_offset, m.leg_width - m.mount_hole_offset),
            ])
            .hole(m.mount_hole_diameter)
        )
        self.model = base

measures = Measures()
result = LBracket(cq.Workplane("XY"), measures).model
