import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .rect(m.leg_width, m.vertical_leg_length)
            .extrude(m.leg_thickness)
        )
        horizontal = (
            cq.Workplane("XY")
            .rect(m.horizontal_leg_length, m.leg_width)
            .translate((0, m.vertical_leg_length - m.leg_width, 0))
            .extrude(m.leg_thickness)
        )
        base_l = vertical.union(horizontal)
        base_l = base_l.edges("|Z").chamfer(m.chamfer_size)
        lip = (
            cq.Workplane("XY")
            .rect(m.horizontal_leg_length, m.lip_width)
            .translate((0, m.vertical_leg_length - m.lip_width, m.leg_thickness))
            .extrude(m.lip_thickness)
        )
        bracket = base_l.union(lip)
        bracket = (
            bracket.faces("<Z")
            .workplane()
            .center(-m.leg_width/2 + m.hole_edge_offset, m.vertical_leg_length/2)
            .hole(m.hole_diameter)
            .center(m.leg_width - 2*m.hole_edge_offset, 0)
            .hole(m.hole_diameter)
        )
        bracket = (
            bracket.faces("<Z")
            .workplane()
            .center(m.horizontal_leg_length/2, -m.vertical_leg_length + m.leg_width/2)
            .hole(m.hole_diameter)
            .center(-m.hole_spacing, 0)
            .hole(m.hole_diameter)
        )
        self.model = bracket

measures = Measures(
    leg_width=12.0,
    vertical_leg_length=60.0,
    horizontal_leg_length=70.0,
    leg_thickness=8.0,
    lip_width=20.0,
    lip_thickness=4.0,
    chamfer_size=2.0,
    hole_diameter=5.0,
    hole_edge_offset=5.0,
    hole_spacing=30.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
