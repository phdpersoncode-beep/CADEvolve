import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = cq.Workplane('XY').box(m.arm_width, m.vertical_length, m.thickness)
        horiz_center_x = (m.arm_width + m.horizontal_length) / 2
        horiz_center_y = m.vertical_length - m.arm_width / 2
        horizontal = (cq.Workplane('XY')
                     .translate((horiz_center_x, horiz_center_y, 0))
                     .box(m.horizontal_length, m.arm_width, m.thickness))
        base = vertical.union(horizontal)
        # recessed tab cutout
        tab_x = m.vertical_length - m.arm_width / 2 - m.tab_offset
        tab_y = m.horizontal_length / 2 + m.arm_width / 2
        base = (base.faces('>Z')
                .workplane()
                .move(tab_x, tab_y)
                .rect(m.tab_width, m.tab_depth)
                .cutBlind(m.thickness - m.tab_clearance))
        # blind tapped holes on vertical arm front
        hole_y1 = m.vertical_length * 0.3
        hole_y2 = m.vertical_length * 0.7
        base = (base.faces('>Y')
                .workplane()
                .pushPoints([(m.arm_width/2, hole_y1), (m.arm_width/2, hole_y2)])
                .hole(m.hole_diameter, depth=m.hole_depth))
        # spot weld dimples (blind holes) on outer corners
        base = (base.faces('>Y')
                .workplane()
                .pushPoints([(m.arm_width/2, m.vertical_length - m.arm_width/2)])
                .hole(m.weld_dimple_diameter, depth=m.weld_dimple_depth))
        base = (base.faces('>X')
                .workplane()
                .pushPoints([(m.horizontal_length - m.arm_width/2, m.vertical_length - m.arm_width/2)])
                .hole(m.weld_dimple_diameter, depth=m.weld_dimple_depth))
        base = base.edges('|Z').chamfer(m.chamfer)
        self.model = base

measures = Measures(
    arm_width=15.0,
    vertical_length=60.0,
    horizontal_length=50.0,
    thickness=8.0,
    tab_width=12.0,
    tab_depth=20.0,
    tab_clearance=2.0,
    tab_offset=5.0,
    hole_diameter=5.0,
    hole_depth=6.0,
    weld_dimple_diameter=2.0,
    weld_dimple_depth=1.0,
    chamfer=0.5
)

result = LBracket(cq.Workplane('XY'), measures).model