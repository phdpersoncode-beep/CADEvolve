import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        leg_long = cq.Workplane('XY').box(m.leg_long_length, m.leg_width, m.thickness).translate((m.leg_long_length/2, m.leg_width/2, m.thickness/2))
        leg_short = cq.Workplane('XY').box(m.leg_width, m.leg_short_length, m.thickness).translate((m.leg_width/2, m.leg_short_length/2, m.thickness/2))
        base = leg_long.union(leg_short)
        rib = (
            cq.Workplane('XY')
            .move(0, 0)
            .polyline([(0, 0), (m.rib_thickness, 0), (0, m.rib_thickness)])
            .close()
            .extrude(m.thickness)
        )
        bracket = base.union(rib)
        bracket = (
            bracket.faces('>Z').workplane()
            .center(m.edge_clearance + (m.leg_long_length - 2*m.edge_clearance)/2, m.leg_width/2)
            .rect(m.leg_long_length - 2*m.edge_clearance, m.leg_width - 2*m.edge_clearance, forConstruction=True)
            .vertices()
            .hole(m.hole_diameter)
        )
        bracket = (
            bracket.faces('>Z').workplane()
            .center(m.leg_width/2, m.edge_clearance + (m.leg_short_length - 2*m.edge_clearance)/2)
            .rect(m.leg_width - 2*m.edge_clearance, m.leg_short_length - 2*m.edge_clearance, forConstruction=True)
            .vertices()
            .hole(m.hole_diameter)
        )
        bracket = bracket.edges('|Z').chamfer(m.chamfer_size)
        self.model = bracket

measures = Measures(
    leg_long_length=80.0,
    leg_short_length=60.0,
    leg_width=30.0,
    thickness=10.0,
    rib_thickness=5.0,
    edge_clearance=8.0,
    hole_diameter=5.0,
    chamfer_size=0.8,
)

result = LBracket(cq.Workplane('XY'), measures).model