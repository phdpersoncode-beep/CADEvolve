import cadquery as cq
import math
module = 4.0
num_teeth = 20
gear_thickness = 15.0
shaft_bore_diameter = 20.0
oil_passage_diameter = 12.0
set_screw_diameter = 5.0
keyway_width = 6.0
keyway_depth = 4.0
bore_fillet_radius = 2.0
edge_fillet = 1.0
pitch_diameter = module * num_teeth
pitch_radius = pitch_diameter / 2.0
outer_diameter = (num_teeth + 2) * module
outer_radius = outer_diameter / 2.0

def hypocycloid(t, r1, r2):
    return ((r1 - r2) * math.cos(t) + r2 * math.cos(r1 / r2 * t - t),
            (r1 - r2) * math.sin(t) + r2 * math.sin(-(r1 / r2 * t - t)))

def epicycloid(t, r1, r2):
    return ((r1 + r2) * math.cos(t) - r2 * math.cos(r1 / r2 * t + t),
            (r1 + r2) * math.sin(t) - r2 * math.sin(r1 / r2 * t + t))

def gear_profile(t, r1=25.0, r2=5.0):
    if ((-1) ** (1 + math.floor(t / (2 * math.pi) * (r1 / r2))) < 0):
        return epicycloid(t, r1, r2)
    else:
        return hypocycloid(t, r1, r2)
gear_body = (
    cq.Workplane('XY')
    .parametricCurve(lambda t: gear_profile(t * 2 * math.pi))
    .extrude(gear_thickness)
)
gear_with_bore = (
    gear_body
    .faces('>Z')
    .workplane()
    .hole(shaft_bore_diameter)
    .edges('|Z')
    .fillet(bore_fillet_radius)
)
gear_with_oil = (
    gear_with_bore
    .workplane(offset=gear_thickness/2)
    .transformed(offset=(outer_radius - oil_passage_diameter/2, 0, 0), rotate=(0,90,0))
    .hole(oil_passage_diameter, depth=outer_radius)
)
gear_with_screw = (
    gear_with_oil
    .faces('>Z')
    .workplane()
    .center(outer_radius - 10, 0)
    .hole(set_screw_diameter)
)
gear_with_keyway = (
    gear_with_screw
    .workplane(offset=gear_thickness/2)
    .center(pitch_radius, 0)
    .rect(keyway_width, keyway_depth)
    .cutBlind(gear_thickness)
)
result = (
    gear_with_keyway
    .edges()
    .fillet(edge_fillet)
)
