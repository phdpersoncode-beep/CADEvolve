import cadquery as cq

# Dimensions (max 100)
duct_length = 80.0
duct_width = 40.0
duct_height = 30.0
wall_thickness = 2.0
slot_width = 8.0
slot_length = 20.0
counter_screw_diameter = 5.0
counter_head_diameter = 9.0
counter_angle = 82.0  # typical countersink angle
chamfer_size = 0.5

# Base solid
result = (
    cq.Workplane('XY')
    .box(duct_length, duct_width, duct_height, centered=(True, True, False))
    # Slot on +Y face (side wall)
    .faces('>Y')
    .workplane()
    .rect(slot_width, slot_length)
    .cutBlind(-wall_thickness * 2)
    # Countersunk hole on -X face (end wall)
    .faces('<X')
    .workplane()
    .cskHole(counter_screw_diameter, counter_head_diameter, counter_angle)
    # Shell to create thin walls
    .shell(-wall_thickness)
    # Chamfer outer edges for safety
    .edges('|Z')
    .chamfer(chamfer_size)
)
