import cadquery as cq

# Dimensions (max 100 units = 10 cm)
outer_diameter = 80.0
height = 60.0
wall_thickness = 4.0
rib_thickness = 2.0
rib_height = 45.0
rib_count = 6
sensor_counterbore_diameter = 15.0
sensor_counterbore_depth = 12.0
top_chamfer = 1.5

# Derived values
outer_radius = outer_diameter / 2.0
inner_radius = outer_radius - wall_thickness
rib_radial_span = outer_radius - inner_radius

# 1. Thin-walled cylinder (shell) using concentric circles
shell = (
    cq.Workplane("XY")
    .circle(outer_radius)
    .circle(inner_radius)
    .extrude(height)
)

# 2. Internal cooling ribs: patterned 2D sketch then extrude
ribs = (
    cq.Workplane("YZ")
    .moveTo(inner_radius, 0)
    .rect(rib_thickness, rib_height)
    .polarArray(0, 0, 360, rib_count)
    .extrude(rib_radial_span)
    .translate((0, 0, (height - rib_height) / 2.0))
)

# 3. Combine shell and ribs
combined = shell.union(ribs)

# 4. Counterbore for sensor on top surface (centered)
combined = combined.faces(">Z").workplane().hole(sensor_counterbore_diameter, sensor_counterbore_depth)

# 5. Chamfer top outer edge for safety
combined = combined.faces(">Z").edges().chamfer(top_chamfer)

result = combined
