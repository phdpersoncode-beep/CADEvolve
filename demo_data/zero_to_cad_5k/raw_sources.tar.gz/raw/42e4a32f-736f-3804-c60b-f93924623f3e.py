import cadquery as cq
from types import SimpleNamespace as Measures

vertical_length = 70.0
horizontal_length = 55.0
thickness = 8.0
hole_diameter = 6.0
mount_hole_diameter = 5.0
mount_spacing = 30.0
fillet_radius = 2.0
chamfer_distance = 1.0
notch_width = 12.0
notch_depth = 6.0
gusset_height = 15.0
gusset_thickness = 4.0

measures = Measures(
    vertical_length=vertical_length,
    horizontal_length=horizontal_length,
    thickness=thickness,
    hole_diameter=hole_diameter,
    mount_hole_diameter=mount_hole_diameter,
    mount_spacing=mount_spacing,
    fillet_radius=fillet_radius,
    chamfer_distance=chamfer_distance,
    notch_width=notch_width,
    notch_depth=notch_depth,
    gusset_height=gusset_height,
    gusset_thickness=gusset_thickness,
)

class LBracket:
    def __init__(self, wp, m):
        self.wp = wp
        self.m = m
        self.model = None
        self.build()

    def build(self):
        m = self.m
        profile = (
            self.wp.polyline([
                (0, 0),
                (0, m.vertical_length),
                (m.thickness, m.vertical_length),
                (m.thickness, m.thickness),
                (m.horizontal_length, m.thickness),
                (m.horizontal_length, 0),
                (0, 0),
            ])
            .close()
        )
        solid = profile.extrude(m.thickness)
        solid = (
            solid.faces(">Z")
            .workplane()
            .center(m.horizontal_length - m.notch_width/2 - 5, m.thickness/2)
            .rect(m.notch_width, m.notch_depth)
            .cutBlind(m.thickness)
        )
        solid = (
            solid.faces(">Z")
            .workplane()
            .center(m.thickness/2, m.vertical_length)
            .hole(m.hole_diameter)
        )
        hole_offset = (m.horizontal_length - m.mount_spacing) / 2
        solid = (
            solid.faces(">Z")
            .workplane()
            .center(hole_offset, m.thickness/2)
            .hole(m.mount_hole_diameter)
            .workplane()
            .center(m.horizontal_length - hole_offset, m.thickness/2)
            .hole(m.mount_hole_diameter)
        )
        gusset = (
            cq.Workplane("XY")
            .polyline([
                (m.horizontal_length, 0),
                (m.horizontal_length + m.gusset_thickness, 0),
                (m.horizontal_length, m.gusset_height),
                (m.horizontal_length, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        solid = solid.union(gusset)
        solid = solid.edges("|Z and >X").chamfer(m.chamfer_distance)
        solid = solid.edges("|Z and <X and <Y").fillet(m.fillet_radius)
        self.model = solid

result = LBracket(cq.Workplane("XY"), measures).model
