
import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile extruded to thickness
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.vertical_length),
                (0, m.vertical_length),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness)
        )
        # Relief cut in inner corner (square)
        relief = (
            profile.faces(">Z")
            .workplane()
            .rect(m.relief_size, m.relief_size)
            .cutBlind(-m.thickness)
        )
        # Counterbore holes on outer vertical leg (negative X face)
        holes = (
            relief.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints([
                (0, m.vertical_length/2 - m.hole_margin - i*m.hole_spacing)
                for i in range(3)
            ])
            .cboreHole(m.hole_diameter, m.hole_cbore_diameter, m.hole_cbore_depth)
        )
        # Small chamfers on all outer vertical edges to remove sharpness
        result = (
            holes.edges("|Z and (>X or <X)")
            .chamfer(m.chamfer)
        )
        self.model = result

# Define parameters respecting the 100‑unit max scale
measures = Measures(
    horizontal_length=70.0,   # length of horizontal leg
    vertical_length=80.0,     # length of vertical leg
    thickness=8.0,            # bracket thickness (extrusion depth)
    relief_size=5.0,          # square relief cut size
    hole_diameter=6.0,        # clearance diameter for main holes
    hole_cbore_diameter=8.0,  # counterbore diameter
    hole_cbore_depth=2.0,     # counterbore depth
    hole_margin=15.0,         # distance from top edge to first hole centre
    hole_spacing=25.0,        # spacing between hole centres
    chamfer=0.5,              # chamfer distance for outer edges
)

bracket = LBracket(cq.Workplane("XY"), measures)
result = bracket.model
