import cadquery as cq

flange_length = 80.0
flange_width = 50.0
flange_thickness = 8.0
gusset_height = 30.0
gusset_thickness = 6.0
hole_clearance_diameter = 4.5
hole_edge_offset = 10.0
fillet_radius = 0.5
rib_height = 4.0
rib_thickness = 3.0
pocket_depth = 3.0

base = (cq.Workplane('XY')
        .rect(flange_length, flange_width)
        .extrude(flange_thickness))

gusset_profile = [
    (0, 0),
    (0, gusset_height),
    (gusset_thickness, 0)
]

gusset = (base.faces('>X').workplane()
          .polyline(gusset_profile)
          .close()
          .extrude(gusset_thickness))

gusset_fillet = gusset.fillet(fillet_radius)

combined = base.union(gusset_fillet)

hole_positions = [
    (-flange_length/2 + hole_edge_offset, 0),
    (0, 0),
    (flange_length/2 - hole_edge_offset, 0)
]

with_holes = (combined.faces('>Z')
               .workplane()
               .pushPoints(hole_positions)
               .hole(hole_clearance_diameter))

rib = (with_holes.faces('<Z')
        .workplane(centerOption='CenterOfMass')
        .rect(rib_thickness, flange_width - 2*hole_edge_offset)
        .extrude(rib_height)
        .translate((0, 0, -flange_thickness)))

with_rib = with_holes.union(rib)

pocket = (with_rib.faces('<Z')
          .workplane()
          .rect(flange_length - 2*hole_edge_offset, flange_width - 2*hole_edge_offset)
          .cutBlind(-pocket_depth))

result = pocket