import cadquery as cq
import math

outer_radius = 40.0
inner_radius = 20.0
thickness = 15.0
fillet_radius = 5.0
recess_depth = 6.0
hole_diameter = 6.0
num_holes = 6
hole_circle_radius = (inner_radius + outer_radius) / 2.0
hole_pitch_angle = 360.0 / num_holes

profile = (
    cq.Workplane("XZ")
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius - fillet_radius, 0)
    .threePointArc((outer_radius, 0), (outer_radius, fillet_radius))
    .lineTo(outer_radius, thickness - fillet_radius)
    .threePointArc((outer_radius, thickness), (outer_radius - fillet_radius, thickness))
    .lineTo(inner_radius, thickness)
    .close()
)

flange = profile.revolve(axisStart=cq.Vector(0, 0, 0), axisEnd=cq.Vector(0, 1, 0))

flange = (
    flange.faces(">Z")
    .workplane()
    .hole(2 * (inner_radius - 5.0), depth=recess_depth)
)

hole_positions = [
    (
        hole_circle_radius * math.cos(math.radians(i * hole_pitch_angle)),
        hole_circle_radius * math.sin(math.radians(i * hole_pitch_angle)),
    )
    for i in range(num_holes)
]
flange = (
    flange.faces(">Z")
    .workplane()
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)

result = flange