import cadquery as cq
beam_total_height = 80.0
flange_thickness = 10.0
web_thickness = 6.0
fillet_radius = 1.0
pocket_depth = 4.0
pocket_width = 12.0
pocket_length = 24.0
half_height = beam_total_height / 2.0
outer_radius = web_thickness / 2.0 + flange_thickness
inner_radius = web_thickness / 2.0
pts = [
    (0, 0),
    (outer_radius, 0),
    (outer_radius, flange_thickness),
    (inner_radius, flange_thickness),
    (inner_radius, half_height - flange_thickness),
    (outer_radius, half_height - flange_thickness),
    (outer_radius, half_height),
    (0, half_height)
]
solid = (
    cq.Workplane("XZ")
    .polyline(pts)
    .close()
    .revolve()
)
solid = solid.edges("%Circle and <Z").fillet(fillet_radius)
solid = (
    solid.faces(">Z")
    .workplane()
    .rect(pocket_width, pocket_length)
    .cutBlind(-pocket_depth)
)
result = solid