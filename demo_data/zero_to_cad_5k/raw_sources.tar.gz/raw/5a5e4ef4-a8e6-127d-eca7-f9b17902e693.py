import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile extrusion
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.vertical_height),
                (0, m.vertical_height),
            ])
            .close()
            .extrude(m.bracket_depth)
            .edges("|Z")
            .chamfer(m.inner_chamfer)
            .shell(m.wall_thickness)
        )
        # Recessed pocket at junction on top face
        pocket = (
            profile.faces(">Z")
            .workplane()
            .center(m.thickness/2, m.thickness/2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(m.pocket_depth)
        )
        # Through hole on top of vertical leg
        result = (
            pocket.faces(">Z")
            .workplane()
            .center(m.thickness/2, m.vertical_height/2)
            .hole(m.top_hole_diameter)
        )
        self.model = result

measures = Measures(
    horizontal_length=80.0,
    vertical_height=70.0,
    thickness=10.0,
    bracket_depth=12.0,
    wall_thickness=2.0,
    inner_chamfer=0.5,
    pocket_width=15.0,
    pocket_height=15.0,
    pocket_depth=6.0,
    top_hole_diameter=5.0,
)

result = LBracket(cq.Workplane("XY"), measures).model