import cadquery as cq
horizontal_length=80.0
vertical_height=60.0
flange_thickness=4.0
fillet_radius=1.0
profile = cq.Workplane('XY').lineTo(horizontal_length,0).lineTo(horizontal_length,flange_thickness).lineTo(flange_thickness,flange_thickness).lineTo(flange_thickness,vertical_height).lineTo(0,vertical_height).close()
solid = profile.extrude(flange_thickness)
result = solid.edges().fillet(fillet_radius)
