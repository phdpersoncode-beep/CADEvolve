import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters (max dimension 100)
width = 80.0
height = 60.0
thickness = 8.0
leg_width = 20.0
central_hole_diameter = 15.0
fillet_radius = 2.0
chamfer_dist = 1.0
mount_hole_diameter = 5.0
mount_spacing = 20.0
mount_offset = 10.0

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()
    def build(self):
        m = self.m
        # L profile sketch
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_width, 0)
            .lineTo(m.leg_width, m.height - m.leg_width)
            .lineTo(m.width, m.height - m.leg_width)
            .lineTo(m.width, m.height)
            .lineTo(0, m.height)
            .close()
        )
        solid = profile.extrude(m.thickness)
        # Chamfer outer edges (vertical and horizontal)
        solid = solid.edges().chamfer(m.chamfer_dist)
        # Fillet interior corner vertical edges located at inner corner
        interior_x = m.leg_width
        interior_y = m.height - m.leg_width
        solid = (
            solid.edges()
            .filter(lambda e: abs(e.Center().x - interior_x) < 0.01 and abs(e.Center().y - interior_y) < 0.01)
            .fillet(m.fillet_radius)
        )
        # Central drilled hole at interior corner (through thickness)
        solid = (
            solid.faces('>Z')
            .workplane()
            .center(interior_x - m.width/2, interior_y - m.height/2)
            .hole(m.central_hole_diameter)
        )
        # Mounting holes on vertical leg (face >Y)
        for i in range(3):
            y_pos = m.mount_offset + i * m.mount_spacing
            solid = (
                solid.faces('>Y')
                .workplane()
                .center(m.leg_width/2 - m.width/2, y_pos - m.height/2)
                .hole(m.mount_hole_diameter)
            )
        # Mounting holes on horizontal leg (face >X)
        for i in range(3):
            x_pos = m.mount_offset + i * m.mount_spacing
            solid = (
                solid.faces('>X')
                .workplane()
                .center(x_pos - m.width/2, (m.height - m.leg_width/2) - m.height/2)
                .hole(m.mount_hole_diameter)
            )
        self.model = solid

measures = Measures(
    width=width,
    height=height,
    thickness=thickness,
    leg_width=leg_width,
    central_hole_diameter=central_hole_diameter,
    fillet_radius=fillet_radius,
    chamfer_dist=chamfer_dist,
    mount_hole_diameter=mount_hole_diameter,
    mount_spacing=mount_spacing,
    mount_offset=mount_offset,
)

result = LBracket(cq.Workplane('XY'), measures).model