import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, wp, m):
        self.m = m
        self.model = wp
        self.build()

    def build(self):
        m = self.m
        base = (
            cq.Workplane('XY')
            .box(m.long_arm_length, m.thickness, m.profile_depth)
            .translate((m.long_arm_length/2, m.thickness/2, 0))
            .union(
                cq.Workplane('XY')
                .box(m.thickness, m.short_arm_length, m.profile_depth)
                .translate((m.thickness/2, m.short_arm_length/2, 0))
            )
        )
        large_fillet_cut = (
            cq.Workplane('XY')
            .center(m.thickness - m.large_fillet_radius, m.thickness - m.large_fillet_radius)
            .circle(m.large_fillet_radius)
            .extrude(-m.profile_depth)
        )
        small_fillet_cut = (
            cq.Workplane('XY')
            .center(m.thickness - m.small_fillet_radius, m.thickness - m.small_fillet_radius)
            .circle(m.small_fillet_radius)
            .extrude(-m.profile_depth)
        )
        bracket = base.cut(large_fillet_cut).cut(small_fillet_cut)
        slots = (
            bracket.faces('>Z').workplane()
            .center(m.long_arm_length/2, m.thickness/2)
            .rarray(m.slot_spacing, 0, 3, 1)
            .rect(m.slot_length, m.slot_width)
            .cutBlind(m.profile_depth)
        )
        result = slots.edges('|Z and (>X or >Y)').chamfer(m.outer_chamfer)
        self.model = result

measures = Measures(
    long_arm_length=80.0,
    short_arm_length=60.0,
    thickness=20.0,
    profile_depth=8.0,
    large_fillet_radius=6.0,
    small_fillet_radius=3.0,
    slot_length=30.0,
    slot_width=6.0,
    slot_spacing=25.0,
    outer_chamfer=2.0,
)

result = LBracket(cq.Workplane('XY'), measures).model