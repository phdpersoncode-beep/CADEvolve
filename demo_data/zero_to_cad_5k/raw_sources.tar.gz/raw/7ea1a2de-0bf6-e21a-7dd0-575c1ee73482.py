import cadquery as cq
import math
outer_diameter = 80.0
inner_diameter = 30.0
thickness = 6.0
edge_fillet = 1.5
screw_diameter = 10.0
countersink_diameter = 18.0
countersink_angle_deg = 82.0
mounting_hole_diameter = 5.0
mount_radius = outer_diameter/2 - 8.0
boss_extra_radius = 5.0
boss_thickness = 2.0
chamfer_dist = 0.7
angle_rad = math.radians(countersink_angle_deg)
cs_depth = (countersink_diameter - screw_diameter)/2 / math.tan(angle_rad/2)
if cs_depth > thickness:
    cs_depth = thickness*0.6
base = (cq.Workplane("XY")
        .circle(outer_diameter/2)
        .circle(inner_diameter/2)
        .extrude(thickness))
base = base.faces(">Z").edges().fillet(edge_fillet)
# countersink cut
cyl_depth = thickness - cs_depth
cyl = (cq.Workplane("XY")
       .circle(screw_diameter/2)
       .extrude(cyl_depth))
cone = cq.Solid.makeCone(cs_depth, screw_diameter/2, countersink_diameter/2).translate((0,0,cyl_depth))
countersink_cut = cyl.union(cone)
base = base.cut(countersink_cut)
# central boss
boss_outer_radius = inner_diameter/2 + boss_extra_radius
boss = (cq.Workplane("XY")
        .circle(boss_outer_radius)
        .circle(inner_diameter/2)
        .extrude(boss_thickness)
        .translate((0,0, thickness/2 - boss_thickness/2)))
base = base.union(boss)
# mounting holes array
base = (base.faces(">Z")
        .workplane()
        .polarArray(radius=mount_radius, count=4, startAngle=0, angle=360)
        .hole(mounting_hole_diameter))
# chamfer edges
base = base.edges().chamfer(chamfer_dist)
result = base