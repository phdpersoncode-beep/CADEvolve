import cadquery as cq

base_width = 80.0
base_depth = 50.0
base_thickness = 5.0
base_corner_radius = 4.0
flange_height = 10.0
flange_rib_width = 8.0
flange_rib_thickness = 3.0
mount_hole_dia = 4.0
mount_hole_spacing_x = 60.0
mount_hole_spacing_y = 30.0
csk_dia = 12.0
csk_depth = 3.0
csk_angle = 82
csk_chamfer = 0.5
clip_wall = 2.0
clip_height = 20.0
clip_length = 40.0
clip_hole_dia = 6.0
clip_fillet = 0.2


def clip_body(wall, height, length, hole_dia):
    return (
        cq.Workplane("XY")
        .rect(wall, height)
        .extrude(length)
        .edges("|Z")
        .fillet(clip_fillet)
        .faces("<Z")
        .workplane()
        .center(0, height/2)
        .hole(hole_dia)
    )

base = (
    cq.Workplane("XY")
    .rect(base_width, base_depth)
    .extrude(base_thickness)
    .edges("|Z").fillet(base_corner_radius)
    .faces(">Z")
    .workplane()
    .rect(base_width, base_depth)
    .extrude(flange_height)
    .faces(">Z")
    .workplane()
    .rect(flange_rib_width, flange_rib_thickness)
    .extrude(flange_height)
)

base = (
    base
    .faces("<Z[1]")
    .workplane()
    .pushPoints([(-mount_hole_spacing_x/2, -mount_hole_spacing_y/2),
                 ( mount_hole_spacing_x/2, -mount_hole_spacing_y/2),
                 (-mount_hole_spacing_x/2,  mount_hole_spacing_y/2),
                 ( mount_hole_spacing_x/2,  mount_hole_spacing_y/2)])
    .hole(mount_hole_dia)
)

base = (
    base
    .faces(">Z[2]")
    .workplane()
    .center(0, 0)
    .cskHole(csk_dia, csk_depth, csk_angle)
    .faces(">Z[2]")
    .edges()
    .chamfer(csk_chamfer)
)

result = (
    base
    .workplane(offset=base_thickness + flange_height)
    .center(0, base_depth/2 + clip_wall/2)
    .union(
        clip_body(clip_wall, clip_height, clip_length, clip_hole_dia)
    )
)
