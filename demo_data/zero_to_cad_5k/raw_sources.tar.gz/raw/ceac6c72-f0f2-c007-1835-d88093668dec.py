import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.vertical_leg_length + m.thickness)
            .lineTo(m.thickness, m.vertical_leg_length + m.thickness)
            .lineTo(m.thickness, m.thickness + m.fillet_radius)
            .threePointArc((m.thickness, m.thickness), (m.thickness + m.fillet_radius, m.thickness))
            .lineTo(m.horizontal_leg_length + m.thickness, m.thickness)
            .lineTo(m.horizontal_leg_length + m.thickness, 0)
            .close()
            .extrude(m.thickness)
        )
        boss_center_x = m.thickness + (m.horizontal_leg_length - m.boss_width) / 2
        base = (
            base.faces(">Z")
            .workplane()
            .center(boss_center_x, 0)
            .rect(m.boss_width, m.boss_depth)
            .cutBlind(-m.boss_height)
        )
        base = (
            base.faces("<X")
            .workplane()
            .center(0, m.vertical_leg_length / 2 - m.edge_margin)
            .rarray(0, (m.vertical_leg_length - 2 * m.edge_margin) / 2, 1, 3)
            .hole(m.hole_diameter)
        )
        base = (
            base.faces(">Y")
            .workplane()
            .center(m.horizontal_leg_length / 2, 0)
            .rarray((m.horizontal_leg_length - 2 * m.edge_margin) / 2, 0, 3, 1)
            .hole(m.hole_diameter)
        )
        base = base.edges("|Z and (<X or >X or <Y or >Y)").chamfer(m.chamfer_distance)
        self.model = base

cq.Workplane.part = lambda self, part_class, measures: self.newObject(part_class(self, measures).model.objects)

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=60.0,
    thickness=10.0,
    fillet_radius=5.0,
    boss_width=30.0,
    boss_depth=10.0,
    boss_height=6.0,
    hole_diameter=6.0,
    edge_margin=5.0,
    chamfer_distance=1.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
