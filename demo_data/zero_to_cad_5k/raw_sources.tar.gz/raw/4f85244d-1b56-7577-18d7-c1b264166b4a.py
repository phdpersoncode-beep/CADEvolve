import cadquery as cq
from types import SimpleNamespace as Measures

class ShellBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        leg_thick = m.leg_thickness
        leg_h = m.leg_height
        base_len = m.base_length
        depth = m.bracket_depth
        wall = m.wall_thickness
        # vertical leg box
        vert = cq.Workplane('XY').box(leg_thick, leg_h, depth)
        # horizontal leg box positioned at top of vertical leg
        horiz = cq.Workplane('XY').box(base_len, leg_thick, depth).translate((base_len/2, leg_thick/2, 0))
        union = vert.union(horiz)
        shell = union.shell(wall)
        # slot cut on outer face of vertical leg (+X side)
        slot = shell.faces('>X').workplane().rect(m.slot_width, m.slot_height).cutBlind(-depth)
        # pattern of clearance holes on same face
        holes = slot.faces('>X').workplane().rarray(m.hole_spacing_y, 0, m.hole_count, 1).hole(m.clearance_dia)
        # bevel outer edges
        result = holes.edges('|Z and (>X or <X)').chamfer(m.bevel)
        self.model = result

measures = Measures(
    leg_thickness=8.0,
    leg_height=80.0,
    base_length=60.0,
    bracket_depth=10.0,
    wall_thickness=2.0,
    slot_width=6.0,
    slot_height=30.0,
    clearance_dia=3.0,
    hole_spacing_y=20.0,
    hole_count=4,
    bevel=1.0,
)

result = ShellBracket(cq.Workplane('XY'), measures).model
