import cadquery as cq

flange_leg_length = 80.0
flange_leg_width = 30.0
flange_thickness = 8.0
inner_cut_width = 20.0
boss_diameter = 20.0
boss_height = 12.0
hole_diameter = 5.5
hole_spacing = 40.0
hole_offset = 10.0
chamfer_size = 4.0
rib_height = 4.0
rib_width = 6.0
rib_spacing = 12.0
fusion_overlap = 0.5

base = cq.Workplane('XY').rect(flange_leg_length, flange_leg_width).extrude(flange_thickness)
cut = (
    cq.Workplane('XY')
    .rect(flange_leg_length - inner_cut_width, flange_leg_width - inner_cut_width)
    .translate((inner_cut_width / 2.0, inner_cut_width / 2.0))
    .extrude(flange_thickness)
)

l_shape = base.cut(cut)
result = l_shape.edges('|Z').chamfer(chamfer_size)

hole_positions = [
    (-hole_spacing / 2.0, flange_leg_width / 2.0 - hole_offset),
    ( hole_spacing / 2.0, flange_leg_width / 2.0 - hole_offset),
    ( flange_leg_length / 2.0 - hole_offset, -hole_spacing / 2.0),
    ( flange_leg_length / 2.0 - hole_offset,  hole_spacing / 2.0),
]

for (x, y) in hole_positions:
    result = (
        result.faces('>Z')
        .workplane()
        .center(x, y)
        .hole(hole_diameter)
    )

rib_count = int((flange_leg_length - inner_cut_width - 2 * hole_offset) // rib_spacing)
for i in range(rib_count):
    rib_x = inner_cut_width / 2.0 + hole_offset + (i + 0.5) * rib_spacing - (flange_leg_length - inner_cut_width) / 2.0
    rib = (
        cq.Workplane('XY')
        .center(rib_x, flange_leg_width / 2.0 - rib_width / 2.0 - hole_offset)
        .rect(rib_spacing * 0.8, rib_width)
        .extrude(rib_height)
        .translate((0, 0, flange_thickness - fusion_overlap))
    )
    result = result.union(rib)

boss = (
    cq.Workplane('XY')
    .center(inner_cut_width / 2.0, inner_cut_width / 2.0)
    .circle(boss_diameter / 2.0)
    .extrude(boss_height)
    .translate((0, 0, flange_thickness - fusion_overlap))
)

result = result.union(boss)
