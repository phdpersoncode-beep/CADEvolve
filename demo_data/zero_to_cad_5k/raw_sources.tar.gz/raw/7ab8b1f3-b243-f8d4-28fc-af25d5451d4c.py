import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        # create L-shaped profile and extrude
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_width, 0),
                (m.leg_width, m.vertical_leg_length),
                (m.leg_width + m.horizontal_leg_length, m.vertical_leg_length),
                (m.leg_width + m.horizontal_leg_length, m.vertical_leg_length + m.leg_width),
                (0, m.vertical_leg_length + m.leg_width),
                (0, 0)
            ])
            .close()
        )
        base = profile.extrude(m.thickness)
        # add blind slot on outer vertical face
        base = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.leg_width/2, 0)
            .rect(m.slot_width, m.slot_length)
            .cutBlind(m.slot_depth)
        )
        # chamfer all outer edges
        base = base.edges().chamfer(m.chamfer_distance)
        # tapped hole pattern on vertical outer face
        start_y = - (m.vertical_leg_length + m.leg_width)/2 + m.hole_offset_start
        base = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.leg_width/2, start_y)
            .rarray(0, m.hole_spacing, 1, 3)
            .cboreHole(m.tapped_hole_clearance, m.tapped_hole_cbore_diam, m.tapped_hole_cbore_depth)
        )
        # blind drilled hole on inner horizontal face
        base = (
            base.faces("<Y")
            .workplane(centerOption="CenterOfBoundBox")
            .hole(m.blind_hole_diameter, depth=m.blind_hole_depth)
        )
        self.model = base

measures = Measures(
    leg_width=20.0,
    thickness=10.0,
    vertical_leg_length=80.0,
    horizontal_leg_length=60.0,
    slot_width=8.0,
    slot_length=30.0,
    slot_depth=5.0,
    chamfer_distance=1.0,
    tapped_hole_clearance=4.5,
    tapped_hole_cbore_diam=7.0,
    tapped_hole_cbore_depth=2.5,
    hole_spacing=20.0,
    hole_offset_start=20.0,
    blind_hole_diameter=6.0,
    blind_hole_depth=5.0,
)

result = LBracket(cq.Workplane("XY"), measures).model