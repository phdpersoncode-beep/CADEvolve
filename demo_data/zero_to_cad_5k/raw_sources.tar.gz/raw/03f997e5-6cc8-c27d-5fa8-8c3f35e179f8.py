import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 5.0
frame_height = 12.0
frame_offset = 10.0
frame_bevel = 1.0
hole_diameter = 5.0
hole_depth = 8.0
hole_offset_x = 20.0
hole_offset_y = 15.0
rib_thickness = 2.0
rib_height = 6.0

# Base plate
result = (
    cq.Workplane('XY')
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges('|Z')
    .fillet(0.5)
    .faces('>Z')
    .workplane(offset=base_thickness)
    # Sketch raised frame as border
    .rect(base_length, base_width)
    .cutBlind(-base_thickness)  # ensure closed profile before extrusion? Actually we will use sketch for extrusion.
)
