import cadquery as cq

prism_length = 80.0
prism_width = 60.0
prism_height = 40.0
wall_thickness = 2.5
channel_width = 12.0
channel_height = 10.0
channel_angle = 45.0
fillet_radius = 3.0
hole_diameter = 5.0
hole_offset = 10.0

base_box = cq.Workplane('XY').box(prism_length, prism_width, prism_height, centered=(True, True, False))

shell_body = base_box.shell(-wall_thickness)

diagonal_length = (prism_length**2 + prism_width**2) ** 0.5
channel_body = (
    cq.Workplane('XY')
    .rect(channel_width, channel_height)
    .extrude(diagonal_length + 2 * wall_thickness)
    .rotate((0, 0, 0), (0, 0, 1), channel_angle)
    .translate((0, 0, prism_height / 2))
)

part_with_channel = shell_body.cut(channel_body)

hole_positions = [
    (hole_offset, hole_offset),
    (-hole_offset, hole_offset),
    (hole_offset, -hole_offset),
    (-hole_offset, -hole_offset)
]

part_with_holes = (
    part_with_channel.faces('>Z')
    .workplane()
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)

result = part_with_holes.edges('|Z').fillet(fillet_radius)
