import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .box(m.leg_width_long, m.thickness, m.leg_length_long)
        )
        horiz_len = m.leg_length_long - m.leg_width_long
        horizontal = (
            cq.Workplane("XY")
            .box(horiz_len, m.thickness, m.leg_width_long)
            .translate((m.leg_width_long/2 + horiz_len/2, 0, m.leg_width_long/2))
        )
        bracket = vertical.union(horizontal)
        bracket = bracket.edges("|Z").fillet(m.fillet_radius)
        # shallow pocket on top face
        bracket = (
            bracket.faces(">Z").first()
            .workplane()
            .rect(m.pocket_width, m.pocket_length)
            .cutBlind(m.pocket_depth)
        )
        # hole pattern on top face
        bracket = (
            bracket.faces(">Z").first()
            .workplane()
            .rect(m.hole_spacing, m.hole_spacing, forConstruction=True)
            .vertices()
            .hole(m.hole_diameter)
        )
        self.model = bracket

measures = Measures(
    leg_length_long=80.0,
    leg_width_long=20.0,
    thickness=10.0,
    fillet_radius=3.0,
    pocket_depth=4.0,
    pocket_width=30.0,
    pocket_length=30.0,
    hole_diameter=5.0,
    hole_spacing=30.0,
)

result = LBracket(cq.Workplane("XY"), measures).model