import cadquery as cq

flange_outer_radius = 40.0
flange_thickness = 5.0
hub_radius = 12.0
rib_width = 8.0
rib_height = 15.0
clearance_hole_diameter = 10.5
hole_radius_position = 30.0
fillet_radius = 5.0
chamfer_size = 0.5

base_profile = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(hub_radius, 0)
    .lineTo(hub_radius, flange_thickness)
    .lineTo(hub_radius + rib_width, flange_thickness)
    .lineTo(hub_radius + rib_width, flange_thickness + rib_height)
    .lineTo(flange_outer_radius, flange_thickness + rib_height)
    .lineTo(flange_outer_radius, 0)
    .close()
)

solid_base = base_profile.revolve(360)

solid_fillet = (
    solid_base
    .faces(">Z")
    .edges()
    .fillet(fillet_radius)
)

solid_holes = (
    solid_fillet
    .faces(">Z")
    .workplane()
    .polarArray(radius=hole_radius_position, count=3, startAngle=0, angle=360)
    .hole(clearance_hole_diameter)
)

result = (
    solid_holes
    .faces("<Z")
    .edges()
    .chamfer(chamfer_size)
)
