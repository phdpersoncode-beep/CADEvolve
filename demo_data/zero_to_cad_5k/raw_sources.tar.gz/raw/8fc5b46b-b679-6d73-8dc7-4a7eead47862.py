import cadquery as cq

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
        self.result = self.model

    def build(self):
        m = self.measures
        # Base L profile
        base_profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_length, 0)
            .lineTo(m.horizontal_length, m.width)
            .lineTo(m.vertical_thickness, m.width)
            .lineTo(m.vertical_thickness, m.vertical_length + m.width)
            .lineTo(0, m.vertical_length + m.width)
            .close()
        )
        base = base_profile.extrude(m.thickness)
        # Countersunk hole on horizontal arm
        base = (
            base.faces(">Z")
            .workplane()
            .center(m.horizontal_length - m.hole_offset, m.width / 2)
            .cskHole(m.hole_diameter, m.countersink_diameter, m.countersink_angle, depth=m.thickness)
        )
        # Rectangular pocket on vertical arm
        base = (
            base.faces(">X")
            .workplane()
            .center(m.vertical_thickness / 2, m.vertical_length / 2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(m.thickness)
        )
        # Circular boss at elbow (inner corner)
        boss = (
            cq.Workplane("XY")
            .center(m.vertical_thickness / 2, m.width / 2)
            .circle(m.boss_radius)
            .extrude(m.boss_height)
        )
        assembled = base.union(boss)
        # Fillet inner corner edge (vertical edge at inner junction)
        inner_edge = assembled.edges("|Z and <X and >Y")
        self.model = inner_edge.fillet(m.fillet_radius)

# Parameter definitions
horizontal_length = 60.0
vertical_length = 70.0
width = 20.0
thickness = 8.0
vertical_thickness = 20.0
fillet_radius = 3.0
boss_radius = 6.0
boss_height = 10.0
hole_diameter = 5.0
countersink_diameter = 8.0
countersink_angle = 82.0
hole_offset = 30.0
pocket_width = 10.0
pocket_height = 30.0

# Measures container
class Measures:
    pass

measures = Measures()
measures.horizontal_length = horizontal_length
measures.vertical_length = vertical_length
measures.width = width
measures.thickness = thickness
measures.vertical_thickness = vertical_thickness
measures.fillet_radius = fillet_radius
measures.boss_radius = boss_radius
measures.boss_height = boss_height
measures.hole_diameter = hole_diameter
measures.countersink_diameter = countersink_diameter
measures.countersink_angle = countersink_angle
measures.hole_offset = hole_offset
measures.pocket_width = pocket_width
measures.pocket_height = pocket_height

# Build the part
result = LBracket(cq.Workplane("XY"), measures).result
