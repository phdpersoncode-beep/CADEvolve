import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 6.0
slot_width = 10.0
slot_height = 20.0
slot_offset = 5.0
fillet_radius = 2.0
chamfer_distance = 0.5
hole_diameter = 5.0
hole_spacing = 40.0
rib_width = 6.0
rib_height = 8.0
rib_thickness = 2.0

base = (
    cq.Workplane("XY")
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)

rib1 = (
    base.faces(">Z").workplane()
    .center(-leaf_length/4, 0)
    .rect(rib_width, rib_height)
    .extrude(rib_thickness)
)

rib2 = (
    base.faces(">Z").workplane()
    .center(leaf_length/4, 0)
    .rect(rib_width, rib_height)
    .extrude(rib_thickness)
)

combined = base.union(rib1).union(rib2)

combined = (
    combined.faces(">Y").workplane()
    .center(leaf_length/2 - slot_offset - slot_width/2, 0)
    .rect(slot_width, slot_height)
    .cutBlind(-leaf_thickness)
)

combined = (
    combined.faces("<Y").workplane()
    .center(-hole_spacing/2, 0)
    .hole(hole_diameter)
    .center(hole_spacing, 0)
    .hole(hole_diameter)
)

combined = combined.edges("|Z").fillet(fillet_radius)

result = combined.edges().chamfer(chamfer_distance)
