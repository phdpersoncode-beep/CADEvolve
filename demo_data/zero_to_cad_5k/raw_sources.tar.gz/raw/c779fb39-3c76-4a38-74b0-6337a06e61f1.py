import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # L‑shaped cross‑section profile (rectangular wire)
        profile = (
            cq.Workplane("YZ")
            .moveTo(-m.profile_width/2, -m.profile_height/2)
            .lineTo(m.profile_width/2, -m.profile_height/2)
            .lineTo(m.profile_width/2, m.profile_height/2)
            .lineTo(-m.profile_width/2, m.profile_height/2)
            .close()
        )
        # L‑shaped sweep path
        path = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg1_len, 0)
            .lineTo(m.leg1_len, m.leg2_len)
            .wire()
        )
        swept = profile.sweep(path, makeSolid=True)
        shelled = swept.shell(m.shell_thickness)
        wp = cq.Workplane().add(shelled)
        wp = (
            wp.faces(">Z")
            .workplane()
            .center(-(m.leg1_len/2 - m.hole_offset_leg1), 0)
            .cboreHole(m.hole_diameter, m.countersink_diameter, m.countersink_depth)
        )
        wp = (
            wp.faces(">Z")
            .workplane()
            .center(m.leg1_len/2, -(m.leg2_len/2 - m.hole_offset_leg2))
            .cboreHole(m.hole_diameter, m.countersink_diameter, m.countersink_depth)
        )
        self.model = wp

measures = Measures(
    leg1_len=60.0,
    leg2_len=40.0,
    profile_width=10.0,
    profile_height=10.0,
    shell_thickness=2.0,
    hole_diameter=5.0,
    countersink_diameter=8.0,
    countersink_depth=2.0,
    hole_offset_leg1=20.0,
    hole_offset_leg2=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model