import cadquery as cq
from types import SimpleNamespace as Measures

leg_length = 80.0
upright_length = 70.0
width = 15.0
outer_thickness = 4.0
wall_thickness = 1.5
pocket_width = 20.0
pocket_height = 30.0
pocket_depth = 4.0
pocket_offset_x = 10.0
pocket_offset_y = 20.0
hole_diameter = 5.0
hole_pitch_x = 25.0
hole_pitch_y = 25.0
hole_rows = 2
hole_cols = 3
chamfer_dist = 0.5

measures = Measures(
    leg_length=leg_length,
    upright_length=upright_length,
    width=width,
    outer_thickness=outer_thickness,
    wall_thickness=wall_thickness,
    pocket_width=pocket_width,
    pocket_height=pocket_height,
    pocket_depth=pocket_depth,
    pocket_offset_x=pocket_offset_x,
    pocket_offset_y=pocket_offset_y,
    hole_diameter=hole_diameter,
    hole_pitch_x=hole_pitch_x,
    hole_pitch_y=hole_pitch_y,
    hole_rows=hole_rows,
    hole_cols=hole_cols,
    chamfer_dist=chamfer_dist,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile with chamfer before shell
        self.model = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.outer_thickness),
                (m.outer_thickness, m.outer_thickness),
                (m.outer_thickness, m.upright_length + m.outer_thickness),
                (0, m.upright_length + m.outer_thickness),
            ])
            .close()
            .extrude(m.width)
            .edges("|Z")
            .chamfer(m.chamfer_dist)
            .shell(-m.wall_thickness)
        )
        # Pocket on inner upright face
        self.model = (
            self.model
            .faces("<X")
            .workplane()
            .move(m.pocket_offset_x + m.wall_thickness / 2, m.pocket_offset_y + m.wall_thickness / 2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        # Six through holes on base plate
        self.model = (
            self.model
            .faces("<Z")
            .workplane()
            .rarray(m.hole_pitch_x, m.hole_pitch_y, m.hole_cols, m.hole_rows, center=True)
            .hole(m.hole_diameter)
        )

result = LBracket(cq.Workplane("XY"), measures).model
