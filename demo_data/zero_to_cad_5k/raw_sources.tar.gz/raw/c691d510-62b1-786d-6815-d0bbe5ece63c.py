import cadquery as cq
import math
from types import SimpleNamespace as Measures

m = Measures(
    plate_width=80.0,
    plate_depth=50.0,
    plate_thickness=8.0,
    pocket_length=40.0,
    pocket_width=30.0,
    pocket_depth=4.0,
    chamfer_angle_deg=10.0,
    hole_offset=10.0,
    hole_diameter=3.0,
    cbore_diameter=5.0,
    cbore_depth=2.5
)

chamfer_dist = m.pocket_depth * math.tan(math.radians(m.chamfer_angle_deg))

base = (
    cq.Workplane('XY')
    .box(m.plate_width, m.plate_depth, m.plate_thickness)
    .translate((0, 0, m.plate_thickness/2))
)

# Add mounting cbore holes on left and right sides
holes = (
    base.faces('>Z').workplane()
    .pushPoints([(-m.plate_width/2 + m.hole_offset, 0), (m.plate_width/2 - m.hole_offset, 0)])
    .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
)

# Pocket cut on top surface centered
pocket = (
    holes.faces('>Z').workplane()
    .center(0, 0)
    .rect(m.pocket_length, m.pocket_width)
    .cutBlind(-m.pocket_depth)
)

# Chamfer entrance on front side of pocket (positive Y direction)
# Select the front vertical edges of the pocket and apply chamfer distance
result = (
    pocket.edges("<<Y and >Z")
    .chamfer(chamfer_dist)
)
