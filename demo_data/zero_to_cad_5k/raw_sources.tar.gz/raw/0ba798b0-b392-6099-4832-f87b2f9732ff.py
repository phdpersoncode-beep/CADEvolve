import cadquery as cq

# Parameter definitions
flange_length = 60.0
flange_width = 40.0
base_thickness = 6.0
outer_chamfer = 1.0
inner_corner_radius = 2.0
hole_diameter = 8.5
countersink_diameter = 9.5
hole_offset = 15.0
rib_height = 3.0
rib_thickness = 2.0
rib_spacing = 10.0
boss_diameter = 12.0
countersink_angle = 82
pocket_depth = 5.0
pocket_width = 15.0
pocket_height = 10.0
pocket_offset_x = 10.0
pocket_offset_y = 10.0

# Base plate with outer chamfer
base = (
    cq.Workplane("XY")
    .rect(flange_length, flange_width)
    .extrude(base_thickness)
    .edges("|Z")
    .chamfer(outer_chamfer)
)

# Pocket with filleted inner corner
pocket = (
    cq.Workplane("XY")
    .rect(pocket_width, pocket_height)
    .extrude(pocket_depth)
    .edges()
    .fillet(inner_corner_radius)
    .translate((
        -flange_length/2 + pocket_offset_x,
        -flange_width/2 + pocket_offset_y,
        base_thickness - pocket_depth,
    ))
)
result = base.cut(pocket)

# Clearance holes (cut through plate)
hole_positions = [
    (-flange_length/2 + hole_offset, 0),
    (flange_length/2 - hole_offset, 0)
]
for x, y in hole_positions:
    result = (
        result
        .faces(">Z").first()
        .workplane()
        .center(x, y)
        .hole(hole_diameter)
    )

# Ribs assembly (separate solid then union)
ribs = cq.Workplane("XY")
rib_count = int((flange_length - 2 * rib_spacing) // rib_spacing) + 1
rib_start = -flange_length/2 + rib_spacing
for i in range(rib_count):
    rib_center_x = rib_start + i * rib_spacing
    ribs = (
        ribs
        .center(rib_center_x, 0)
        .rect(rib_thickness, flange_width - 2 * outer_chamfer)
        .extrude(rib_height)
    )
result = result.union(ribs)

# Central boss (separate then union)
boss = (
    cq.Workplane("XY")
    .circle(boss_diameter/2)
    .extrude(base_thickness / 2)
)
result = result.union(boss)

# Countersink holes (cut from top face)
for x, y in hole_positions:
    result = (
        result
        .faces(">Z").first()
        .workplane()
        .center(x, y)
        .cskHole(hole_diameter, countersink_diameter, countersink_angle, base_thickness)
    )
