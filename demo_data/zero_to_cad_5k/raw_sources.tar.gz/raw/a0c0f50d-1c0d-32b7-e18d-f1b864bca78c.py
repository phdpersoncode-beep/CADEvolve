import cadquery as cq

length = 80.0
flange_width = 60.0
flange_thickness = 8.0
web_height = 40.0
web_thickness = 6.0
chamfer_dim = 2.0
hole_diameter = 5.0
hole_spacing = 30.0
hole_offset_y = 10.0

half_height = web_height / 2.0
outer_half_height = half_height + flange_thickness
half_thickness = web_thickness / 2.0

pts = [
    (-flange_width / 2.0, -outer_half_height),
    (-flange_width / 2.0, -half_height),
    (-half_thickness, -half_height),
    (-half_thickness, half_height),
    (-flange_width / 2.0, half_height),
    (-flange_width / 2.0, outer_half_height),
    (flange_width / 2.0, outer_half_height),
    (flange_width / 2.0, half_height),
    (half_thickness, half_height),
    (half_thickness, -half_height),
    (flange_width / 2.0, -half_height),
    (flange_width / 2.0, -outer_half_height)
]

result = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .extrude(length)
)

result = result.edges("|Z and >X").chamfer(chamfer_dim, chamfer_dim)

hole_positions = [(-hole_spacing / 2.0, half_height + flange_thickness / 2.0),
                 (hole_spacing / 2.0, half_height + flange_thickness / 2.0)]
result = (
    result.faces(">Z")
    .workplane(centerOption="CenterOfMass")
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)
