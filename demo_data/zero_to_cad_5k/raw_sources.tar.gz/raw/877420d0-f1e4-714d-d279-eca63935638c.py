import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()

    def build(self):
        m = self.m
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.thickness, 0),
                (m.thickness, m.vertical_leg),
                (m.thickness + m.horizontal_leg, m.vertical_leg),
                (m.thickness + m.horizontal_leg, m.vertical_leg + m.thickness),
                (0, m.vertical_leg + m.thickness),
                (0, 0),
            ])
            .close()
            .extrude(m.depth)
        )
        boss = (
            cq.Workplane("XY")
            .box(m.boss_width, m.boss_width, m.boss_height)
            .translate((m.thickness/2, m.thickness/2, m.depth/2 + m.boss_height/2))
        )
        solid = base.union(boss)
        hole_y = m.thickness/2
        hole_x1 = m.thickness + m.edge_margin + m.hole_diameter/2
        hole_x2 = m.thickness + m.horizontal_leg - m.edge_margin - m.hole_diameter/2
        solid = (
            solid.faces(">Z")
            .workplane()
            .pushPoints([(hole_x1, hole_y), (hole_x2, hole_y)])
            .hole(m.hole_diameter)
        )
        solid = solid.edges("|Z and >X and >Y").fillet(m.fillet_radius)
        self.model = solid

measures = Measures(
    thickness=8.0,
    vertical_leg=50.0,
    horizontal_leg=70.0,
    depth=10.0,
    boss_width=4.0,
    boss_height=12.0,
    hole_diameter=5.0,
    edge_margin=5.0,
    fillet_radius=3.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
