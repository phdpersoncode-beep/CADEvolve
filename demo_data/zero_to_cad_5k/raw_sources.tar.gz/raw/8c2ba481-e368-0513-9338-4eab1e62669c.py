import cadquery as cq

# Parameters
plate_length = 80.0
plate_width = 60.0
plate_thickness = 5.0
rib_height = 6.0
rib_width = 20.0
rib_margin = 10.0
mount_hole_diameter = 6.0
mount_hole_spacing_x = 60.0
mount_hole_spacing_y = 40.0
blind_hole_diameter = 8.0
blind_hole_depth = 4.0
blind_hole_counterbore_diameter = 12.0
blind_hole_counterbore_depth = 1.0
slot_width = 5.0
slot_offset_from_edge = 5.0
chamfer_size = 1.0
pocket_depth = 2.0
pocket_margin = 10.0
fillet_radius = 0.5

# Base plate sketch (simple rectangle)
base_sketch = cq.Sketch().rect(plate_length, plate_width)

# Create base plate solid
result = (
    cq.Workplane("XY")
    .placeSketch(base_sketch)
    .extrude(plate_thickness)
)

# Cut through-side slot (centered longitudinally)
result = (
    result
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(slot_width, plate_width - 2 * slot_offset_from_edge)
    .cutBlind(plate_thickness)
)

# Rib sketch (rectangle centered about its own origin)
rib_sketch = cq.Sketch().rect(rib_width, plate_width - 2 * rib_margin)

# Add rib on top face, positioned toward one long edge
rib_center_x = plate_length/2 - rib_margin - rib_width/2
result = (
    result
    .faces(">Z")
    .workplane()
    .center(rib_center_x, 0)
    .placeSketch(rib_sketch)
    .extrude(rib_height)
)

# Define mounting hole positions (four corners)
mount_points = [
    (-mount_hole_spacing_x/2, -mount_hole_spacing_y/2),
    ( mount_hole_spacing_x/2, -mount_hole_spacing_y/2),
    ( mount_hole_spacing_x/2,  mount_hole_spacing_y/2),
    (-mount_hole_spacing_x/2,  mount_hole_spacing_y/2),
]
result = (
    result
    .faces(">Z")
    .workplane()
    .pushPoints(mount_points)
    .hole(mount_hole_diameter)
)

# Blind tapped hole with counterbore on rib center
result = (
    result
    .faces(">Z")
    .workplane()
    .center(rib_center_x, 0)
    .hole(blind_hole_counterbore_diameter, depth=blind_hole_counterbore_depth)
    .hole(blind_hole_diameter, depth=blind_hole_counterbore_depth + blind_hole_depth)
)

# Chamfer outer vertical edges for safety
result = result.edges("|Z").chamfer(chamfer_size)

# Underside blind pocket for weight reduction
pocket_width = plate_length - 2 * pocket_margin
pocket_height = plate_width - 2 * pocket_margin
result = (
    result
    .faces("<Z")
    .workplane()
    .rect(pocket_width, pocket_height)
    .cutBlind(pocket_depth)
)

# Small fillet on rib top edges for handling comfort
result = result.edges(">Z").fillet(fillet_radius)
