import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(0, m.vertical_leg_height)
            .lineTo(m.leg_thickness, m.vertical_leg_height)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness + m.horizontal_leg_length, m.leg_thickness)
            .lineTo(m.leg_thickness + m.horizontal_leg_length, 0)
            .close()
        )
        base = profile.extrude(m.extrude_depth)
        inner_edge = base.edges().filter(lambda e: abs(e.Center().x - m.leg_thickness) < 0.01 and abs(e.Center().y - m.leg_thickness) < 0.01)
        base = inner_edge.fillet(m.inner_fillet_radius)
        rib = (
            cq.Workplane("XY")
            .rect(m.rib_width, m.rib_height)
            .extrude(m.extrude_depth)
            .translate((m.leg_thickness / 2 + m.rib_width / 2, m.vertical_leg_height / 2, 0))
        )
        base = base.union(rib)
        base = (
            base.faces("<X")
            .workplane()
            .center(0, m.vertical_leg_height / 2)
            .cboreHole(m.main_hole_diameter, m.main_counterbore_diameter, m.main_counterbore_depth)
        )
        points = [
            (m.leg_thickness + m.horizontal_leg_length / 2, m.mount_hole_offset),
            (m.leg_thickness + m.horizontal_leg_length / 2, m.vertical_leg_height - m.mount_hole_offset)
        ]
        base = (
            base.faces(">Z")
            .workplane()
            .pushPoints(points)
            .hole(m.mount_hole_diameter)
        )
        self.model = base

measures = Measures(
    vertical_leg_height=80.0,
    horizontal_leg_length=60.0,
    leg_thickness=8.0,
    extrude_depth=8.0,
    inner_fillet_radius=5.0,
    rib_width=20.0,
    rib_height=15.0,
    main_hole_diameter=6.0,
    main_counterbore_diameter=10.0,
    main_counterbore_depth=6.0,
    mount_hole_diameter=4.0,
    mount_hole_offset=12.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
