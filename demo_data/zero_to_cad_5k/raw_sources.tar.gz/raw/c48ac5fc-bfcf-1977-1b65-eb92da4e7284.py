import cadquery as cq
leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 8.0
shell_thickness = 2.0
hinge_hole_diameter = 6.0
hole_spacing = 40.0
side_notch_width = 12.0
side_notch_depth = 4.0
chamfer_distance = 0.8

# Base plate solid
base = cq.Workplane('XY').rect(leaf_length, leaf_width).extrude(leaf_thickness)
# Add notches on top and bottom edges (through thickness)
for y_off in (leaf_width/2 - side_notch_depth/2, -leaf_width/2 + side_notch_depth/2):
    base = (base
            .faces('>Z')
            .workplane()
            .center(0, y_off)
            .rect(side_notch_width, side_notch_depth)
            .cutBlind(leaf_thickness))
# Shell to create hollow interior
hollow = base.shell(shell_thickness)
# Pin holes through the leaf (aligned with center line)
holes = hollow.faces('>Z').workplane().pushPoints([
    (0, hole_spacing/2),
    (0, -hole_spacing/2)
]).hole(hinge_hole_diameter)
# Chamfer outer vertical edges for safety
result = holes.edges('|Z').chamfer(chamfer_distance)
