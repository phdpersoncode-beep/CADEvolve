import cadquery as cq

class Measures:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

class RevolvedLBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XZ")
            .moveTo(0, 0)
            .lineTo(0, m.upright_height)
            .lineTo(m.thickness, m.upright_height)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.leg_length, m.thickness)
            .lineTo(m.leg_length, 0)
            .close()
            .revolve(360)
        )
        rib = (
            cq.Workplane("XZ")
            .moveTo(m.thickness, m.thickness)
            .rect(m.rib_width, m.rib_height, centered=False)
            .extrude(m.rib_thickness)
        )
        bracket = base.union(rib)
        slot_cut = (
            cq.Workplane()
            .box(m.slot_width, m.leg_length * 2, m.slot_height)
            .translate((m.thickness / 2, 0, m.upright_height / 2))
        )
        bracket = bracket.cut(slot_cut)
        bracket = bracket.edges("|Z").chamfer(m.chamfer_size)
        self.model = bracket

measures = Measures(
    leg_length=60.0,
    upright_height=40.0,
    thickness=5.0,
    rib_width=8.0,
    rib_height=6.0,
    rib_thickness=5.0,
    slot_width=2.0,
    slot_height=15.0,
    chamfer_size=0.5,
)

result = RevolvedLBracket(cq.Workplane("XY"), measures).model
