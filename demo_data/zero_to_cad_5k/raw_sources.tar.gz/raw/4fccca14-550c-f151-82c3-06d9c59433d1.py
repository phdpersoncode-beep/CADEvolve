import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (0, m.vertical_length),
                (m.thickness, m.vertical_length),
                (m.thickness, m.horizontal_offset + m.thickness),
                (m.horizontal_length + m.thickness, m.horizontal_offset + m.thickness),
                (m.horizontal_length + m.thickness, m.horizontal_offset),
                (m.thickness, m.horizontal_offset),
                (m.thickness, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.width)
        )
        base = base.edges().chamfer(m.chamfer)
        # Through holes pattern (2x2) on vertical arm
        verticalusable = m.vertical_length - 2 * m.edge_clearance
        hole_spacing_y = verticalusable / 3
        hole_center_x = m.thickness / 2
        first_y = m.edge_clearance + hole_spacing_y
        holes = (
            base
            .faces('>Z')
            .workplane(centerOption='CenterOfBoundBox')
            .pushPoints([
                (hole_center_x, first_y),
                (hole_center_x, first_y + 2 * hole_spacing_y),
                (hole_center_x + m.thickness / 2, first_y),
                (hole_center_x + m.thickness / 2, first_y + 2 * hole_spacing_y)
            ])
            .hole(m.hole_diameter)
        )
        # Honeycomb infill cutouts in horizontal arm
        honey_start_x = m.thickness
        honey_end_x = m.thickness + m.horizontal_length
        honey_start_y = m.horizontal_offset
        honey_end_y = m.horizontal_offset + m.thickness
        hex_radius = m.honey_hex_radius
        hex_height = (3 ** 0.5) * hex_radius
        cols = int((honey_end_x - honey_start_x) / (1.5 * hex_radius)) + 2
        rows = int((honey_end_y - honey_start_y) / hex_height) + 2
        result = holes
        for col in range(cols):
            x = honey_start_x + col * 1.5 * hex_radius
            for row in range(rows):
                y_offset = hex_height / 2 if col % 2 else 0
                y = honey_start_y + row * hex_height + y_offset
                if x - hex_radius < honey_start_x or x + hex_radius > honey_end_x:
                    continue
                if y - hex_height / 2 < honey_start_y or y + hex_height / 2 > honey_end_y:
                    continue
                cell = (
                    cq.Workplane('XY')
                    .polygon(6, 2 * hex_radius)
                    .translate((x, y, 0))
                    .extrude(m.width)
                )
                result = result.cut(cell)
        self.model = result

measures = Measures(
    width=20.0,
    thickness=8.0,
    vertical_length=70.0,
    horizontal_length=60.0,
    horizontal_offset=30.0,
    edge_clearance=5.0,
    hole_diameter=6.0,
    chamfer=1.0,
    honey_hex_radius=3.0,
)

result = LBracket(cq.Workplane('XY'), measures).model
