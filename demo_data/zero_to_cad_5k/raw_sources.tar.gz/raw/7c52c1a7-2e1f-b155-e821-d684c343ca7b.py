import cadquery as cq
import math
outer_radius = 45
flange_thickness = 10
boss_height = 4
boss_radius = 8
rib_width = 5
rib_thickness = 2
rib_length = outer_radius - 20
m5_diameter = 5.0
hole_offset = 25
chamfer_size = 2
tooth_count = 30
tooth_height = 3
# base flange
base = cq.Workplane('XY').circle(outer_radius).extrude(flange_thickness)
# central boss
boss = cq.Workplane('XY').circle(boss_radius).extrude(boss_height)
base = base.union(boss)
# ribs
rib1 = (
    cq.Workplane('XY')
    .workplane(offset=flange_thickness - rib_thickness)
    .rect(rib_length, rib_width)
    .extrude(rib_thickness)
)
rib2 = rib1.rotate((0,0,0), (0,0,1), 90)
base = base.union(rib1).union(rib2)
# holes
hole_depth = flange_thickness
cbore_depth = flange_thickness/2
base = (
    base
    .faces('>Z')
    .workplane()
    .pushPoints([
        (hole_offset,0),
        (-hole_offset,0),
        (0,hole_offset),
        (0,-hole_offset)
    ])
    .cboreHole(m5_diameter, cbore_depth, hole_depth)
)
# chamfer all edges
base = base.edges().chamfer(chamfer_size)
# gear tooth solid
pitch = 2*math.pi*outer_radius / tooth_count
tooth_width = pitch*0.5
tooth = (
    cq.Workplane('XY')
    .rect(tooth_width, flange_thickness+0.1)
    .extrude(tooth_height)
    .translate((outer_radius - tooth_height/2, 0, 0))
)
teeth = cq.Workplane('XY')
for i in range(tooth_count):
    angle = i * 360.0 / tooth_count
    teeth = teeth.union(tooth.rotate((0,0,0), (0,0,1), angle))
result = base.cut(teeth.val())
