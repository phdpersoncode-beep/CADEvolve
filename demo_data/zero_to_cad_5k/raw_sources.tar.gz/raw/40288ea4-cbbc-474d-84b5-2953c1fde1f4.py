import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width=40.0,
    depth=18.0,
    height=14.0,
    arc_outer_diameter=80.0,
    chamfer_size=1.0,
    slot_width=32.0,
    slot_height=8.0,
    tube_diameter=12.0,
    tube_offset_x=0.0,
    tube_offset_y=0.0,
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_radius = m.arc_outer_radius - m.depth
m.arc_center_angle = degrees(
    acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2))
)
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_size)
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(m.slot_width, m.slot_height)
    .cutBlind(-m.depth)
    .faces(">Z")
    .workplane()
    .center(m.tube_offset_x, m.tube_offset_y)
    .hole(m.tube_diameter)
)
