
import cadquery as cq
from types import SimpleNamespace as Measures
from math import acos, degrees

m = Measures(
    linear_width = 60.0,
    depth = 20.0,
    height = 15.0,
    arc_outer_diameter = 80.0,
    top_chamfer = 1.0,
    side_chamfer = 1.0,
    insert_diameter = 4.5,
    insert_length = 12.0,
    insert_clearance = 0.3,
    groove_width = 30.0,
    groove_depth = 4.0,
    groove_offset = 10.0,
    screw_head_diameter = 7.0,
    screw_head_height = 3.0,
    screw_shank_diameter = 4.2
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate = (90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition = "round")
    .edges("|Z")
    .chamfer(m.side_chamfer)
    .edges(">Z")
    .chamfer(m.top_chamfer)
    .faces("<Z")
    .workplane()
    .center(0, m.groove_offset)
    .rect(m.groove_width, m.groove_depth)
    .cutBlind(-m.groove_depth)
    .faces("<Z")
    .workplane()
    .center(0, 0)
    .hole(m.insert_diameter + m.insert_clearance, depth = m.insert_length)
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .cskHole(m.screw_shank_diameter, m.screw_head_diameter, m.screw_head_height)
)
