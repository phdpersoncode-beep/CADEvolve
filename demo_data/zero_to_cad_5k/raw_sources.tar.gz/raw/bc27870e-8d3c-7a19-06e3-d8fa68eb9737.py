import cadquery as cq
from types import SimpleNamespace as Measures

base_length = 20.0
base_height = 25.0
material_thickness = 5.0
extrude_depth = 10.0
fillet_radius = 2.0
hole_diameter = 5.0
hole_spacing = 15.0
hole_offset_from_corner = 7.0

class LBracket:
    def __init__(self, wp, measures):
        self.model = wp
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        solid = (
            cq.Workplane("XY")
            .box(m.base_length + m.material_thickness,
                 m.base_height + m.material_thickness,
                 m.extrude_depth)
        )
        pocket = (
            solid
            .faces(">Z")
            .workplane()
            .center(m.material_thickness/2, m.material_thickness/2)
            .rect(m.base_length, m.base_height)
            .cutBlind(-m.extrude_depth)
        )
        self.model = (
            pocket
            .edges("|Z").fillet(m.fillet_radius)
            .faces(">Z")
            .workplane()
            .pushPoints([
                (m.material_thickness/2, m.hole_offset_from_corner),
                (m.material_thickness/2, m.hole_offset_from_corner + m.hole_spacing)
            ])
            .hole(m.hole_diameter)
        )

measures = Measures(
    base_length=base_length,
    base_height=base_height,
    material_thickness=material_thickness,
    extrude_depth=extrude_depth,
    fillet_radius=fillet_radius,
    hole_diameter=hole_diameter,
    hole_spacing=hole_spacing,
    hole_offset_from_corner=hole_offset_from_corner,
)

result = LBracket(cq.Workplane("XY"), measures).model
