
import cadquery as cq

bracket_length = 80.0
bracket_width = 40.0
bracket_thickness = 8.0
wall_thickness = 4.0
cavity_margin = 6.0
cavity_depth = 5.0
rib_width = 8.0
rib_height = 6.0
hole_spacing_x = 30.0
hole_spacing_y = 20.0
hole_clearance_dia = 9.0
fillet_radius = 1.0
chamfer_size = 0.3

base = (
    cq.Workplane("XY")
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
)

rib = (
    cq.Workplane("XY")
    .rect(rib_width, bracket_width - 2 * wall_thickness)
    .extrude(rib_height)
)

ribs = (
    rib.translate((bracket_length/2 - rib_width/2 - wall_thickness, 0, 0))
    .union(rib.translate((-bracket_length/2 + rib_width/2 + wall_thickness, 0, 0)))
)

part = base.union(ribs)

part = (
    part.workplane(offset=bracket_thickness)
    .rect(bracket_length - 2 * cavity_margin, bracket_width - 2 * cavity_margin)
    .cutBlind(-cavity_depth)
)

hole_pts = [
    (-hole_spacing_x/2, -hole_spacing_y/2),
    (hole_spacing_x/2, -hole_spacing_y/2),
    (-hole_spacing_x/2, hole_spacing_y/2),
    (hole_spacing_x/2, hole_spacing_y/2),
]
part = (
    part.workplane(offset=bracket_thickness)
    .pushPoints(hole_pts)
    .hole(hole_clearance_dia)
)

part = part.faces(">Z").edges().chamfer(chamfer_size)

part = part.edges("|Z").fillet(fillet_radius)

result = part
