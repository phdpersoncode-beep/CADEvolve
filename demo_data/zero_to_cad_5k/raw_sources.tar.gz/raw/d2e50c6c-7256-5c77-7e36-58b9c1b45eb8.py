import cadquery as cq

# Parameters
bracket_width = 80.0
bracket_height = 60.0
bracket_thickness = 8.0
chamfer_dist = 1.0
notch_width = 20.0
notch_depth = 10.0
boss_radius = 12.0
boss_height = 10.0
boss_offset_x = -bracket_width/2 + 20.0
boss_offset_y = 0.0
hole_dia = 8.0
hole_center_x = 0.0
hole_center_y = 0.0
rib_width = 6.0
rib_thickness = 3.0
rib_spacing = 30.0
rib_offset_y = bracket_thickness/2 + rib_thickness/2

# Base plate
result = (
    cq.Workplane('XY')
    .rect(bracket_width, bracket_height)
    .extrude(bracket_thickness)
    .edges('|Z')
    .chamfer(chamfer_dist)
)

# Notch on lower left side (cut from top face)
result = (
    result
    .faces('>Z')
    .workplane()
    .center(-bracket_width/2 + notch_width/2, -bracket_height/2 + notch_depth/2)
    .rect(notch_width, notch_depth)
    .cutBlind(-bracket_thickness)
)

# Circular boss on interior side (centered on left edge)
result = (
    result
    .faces('>Z')
    .workplane()
    .center(boss_offset_x, boss_offset_y)
    .circle(boss_radius)
    .extrude(boss_height)
)

# Through bolt hole (centered)
result = (
    result
    .faces('>Z')
    .workplane()
    .center(hole_center_x, hole_center_y)
    .hole(hole_dia)
)

# Add two longitudinal ribs on inner face (parallel to Y axis)
# First rib
rib1 = (
    cq.Workplane('YZ')
    .rect(rib_thickness, bracket_height - 2*notch_depth)
    .extrude(rib_width)
    .translate((rib_offset_y, 0, 0))
)
# Second rib mirrored across X=0 plane
rib2 = rib1.mirror(mirrorPlane='YZ')

result = result.union(rib1).union(rib2)

# Small fillet on all vertical edges for safety
result = result.edges('|Z').fillet(0.5)
