import cadquery as cq

# Parameters
overall_length = 80.0
overall_width = 30.0
plate_thickness = 5.0
cutout_diameter = 20.0
cutout_center_x = -20.0
cutout_center_y = 0.0
chamfer_distance = 1.0
hole_diameter = 4.0
counterbore_diameter = 7.0
counterbore_depth = 2.0
hole_rows = 2
hole_columns = 3
hole_spacing_x = 12.0
hole_spacing_y = 12.0
pattern_center_x = 15.0
pattern_center_y = 0.0
rib_thickness = 2.0
rib_width = 5.0
rib_length = overall_length - 10.0
outer_chamfer = 0.5

# Base plate
base = (
    cq.Workplane("XY")
    .rect(overall_length, overall_width)
    .extrude(plate_thickness)
)

# Circular cutout through thickness
base = (
    base.faces(">Z")
    .workplane()
    .center(cutout_center_x, cutout_center_y)
    .hole(cutout_diameter)
)

# Chamfer on cutout edge (circular edges)
base = (
    base.edges("%CIRCLE")
    .chamfer(chamfer_distance)
)

# Tapped hole pattern with counterbore on top surface
base = (
    base.faces(">Z")
    .workplane()
    .center(pattern_center_x, pattern_center_y)
    .rarray(hole_spacing_x, hole_spacing_y, hole_columns, hole_rows)
    .cboreHole(hole_diameter, counterbore_diameter, counterbore_depth)
)

# Reinforcing rib on the back side (negative Z direction)
rib = (
    base.faces("<Z")
    .workplane()
    .rect(rib_width, rib_length)
    .extrude(rib_thickness)
)

# Add rib to base
base = base.union(rib)

# Small chamfer on outer perimeter edges for safety
base = base.edges("|Z").chamfer(outer_chamfer)

result = base