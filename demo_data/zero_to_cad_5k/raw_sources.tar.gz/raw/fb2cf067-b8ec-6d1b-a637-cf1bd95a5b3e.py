import cadquery as cq
from types import SimpleNamespace as Measures
import math

params = Measures(
    linear_width = 60.0,
    depth = 12.0,
    height = 12.0,
    arc_outer_diameter = 80.0,
    cavity_thickness = 3.0,
    corner_fillet = 2.0,
    holes = Measures(
        hole_spacing = 20.0,
        hole_offset = 8.0,
        bolt_diameter = 4.2,
        head_diameter = 7.0,
        head_height = 4.0,
    )
)

params.arc_outer_radius = 0.5 * params.arc_outer_diameter
params.arc_center_diameter = params.arc_outer_diameter - params.depth
params.arc_center_radius = 0.5 * params.arc_center_diameter
params.arc_center_angle = math.degrees(math.acos((2 * params.arc_center_radius**2 - params.linear_width**2) / (2 * params.arc_center_radius**2)))
params.arc_secant_angle = 0.5 * (180.0 - params.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((params.linear_width, 0.0), params.arc_center_radius)
    .wire()
)

block = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -params.arc_secant_angle, 0))
    .rect(params.depth, params.height)
    .sweep(path, transition="round")
)

block_with_holes = (
    block
    .faces(">Z")
    .workplane()
    .center(-params.holes.hole_spacing/2, params.holes.hole_offset)
    .cboreHole(params.holes.bolt_diameter, params.holes.head_diameter, params.holes.head_height)
    .center(params.holes.hole_spacing, 0)
    .cboreHole(params.holes.bolt_diameter, params.holes.head_diameter, params.holes.head_height)
)

# Fillet a representative corner edge (first edge)
filleted = block_with_holes.edges().first().fillet(params.corner_fillet)

result = filleted.shell(-params.cavity_thickness)
