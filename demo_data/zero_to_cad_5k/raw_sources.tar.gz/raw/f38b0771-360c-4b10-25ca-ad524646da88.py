import cadquery as cq
bracket_width=80.0
bracket_height=60.0
plate_thickness=8.0
horizontal=cq.Workplane('XY').box(bracket_width, plate_thickness, plate_thickness)
vertical=cq.Workplane('XY').box(plate_thickness, bracket_height, plate_thickness).translate((0, bracket_height/2+plate_thickness/2,0))
result=horizontal.union(vertical)
