import cadquery as cq
from types import SimpleNamespace as Measures

# Define parameters
vertical_leg_height = 80.0
vertical_leg_thickness = 10.0
horizontal_leg_length = 70.0
horizontal_leg_thickness = 10.0
leg_width = 12.0
hole_diameter = 5.0
hole_clearance = 6.0
horizontal_hole_spacing = 30.0
vertical_hole_spacing = 40.0
rib_height = 15.0
rib_thickness = 6.0
rib_offset = 2.0
chamfer_size = 1.0

measures = Measures(
    vertical_leg_height=vertical_leg_height,
    vertical_leg_thickness=vertical_leg_thickness,
    horizontal_leg_length=horizontal_leg_length,
    horizontal_leg_thickness=horizontal_leg_thickness,
    leg_width=leg_width,
    hole_diameter=hole_diameter,
    hole_clearance=hole_clearance,
    horizontal_hole_spacing=horizontal_hole_spacing,
    vertical_hole_spacing=vertical_hole_spacing,
    rib_height=rib_height,
    rib_thickness=rib_thickness,
    rib_offset=rib_offset,
    chamfer_size=chamfer_size,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.m = measures
        self.build()

    def build(self):
        m = self.m
        # Create composite L profile in XY plane
        # Start at origin, build vertical leg upwards, then horizontal leg to the right
        self.model = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_leg_height),
                (m.vertical_leg_thickness, m.vertical_leg_height),
                (m.vertical_leg_thickness, m.horizontal_leg_thickness),
                (m.horizontal_leg_length, m.horizontal_leg_thickness),
                (m.horizontal_leg_length, 0),
                (0, 0),
            ])
            .close()
            .extrude(m.leg_width)
        )
        # Chamfer outer edges of the L shape for safety
        self.model = self.model.edges(">X or >Y or <X or <Y").chamfer(m.chamfer_size)
        # Drill clearance holes in horizontal leg (centered along width)
        horiz_hole_y = m.horizontal_leg_thickness / 2
        first_hole_x = (m.horizontal_leg_length - m.horizontal_hole_spacing) / 2
        self.model = (
            self.model.faces("<Z")
            .workplane(offset=0)
            .center(first_hole_x, horiz_hole_y)
            .hole(m.hole_clearance)
            .center(m.horizontal_hole_spacing, 0)
            .hole(m.hole_clearance)
        )
        # Drill clearance holes in vertical leg (centered along width)
        vert_hole_z = m.leg_width / 2
        first_vert_y = (m.vertical_leg_height - m.vertical_hole_spacing) / 2
        self.model = (
            self.model.faces("<Y")
            .workplane()
            .center(m.vertical_leg_thickness/2, first_vert_y)
            .hole(m.hole_clearance)
            .center(0, m.vertical_hole_spacing)
            .hole(m.hole_clearance)
        )
        # Add reinforcement rib on outer face of vertical leg (+X face)
        self.model = (
            self.model.faces(">X")
            .workplane(centerOption='CenterOfBoundBox')
            .rect(m.rib_thickness, m.rib_height)
            .translate((m.rib_offset, 0, m.vertical_leg_height/2))
            .extrude(m.rib_thickness)
        )

# Build part
result = LBracket(cq.Workplane("XY"), measures).model
