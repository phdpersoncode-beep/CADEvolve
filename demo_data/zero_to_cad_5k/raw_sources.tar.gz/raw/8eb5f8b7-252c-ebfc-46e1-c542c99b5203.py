import cadquery as cq

outer_diameter = 80.0
thickness = 8.0
central_hole_diameter = 12.0
chamfer_distance = 1.0
mount_hole_diameter = 5.0
mount_hole_count = 4
mount_hole_radius = outer_diameter/2 - 12.0
rib_count = 6
rib_width = 4.0
rib_length = 12.0
rib_height = thickness * 0.5
rib_offset = 6.0
pocket_diameter = 30.0
pocket_depth = thickness * 0.4

base = (
    cq.Workplane("XY")
    .circle(outer_diameter/2)
    .extrude(thickness)
)

base = (
    base.faces(">Z").workplane()
    .hole(central_hole_diameter)
)

base = base.edges(">Z").chamfer(chamfer_distance)

base = (
    base.faces(">Z").workplane()
    .polarArray(radius=mount_hole_radius, startAngle=0, count=mount_hole_count, angle=360)
    .hole(mount_hole_diameter)
)

rib_radius = outer_diameter/2 - rib_offset - rib_width/2
ribs = (
    cq.Workplane("XY")
    .polarArray(radius=rib_radius, startAngle=0, count=rib_count, angle=360)
    .rect(rib_width, rib_length)
    .extrude(rib_height)
)

base = base.union(ribs)

pocket = (
    base.faces("<Z").workplane()
    .circle(pocket_diameter/2)
    .cutBlind(-pocket_depth)
)

result = pocket