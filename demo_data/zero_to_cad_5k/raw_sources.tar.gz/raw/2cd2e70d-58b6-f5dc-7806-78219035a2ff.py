import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()
    def build(self):
        m = self.measures
        th = m.leg_thickness
        vertical = cq.Workplane("XY").box(th, m.vertical_height, th)
        horizontal = (
            cq.Workplane("XY")
            .transformed(offset=(th/2 + m.horizontal_length/2, 0, 0))
            .box(m.horizontal_length, th, th)
        )
        base = vertical.union(horizontal)
        holes = (
            base.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.horizontal_length/2 - m.hole_edge_margin, 0)
            .rect(m.hole_spacing, m.hole_spacing)
            .vertices()
            .cboreHole(m.hole_diameter, m.hole_cbore_diameter, m.hole_cbore_depth)
        )
        pocket_cut = (
            cq.Workplane("XZ")
            .rect(m.pocket_width, m.pocket_height)
            .extrude(-m.pocket_depth)
            .translate((0, th/2, 0))
            .translate((0, 0, m.pocket_offset))
        )
        pocketed = holes.cut(pocket_cut)
        final = pocketed
        result = final.edges().chamfer(m.chamfer_distance)
        self.model = result

measures = Measures(
    leg_thickness=10.0,
    vertical_height=70.0,
    horizontal_length=55.0,
    hole_spacing=30.0,
    hole_edge_margin=5.0,
    hole_diameter=4.5,
    hole_cbore_diameter=7.0,
    hole_cbore_depth=2.0,
    pocket_width=20.0,
    pocket_height=15.0,
    pocket_depth=10.0,
    pocket_offset=30.0,
    chamfer_distance=1.0,
)

result = LBracket(cq.Workplane("XY"), measures).model