import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.vertical_leg_length)
            .lineTo(0, m.vertical_leg_length)
            .close()
            .extrude(m.thickness)
        )
        base = base.edges('|Z').fillet(m.fillet_radius)
        rib = (
            cq.Workplane('XY')
            .box(m.rib_length, m.rib_width, m.rib_height)
            .translate((m.horizontal_leg_length - m.rib_length/2, m.thickness/2, m.thickness + m.rib_height/2))
        )
        bracket = base.union(rib)
        hole_points = []
        start_y = m.thickness + m.hole_spacing/2
        for i in range(3):
            hole_points.append((m.thickness/2, start_y + i*m.hole_spacing))
        start_x = m.thickness + m.hole_spacing/2
        for i in range(3):
            hole_points.append((start_x + i*m.hole_spacing, m.thickness/2))
        self.model = (
            bracket
            .faces('>Z')
            .workplane()
            .pushPoints(hole_points)
            .cboreHole(m.hole_clearance_diameter, m.hole_cbore_diameter, m.hole_cbore_depth)
        )

measures = Measures(
    horizontal_leg_length=70.0,
    vertical_leg_length=60.0,
    thickness=10.0,
    fillet_radius=2.0,
    rib_length=20.0,
    rib_width=10.0,
    rib_height=5.0,
    hole_spacing=15.0,
    hole_clearance_diameter=5.5,
    hole_cbore_diameter=7.0,
    hole_cbore_depth=2.5,
)

result = LBracket(cq.Workplane('XY'), measures).model