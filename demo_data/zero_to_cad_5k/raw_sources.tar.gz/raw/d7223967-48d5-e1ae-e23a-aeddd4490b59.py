import cadquery as cq

# Parameters
base_radius = 25.0
base_height = 5.0
frame_thickness = 5.0
frame_height = 8.0
fillet_radius = 0.5
m4_diameter = 4.0
hole_pitch_radius = 20.0
hole_depth = base_height + frame_height + 2.0

result = (
    cq.Workplane("XZ")
    .moveTo(base_radius, 0)
    .lineTo(base_radius, base_height)
    .lineTo(base_radius + frame_thickness, base_height)
    .lineTo(base_radius + frame_thickness, base_height + frame_height)
    .lineTo(base_radius, base_height + frame_height)
    .close()
    .revolve()
    .edges()
    .fillet(fillet_radius)
    .faces(">Z")
    .workplane()
    .polarArray(radius=hole_pitch_radius, count=5, startAngle=0, angle=360)
    .hole(m4_diameter, depth=hole_depth)
)
