import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane('XY')
            .box(m.leg_width, m.leg_height, m.thickness)
            .translate((m.leg_width/2, m.leg_height/2, m.thickness/2))
        )
        horizontal = (
            cq.Workplane('XY')
            .box(m.horizontal_length, m.leg_width, m.thickness)
            .translate((m.horizontal_length/2, m.leg_height + m.leg_width/2, m.thickness/2))
        )
        base = vertical.union(horizontal)
        base = base.fillet(m.fillet_radius)
        pocket = (
            cq.Workplane('XY')
            .box(m.pocket_width, m.pocket_depth, m.pocket_depth_z)
            .translate((m.pocket_width/2, m.leg_height + m.pocket_depth/2, m.pocket_depth_z/2))
        )
        base = base.cut(pocket)
        base = (
            base.faces('>Z')
            .workplane()
            .center(m.horizontal_length/2, m.leg_height + m.leg_width/2)
            .rect(m.hole_grid_x, m.hole_grid_y, forConstruction=True)
            .vertices()
            .hole(m.hole_diameter)
        )
        self.model = base

measures = Measures(
    leg_width=20.0,
    leg_height=60.0,
    horizontal_length=80.0,
    thickness=10.0,
    fillet_radius=3.0,
    pocket_width=15.0,
    pocket_depth=20.0,
    pocket_depth_z=5.0,
    hole_diameter=5.5,
    hole_grid_x=40.0,
    hole_grid_y=20.0,
)

result = LBracket(cq.Workplane('XY'), measures).model