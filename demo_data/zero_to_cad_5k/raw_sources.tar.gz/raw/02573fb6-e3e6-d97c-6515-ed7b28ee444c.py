import cadquery as cq

# Parameters
base_length = 80.0
base_width = 60.0
base_thickness = 6.0
frame_thickness = 4.0
frame_height = 12.0
base_fillet = 2.0
corner_fillet = 3.0
hole_diameter = 4.0
hole_radius = hole_diameter / 2.0
hole_depth = 10.0
# Positions for six blind holes (relative to center)
hole_positions = [
    ( -base_length/2 + frame_thickness + 10, -base_width/2 + frame_thickness + 10),
    (  base_length/2 - frame_thickness - 10, -base_width/2 + frame_thickness + 10),
    ( -base_length/2 + frame_thickness + 10,  base_width/2 - frame_thickness - 10),
    (  base_length/2 - frame_thickness - 10,  base_width/2 - frame_thickness - 10),
    ( 0, -base_width/2 + frame_thickness + 12),
    ( 0,  base_width/2 - frame_thickness - 12),
]

# Begin modeling
result = (
    cq.Workplane("XY")
    # Base plate
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    # Fillet base vertical edges for safety
    .edges("|Z").fillet(base_fillet)
    # Add raised frame (full rectangle extrusion)
    .faces(">Z").workplane()
    .rect(base_length, base_width)
    .extrude(frame_height, combine=True)
    # Cut inner cavity to create perimeter frame
    .faces(">Z").workplane()
    .rect(base_length - 2*frame_thickness, base_width - 2*frame_thickness)
    .cutBlind(-frame_height)
    # Fillet outer vertical edges of frame
    .edges("|Z").fillet(corner_fillet)
    # Create six blind tapped holes in the frame
    .faces(">Z").workplane()
    .pushPoints(hole_positions)
    .circle(hole_radius)
    .cutBlind(-hole_depth)
)
