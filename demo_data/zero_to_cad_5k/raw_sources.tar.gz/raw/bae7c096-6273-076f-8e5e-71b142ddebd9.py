import cadquery as cq
from types import SimpleNamespace as Measures

class SupportBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.horizontal_leg_length, 0)
            .lineTo(m.horizontal_leg_length, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.vertical_leg_length)
            .lineTo(0, m.vertical_leg_length)
            .close()
        )
        self.model = profile.extrude(m.depth)
        self.model = (
            self.model.edges()
            .filter(lambda e: abs(e.Center().x) < 1e-6 and abs(e.Center().y) < 1e-6)
            .fillet(m.inner_fillet_radius)
        )
        start_x = m.thickness + m.hole_margin
        start_y = m.thickness / 2 - (m.hole_spacing / 2)
        hole_positions = []
        for row in range(2):
            for col in range(2):
                x = start_x + col * m.hole_spacing
                y = start_y + row * m.hole_spacing
                hole_positions.append((x, y))
        for hx, hy in hole_positions:
            self.model = (
                self.model.faces("<Z")
                .workplane()
                .center(hx, hy)
                .hole(m.hole_diameter)
            )
        gusset = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.gusset_width, 0)
            .lineTo(0, m.gusset_height)
            .close()
            .extrude(m.gusset_thickness)
        )
        self.model = self.model.union(gusset)

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=60.0,
    thickness=8.0,
    depth=10.0,
    inner_fillet_radius=2.0,
    hole_diameter=5.0,
    hole_spacing=20.0,
    hole_margin=4.0,
    gusset_width=30.0,
    gusset_height=30.0,
    gusset_thickness=5.0,
)

result = SupportBracket(cq.Workplane("XY"), measures).model