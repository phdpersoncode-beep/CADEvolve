import cadquery as cq

# dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 8.0
frame_outer_length = 60.0
frame_outer_width = 40.0
frame_height = 12.0
frame_thickness = 4.0
hole_diameter = 6.0
hole_depth = 8.0
rib_height = 6.0
rib_thickness = 4.0
chamfer_size = 0.8

result = (
    cq.Workplane('XY')
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges('|Z').fillet(chamfer_size)
    .faces('>Z')
    .workplane()
    # raised frame outer block
    .box(frame_outer_length, frame_outer_width, frame_height, centered=(True, True, False), combine=True)
    # cut inner cavity to make frame hollow
    .workplane(offset=frame_thickness)
    .rect(frame_outer_length - 2*frame_thickness, frame_outer_width - 2*frame_thickness)
    .cutBlind(- (frame_height - frame_thickness))
    # three blind holes in frame
    .faces('>Z')
    .workplane(offset=-frame_thickness/2)
    .pushPoints([
        (0, 0),
        (frame_outer_length/2 - frame_thickness - hole_diameter, 0),
        (-frame_outer_length/2 + frame_thickness + hole_diameter, 0),
    ])
    .circle(hole_diameter/2)
    .cutBlind(-hole_depth)
    # reinforcing rib on bottom side
    .faces('<Z')
    .workplane(offset=-rib_thickness)
    .polyline([(-rib_thickness, -rib_thickness), (rib_thickness, -rib_thickness), (rib_thickness, rib_height - rib_thickness), (-rib_thickness, rib_height - rib_thickness), (-rib_thickness, -rib_thickness)])
    .close()
    .extrude(rib_thickness)
    .edges('|Z').chamfer(chamfer_size)
)
