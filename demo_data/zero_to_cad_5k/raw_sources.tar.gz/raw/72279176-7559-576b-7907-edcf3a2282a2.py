import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.leg_length - m.thickness)
            .lineTo(m.leg_width, m.leg_length - m.thickness)
            .lineTo(m.leg_width, m.leg_length)
            .lineTo(0, m.leg_length)
            .close()
            .extrude(m.bracket_height)
            .edges("|Z")
            .fillet(m.fillet_radius)
        )
        if m.add_rib:
            base = (
                base.faces("<Y")
                .workplane()
                .center(m.leg_width/2, m.thickness/2)
                .rect(m.rib_width, m.rib_height)
                .cutBlind(-m.rib_depth)
            )
        boss_shape = (
            cq.Workplane("XY")
            .center((m.leg_width - m.boss_width)/2, m.thickness/2)
            .rect(m.boss_width, m.boss_depth)
            .extrude(m.boss_height)
        )
        combined = base.union(boss_shape)
        holes = (
            combined.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .rarray(0, m.hole_spacing, 1, 2)
            .cboreHole(m.hole_clearance, m.hole_cbore_diameter, m.hole_cbore_depth)
        )
        self.model = holes

measures = Measures(
    leg_width=80.0,
    leg_length=60.0,
    thickness=10.0,
    bracket_height=8.0,
    fillet_radius=2.0,
    boss_width=30.0,
    boss_depth=25.0,
    boss_height=5.0,
    hole_clearance=9.0,
    hole_cbore_diameter=11.0,
    hole_cbore_depth=2.0,
    hole_spacing=20.0,
    add_rib=True,
    rib_width=15.0,
    rib_height=5.0,
    rib_depth=2.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
