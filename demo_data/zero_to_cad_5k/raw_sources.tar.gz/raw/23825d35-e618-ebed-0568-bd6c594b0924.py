import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        main_profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.leg_height)
            .lineTo(m.thickness + m.leg_length, m.leg_height)
            .lineTo(m.thickness + m.leg_length, m.leg_height + m.thickness)
            .lineTo(0, m.leg_height + m.thickness)
            .close()
            .extrude(m.thickness)
        )
        gusset = (
            cq.Workplane("XY")
            .moveTo(m.thickness, m.leg_height / 2)
            .lineTo(m.thickness + m.gusset_length, m.leg_height / 2)
            .lineTo(m.thickness, m.leg_height / 2 + m.gusset_height)
            .close()
            .extrude(m.thickness)
        )
        body = main_profile.union(gusset)
        edge_margin = m.thickness
        spacing = (m.leg_height - 2 * edge_margin) / (m.hole_count - 1)
        holes = []
        for i in range(m.hole_count):
            y = edge_margin + i * spacing
            holes.append((m.thickness / 2, y))
        body = (
            body.faces(">Z")
            .workplane()
            .pushPoints(holes)
            .hole(m.hole_diameter)
        )
        self.model = body.edges("|Z").chamfer(m.chamfer_distance)

measures = Measures(
    leg_length=70.0,
    leg_height=80.0,
    thickness=10.0,
    gusset_length=20.0,
    gusset_height=15.0,
    hole_diameter=6.0,
    hole_count=3,
    chamfer_distance=3.0,
)

result = LBracket(cq.Workplane("XY"), measures).model