import cadquery as cq
import math

outer_diameter = 80.0
block_thickness = 15.0
block_height = 20.0
arc_center_radius = outer_diameter/2 - block_thickness
theta_deg = 130.0
theta_rad = math.radians(theta_deg)
linear_width = 2 * arc_center_radius * math.sin(theta_rad/2)
arc_center_angle = math.degrees(math.acos((2*arc_center_radius**2 - linear_width**2)/(2*arc_center_radius**2)))
arc_secant_angle = 0.5 * (180.0 - arc_center_angle)

fillet_vertical = 2.0
fillet_top = 3.0
chamfer_distance = 0.8

hole_diameter = 4.0
head_diameter = 7.0
head_height = 4.0
hole_offset_x = linear_width*0.4
hole_offset_y = block_thickness*0.5

pocket_width = block_thickness * 0.5
pocket_height = block_height * 0.5
pocket_depth = block_thickness * 0.6

path = (
    cq.Workplane("XY")
       .radiusArc((linear_width, 0), arc_center_radius)
       .wire()
)

base = (
    cq.Workplane("XY")
       .transformed(rotate=(90, -arc_secant_angle, 0))
       .rect(block_thickness, block_height)
       .sweep(path, transition="round")
)

base = base.edges("|Z").fillet(fillet_vertical)
base = base.edges(">Z").fillet(fillet_top)
base = base.faces("<Z").edges().chamfer(chamfer_distance)
base = base.faces(">Z").workplane().center(hole_offset_x, hole_offset_y).cboreHole(hole_diameter, head_diameter, head_height)
base = base.faces(">Z").workplane().rect(pocket_width, pocket_height).cutBlind(-pocket_depth)

result = base
