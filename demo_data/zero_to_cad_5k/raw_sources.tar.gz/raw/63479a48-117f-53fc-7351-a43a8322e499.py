import cadquery as cq

bracket_width = 40
leg_length = 50
leg_width = 15
thickness = 10
counterbore_shank_dia = 5
counterbore_head_dia = 10
countersink_angle = 90
mount_hole_dia = 4
mount_hole_spacing = 30
mount_hole_offset_y = 10
chamfer_dist = 1
pocket_width = leg_width - 4
pocket_height = leg_length - 20
pocket_depth = thickness - 2

points = [
    (0, 0),
    (leg_width, 0),
    (leg_width, leg_length),
    (leg_width + bracket_width, leg_length),
    (leg_width + bracket_width, leg_length + leg_width),
    (0, leg_length + leg_width),
]

result = (
    cq.Workplane("XY")
    .polyline(points)
    .close()
    .extrude(thickness)
    .edges()
    .chamfer(chamfer_dist)
    .faces(">Z")
    .workplane()
    .center(- (leg_width + bracket_width) / 2, - (leg_length + leg_width) / 2)
    .pushPoints([
        (leg_width / 2, mount_hole_offset_y),
        (leg_width / 2, mount_hole_offset_y + mount_hole_spacing),
    ])
    .hole(mount_hole_dia)
    .center(bracket_width / 2, leg_width / 2)
    .cskHole(counterbore_shank_dia, counterbore_head_dia, countersink_angle)
    .faces(">Z")
    .workplane()
    .center(- (leg_width + bracket_width) / 2, - (leg_length + leg_width) / 2)
    .center(leg_width / 2, leg_length / 2)
    .rect(pocket_width, pocket_height)
    .cutBlind(-pocket_depth)
)
