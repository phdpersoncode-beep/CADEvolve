import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()

    def build(self):
        m = self.measures
        solid = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (0, m.vertical_height),
                (m.leg_thickness, m.vertical_height),
                (m.leg_thickness, m.leg_thickness),
                (m.horizontal_length, m.leg_thickness),
                (m.horizontal_length, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        solid = (
            solid.faces('>Z')
            .workplane()
            .center(m.leg_thickness/2, m.notch_offset + m.notch_depth/2)
            .rect(m.notch_width, m.notch_depth)
            .cutBlind(m.notch_depth)
        )
        shoulder = (
            cq.Workplane('XY')
            .transformed(offset=(0, 0, m.bracket_thickness))
            .center(m.horizontal_length - m.shoulder_length/2, m.leg_thickness/2)
            .rect(m.shoulder_length, m.leg_thickness)
            .extrude(m.shoulder_extra_thickness)
        )
        solid = solid.union(shoulder)
        solid = (
            solid.faces('>Y')
            .workplane()
            .center(m.horizontal_length - m.shoulder_length/2, 0)
            .rarray(m.mount_hole_spacing, 0, m.mount_hole_count, 1)
            .hole(m.mount_hole_diameter)
        )
        solid = (
            solid.faces('<Y')
            .workplane()
            .center(m.leg_thickness/2, m.vertical_height/2)
            .hole(m.blind_hole_diameter, depth=m.blind_hole_depth)
        )
        solid = solid.edges('|Z and <<X and <<Y').fillet(m.inner_fillet_radius)
        self.model = solid

measures = Measures(
    vertical_height=60.0,
    horizontal_length=70.0,
    leg_thickness=10.0,
    bracket_thickness=8.0,
    notch_width=6.0,
    notch_depth=4.0,
    notch_offset=20.0,
    shoulder_length=30.0,
    shoulder_extra_thickness=4.0,
    mount_hole_diameter=4.0,
    mount_hole_spacing=20.0,
    mount_hole_count=2,
    blind_hole_diameter=5.0,
    blind_hole_depth=12.0,
    inner_fillet_radius=2.0,
)

result = LBracket(cq.Workplane('XY'), measures).model