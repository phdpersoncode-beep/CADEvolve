import cadquery as cq
from types import SimpleNamespace as Measures

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_a_length, 0),
                (m.leg_a_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.leg_b_length),
                (0, m.leg_b_length),
                (0, 0),
            ])
            .close()
        )
        solid = profile.extrude(m.outer_thickness)
        # Chamfer outer vertical edges before shell gives valid edges
        solid = solid.edges("|Z").chamfer(m.chamfer)
        shell = solid.shell(m.wall_thickness)
        pocket = (
            shell.faces(">Z")
            .workplane()
            .center(m.wall_thickness / 2, m.wall_thickness / 2)
            .rect(m.notch_width, m.notch_depth)
            .cutBlind(-m.wall_thickness)
        )
        with_counterbore = (
            pocket.faces(">X")
            .workplane()
            .center(0, m.leg_b_length / 2)
            .cboreHole(m.hole_diameter, m.counterbore_diameter, m.counterbore_depth)
        )
        self.model = with_counterbore

measures = Measures(
    leg_a_length=80.0,
    leg_b_length=60.0,
    leg_thickness=6.0,
    outer_thickness=6.0,
    wall_thickness=2.0,
    hole_diameter=10.0,
    counterbore_diameter=16.0,
    counterbore_depth=4.0,
    chamfer=0.5,
    notch_width=4.0,
    notch_depth=6.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
