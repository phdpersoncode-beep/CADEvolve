import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        points = [
            (0, 0),
            (m.leg_thickness, 0),
            (m.leg_thickness, m.vertical_leg_length),
            (m.horizontal_leg_length, m.vertical_leg_length),
            (m.horizontal_leg_length, m.vertical_leg_length - m.leg_thickness),
            (m.leg_thickness, m.vertical_leg_length - m.leg_thickness),
            (m.leg_thickness, 0),
        ]
        base = (
            cq.Workplane("XY")
            .polyline(points)
            .close()
            .extrude(m.bracket_thickness)
        )
        vertical_rib = (
            cq.Workplane("XY")
            .center(m.leg_thickness + m.rib_width/2, m.leg_thickness + (m.vertical_leg_length - m.leg_thickness)/2)
            .rect(m.rib_width, m.vertical_leg_length - m.leg_thickness)
            .extrude(m.bracket_thickness)
        )
        horizontal_rib = (
            cq.Workplane("XY")
            .center(m.leg_thickness + (m.horizontal_leg_length - m.leg_thickness)/2, m.vertical_leg_length - m.leg_thickness/2)
            .rect(m.horizontal_leg_length - m.leg_thickness, m.rib_width)
            .extrude(m.bracket_thickness)
        )
        model = base.union(vertical_rib).union(horizontal_rib)
        model = (
            model.faces(">Z")
            .workplane()
            .moveTo(m.leg_thickness + m.boss_offset, m.leg_thickness + m.boss_offset)
            .hole(m.boss_diameter, depth=m.boss_thread_depth)
        )
        model = (
            model.faces(">Z")
            .workplane()
            .moveTo(m.horizontal_leg_length/2, m.vertical_leg_length - m.leg_thickness/2)
            .rect(m.slot_width, m.slot_length)
            .cutBlind(m.bracket_thickness)
        )
        model = model.edges().chamfer(m.chamfer_size)
        self.model = model

measures = Measures(
    leg_thickness=5.0,
    vertical_leg_length=60.0,
    horizontal_leg_length=80.0,
    bracket_thickness=4.0,
    rib_width=3.0,
    boss_diameter=6.0,
    boss_thread_depth=15.0,
    boss_offset=2.0,
    slot_width=4.0,
    slot_length=20.0,
    chamfer_size=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model