import cadquery as cq
from types import SimpleNamespace as Measures

# Parameter definitions
outer_width = 80.0
outer_height = 60.0
leg_thickness = 12.0
material_thickness = 8.0
wall_thickness = 2.0
pocket_width = leg_thickness - 2 * wall_thickness
pocket_height = outer_height - leg_thickness - 2 * wall_thickness
pocket_depth = material_thickness - wall_thickness
clearance_hole_dia = 5.0
hole_spacing = (outer_width - leg_thickness) / 2.0
inner_fillet_radius = 3.0
chamfer_distance = 0.5

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        # Create L‑shape profile and extrude
        self.model = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.outer_width, 0),
                (m.outer_width, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.outer_height),
                (0, m.outer_height),
                (0, 0)
            ])
            .close()
            .extrude(m.material_thickness)
        )
        # Fillet inner vertical edge (rounded inner junction)
        self.model = self.model.edges("|Z").fillet(m.inner_fillet_radius)
        # Recessed pocket on vertical leg
        self.model = (
            self.model
            .faces("<X")
            .workplane()
            .center(0, (m.leg_thickness + m.outer_height) / 2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        # Two clearance holes on horizontal leg
        self.model = (
            self.model
            .faces("<Y")
            .workplane()
            .center((m.leg_thickness + m.outer_width) / 2, 0)
            .pushPoints([(-m.hole_spacing/2, 0), (m.hole_spacing/2, 0)])
            .hole(m.clearance_hole_dia)
        )
        # Chamfer outer edges for safety
        self.model = self.model.edges(">Z or <Z").chamfer(m.chamfer_distance)

# Measures container
measures = Measures(
    outer_width=outer_width,
    outer_height=outer_height,
    leg_thickness=leg_thickness,
    material_thickness=material_thickness,
    wall_thickness=wall_thickness,
    pocket_width=pocket_width,
    pocket_height=pocket_height,
    pocket_depth=pocket_depth,
    clearance_hole_dia=clearance_hole_dia,
    hole_spacing=hole_spacing,
    inner_fillet_radius=inner_fillet_radius,
    chamfer_distance=chamfer_distance,
)

result = LBracket(cq.Workplane("XY"), measures).model