import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane('XY')
            .box(m.leg_width, m.leg_length_long, m.thickness)
            .translate((0, m.leg_length_long / 2, 0))
        )
        horizontal = (
            cq.Workplane('XY')
            .box(m.leg_length_short, m.leg_width, m.thickness)
            .translate((m.leg_length_short / 2, 0, 0))
        )
        base = vertical.union(horizontal)
        pocket = (
            base.faces('>Z')
            .workplane()
            .moveTo(m.leg_width / 2, m.leg_width / 2)
            .rect(m.pocket_width, m.pocket_width)
            .cutBlind(-m.pocket_depth)
        )
        filleted = (
            pocket.edges('>X and |Z')
            .fillet(m.fillet_radius)
            .edges('>Y and |Z')
            .fillet(m.fillet_radius)
        )
        holes_vert = (
            filleted.faces('>Y')
            .workplane()
            .pushPoints([(-m.hole_spacing / 2, m.thickness / 2), (m.hole_spacing / 2, m.thickness / 2)])
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        holes_horiz = (
            holes_vert.faces('>X')
            .workplane()
            .pushPoints([(-m.hole_spacing / 2, m.thickness / 2), (m.hole_spacing / 2, m.thickness / 2)])
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.model = holes_horiz

measures = Measures(
    leg_width=20.0,
    leg_length_long=80.0,
    leg_length_short=60.0,
    thickness=10.0,
    pocket_width=12.0,
    pocket_depth=10.0,
    fillet_radius=5.0,
    hole_diameter=5.0,
    cbore_diameter=8.0,
    cbore_depth=2.0,
    hole_spacing=30.0,
)

result = LBracket(cq.Workplane('XY'), measures).model