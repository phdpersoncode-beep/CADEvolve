import cadquery as cq
import math
from types import SimpleNamespace as Measures

m = Measures(
    linear_width = 30.0,
    block_depth = 15.0,
    block_height = 30.0,
    arc_outer_diameter = 80.0,
    step_height = 12.0,
    inner_radius_low = 22.0,
    inner_radius_high = 16.0,
    through_hole_radius = 5.0,
    chamfer_distance = 1.0,
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.block_depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = math.degrees(
    math.acos(
        (2 * m.arc_center_radius ** 2 - m.linear_width ** 2) / (2 * m.arc_center_radius ** 2)
    )
)
m.arc_secant_angle = 0.5 * (180.0 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

swept_block = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_depth, m.block_height)
    .sweep(path, transition="round")
)

lower_cylinder = (
    cq.Workplane("XY")
    .circle(m.inner_radius_low)
    .extrude(m.step_height)
)

upper_cylinder = (
    cq.Workplane("XY")
    .circle(m.inner_radius_high)
    .extrude(m.block_height - m.step_height)
)

stepped_cavity = lower_cylinder.union(upper_cylinder)

through_hole = (
    cq.Workplane("XY")
    .circle(m.through_hole_radius)
    .extrude(m.block_height * 1.2)
)

result = (
    swept_block
    .cut(stepped_cavity)
    .cut(through_hole)
    .edges("|Z")
    .chamfer(m.chamfer_distance)
)
