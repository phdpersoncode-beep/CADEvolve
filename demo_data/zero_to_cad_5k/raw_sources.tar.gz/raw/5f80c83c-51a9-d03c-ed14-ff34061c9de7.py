import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    outer_diameter = 80.0,
    inner_diameter = 50.0,
    width = 10.0,
    seam_width = 2.0,
    chamfer_distance = 1.0,
    bolt_hole = Measures(
        diameter = 4.0,
        count = 3,
        radius_offset = 0.5
    )
)

inner_radius = m.inner_diameter / 2.0
outer_radius = m.outer_diameter / 2.0

ring = (
    cq.Workplane("XZ")
    .moveTo(inner_radius, 0)
    .lineTo(outer_radius, 0)
    .lineTo(outer_radius, m.width)
    .lineTo(inner_radius, m.width)
    .close()
    .revolve()
)

seam_cut = (
    cq.Workplane("YZ")
    .center(inner_radius + m.seam_width/2.0, 0)
    .rect(m.seam_width, m.width + 2.0)
    .extrude(outer_radius * 2.0)
)

ring = ring.cut(seam_cut)

ring = ring.faces(">Z").edges().chamfer(m.chamfer_distance)

hole_center_radius = inner_radius + m.bolt_hole.radius_offset * (outer_radius - inner_radius)
ring = (
    ring.faces(">Z").workplane()
    .polarArray(radius=hole_center_radius, count=m.bolt_hole.count, startAngle=0, angle=360)
    .hole(m.bolt_hole.diameter)
)

result = ring