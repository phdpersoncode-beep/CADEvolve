import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 5.0
frame_margin = 5.0
frame_height = 8.0
hole_diameter = 4.0
hole_depth = 4.0
rib_width = 20.0
rib_thickness = 3.0
rib_height = 2.0
revolve_radius = 12.0
revolve_profile_height = 15.0
revolve_outer_radius = 18.0
edge_fillet = 1.5
frame_fillet = 0.8

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges("|Z").fillet(edge_fillet)
    .faces("<Z").fillet(edge_fillet)
    .faces(">Z")
    .workplane()
    .rect(base_length - 2*frame_margin, base_width - 2*frame_margin)
    .extrude(frame_height)
    .edges("|Z").fillet(frame_fillet)
    .faces("<Z")
    .workplane(offset=base_thickness - 0.01)
    .pushPoints([
        (-base_length/3, -base_width/4),
        ( base_length/3, -base_width/4),
        (-base_length/3,  base_width/4),
        ( base_length/3,  base_width/4),
        (0.0, -base_width/2 + frame_margin + hole_diameter),
        (0.0,  base_width/2 - frame_margin - hole_diameter),
    ])
    .circle(hole_diameter/2)
    .cutBlind(-hole_depth)
    .faces("<Z")
    .workplane()
    .rect(rib_width, base_width - 2*frame_margin)
    .extrude(rib_thickness)
    .faces("<Z")
    .workplane(offset=rib_thickness)
    .rect(rib_width - 2, base_width - 2*frame_margin - 2)
    .cutBlind(-rib_height)
    .faces(">Z")
    .workplane(offset=frame_height)
    .moveTo(revolve_radius, 0)
    .lineTo(revolve_radius, revolve_profile_height)
    .lineTo(revolve_outer_radius, revolve_profile_height)
    .threePointArc((revolve_outer_radius+2, revolve_profile_height/2), (revolve_outer_radius, 0))
    .close()
    .revolve(360)
    .edges("|Z").fillet(0.3)
)
