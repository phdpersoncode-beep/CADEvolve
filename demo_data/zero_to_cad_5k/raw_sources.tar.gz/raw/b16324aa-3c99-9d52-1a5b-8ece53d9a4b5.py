import cadquery as cq

# Parameters
base_length = 60.0
bracket_height = 30.0
thickness = 8.0
step1_height = 10.0
step2_height = 20.0
step1_depth = 10.0
step2_depth = 20.0
fillet_radius = 2.0
chamfer_distance = 1.0
hole_diameter = 6.0
hole_depth = thickness * 0.6
hole_spacing = base_length / 4.0
mount_hole_dia = 5.0
mount_hole_offset = 5.0
rib_thickness = 4.0
rib_offset = mount_hole_offset
pocket_rect_width = base_length * 0.3
pocket_rect_height = bracket_height * 0.4
pocket_depth_inner = thickness * 0.4

# Base profile using Workplane polyline (non‑trivial closed sketch)
result = (
    cq.Workplane("XY")
    .polyline([
        (0, 0),
        (base_length, 0),
        (base_length, bracket_height - step2_height),
        (base_length - step2_depth, bracket_height - step2_height),
        (base_length - step2_depth, bracket_height - step1_height),
        (base_length - step1_depth, bracket_height - step1_height),
        (base_length - step1_depth, bracket_height),
        (0, bracket_height),
    ])
    .close()
    .extrude(thickness)
)

# Fillet on the vertical edges of the stepped shoulder (parallel to Y)
result = result.edges("|Y").fillet(fillet_radius)

# Chamfer on bottom outer corners (parallel to X and below Z)
result = result.edges("|X and <Z").chamfer(chamfer_distance)

# Three blind holes on top face, equally spaced
result = (
    result.faces(">Z")
    .workplane()
    .rarray(hole_spacing, 0, 3, 1)
    .circle(hole_diameter / 2)
    .cutBlind(hole_depth)
)

# Two mounting holes on the +X side face
mount_y_positions = [mount_hole_offset, bracket_height - mount_hole_offset]
result = (
    result.faces(">X")
    .workplane()
    .pushPoints([(0, y) for y in mount_y_positions])
    .hole(mount_hole_dia)
)

# Internal stiffening rib on the inner face (<Y)
rib = (
    cq.Workplane("XY")
    .moveTo(base_length - step1_depth - rib_thickness / 2, rib_offset)
    .rect(rib_thickness, bracket_height - 2 * rib_offset)
    .extrude(thickness)
)
result = result.union(rib)

# Weight‑reduction pocket on the inner face using a Sketch
pocket_sketch = cq.Sketch().rect(pocket_rect_width, pocket_rect_height)
result = (
    result.faces("<Y")
    .workplane()
    .placeSketch(pocket_sketch)
    .cutBlind(pocket_depth_inner)
)
