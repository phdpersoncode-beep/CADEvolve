
import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_width, 0)
            .lineTo(m.leg_width, m.vertical_leg_length)
            .lineTo(m.leg_width + m.horizontal_leg_length, m.vertical_leg_length)
            .lineTo(m.leg_width + m.horizontal_leg_length, m.vertical_leg_length + m.leg_width)
            .lineTo(0, m.vertical_leg_length + m.leg_width)
            .close()
        )
        base = (
            profile.extrude(m.flange_thickness)
            .edges("|Z")
            .fillet(m.interior_fillet_radius)
        )
        with_hole = (
            base.faces(">Y[0]")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.leg_width/2, m.vertical_leg_length - m.hole_from_top)
            .hole(m.hole_diameter)
        )
        with_pocket = (
            with_hole.faces("<Z")
            .workplane(centerOption="CenterOfBoundBox")
            .center(m.leg_width/2, m.pocket_offset)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(m.pocket_depth)
        )
        interior_block = (
            with_pocket.faces(">Z")
            .workplane()
            .center(m.leg_width/2, m.vertical_leg_length/2)
            .rect(m.interior_block_width, m.interior_block_height)
            .extrude(-m.flange_thickness)
        )
        unified = with_pocket.union(interior_block)
        vertical_holes = (
            unified.faces("<Y[0]")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints([
                (m.leg_width/2, m.vertical_leg_length*0.3),
                (m.leg_width/2, m.vertical_leg_length*0.7),
            ])
            .hole(m.mount_hole_diameter)
        )
        final = (
            vertical_holes.faces(">X[0]")
            .workplane(centerOption="CenterOfBoundBox")
            .pushPoints([
                (m.horizontal_leg_length*0.3, m.leg_width/2),
                (m.horizontal_leg_length*0.7, m.leg_width/2),
            ])
            .hole(m.mount_hole_diameter)
        )
        self.model = final

measures = Measures(
    leg_width=20.0,
    vertical_leg_length=70.0,
    horizontal_leg_length=50.0,
    flange_thickness=4.0,
    hole_diameter=6.0,
    hole_from_top=15.0,
    interior_fillet_radius=1.5,
    pocket_width=10.0,
    pocket_height=8.0,
    pocket_depth=2.0,
    pocket_offset=12.0,
    interior_block_width=12.0,
    interior_block_height=12.0,
    mount_hole_diameter=4.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
