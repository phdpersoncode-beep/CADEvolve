import cadquery as cq

outer_diameter = 60
inner_diameter = 30
height = 40
wall_thickness = 4
relief_hole_diameter = 4
relief_hole_offset = 20
chamfer_depth = 1

def firstSolid(self):
    return self.newObject([self.findSolid()])

cq.Workplane.firstSolid = firstSolid

profile = (
    cq.Workplane("XZ")
    .polyline([
        (inner_diameter/2, 0),
        (outer_diameter/2, 0),
        (outer_diameter/2, height),
        (inner_diameter/2, height),
        (inner_diameter/2, 0)
    ])
    .close()
)

housing = (
    profile
    .revolve(360)
    .shell(-wall_thickness)
    .faces(">Z")
    .workplane()
    .tag("top_face")
    .firstSolid()
    .faces(">Z")
    .edges()
    .chamfer(chamfer_depth)
    .firstSolid()
    .faces("<Z")
    .edges()
    .chamfer(chamfer_depth)
)

result = (
    housing
    .workplaneFromTagged("top_face")
    .center(relief_hole_offset, 0)
    .hole(relief_hole_diameter)
)
