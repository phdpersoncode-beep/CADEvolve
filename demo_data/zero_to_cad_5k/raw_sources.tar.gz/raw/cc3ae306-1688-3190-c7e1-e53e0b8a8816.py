import cadquery as cq

panel_width = 80.0
panel_height = 60.0
panel_thickness = 4.0
corner_chamfer = 2.0
hole_diameter = 5.2
hole_spacing = 10.0
hole_count = 6
hole_start_x = - (hole_count - 1) * hole_spacing / 2
hole_start_y = -20.0
slot_width = 30.0
slot_height = 12.0
rib_width = 5.0
rib_height = 20.0
rib_thickness = 2.0
rib_spacing = 20.0
rib_count = 2

base = cq.Workplane("XY").rect(panel_width, panel_height).extrude(panel_thickness)
# T-slot cutout through the panel
base = base.faces("+Z").workplane().center(0, 0).rect(slot_width, slot_height).cutThruAll()
# Chamfer one corner (top right)
base = base.edges(">X and >Y").chamfer(corner_chamfer)
# Linear array of terminal strip holes
base = base.faces("+Z").workplane().center(hole_start_x, hole_start_y).rarray(hole_spacing, 0, hole_count, 1).hole(hole_diameter)
# Add ribs on the back side for stiffness
for i in range(rib_count):
    offset = -panel_width/2 + rib_spacing/2 + i * rib_spacing
    rib = cq.Workplane("XY").rect(rib_width, rib_height).extrude(rib_thickness)
    rib = rib.translate((offset, 0, -rib_thickness))
    base = base.union(rib)

result = base