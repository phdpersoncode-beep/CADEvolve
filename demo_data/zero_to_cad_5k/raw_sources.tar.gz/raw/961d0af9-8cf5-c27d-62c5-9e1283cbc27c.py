import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.long_leg_length, 0),
                (m.long_leg_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.short_leg_length + m.thickness),
                (0, m.short_leg_length + m.thickness),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        base = base.edges("|Z").chamfer(m.chamfer_size)
        hole_x_positions = [m.long_leg_length * 0.25, m.long_leg_length * 0.75]
        for hx in hole_x_positions:
            base = (
                base.faces(">Z")
                .workplane()
                .center(hx, m.bracket_thickness / 2)
                .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
            )
        boss_x = m.thickness / 2
        boss_y = m.thickness + m.short_leg_length / 2
        boss = (
            cq.Workplane("XY")
            .center(boss_x, boss_y)
            .circle(m.boss_diameter / 2)
            .extrude(m.boss_height)
        )
        base = base.union(boss, glue=True)
        self.model = base

measures = Measures(
    long_leg_length=80.0,
    short_leg_length=60.0,
    thickness=8.0,
    bracket_thickness=6.0,
    chamfer_size=3.0,
    hole_diameter=5.0,
    cbore_diameter=7.5,
    cbore_depth=2.0,
    boss_diameter=12.0,
    boss_height=4.0,
)

result = LBracket(cq.Workplane("XY"), measures).model