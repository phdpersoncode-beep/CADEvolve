import cadquery as cq

base_length = 80.0
base_width = 50.0
base_thickness = 12.0
wall_thickness = 2.0
rib_height = 6.0
rib_thickness = 4.0
chamfer_size = 1.0
mount_hole_diameter = 5.0
mount_hole_spacing = 30.0
mount_hole_offset_y = 15.0
circular_cutout_diameter = 12.0

class RearViewMirrorMount:
    def __init__(self):
        self.base_length = base_length
        self.base_width = base_width
        self.base_thickness = base_thickness
        self.wall_thickness = wall_thickness
        self.rib_height = rib_height
        self.rib_thickness = rib_thickness
        self.chamfer_size = chamfer_size
        self.mount_hole_diameter = mount_hole_diameter
        self.mount_hole_spacing = mount_hole_spacing
        self.mount_hole_offset_y = mount_hole_offset_y
        self.circular_cutout_diameter = circular_cutout_diameter
    def build(self):
        # Create base rectangular plate
        rect_plate = (
            cq.Workplane("XY")
            .rect(self.base_length, self.base_width - 20)
            .extrude(self.base_thickness)
        )
        # Add rounded top by union with a cylinder
        top_cylinder = (
            cq.Workplane("XY")
            .center(0, (self.base_width - 20) / 2)
            .circle(self.base_length / 2)
            .extrude(self.base_thickness)
        )
        solid = rect_plate.union(top_cylinder)
        # Create central circular cutout for mirror pole
        cutout = (
            cq.Workplane("XY")
            .circle(self.circular_cutout_diameter / 2)
            .extrude(self.base_thickness + 2)
        )
        solid = solid.cut(cutout)
        # Shell the solid leaving bottom face solid
        shell = solid.faces("-Z").shell(self.wall_thickness)
        # Add ribs on both side walls
        rib_profile = (
            cq.Workplane("YZ")
            .rect(self.rib_thickness, self.rib_height)
            .extrude(self.wall_thickness + 0.5)
        )
        ribs_left = (
            shell.faces("<X")
            .workplane(offset=self.wall_thickness)
            .add(rib_profile)
        )
        ribs_right = (
            shell.faces(">X")
            .workplane(offset=self.wall_thickness)
            .add(rib_profile)
        )
        with_ribs = ribs_left.union(ribs_right)
        # Add mounting holes on bottom face
        bottom = with_ribs.faces("-Z").workplane()
        hole_positions = [(-self.mount_hole_spacing/2, -self.base_width/2 + self.mount_hole_offset_y),
                          (self.mount_hole_spacing/2, -self.base_width/2 + self.mount_hole_offset_y)]
        for x, y in hole_positions:
            bottom = bottom.pushPoints([(x, y)]).hole(self.mount_hole_diameter)
        # Apply chamfer to outer edges
        final = bottom.edges("|Z").chamfer(self.chamfer_size)
        return final

result = RearViewMirrorMount().build()
