import cadquery as cq
leaf_length=80.0
leaf_width=30.0
leaf_thickness=5.0
clearance_dia=10.0
profile=cq.Sketch().rect(leaf_length,leaf_width).circle(clearance_dia/2,mode='s')
result=cq.Workplane('XY').placeSketch(profile).extrude(leaf_thickness)