import cadquery as cq
from types import SimpleNamespace as Measures

vertical_leg_length = 80.0
horizontal_leg_length = 70.0
leg_thickness = 15.0
leg_width_z = 10.0
chamfer_distance = 1.0
hole_diameter = 5.0
blind_depth = 6.0
hole_edge_clearance = 5.0
holes_per_row = 3
rows = 2
hole_spacing = (horizontal_leg_length - 2 * hole_edge_clearance) / (holes_per_row - 1)
row_spacing = (leg_thickness - 2 * hole_edge_clearance) / (rows - 1)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        self.model = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.vertical_leg_length),
                (m.leg_thickness, m.vertical_leg_length),
                (m.leg_thickness, m.leg_thickness),
                (m.horizontal_leg_length, m.leg_thickness),
                (m.horizontal_leg_length, 0),
                (0, 0),
            ])
            .close()
            .extrude(m.leg_width_z)
            .edges("|Z")
            .chamfer(m.chamfer_distance)
        )
        # calculate hole positions on inner face of horizontal leg
        start_x = -m.horizontal_leg_length / 2 + m.hole_edge_clearance
        start_y = -m.leg_thickness / 2 + m.hole_edge_clearance
        points = []
        for i in range(3):
            for j in range(2):
                x = start_x + i * m.hole_spacing
                y = start_y + j * m.row_spacing
                points.append((x, y))
        self.model = (
            self.model.faces("<Y")
            .workplane()
            .pushPoints(points)
            .hole(m.hole_diameter, m.blind_depth)
        )

measures = Measures(
    vertical_leg_length=vertical_leg_length,
    horizontal_leg_length=horizontal_leg_length,
    leg_thickness=leg_thickness,
    leg_width_z=leg_width_z,
    chamfer_distance=chamfer_distance,
    hole_diameter=hole_diameter,
    blind_depth=blind_depth,
    hole_edge_clearance=hole_edge_clearance,
    hole_spacing=hole_spacing,
    row_spacing=row_spacing,
)

result = LBracket(cq.Workplane("XY"), measures).model
