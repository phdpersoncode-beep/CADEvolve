import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # base L profile
        profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.outer_width, 0)
            .lineTo(m.outer_width, m.thickness)
            .lineTo(m.thickness, m.thickness)
            .lineTo(m.thickness, m.vert_length + m.thickness)
            .lineTo(0, m.vert_length + m.thickness)
            .close()
            .extrude(m.plate_thickness)
        )
        # mounting holes on horizontal leg
        horizontal = (
            profile.faces("<Z")
            .workplane(offset=m.plate_thickness / 2)
            .center(m.outer_width / 2, -m.thickness / 2)
            .rarray(m.hole_spacing, 0, m.hole_columns, 1)
            .hole(m.hole_diameter)
        )
        # mounting holes on vertical leg
        vertical = (
            horizontal.faces("<Z")
            .workplane(offset=m.plate_thickness / 2)
            .center(-m.thickness / 2, m.vert_length / 2)
            .rarray(0, m.hole_spacing, 1, m.hole_rows)
            .hole(m.hole_diameter)
        )
        # recessed pocket on inner side of vertical leg
        pocket = (
            vertical.faces(">X")
            .workplane()
            .center(m.pocket_offset_x, m.pocket_offset_y)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        # chamfer outer edges
        chamfered = (
            pocket.edges("|Z")
            .chamfer(m.chamfer)
        )
        self.model = chamfered

# Parameter definitions
measures = Measures(
    outer_width=80.0,               # total X dimension
    vert_length=60.0,               # total Y dimension of vertical leg
    thickness=10.0,                 # leg thickness (L shape width)
    plate_thickness=8.0,           # extrusion thickness (Z)
    hole_diameter=4.0,
    hole_spacing=30.0,
    hole_columns=2,
    hole_rows=2,
    pocket_width=12.0,
    pocket_height=30.0,
    pocket_depth=4.0,
    pocket_offset_x=5.0,
    pocket_offset_y=20.0,
    chamfer=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model