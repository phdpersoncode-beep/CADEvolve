import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(chamfer_size=1.0)
shape = cq.Workplane('XY').box(20,20,5)
result = shape.edges('|X').chamfer(m.chamfer_size)
