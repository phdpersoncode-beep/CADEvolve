import cadquery as cq
import math
inner_radius = 20.0
flange_thickness = 10.0
outer_radius_bottom = 40.0
draft_angle_deg = 30.0
draft_angle_rad = math.radians(draft_angle_deg)
outer_radius_top = outer_radius_bottom + flange_thickness * math.tan(draft_angle_rad)
chamfer_distance = 4.0
hole_diameter = 12.0
countersink_diameter = 18.0
countersink_angle = 82.0
hole_radius = (inner_radius + outer_radius_bottom) / 2.0
boss_radius = 8.0
boss_height = 5.0
rib_width = 15.0
rib_thickness = 5.0
flange = (
    cq.Workplane("XZ")
    .polyline([
        (inner_radius, 0),
        (outer_radius_bottom, 0),
        (outer_radius_top, flange_thickness),
        (inner_radius, flange_thickness),
        (inner_radius, 0)
    ])
    .close()
    .revolve()
    .edges(">Z")
    .chamfer(chamfer_distance)
)
boss = (
    cq.Workplane("XY")
    .circle(boss_radius)
    .extrude(boss_height)
)
connector = (
    cq.Workplane("XY")
    .circle(inner_radius)
    .extrude(boss_height)
)
rib = (
    cq.Workplane("XY")
    .rect(rib_width, rib_thickness)
    .extrude(rib_thickness)
)
combined = flange.union(boss).union(connector).union(rib)
combined = (
    combined
    .faces(">Z")
    .workplane()
    .rect(30, 10)
    .cutBlind(-2)
)
result = (
    combined
    .faces(">Z")
    .workplane()
    .polarArray(radius=hole_radius, startAngle=0, angle=360, count=4)
    .cskHole(hole_diameter, flange_thickness, countersink_diameter, countersink_angle)
)
