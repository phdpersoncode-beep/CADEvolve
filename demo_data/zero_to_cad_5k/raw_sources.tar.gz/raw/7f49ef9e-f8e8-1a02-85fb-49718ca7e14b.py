import cadquery as cq
from cadquery import selectors

outer_diameter = 30.0
washer_thickness = 5.0
hole_diameter = 10.0
hole_depth = washer_thickness - 1.0
fillet_radius = 0.25
outer_chamfer = 0.3
rivet_radius = 4.0
rivet_height = 2.0
notch_width = 2.0
notch_height = 1.0
notch_depth = washer_thickness
notch_count = 6
notch_offset_radius = outer_diameter/2 - 3.0

result = (cq.Workplane("XY")
    .circle(outer_diameter/2)
    .extrude(washer_thickness)
)
result = result.faces(">Z").edges().chamfer(outer_chamfer)
result = result.faces(">Z").workplane().hole(hole_diameter, depth=hole_depth)
result = result.faces(">Z").edges().fillet(fillet_radius)
result = (result.faces("<Z")
    .workplane()
    .circle(rivet_radius)
    .extrude(rivet_height)
)
result = (result.faces(">Z")
    .workplane()
    .polarArray(count=notch_count, angle=360, startAngle=0, radius=notch_offset_radius)
    .rect(notch_width, notch_height)
    .cutBlind(notch_depth)
)
