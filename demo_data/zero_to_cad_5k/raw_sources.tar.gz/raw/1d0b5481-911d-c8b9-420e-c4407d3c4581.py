import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.vertical_length),
                (0, m.vertical_length),
                (0, 0)
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        rib = (
            base
            .faces('>Z')
            .workplane()
            .center(m.thickness/2 + m.rib_width/2, m.vertical_length/2)
            .rect(m.rib_width, m.rib_height)
            .extrude(m.rib_thickness)
        )
        pocket = (
            rib
            .faces('>Z')
            .workplane()
            .center(m.pocket_width/2, m.pocket_width/2)
            .rect(m.pocket_width, m.pocket_width)
            .cutBlind(-m.pocket_depth)
        )
        holes = (
            pocket
            .faces('>Z')
            .workplane()
            .pushPoints([
                (m.hole_edge_offset + i * m.hole_spacing, m.thickness/2) for i in range(m.hole_count)
            ])
            .hole(m.hole_diameter)
        )
        result = (
            holes
            .edges('|Z')
            .chamfer(m.chamfer_size)
        )
        self.model = result

cq.Workplane.part = lambda self, part_class, measures: part_class(self, measures).model

measures = Measures(
    horizontal_length=80.0,
    vertical_length=70.0,
    thickness=8.0,
    bracket_thickness=10.0,
    rib_width=12.0,
    rib_height=40.0,
    rib_thickness=4.0,
    pocket_width=20.0,
    pocket_depth=6.0,
    hole_diameter=5.0,
    hole_spacing=25.0,
    hole_edge_offset=15.0,
    hole_count=3,
    chamfer_size=1.0,
)

result = cq.Workplane('XY').part(LBracket, measures)
