import cadquery as cq
import math

plate_flat_to_flat = 80.0
plate_thickness = 8.0
slot_width = 5.0
slot_length = 30.0
boss_diameter = 20.0
boss_height = 10.0
shell_thickness = 2.0
chamfer_size = 1.0
mount_hole_dia = 4.0
mount_pattern_radius = 30.0
mount_pattern_count = 6

plate = cq.Workplane('XY').polygon(6, plate_flat_to_flat).extrude(plate_thickness)
apothem = plate_flat_to_flat / 2.0
for i in range(6):
    angle = i * 60.0
    plate = (plate.faces('>Z')
             .workplane()
             .center(0, apothem)
             .rotate((0, 0, 0), (0, 0, 1), angle)
             .rect(slot_length, slot_width)
             .cutBlind(-plate_thickness))

boss = (cq.Workplane('XY')
        .circle(boss_diameter / 2.0)
        .extrude(boss_height)
        .translate((0, 0, plate_thickness)))

part = plate.union(boss)

hole_positions = [
    (mount_pattern_radius * math.cos(math.radians(i * 360.0 / mount_pattern_count)),
     mount_pattern_radius * math.sin(math.radians(i * 360.0 / mount_pattern_count)))
    for i in range(mount_pattern_count)
]
part = (part.faces('>Z[-2]')
        .workplane()
        .pushPoints(hole_positions)
        .hole(mount_hole_dia))

part = part.edges('|Z').chamfer(chamfer_size)

part = part.faces('>Z[-1]').shell(shell_thickness)

result = part
