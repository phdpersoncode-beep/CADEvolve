import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 6.0
brace_thickness = 4.0
brace_height = 8.0
horizontal_arm_length = 70.0
vertical_arm_length = 50.0
hole_diameter = 3.0
hole_depth = brace_height + 0.5
chamfer_size = 0.5
fillet_base = 1.0

# Base plate
result = (
    cq.Workplane('XY')
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges('|Z').fillet(fillet_base)
    # Move to top face for brace
    .faces('>Z')
    .workplane(offset=0)
    # Horizontal brace
    .center(0, 0)
    .rect(horizontal_arm_length, brace_thickness)
    .extrude(brace_height, combine=False)
    # Vertical brace (union with previous)
    .center(0, 0)
    .rect(brace_thickness, vertical_arm_length)
    .extrude(brace_height, combine=True)
    # Chamfer top edges of brace
    .faces('>Z').edges().chamfer(chamfer_size)
    # Drill holes on horizontal arm (four holes)
    .faces('>Z')
    .workplane(offset=-0.1)
    .pushPoints([
        (-horizontal_arm_length/2 + 10, 0),
        (-horizontal_arm_length/2 + 10, -brace_thickness/2 + 10),
        (horizontal_arm_length/2 - 10, 0),
        (horizontal_arm_length/2 - 10, -brace_thickness/2 + 10)
    ])
    .hole(hole_diameter)
    # Drill holes on vertical arm (four holes)
    .pushPoints([
        (0, -vertical_arm_length/2 + 10),
        (brace_thickness/2 - 10, -vertical_arm_length/2 + 10),
        (0, vertical_arm_length/2 - 10),
        (brace_thickness/2 - 10, vertical_arm_length/2 - 10)
    ])
    .hole(hole_diameter)
)
