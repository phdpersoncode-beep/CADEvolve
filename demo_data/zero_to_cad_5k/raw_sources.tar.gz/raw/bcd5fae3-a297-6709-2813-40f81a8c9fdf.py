import cadquery as cq

# Primary dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 6.0
frame_height = 10.0
frame_wall = 4.0
inner_length = base_length - 2 * frame_wall
inner_width = base_width - 2 * frame_wall
hole_diameter = 4.0
hole_radius = hole_diameter / 2.0
fillet_radius = 2.0

total_thickness = base_thickness + frame_height

# Base plate with outer fillet
base = (
    cq.Workplane('XY')
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .edges('|Z').fillet(fillet_radius)
)

# Raised frame block positioned on top of base
frame = (
    cq.Workplane('XY')
    .box(base_length, base_width, frame_height, centered=(True, True, False))
    .translate((0, 0, base_thickness))
)

# Combine base and frame into a single solid
combined = base.union(frame)

# Create inner recessed pocket to form raised border
combined = (
    combined
    .faces('>Z')
    .workplane()
    .rect(inner_length, inner_width)
    .cutBlind(-frame_height)
)

# Drill five M4 holes through full thickness
result = (
    combined
    .faces('>Z')
    .workplane()
    .pushPoints([
        ( inner_length/2,  inner_width/2),
        (-inner_length/2,  inner_width/2),
        ( inner_length/2, -inner_width/2),
        (-inner_length/2, -inner_width/2),
        (0.0, 0.0),
    ])
    .circle(hole_radius)
    .cutBlind(-total_thickness)
)
