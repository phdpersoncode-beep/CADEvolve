import cadquery as cq

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_a, 0),
                (m.leg_a, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.leg_b),
                (0, m.leg_b),
            ])
            .close()
            .extrude(m.thickness)
        )
        # Pocket in inner corner
        pocket_cut = (
            base.faces(">Z")
            .workplane()
            .moveTo(m.pocket_offset + m.pocket_width / 2, m.pocket_offset + m.pocket_width / 2)
            .rect(m.pocket_width, m.pocket_width)
            .cutBlind(-m.pocket_depth)
        )
        # Slots on outer horizontal leg
        slot_centers = []
        for i in range(4):
            x = (
                m.thickness
                + m.slot_margin
                + i * (m.slot_length + m.slot_spacing)
                + m.slot_length / 2
            )
            y = m.thickness / 2
            slot_centers.append((x, y))
        slots_cut = (
            pocket_cut.faces(">Z")
            .workplane()
            .pushPoints(slot_centers)
            .rect(m.slot_length, m.slot_width)
            .cutBlind(-m.thickness)
        )
        # Chamfer outer edges
        self.model = (
            slots_cut.edges("|Z")
            .chamfer(m.chamfer)
        )

# Define measures
measures = cq.Workplane().transformed().newObject([])  # dummy placeholder

class Measures:
    def __init__(self):
        self.leg_a = 70.0          # Length of horizontal leg
        self.leg_b = 50.0          # Length of vertical leg
        self.thickness = 10.0      # Uniform thickness of legs
        self.pocket_width = 30.0   # Width of square pocket
        self.pocket_depth = 8.0    # Depth of pocket
        self.pocket_offset = 5.0   # Offset of pocket from inner edges
        self.slot_length = 20.0    # Length of each slot (along X)
        self.slot_width = 5.0      # Width of each slot (across thickness)
        self.slot_margin = 10.0    # Margin from inner corner to first slot
        self.slot_spacing = 10.0   # Spacing between slots
        self.chamfer = 1.0         # Chamfer size on outer edges

meas = Measures()
result = LBracket(cq.Workplane("XY"), meas).model
