import cadquery as cq

bracket_length = 80.0
flange_width = 30.0
flange_thickness = 5.0
web_height = 40.0
web_thickness = 4.0
cutout_width = 12.0
cutout_height = 20.0
cutout_depth = 2.0
hole_diameter = 2.0
fillet_radius = 0.5
chamfer_distance = 0.2

half_flange_w = flange_width / 2.0
half_web_h = web_height / 2.0
half_web_t = web_thickness / 2.0

result = (
    cq.Workplane("XY")
    .moveTo(-half_flange_w, -(half_web_h + flange_thickness))
    .lineTo(half_flange_w, -(half_web_h + flange_thickness))
    .lineTo(half_flange_w, -half_web_h)
    .lineTo(half_web_t, -half_web_h)
    .lineTo(half_web_t, half_web_h)
    .lineTo(half_flange_w, half_web_h)
    .lineTo(half_flange_w, half_web_h + flange_thickness)
    .lineTo(-half_flange_w, half_web_h + flange_thickness)
    .lineTo(-half_flange_w, half_web_h)
    .lineTo(-half_web_t, half_web_h)
    .lineTo(-half_web_t, -half_web_h)
    .close()
    .extrude(bracket_length)
    .faces("<Z")
    .workplane()
    .center(0, 0)
    .rect(cutout_width, cutout_height)
    .cutBlind(-cutout_depth)
    .faces(">Z")
    .workplane()
    .hole(hole_diameter)
    .faces(">Z")
    .edges("|X")
    .chamfer(chamfer_distance)
    .edges("|Z")
    .fillet(fillet_radius)
)
