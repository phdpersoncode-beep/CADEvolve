import cadquery as cq

beam_length = 80.0
web_height = 60.0
flange_width = 30.0
flange_thickness = 6.0
web_thickness = 4.0
counterbore_diameter = 10.0
drill_diameter = 5.0
counterbore_depth = 4.0
chamfer_size = 1.0

half_profile = [
    (0, -web_height/2),
    (web_thickness/2, -web_height/2),
    (web_thickness/2, -flange_thickness/2),
    (flange_width, -flange_thickness/2),
    (flange_width, 0),
    (web_thickness/2, 0),
    (web_thickness/2, web_height/2 - flange_thickness),
    (0, web_height/2 - flange_thickness)
]

result = (
    cq.Workplane("XY")
    .polyline(half_profile)
    .mirrorY()
    .extrude(beam_length)
    .faces(">Z")
    .workplane()
    .center(0, web_height/2 - flange_thickness/2)
    .cboreHole(counterbore_diameter, drill_diameter, counterbore_depth)
    .edges("|Z")
    .chamfer(chamfer_size)
)
