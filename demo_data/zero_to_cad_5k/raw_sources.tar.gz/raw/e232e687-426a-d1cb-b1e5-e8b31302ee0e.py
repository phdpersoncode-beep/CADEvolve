import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.wp = workplane
        self.m = measures
        self.build()

    def build(self):
        m = self.m
        l_plate = (
            self.wp.workplane()
            .polyline([
                (0, 0),
                (0, m.leg_vertical),
                (m.thickness, m.leg_vertical),
                (m.thickness, m.thickness),
                (m.leg_horizontal, m.thickness),
                (m.leg_horizontal, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
        )
        gusset = (
            self.wp.workplane()
            .move(m.gusset_size/2, m.gusset_size/2)
            .rect(m.gusset_size, m.gusset_size)
            .extrude(m.thickness)
        )
        combined = l_plate.union(gusset)
        combined = combined.edges("|Z").fillet(m.fillet_radius)
        combined = (
            combined.faces(">Y")
            .workplane()
            .center(0, m.hole_offset)
            .hole(m.hole_diameter)
        )
        self.model = combined

measures = Measures(
    leg_vertical=70.0,
    leg_horizontal=70.0,
    thickness=8.0,
    gusset_size=20.0,
    fillet_radius=3.0,
    hole_diameter=6.0,
    hole_offset=35.0,
)

result = LBracket(cq.Workplane("XY"), measures).model