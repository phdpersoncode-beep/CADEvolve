import cadquery as cq

pyramid_base_radius = 30.0
pyramid_step_height = 10.0
pyramid_step_increment = 5.0
channel_width = 30.0
channel_height = 30.0
channel_length = 60.0
channel_wall_thickness = 4.0
fillet_radius = 2.0
clearance_hole_diameter = 7.0
chamfer_distance = 1.0

profile = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(pyramid_base_radius, 0)
    .lineTo(pyramid_base_radius, pyramid_step_height)
    .lineTo(pyramid_base_radius - pyramid_step_increment, pyramid_step_height)
    .lineTo(pyramid_base_radius - pyramid_step_increment, pyramid_step_height * 2)
    .lineTo(pyramid_base_radius - 2 * pyramid_step_increment, pyramid_step_height * 2)
    .lineTo(pyramid_base_radius - 2 * pyramid_step_increment, pyramid_step_height * 3)
    .lineTo(0, pyramid_step_height * 3)
    .close()
)

pyramid = profile.revolve()
# Position pyramid at the rear of the channel
pyramid = pyramid.translate((-channel_length / 2.0, 0, 0))

channel = (
    cq.Workplane("XY")
    .box(channel_length, channel_width, channel_height, centered=(True, True, False))
    .shell(-channel_wall_thickness)
    .edges(">X and |Z")
    .chamfer(chamfer_distance)
    .edges("|X")
    .fillet(fillet_radius)
)

combined = channel.union(pyramid)

combined = (
    combined.faces(">Y")
    .workplane()
    .center(0, channel_height / 2.0)
    .hole(clearance_hole_diameter)
)

result = combined
