import cadquery as cq
from types import SimpleNamespace as Measures

params = Measures(
    length=80.0,
    width=30.0,
    thickness=5.0,
    edge_fillet=1.0,
    central_hole=Measures(
        diameter=8.0
    ),
    tab=Measures(
        width=12.0,
        height=6.0,
        overlap=1.0,
        tip_chamfer=0.8,
        slot_margin=1.0,
        slot_depth=2.5
    )
)

p = params

base = (
    cq.Workplane("XY")
    .rect(p.length, p.width)
    .extrude(p.thickness)
)

y_offset = p.width/2 - p.tab.height/2 + p.tab.overlap

tab = (
    cq.Workplane("XY")
    .rect(p.tab.width, p.tab.height)
    .extrude(p.thickness)
    .translate((0, y_offset, -p.thickness/2))
)

result = (
    base.union(tab)
    .faces("<Z")
    .workplane()
    .hole(p.central_hole.diameter)
    .edges("(<Y) and |Z")
    .fillet(p.edge_fillet)
    .faces(">Y")
    .edges()
    .chamfer(p.tab.tip_chamfer)
    .faces("<Y")
    .workplane(invert=True)
    .rect(p.tab.width - 2 * p.tab.slot_margin, p.thickness)
    .cutBlind(-p.tab.slot_depth)
)
