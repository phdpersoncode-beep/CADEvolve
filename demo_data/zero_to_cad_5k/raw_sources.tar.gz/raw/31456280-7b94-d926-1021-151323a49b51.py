
import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.horizontal_leg_length),
                (m.thickness, m.horizontal_leg_length),
                (m.thickness, m.thickness),
                (m.vertical_leg_length, m.thickness),
                (m.vertical_leg_length, 0),
                (0, 0)
            ])
            .close()
            .extrude(m.width)
        )
        chamfered = base.edges("|Z").chamfer(m.chamfer_distance)
        drilled = (
            chamfered.faces(">Z")
            .workplane()
            .pushPoints([
                (m.thickness/2, m.horizontal_leg_length/4),
                (m.thickness/2, 3*m.horizontal_leg_length/4)
            ])
            .hole(m.hole_diameter)
        )
        ribbed = (
            drilled.faces(">Z")
            .workplane()
            .center(m.thickness/2, m.vertical_leg_length/2)
            .rect(m.rib_thickness, m.rib_height)
            .extrude(m.rib_extrude)
        )
        pocketed = (
            ribbed.faces(">Z")
            .workplane()
            .center(m.thickness/2, m.vertical_leg_length/2)
            .rect(m.pocket_width, m.pocket_width)
            .cutBlind(-m.pocket_depth)
        )
        self.model = pocketed

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

measures = Measures(
    vertical_leg_length=80.0,
    horizontal_leg_length=60.0,
    thickness=10.0,
    width=12.0,
    chamfer_distance=2.0,
    hole_diameter=5.0,
    pocket_width=30.0,
    pocket_depth=6.0,
    rib_thickness=4.0,
    rib_height=20.0,
    rib_extrude=4.0,
)

result = cq.Workplane("XY").part(LBracket, measures)
