import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        bracket = (
            cq.Workplane("XY")
            .polyline([
                (0, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.height),
                (m.width, m.height),
                (m.width, 0),
                (0, 0),
            ])
            .close()
            .extrude(m.thickness_z)
        )
        # Chamfer only the outer corner vertical edge
        bracket = bracket.edges("|Z and >X and >Y").chamfer(m.chamfer_dist)
        rib = (
            bracket.faces("<Z")
            .workplane()
            .center(m.rib_width/2, m.rib_height/2)
            .rect(m.rib_width, m.rib_height)
            .extrude(-m.rib_depth)
        )
        part = bracket.union(rib)
        part = (
            part.faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.hole_offset_x, m.hole_offset_y1)
            .hole(m.hole_diameter, depth=m.hole_depth)
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.hole_offset_x, m.hole_offset_y2)
            .hole(m.hole_diameter, depth=m.hole_depth)
        )
        self.model = part

measures = Measures(
    width=80.0,
    height=60.0,
    thickness=8.0,
    thickness_z=8.0,
    rib_width=20.0,
    rib_height=20.0,
    rib_depth=5.0,
    hole_diameter=5.0,
    hole_depth=6.0,
    hole_offset_x=4.0,
    hole_offset_y1=20.0,
    hole_offset_y2=40.0,
    chamfer_dist=5.0,
)

result = LBracket(cq.Workplane("XY"), measures).model