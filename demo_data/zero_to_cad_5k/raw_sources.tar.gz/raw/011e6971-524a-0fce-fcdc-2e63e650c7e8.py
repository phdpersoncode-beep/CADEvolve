import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_thickness, 0),
                (m.leg_thickness, m.leg_height),
                (m.leg_thickness + m.foot_length, m.leg_height),
                (m.leg_thickness + m.foot_length, m.leg_height + m.foot_thickness),
                (0, m.leg_height + m.foot_thickness),
                (0, 0),
            ])
            .close()
            .extrude(m.depth)
        )
        chamfered = profile.edges().chamfer(m.chamfer)
        hollow = chamfered.shell(-m.shell_thickness)
        leg_hole_points = [
            (m.leg_thickness / 2, m.leg_height / 2 - m.hole_spacing / 2),
            (m.leg_thickness / 2, m.leg_height / 2 + m.hole_spacing / 2),
        ]
        foot_hole_start_x = m.leg_thickness + m.foot_hole_offset
        foot_hole_points = [
            (foot_hole_start_x + i * m.hole_spacing, m.leg_height + m.foot_thickness / 2)
            for i in range(3)
        ]
        result = (
            hollow
            .faces(">Z")
            .workplane()
            .pushPoints(leg_hole_points)
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
            .pushPoints(foot_hole_points)
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.model = result

measures = Measures(
    leg_height=60.0,
    leg_thickness=10.0,
    foot_length=50.0,
    foot_thickness=10.0,
    depth=12.0,
    hole_diameter=4.0,
    cbore_diameter=6.0,
    cbore_depth=2.0,
    hole_spacing=20.0,
    foot_hole_offset=5.0,
    shell_thickness=3.0,
    chamfer=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model
