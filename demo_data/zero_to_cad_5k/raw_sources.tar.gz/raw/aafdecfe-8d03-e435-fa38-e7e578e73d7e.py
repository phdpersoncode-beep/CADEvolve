import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        r = m.inner_fillet
        profile = (
            cq.Workplane('XY')
            .moveTo(r, 0)
            .lineTo(m.short_leg + m.thickness, 0)
            .lineTo(m.short_leg + m.thickness, m.long_leg + m.thickness)
            .lineTo(0, m.long_leg + m.thickness)
            .lineTo(0, r)
            .threePointArc((0, 0), (r, 0))
            .close()
        )
        solid = profile.extrude(m.thickness)
        hole = (
            solid
            .faces('>X')
            .workplane()
            .center(0, (m.long_leg + m.thickness) / 2 - m.hole_offset)
            .hole(m.clearance_hole_dia)
        )
        result = hole.edges('>X').chamfer(m.edge_chamfer)
        self.model = result

measures = Measures(
    short_leg=40.0,
    long_leg=80.0,
    thickness=12.0,
    clearance_hole_dia=8.0,
    inner_fillet=5.0,
    edge_chamfer=0.5,
    hole_offset=20.0,
)

result = LBracket(cq.Workplane('XY'), measures).model