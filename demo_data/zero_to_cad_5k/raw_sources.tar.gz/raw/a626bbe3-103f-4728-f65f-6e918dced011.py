import cadquery as cq
beam_length = 100.0
overall_width = 80.0
overall_height = 60.0
flange_thickness = 10.0
web_thickness = 8.0
cutout_width = 30.0
cutout_depth = 6.0
cutout_height = flange_thickness
hole_diameter = 5.0
hole_spacing = 40.0
chamfer_size = 1.0
pts = [
    (0, overall_height/2),
    (overall_width/2, overall_height/2),
    (overall_width/2, overall_height/2 - flange_thickness),
    (web_thickness/2, overall_height/2 - flange_thickness),
    (web_thickness/2, -overall_height/2 + flange_thickness),
    (overall_width/2, -overall_height/2 + flange_thickness),
    (overall_width/2, -overall_height/2),
    (0, -overall_height/2)
]
base = cq.Workplane("front").polyline(pts).mirrorY().extrude(beam_length)
result = (
    base
    .faces("<Y").workplane().center(0, -overall_height/2 + flange_thickness/2).rect(cutout_width, cutout_depth).cutBlind(-cutout_height)
    .faces(">Y").workplane().pushPoints([(-hole_spacing/2, 0), (hole_spacing/2, 0)]).hole(hole_diameter)
    .edges().chamfer(chamfer_size)
)
