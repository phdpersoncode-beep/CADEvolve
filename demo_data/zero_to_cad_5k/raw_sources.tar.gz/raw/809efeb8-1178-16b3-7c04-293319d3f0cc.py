import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    block_width=60.0,
    block_depth=12.0,
    block_height=20.0,
    arc_outer_diameter=100.0,
    wall_thickness=2.0,
    outer_fillet_radius=4.0,
    holes=Measures(
        diameter=4.0,
        pattern_rows=2,
        pattern_cols=3,
        row_spacing=15.0,
        col_spacing=20.0,
        offset_y=5.0
    )
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.block_depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.block_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

arc_path = (
    cq.Workplane("XY")
    .radiusArc((m.block_width, 0.0), m.arc_center_radius)
    .wire()
)

base = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.block_depth, m.block_height)
    .sweep(arc_path, transition="round")
    .edges(">Z")
    .fillet(m.outer_fillet_radius)
)

result = base
