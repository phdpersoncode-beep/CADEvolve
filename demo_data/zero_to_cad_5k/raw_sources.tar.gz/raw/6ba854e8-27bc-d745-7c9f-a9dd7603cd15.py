import cadquery as cq
panel_width = 80.0
panel_height = 100.0
panel_thickness = 4.0
tab_width = 40.0
tab_height = 15.0
chamfer_size = 0.8
hole_diameter = 4.5
hole_spacing = 20.0
hole_count = 5
edge_margin = 10.0
countersink_diameter = 6.0
countersink_depth = 2.0
slot_width = 12.0
slot_length = 30.0
rib_width = 6.0
rib_height = 30.0

base_sketch = (
    cq.Workplane("XY")
    .rect(panel_width, panel_height)
    .center(0, panel_height/2 + tab_height/2)
    .rect(tab_width, tab_height)
)
result = base_sketch.extrude(panel_thickness)
# central rib pocket from bottom
result = (
    result.faces("<Z").workplane()
    .center(0, 0)
    .rect(rib_width, rib_height)
    .cutBlind(panel_thickness/2)
)
# side slot cut through entire thickness
result = (
    result.faces(">Z").workplane()
    .center(-panel_width/2 + edge_margin + slot_width/2, 0)
    .rect(slot_width, slot_length)
    .cutThruAll()
)
# linear array of bracket holes centered horizontally
hole_array_center_y = -panel_height/2 + edge_margin + (hole_count-1)*hole_spacing/2
result = (
    result.faces(">Z").workplane()
    .center(0, hole_array_center_y)
    .rarray(0, hole_spacing, 1, hole_count)
    .hole(hole_diameter)
)
# corner mounting countersink holes
result = (
    result.faces("<Z").workplane()
    .rect(panel_width - 2*edge_margin, panel_height - 2*edge_margin)
    .vertices()
    .cboreHole(countersink_diameter, hole_diameter, countersink_depth)
)
# chamfer edges for safety
result = result.edges().chamfer(chamfer_size)
