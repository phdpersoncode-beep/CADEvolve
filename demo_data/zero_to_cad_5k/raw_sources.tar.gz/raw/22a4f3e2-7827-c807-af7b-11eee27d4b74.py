import cadquery as cq
import math
flange_size = 60
flange_thickness = 8
rib_width = 20
rib_height = 30
chamfer_dist = 3
hole_diameter = 6
countersink_angle = 82
hole_offset = 10
slot_length = 30
slot_width = 8
slot_depth = 4
cross_width = 20
cross_depth = 6
countersink_depth = (hole_diameter / 2) / math.tan(math.radians(countersink_angle / 2))
profile_points = [
    (-flange_size / 2, -flange_size / 2),
    (flange_size / 2, -flange_size / 2),
    (flange_size / 2, flange_size / 2 - rib_height),
    (flange_size / 2 + rib_width, flange_size / 2 - rib_height),
    (flange_size / 2 + rib_width, flange_size / 2),
    (-flange_size / 2, flange_size / 2),
]
result = (
    cq.Workplane("XY")
    .polyline(profile_points)
    .close()
    .extrude(flange_thickness)
    .edges("|Z")
    .chamfer(chamfer_dist)
)
positions = [
    (hole_offset, hole_offset),
    (-hole_offset, hole_offset),
    (-hole_offset, -hole_offset),
    (hole_offset, -hole_offset),
]
result = (
    result
    .faces(">Z")
    .workplane()
    .pushPoints(positions)
    .cskHole(hole_diameter, countersink_depth, countersink_angle)
)
result = (
    result
    .faces(">Z")
    .workplane()
    .center(flange_size / 2 + rib_width / 2, 0)
    .rect(slot_length, slot_width)
    .cutBlind(-slot_depth)
)
result = (
    result
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(cross_width, cross_width)
    .cutBlind(-cross_depth)
)
