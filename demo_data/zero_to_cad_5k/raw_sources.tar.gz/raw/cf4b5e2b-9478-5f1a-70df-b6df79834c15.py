import cadquery as cq
leaf_length = 80
leaf_width = 30
leaf_thickness = 4
central_hole_diameter = 10
central_hole_depth = leaf_thickness - 0.5
edge_chamfer = 0.5
mount_hole_diameter = 5
mount_hole_offset = 8
rib_height = 1.5
rib_width = 6
rib_spacing = 12
rib_count = 3
# base leaf
leaf = cq.Workplane("XY").rect(leaf_length, leaf_width).extrude(leaf_thickness)
leaf = leaf.edges("|Z").chamfer(edge_chamfer)
# central blind hole
leaf = leaf.faces(">Z").workplane().hole(central_hole_diameter, depth=central_hole_depth)
# mounting holes (through)
mount_points = [(-leaf_length/2 + mount_hole_offset, 0), (leaf_length/2 - mount_hole_offset, 0)]
leaf = leaf.faces(">Z").workplane().pushPoints(mount_points).hole(mount_hole_diameter)
# ribs on opposite face
rib_positions = []
start = -leaf_length/2 + mount_hole_offset + rib_spacing/2 + rib_width/2
for i in range(rib_count):
    rib_positions.append(start + i*(rib_width + rib_spacing))
leaf = leaf.faces("<Z").workplane().pushPoints([(x, 0) for x in rib_positions]).rect(rib_width, leaf_width - 2*edge_chamfer).extrude(rib_height)
result = leaf