
import cadquery as cq

# Parameters
base_width = 80.0
base_height = 40.0
base_thickness = 6.0
base_chamfer = 0.5

tab_width = 30.0
tab_height = 20.0
tab_thickness = base_thickness
tab_step = 5.0
tab_fillet = 0.8

hole_diameter = 8.0

# Helper function to create a tab with a step profile and a through hole

def make_tab():
    points = [
        (0, 0),
        (tab_width, 0),
        (tab_width, tab_height),
        (tab_width - tab_step, tab_height),
        (tab_width - tab_step, tab_step),
        (0, tab_step),
        (0, 0),
    ]
    tab = (
        cq.Workplane("XY")
        .polyline(points)
        .close()
        .extrude(tab_thickness)
        .edges("|Z")
        .fillet(tab_fillet)
    )
    tab = (
        tab.faces(">Z")
        .workplane()
        .center(tab_width / 2, (tab_height + tab_step) / 2)
        .hole(hole_diameter)
    )
    return tab

# Base plate with chamfer applied before adding tabs
base = (
    cq.Workplane("XY")
    .rect(base_width, base_height)
    .extrude(base_thickness)
    .edges("|Z")
    .chamfer(base_chamfer)
)

left_tab = make_tab().translate((-base_width / 2 - tab_width, 0, 0))
right_tab = make_tab().translate((base_width / 2, 0, 0))

result = base.union(left_tab).union(right_tab)
