import cadquery as cq
import math

body_diameter = 70
body_length = 80
wall_thickness = 5
flange_diameter = 90
flange_thickness = 10
inlet_diameter = 30
outlet_diameter = 30
relief_seat_angle_deg = 45
relief_seat_height = 12
vent_hole_diameter = 10
vent_hole_offset = 20
mount_chamfer = 2
rib_width = 4
rib_height = 6
rib_thickness = 3
rib_spacing = 20

body = cq.Workplane('XY').circle(body_diameter/2).extrude(body_length)
flange = cq.Workplane('XY').circle(flange_diameter/2).extrude(flange_thickness).translate((0,0,body_length))
solid = body.union(flange)
inner_radius = (body_diameter/2) - wall_thickness
inner_cyl = cq.Workplane('XY').circle(inner_radius).extrude(body_length+flange_thickness)
solid = solid.cut(inner_cyl)
inlet = cq.Workplane('XY').circle(inlet_diameter/2).extrude(-20)
solid = solid.cut(inlet)
outlet = cq.Workplane('XY').circle(outlet_diameter/2).extrude(flange_thickness+10).translate((0,0,body_length+flange_thickness))
solid = solid.cut(outlet)
inner_wall_radius = inner_radius
angle_rad = math.radians(relief_seat_angle_deg)
seat_top_radius = inner_wall_radius - (relief_seat_height * math.tan(angle_rad))
if seat_top_radius < 0:
    seat_top_radius = 0.1
cone = cq.Workplane('XY').circle(inner_wall_radius).workplane(offset=body_length - relief_seat_height).circle(seat_top_radius).loft()
solid = solid.cut(cone)
vent = cq.Workplane('XY').center(body_diameter/2 - wall_thickness/2, vent_hole_offset).circle(vent_hole_diameter/2).extrude(body_length+flange_thickness)
solid = solid.cut(vent)
num_ribs = int(body_length // rib_spacing)
for i in range(num_ribs):
    z_pos = i * rib_spacing + rib_height/2
    angle = (360 / num_ribs) * i
    rib = (
        cq.Workplane('XY')
        .center(body_diameter/2 - wall_thickness - rib_thickness/2, 0)
        .rect(rib_width, rib_height)
        .extrude(rib_thickness)
        .rotate((0,0,0), (0,0,1), angle)
        .translate((0,0,z_pos))
    )
    solid = solid.union(rib)
result = solid
