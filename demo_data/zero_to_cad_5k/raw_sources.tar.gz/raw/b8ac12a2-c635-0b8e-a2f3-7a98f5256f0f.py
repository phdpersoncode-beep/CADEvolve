import cadquery as cq

chute_length = 50.0
apex_radius = 5.0
outer_radius = 15.0
lip_extension = 12.0
lip_height = 4.0
fillet_radius = 1.0
hole_diameter = 6.0
counterbore_diameter = 10.0
counterbore_depth = 3.0
hole_offset = 8.0

outer_profile = (
    cq.Workplane("XZ")
    .moveTo(apex_radius, 0)
    .lineTo(outer_radius, 0)
    .lineTo(outer_radius, chute_length + lip_height)
    .lineTo(apex_radius + lip_extension, chute_length + lip_height)
    .lineTo(apex_radius, chute_length + lip_height)
    .close()
)

outer_solid = outer_profile.revolve()

inner_profile = (
    cq.Workplane("XZ")
    .moveTo(apex_radius, 0)
    .lineTo(apex_radius, chute_length)
    .lineTo(apex_radius + lip_extension, chute_length)
    .lineTo(apex_radius + lip_extension, chute_length + lip_height)
    .lineTo(apex_radius, chute_length + lip_height)
    .close()
)

inner_solid = inner_profile.revolve()

hollow = outer_solid.cut(inner_solid)

lip_fillet = hollow.faces(">Z").edges().fillet(fillet_radius)

result = (
    lip_fillet
    .faces(">Z")
    .workplane()
    .center(hole_offset, 0)
    .cboreHole(hole_diameter, counterbore_diameter, counterbore_depth)
)
