import cadquery as cq

leg_height = 80.0
leg_thickness = 5.0
leg_width = 30.0
web_radius = leg_height/2
web_thickness = 6.0
rib_thickness = 3.0
rib_height = 12.0
rib_spacing = 20.0
hole_diameter = 4.0
hole_offset = 10.0
chamfer_dist = 0.8

leg_offset = leg_thickness/2
left_leg = (cq.Workplane('XY')
    .box(leg_thickness, leg_height, leg_width)
    .translate((-leg_offset, 0, 0)))
right_leg = (cq.Workplane('XY')
    .box(leg_thickness, leg_height, leg_width)
    .translate((leg_offset, 0, 0)))

profile = cq.Workplane('XY').rect(web_thickness, leg_thickness)
path = (cq.Workplane('XY')
    .moveTo(web_radius, leg_height/2)
    .threePointArc((0, 0), (web_radius, -leg_height/2))
    .wire())
web = profile.sweep(path)

bracket = left_leg.union(right_leg).union(web)

rib_count = int((leg_height - rib_spacing) // rib_spacing)
for i in range(rib_count):
    y_pos = -leg_height/2 + rib_spacing + i * rib_spacing
    rib = (cq.Workplane('XY')
        .center(0, y_pos)
        .rect(rib_thickness, rib_height)
        .extrude(leg_width))
    bracket = bracket.union(rib)

hole_positions = [
    (-leg_offset + hole_offset, leg_height/4),
    (-leg_offset + hole_offset, -leg_height/4),
    ( leg_offset - hole_offset, leg_height/4),
    ( leg_offset - hole_offset, -leg_height/4)
]
bracket = bracket.faces('>Z').workplane().pushPoints(hole_positions).hole(hole_diameter)

bracket = bracket.edges('|Z').chamfer(chamfer_dist)

result = bracket