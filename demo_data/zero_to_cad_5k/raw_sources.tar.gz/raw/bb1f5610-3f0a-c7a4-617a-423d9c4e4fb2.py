import cadquery as cq

# Dimensions
base_length = 80.0
base_width = 60.0
base_thickness = 5.0
base_shell_thickness = 1.0
frame_outer_length = 70.0
frame_outer_width = 50.0
frame_height = 10.0
frame_wall = 4.0
frame_inner_length = frame_outer_length - 2 * frame_wall
frame_inner_width = frame_outer_width - 2 * frame_wall
countersink_diameter = 6.0
countersink_csk_diam = 10.0
countersink_angle = 82.0
hole_depth = base_thickness + frame_height
fillet_radius = 1.0

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thickness, centered=(True, True, False))
    .shell(-base_shell_thickness)
    .faces(">Z")
    .workplane()
    .rect(frame_outer_length, frame_outer_width)
    .extrude(frame_height, combine=True)
    .faces(">Z")
    .workplane()
    .rect(frame_inner_length, frame_inner_width)
    .cutBlind(-frame_height)
    .faces(">Z")
    .edges()
    .fillet(fillet_radius)
    .faces(">Z")
    .workplane()
    .pushPoints([
        ( frame_outer_length/2 - frame_wall/2,  frame_outer_width/2 - frame_wall/2),
        (-frame_outer_length/2 + frame_wall/2,  frame_outer_width/2 - frame_wall/2),
        (-frame_outer_length/2 + frame_wall/2, -frame_outer_width/2 + frame_wall/2),
        ( frame_outer_length/2 - frame_wall/2, -frame_outer_width/2 + frame_wall/2),
        (0, 0)
    ])
    .cskHole(countersink_diameter, countersink_csk_diam, countersink_angle, depth=hole_depth)
)
