import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    outer_diameter=80.0,
    inner_diameter=68.0,
    cap_height=20.0,
    rim_height=4.0,
    snap_thickness=2.0,
    snap_depth=1.5,
    chamfer=0.8,
    screw_diameter=4.0,
    countersink_diameter=7.0,
    countersink_angle=82.0,
)
outer_radius = 0.5 * m.outer_diameter
inner_radius = 0.5 * m.inner_diameter
height = m.cap_height
rim_h = m.rim_height
snap_t = m.snap_thickness
snap_d = m.snap_depth

profile = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(inner_radius, 0)
    .lineTo(inner_radius, height - rim_h)
    .lineTo(outer_radius, height - rim_h)
    .lineTo(outer_radius, height)
    .lineTo(outer_radius + snap_t, height)
    .lineTo(outer_radius + snap_t, height - snap_d)
    .lineTo(outer_radius, height - snap_d)
    .lineTo(outer_radius, rim_h)
    .lineTo(inner_radius, rim_h)
    .close()
    .revolve()
)

result = (
    profile
    .faces(">Z").edges().chamfer(m.chamfer)
    .faces(">Z").workplane()
    .cskHole(m.screw_diameter, m.countersink_diameter, m.countersink_angle)
)
