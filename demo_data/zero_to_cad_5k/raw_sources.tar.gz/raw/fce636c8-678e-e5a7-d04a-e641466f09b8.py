import cadquery as cq
from types import SimpleNamespace as Measures

vertical_leg_length = 70.0
horizontal_leg_length = 55.0
bracket_thickness = 10.0
hole_diameter = 8.0
counterbore_diameter = 12.0
counterbore_depth = 5.0
rear_shoulder_length = 20.0
rear_shoulder_thickness = 12.0
chamfer_size = 1.0

class LBracket:
    def __init__(self, wp, measures):
        self.model = wp
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        l_profile = (
            cq.Workplane("XY")
            .lineTo(0, m.vertical_leg_length)
            .lineTo(m.bracket_thickness, m.vertical_leg_length)
            .lineTo(m.bracket_thickness, m.bracket_thickness)
            .lineTo(m.horizontal_leg_length + m.bracket_thickness, m.bracket_thickness)
            .lineTo(m.horizontal_leg_length + m.bracket_thickness, 0)
            .close()
        )
        base = l_profile.extrude(m.bracket_thickness)
        shoulder = (
            cq.Workplane("XY")
            .box(m.rear_shoulder_thickness, m.rear_shoulder_length, m.bracket_thickness)
            .translate((-(m.rear_shoulder_thickness/2),
                        m.vertical_leg_length - m.rear_shoulder_length/2,
                        m.bracket_thickness/2))
        )
        solid = base.union(shoulder)
        # First hole
        solid = solid.faces(">Y")[0].workplane().move(0, -m.vertical_leg_length/3).cboreHole(
            m.hole_diameter, m.counterbore_diameter, m.counterbore_depth)
        # Second hole
        solid = solid.faces(">Y")[0].workplane().move(0, 2*m.vertical_leg_length/3).cboreHole(
            m.hole_diameter, m.counterbore_diameter, m.counterbore_depth)
        # Chamfer outer edges
        result = solid.edges("<Z or >X or >Y").chamfer(m.chamfer_size)
        self.model = result

measures = Measures(
    vertical_leg_length=vertical_leg_length,
    horizontal_leg_length=horizontal_leg_length,
    bracket_thickness=bracket_thickness,
    hole_diameter=hole_diameter,
    counterbore_diameter=counterbore_diameter,
    counterbore_depth=counterbore_depth,
    rear_shoulder_length=rear_shoulder_length,
    rear_shoulder_thickness=rear_shoulder_thickness,
    chamfer_size=chamfer_size,
)

part = LBracket(cq.Workplane("XY"), measures)
result = part.model
