import cadquery as cq

gear_outer_dia = 80.0
gear_inner_dia = 30.0
gear_length = 40.0
boss_dia = 30.0
boss_height = 10.0
set_screw_dia = 4.0
set_screw_counterbore_dia = 8.0
set_screw_depth = 5.0
tooth_pitch = 5.0
tooth_height = 6.0
tooth_width = 4.0
chamfer_size = 1.0
slot_width = 6.0
slot_length = 30.0
slot_offset = 10.0
slot_depth = gear_length * 0.5

result = cq.Workplane('XY')
result = result.circle(gear_outer_dia/2).extrude(gear_length)
result = result.faces('>Z').workplane().circle(boss_dia/2).extrude(boss_height)
result = result.faces('>Z').workplane().cskHole(set_screw_dia, set_screw_depth, set_screw_counterbore_dia)
result = result.faces('<Z').workplane().hole(gear_inner_dia)
slot = cq.Workplane('XY')
slot = slot.rect(slot_width, slot_length).extrude(slot_depth)
slot = slot.translate((0, slot_offset, (gear_length - slot_depth)/2))
result = result.cut(slot)
profile = cq.Workplane('XZ').rect(tooth_width, tooth_height).translate((gear_outer_dia/2 - tooth_height/2, 0, 0))
helix_path = cq.Wire.makeHelix(pitch=tooth_pitch, height=gear_length, radius=gear_outer_dia/2 - tooth_height/2)
cut_solid = profile.sweep(helix_path)
result = result.cut(cut_solid)
result = result.edges('>Z').chamfer(chamfer_size)
