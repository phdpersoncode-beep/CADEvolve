import cadquery as cq

outer_diameter = 60.0
inner_radius = 5.0
body_height = 15.0
ridge_diameter = 20.0
ridge_height = 5.0
hole_diameter = 5.0
hole_depth = 8.0
hole_count = 12
hole_radius_offset = (outer_diameter / 2) - 5.0
bottom_chamfer = 0.5
top_chamfer = 0.2


def firstSolid(self):
    return self.newObject([self.findSolid()])

cq.Workplane.firstSolid = firstSolid

profile = (
    cq.Workplane("XZ")
    .moveTo(inner_radius, 0)
    .lineTo(outer_diameter / 2, 0)
    .lineTo(outer_diameter / 2, body_height)
    .lineTo(inner_radius, body_height)
    .close()
)

base = profile.revolve()

base_with_holes = (
    base
    .faces(">Z")
    .workplane()
    .polarArray(radius=hole_radius_offset, startAngle=0, angle=360, count=hole_count)
    .circle(hole_diameter / 2)
    .cutBlind(-hole_depth)
)

ridge_added = (
    base_with_holes
    .faces(">Z")
    .workplane()
    .circle(ridge_diameter / 2)
    .extrude(ridge_height)
)

result = (
    ridge_added
    .faces("<Z")
    .chamfer(bottom_chamfer)
    .edges()
    .chamfer(top_chamfer)
)
