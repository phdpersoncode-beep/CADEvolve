import cadquery as cq
from math import sin, cos, radians

base_width = 80.0
base_depth = 30.0
base_height = 4.0
base_corner_radius = 6.0
mount_hole_diameter = 5.0
mount_hole_spacing = 50.0
shell_cut_radius = 10.0
shell_cut_depth = 2.0
arm_wall_thickness = 2.0
arm_height = 12.0
arm_sweep_radius = 15.0
arm_sweep_angle = 60.0
arm_fillet_radius = 0.8
arm_chamfer = 0.5


def arm_sweep_path(radius, angle_deg):
    start_angle = -angle_deg/2
    end_angle = angle_deg/2
    start = [cos(radians(start_angle))*radius, sin(radians(start_angle))*radius]
    end = [cos(radians(end_angle))*radius, sin(radians(end_angle))*radius]
    mid = [cos(radians(0))*radius, sin(radians(0))*radius]
    path = (
        cq.Workplane('XY')
        .moveTo(*start)
        .threePointArc(mid, end)
        .wire()
    )
    return path, start

arm_path, arm_start = arm_sweep_path(arm_sweep_radius, arm_sweep_angle)

# Base plate with rounded corners
base = (
    cq.Workplane('XY')
    .rect(base_width, base_depth)
    .extrude(base_height)
    .edges('|Z')
    .fillet(base_corner_radius)
)

# Shell cut pocket on side of base
base = (
    base
    .faces('>Z')
    .workplane()
    .center(base_width/2 - shell_cut_radius - 5, 0)
    .circle(shell_cut_radius)
    .cutBlind(shell_cut_depth)
)

# Mounting holes through base
base = (
    base
    .faces('>Z')
    .workplane(offset=base_height)
    .pushPoints([(-mount_hole_spacing/2, 0), (mount_hole_spacing/2, 0)])
    .hole(mount_hole_diameter)
)

# Arm sweep
arm = (
    cq.Workplane('XY')
    .center(*arm_start)
    .transformed(rotate=(90, 0, 0))
    .rect(arm_wall_thickness, arm_height)
    .sweep(arm_path, transition='round')
    .edges('>Z')
    .fillet(arm_fillet_radius)
    .edges('<<Z')
    .chamfer(arm_chamfer)
)

result = base.union(arm)
