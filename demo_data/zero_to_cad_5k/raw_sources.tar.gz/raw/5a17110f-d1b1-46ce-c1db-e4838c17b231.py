import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_arm_length, 0),
                (m.horizontal_arm_length, m.arm_thickness),
                (m.arm_thickness, m.arm_thickness),
                (m.arm_thickness, m.vertical_arm_length),
                (0, m.vertical_arm_length),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        base = base.edges("|Z").chamfer(m.chamfer_size)
        hole_spacing = (m.horizontal_arm_length - 2 * m.edge_clearance - m.hole_diameter) / 5
        hole_start = m.edge_clearance + m.hole_diameter / 2
        hole_positions = [
            (hole_start + i * hole_spacing, m.arm_thickness / 2) for i in range(6)
        ]
        base = (
            base.faces(">Z")
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        self.model = base

measures = Measures(
    horizontal_arm_length=70.0,
    vertical_arm_length=50.0,
    arm_thickness=8.0,
    bracket_thickness=10.0,
    edge_clearance=5.0,
    chamfer_size=3.0,
    hole_diameter=5.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
