import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width = 60.0,
    depth = 12.0,
    height = 20.0,
    arc_outer_diameter = 100.0,
    side_chamfer = 0.8,
    top_chamfer = 1.0,
    cutout_width = 20.0,
    cutout_height = 10.0,
    cutout_offset_x = 0.0,
    cutout_offset_y = 0.0,
    cutout_depth = 12.0,
    sensor_hole_diameter = 6.0,
    sensor_hole_depth = 5.0,
    sensor_hole_offset_x = 0.0,
    sensor_hole_offset_y = 5.0
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

result = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.side_chamfer)
    .edges(">Z")
    .chamfer(m.top_chamfer)
    .faces(">Z")
    .workplane()
    .center(m.cutout_offset_x, m.cutout_offset_y)
    .rect(m.cutout_width, m.cutout_height)
    .cutBlind(m.cutout_depth)
    .faces(">Z")
    .workplane()
    .center(m.sensor_hole_offset_x, m.sensor_hole_offset_y)
    .hole(m.sensor_hole_diameter, depth=m.sensor_hole_depth)
)
