import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width=60.0,
    depth=12.0,
    height=12.0,
    arc_outer_diameter=100.0,
    clearance_radius=15.0,
    clearance_depth=8.0,
    inner_fillet=2.0,
    chamfer_size=1.0,
    top_hole_diameter=5.0,
    top_hole_depth=6.0,
    top_hole_offset=15.0,
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_inner_radius = m.arc_outer_radius - m.depth
m.arc_center_radius = m.arc_inner_radius + 0.5 * m.depth
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

base = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .sweep(path, transition="round")
    .edges("|Z")
    .chamfer(m.chamfer_size)
    .faces("<X")
    .edges(">Z")
    .fillet(m.inner_fillet)
)

pocket = (
    base.faces(">Z")
    .workplane()
    .center(0, 0)
    .circle(m.clearance_radius)
    .cutBlind(m.clearance_depth)
)

result = (
    pocket
    .faces(">Z")
    .workplane()
    .center(-m.top_hole_offset, 0)
    .cboreHole(m.top_hole_diameter, m.top_hole_diameter*1.5, m.top_hole_depth)
    .center(2*m.top_hole_offset, 0)
    .cboreHole(m.top_hole_diameter, m.top_hole_diameter*1.5, m.top_hole_depth)
)
