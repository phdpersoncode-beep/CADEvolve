import cadquery as cq

outer_diameter = 80.0
length = 60.0
wall_thickness = 4.0
inlet_diameter = 20.0
outlet_diameter = 25.0
inlet_offset = 30.0
outlet_offset = -30.0
channel_width = 6.0
channel_height = 8.0
num_channels = 3
channel_spacing = 10.0
sensor_boss_diameter = 15.0
sensor_boss_height = 8.0
sensor_hole_diameter = 5.0
mount_hole_diameter = 5.0
mount_pattern_radius = 25.0
chamfer_size = 2.0

# Create outer solid
body = cq.Workplane("XY").circle(outer_diameter/2).extrude(length)
# Shell to create wall thickness
hollow = body.shell(-wall_thickness)
# Inlet port cut
inlet = (
    cq.Workplane("XY")
    .center(inlet_offset, 0)
    .cylinder(inlet_diameter, length + 2)
)
# Outlet port cut
outlet = (
    cq.Workplane("XY")
    .center(outlet_offset, 0)
    .cylinder(outlet_diameter, length + 2)
)
body_with_ports = hollow.cut(inlet).cut(outlet)
# Internal channels cut on side faces
channel_positions = []
start_y = -((num_channels-1)*channel_spacing)/2
for i in range(num_channels):
    channel_positions.append((0, start_y + i*channel_spacing))
channels = (
    cq.Workplane("XZ")
    .pushPoints(channel_positions)
    .rect(channel_width, channel_height)
    .extrude(length+2)
)
body_with_channels = body_with_ports.cut(channels)
# Sensor boss on top
sensor_boss = (
    body_with_channels.faces(">Z").workplane()
    .circle(sensor_boss_diameter/2)
    .extrude(sensor_boss_height)
)
# Sensor hole through boss
sensor_hole = (
    cq.Workplane("XY")
    .center(0,0)
    .cylinder(sensor_hole_diameter, sensor_boss_height+2)
)
body_with_sensor = sensor_boss.cut(sensor_hole)
# Add mounting holes on top pattern
mount_holes = (
    body_with_sensor.faces(">Z").workplane()
    .polarArray(0, 0, mount_pattern_radius, 4)
    .hole(mount_hole_diameter)
)
# Apply chamfer to outer vertical edges
result = mount_holes.edges("|Z").chamfer(chamfer_size)
