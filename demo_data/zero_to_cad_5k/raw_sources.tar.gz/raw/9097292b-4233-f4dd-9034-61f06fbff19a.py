import cadquery as cq
import math
impeller_diameter = 80.0
impeller_radius = impeller_diameter / 2.0
hub_diameter = 30.0
hub_radius = hub_diameter / 2.0
hub_height = 15.0
body_thickness = 8.0
fillet_radius = 2.0
slot_width = 5.0
slot_length = 10.0
slot_depth = hub_radius + 2.0
shaft_hole_dia = 8.0
mounting_hole_dia = 5.0
mounting_hole_offset = impeller_radius - body_thickness * 0.8
rib_width = 6.0
rib_height = 12.0
rib_thickness = 2.0
profile = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(hub_radius, 0)
    .lineTo(hub_radius, hub_height)
    .threePointArc((hub_radius + fillet_radius, hub_height + fillet_radius), (impeller_radius, hub_height + body_thickness))
    .lineTo(0, hub_height + body_thickness)
    .close()
)
base = profile.revolve()
base = base.faces(">Z").workplane().hole(shaft_hole_dia)
# Side slot cut using a rectangular solid
slot_solid = (
    cq.Workplane("XY")
    .box(slot_depth, slot_width, slot_length)
    .translate((impeller_radius - slot_depth/2, 0, hub_height/2 + body_thickness/2))
)
base = base.cut(slot_solid)
# Mounting holes pattern on top face
hole_positions = []
for angle in [0, 120, 240]:
    rad = math.radians(angle)
    x = mounting_hole_offset * math.cos(rad)
    y = mounting_hole_offset * math.sin(rad)
    hole_positions.append((x, y))
base = (
    base.faces(">Z")
    .workplane()
    .pushPoints(hole_positions)
    .hole(mounting_hole_dia)
)
# Stiffening rib on bottom face, extruded downward
rib = (
    cq.Workplane("XY")
    .rect(rib_width, rib_height)
    .extrude(-rib_thickness)
)
result = base.union(rib)
