import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base_profile = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.long_leg_length, 0),
                (m.long_leg_length, m.thickness),
                (m.thickness, m.thickness),
                (m.thickness, m.short_leg_length),
                (0, m.short_leg_length),
                (0, 0)
            ])
            .close()
            .extrude(m.thickness)
        )
        filleted = base_profile.edges('|Z and <X and <Y').fillet(m.inner_fillet_radius)
        notched = (
            filleted
            .faces('>Z')
            .workplane()
            .center(m.long_leg_length / 2, m.short_leg_length / 2)
            .rect(m.notch_width, m.notch_height)
            .cutBlind(-m.thickness)
        )
        bolt_circle_center_x = m.long_leg_length - m.bolt_circle_offset
        bolt_circle_center_y = m.short_leg_length / 2
        result = (
            notched
            .faces('>Z')
            .workplane()
            .center(bolt_circle_center_x, bolt_circle_center_y)
            .polarArray(radius=m.bolt_circle_radius, count=6, startAngle=0, angle=360)
            .hole(m.bolt_hole_diameter)
        )
        self.result = result

measures = Measures(
    long_leg_length=80.0,
    short_leg_length=60.0,
    thickness=8.0,
    inner_fillet_radius=5.0,
    notch_width=20.0,
    notch_height=10.0,
    bolt_circle_radius=20.0,
    bolt_hole_diameter=5.0,
    bolt_circle_offset=15.0,
)

result = LBracket(cq.Workplane('XY'), measures).result