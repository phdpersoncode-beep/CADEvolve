import cadquery as cq
import math

flange_outer_radius = 45.0
flange_thickness = 10.0
boss_base_radius = 15.0
boss_height = 20.0
draft_angle_deg = 30.0
fillet_radius = 2.0
hole_diameter = 8.5
hole_count = 6
hole_circle_radius = 30.0

draft_angle_rad = math.radians(draft_angle_deg)
boss_top_radius = boss_base_radius + boss_height * math.tan(draft_angle_rad)

result = (cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(flange_outer_radius, 0)
    .lineTo(flange_outer_radius, flange_thickness)
    .lineTo(boss_base_radius, flange_thickness)
    .lineTo(boss_top_radius, flange_thickness + boss_height)
    .lineTo(0, flange_thickness + boss_height)
    .close()
    .revolve(360)
    .faces(">Z")
    .edges()
    .fillet(fillet_radius)
    .faces(">Z")
    .workplane()
    .polarArray(radius=hole_circle_radius, count=hole_count, startAngle=0, angle=360)
    .hole(hole_diameter)
)
