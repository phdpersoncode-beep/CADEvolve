import cadquery as cq

# Parameters
plate_length = 80.0
plate_width = 60.0
plate_thickness = 10.0
hole_diameter = 5.0
hole_offset_x = 30.0
hole_offset_y = 20.0
central_boss_diameter = 12.0
central_boss_height = 5.0
rib_width = 5.0
rib_thickness = 2.0
rib_length = 20.0
rib_offset = 2.0  # distance from plate edge
chamfer_distance = 0.5

# Base plate
base = (
    cq.Workplane("XY")
    .rect(plate_length, plate_width)
    .extrude(plate_thickness)
)

# Mounting holes (four holes, symmetric)
hole_positions = [
    ( hole_offset_x,  hole_offset_y),
    (-hole_offset_x,  hole_offset_y),
    ( hole_offset_x, -hole_offset_y),
    (-hole_offset_x, -hole_offset_y),
]
base = (
    base
    .faces(">Z")
    .workplane()
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)

# Central boss (cylindrical protrusion)
central_boss = (
    cq.Workplane("XY")
    .center(0, 0)
    .circle(central_boss_diameter / 2)
    .extrude(central_boss_height)
)

# Add ribs on top surface (four ribs at each side)
rib = (
    cq.Workplane("XY")
    .rect(rib_length, rib_width)
    .extrude(rib_thickness)
)
# positions for ribs: mid of each edge offset inward
rib_positions = [
    (0, plate_width/2 - rib_offset - rib_width/2),   # front
    (0, -plate_width/2 + rib_offset + rib_width/2), # back
    (plate_length/2 - rib_offset - rib_length/2, 0), # right
    (-plate_length/2 + rib_offset + rib_length/2, 0),# left
]
rib_assemblies = []
for pos in rib_positions:
    r = rib.translate((pos[0], pos[1], plate_thickness))
    rib_assemblies.append(r)

# Combine all features
result = base.union(central_boss)
for r in rib_assemblies:
    result = result.union(r)

# Apply chamfer to all outer vertical edges
result = result.edges("|Z").chamfer(chamfer_distance)
