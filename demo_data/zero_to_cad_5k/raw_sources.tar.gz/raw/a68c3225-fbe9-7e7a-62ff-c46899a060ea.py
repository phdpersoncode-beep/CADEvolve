import cadquery as cq
import math
from types import SimpleNamespace as Params

params = Params(
    chord_length = 45.0,
    block_depth = 12.0,
    block_height = 12.0,
    outer_diameter = 80.0,
    vertical_fillet = 3.0,
    top_fillet = 2.0,
    insert_diameter = 5.0,
    insert_depth = 10.0,
    insert_csk_angle = 82,
    groove_thickness = 2.0,
    groove_height = 8.0,
    hole_offset_angle = 30.0
)

params.outer_radius = 0.5 * params.outer_diameter
params.center_diameter = params.outer_diameter - params.block_depth
params.center_radius = 0.5 * params.center_diameter
params.center_angle = math.degrees(math.acos((2*params.center_radius**2 - params.chord_length**2) / (2*params.center_radius**2)))
params.secant_angle = 0.5 * (180.0 - params.center_angle)

path = (
    cq.Workplane('XY')
    .radiusArc((params.chord_length, 0.0), params.center_radius)
    .wire()
)

block = (
    cq.Workplane('XY')
    .transformed(rotate=(90, -params.secant_angle, 0))
    .rect(params.block_depth, params.block_height)
    .sweep(path, transition='round')
    .edges('|Z')
    .fillet(params.vertical_fillet)
    .edges('>Z')
    .fillet(params.top_fillet)
)

# Add a rectangular groove on the top surface for reinforcement
block = (
    block
    .faces('>Z')
    .workplane()
    .center(-params.chord_length/2 + params.block_depth/4, 0)
    .rect(params.groove_thickness, params.groove_height)
    .cutBlind(-params.groove_thickness)
)

angle_rad = math.radians(params.hole_offset_angle)
insert_x = params.outer_radius * math.cos(angle_rad)
insert_y = params.outer_radius * math.sin(angle_rad)

result = (
    block
    .faces('>Z')
    .workplane()
    .center(insert_x, insert_y)
    .cskHole(params.insert_diameter, params.insert_depth, params.insert_csk_angle)
)
