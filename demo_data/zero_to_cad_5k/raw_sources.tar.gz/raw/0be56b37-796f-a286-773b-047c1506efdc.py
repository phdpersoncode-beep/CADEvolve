import cadquery as cq
import math
from types import SimpleNamespace as NS

m = NS(
    width=50.0,
    thickness=12.0,
    height=20.0,
    arc_angle_deg=115.0,
    vertical_fillet=2.0,
    top_fillet=3.0,
    hole_spacing=10.0,
    bolt_diameter=4.0,
    head_diameter=7.0,
    head_height=4.0,
)

# Derived values
m.arc_radius = m.width / (2 * math.sin(math.radians(m.arc_angle_deg / 2)))
# Secant angle for workplane orientation
m.arc_secant_angle = 0.5 * (180.0 - m.arc_angle_deg)

# Path for sweep: an arc from (0,0) to (width,0) with given radius
path = (
    cq.Workplane('XY')
    .radiusArc((m.width, 0.0), m.arc_radius)
    .wire()
)

result = (
    cq.Workplane('XY')
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.thickness, m.height)
    .sweep(path, transition='round')
    .edges('|Z')
    .fillet(m.vertical_fillet)
    .edges('>Z')
    .fillet(m.top_fillet)
    .faces('>Z')
    .workplane()
    .pushPoints([
        ( m.hole_spacing/2,  m.hole_spacing/2),
        (-m.hole_spacing/2,  m.hole_spacing/2),
        ( m.hole_spacing/2, -m.hole_spacing/2),
        (-m.hole_spacing/2, -m.hole_spacing/2),
    ])
    .cboreHole(m.bolt_diameter, m.head_diameter, m.head_height)
)
