import cadquery as cq

# Parameters
outer_radius = 30.0
head_height = 20.0
shell_thickness = 2.0
bore_diameter = 15.0
tab_width = 10.0
tab_height = 5.0
rib_height = 12.0
rib_thickness = 2.0
rib_length = shell_thickness
num_ribs = 4
chamfer_size = 0.5

# Create circular head solid
cyl = cq.Workplane("XY").circle(outer_radius).extrude(head_height)
# Create side tab solid
tab = (
    cq.Workplane("XY")
    .rect(tab_width, tab_height)
    .translate((outer_radius - tab_width / 2, 0, 0))
    .extrude(head_height)
)
# Combine head and tab
base = cyl.union(tab)
# Central bore
bored = base.faces(">Z").workplane().hole(bore_diameter)
# Shell operation to create thin-walled head
shell_part = bored.shell(shell_thickness)
# Internal ribs placed inside the shell
inner_radius = outer_radius - 2 * shell_thickness
rib_box = (
    cq.Workplane("XY")
    .box(rib_length, rib_thickness, rib_height, centered=(True, True, False))
    .translate((inner_radius + rib_length / 2, 0, 0))
)
ribs = rib_box.polarArray(radius=inner_radius + rib_length / 2, startAngle=0, count=num_ribs, angle=360.0/num_ribs)
# Combine ribs with shell using solids
shell_solid = shell_part.val()
ribs_solid = ribs.val()
combined = cq.Workplane("XY").add(shell_solid).add(ribs_solid).union()
# Apply chamfer to suitable edges
result = combined.edges().chamfer(chamfer_size)
