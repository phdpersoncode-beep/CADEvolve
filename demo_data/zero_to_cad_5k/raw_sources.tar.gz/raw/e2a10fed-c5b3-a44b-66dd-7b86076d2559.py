import cadquery as cq
import math
block_length=80.0
block_width=40.0
block_height=20.0
chamfer_size=1.0
top_offset=block_height/2
base=cq.Workplane('XY').box(block_length,block_width,block_height,centered=True).edges().chamfer(chamfer_size)
guide=cq.Workplane('XY')
result=base.workplane(offset=top_offset).center(0,0).rect(12,12).cutBlind(-block_height)
