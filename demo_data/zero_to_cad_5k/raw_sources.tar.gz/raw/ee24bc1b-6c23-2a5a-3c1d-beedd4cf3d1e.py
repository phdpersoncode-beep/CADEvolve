import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.workplane = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L profile
        base = (
            self.workplane
            .polyline([
                (0, 0),
                (m.long_leg_length, 0),
                (m.long_leg_length, m.leg_thickness),
                (m.short_leg_width, m.leg_thickness),
                (m.short_leg_width, m.long_leg_length),
                (0, m.long_leg_length),
                (0, 0)
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        # Fillet inner corner (the vertical and horizontal legs meet)
        filleted = (
            base.edges("|Z and <<X and >>Y")
                .fillet(m.inner_fillet_radius)
        )
        # Add rib on vertical leg near outer side
        rib = (
            filleted.faces(">Y")
                .workplane(origin=(m.short_leg_width/2, m.long_leg_length - m.rib_offset))
                .rect(m.rib_width, m.rib_height)
                .extrude(m.bracket_thickness)
        )
        # Drill clearance holes on long leg
        holes = (
            rib.faces("<Y")
                .workplane(centerOption="CenterOfBoundBox")
                .pushPoints([
                    (m.long_leg_length - m.hole_edge_distance - i*m.hole_spacing, m.leg_thickness/2)
                    for i in range(m.hole_count)
                ])
                .hole(m.clearance_hole_diameter)
        )
        self.model = holes

# Define parameters respecting 100 unit max scale
measures = Measures(
    long_leg_length=80.0,
    short_leg_width=30.0,
    leg_thickness=30.0,
    bracket_thickness=8.0,
    inner_fillet_radius=12.0,
    rib_width=10.0,
    rib_height=4.0,
    rib_offset=5.0,
    clearance_hole_diameter=3.0,
    hole_spacing=12.0,
    hole_count=5,
    hole_edge_distance=10.0,
)

result = LBracket(cq.Workplane("XY"), measures).model