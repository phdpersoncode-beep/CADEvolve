import cadquery as cq

# variables
base_length = 80.0
base_width = 60.0
base_thick = 5.0
outer_hex_dia = 70.0
inner_hex_dia = 50.0
frame_height = 8.0
inner_fillet = 0.5
clearance_hole_dia = 4.0
hole_offset_x = 30.0
hole_offset_y = 20.0
chamfer_dist = 0.5

result = (
    cq.Workplane("XY")
    .box(base_length, base_width, base_thick, centered=(True, True, False))
    .edges("|Z")
    .chamfer(chamfer_dist)
    .faces(">Z")
    .workplane()
    .polygon(6, outer_hex_dia)
    .extrude(frame_height, combine=True)
    .faces(">Z")
    .workplane()
    .polygon(6, inner_hex_dia)
    .cutBlind(-frame_height)
    .edges("|Z")
    .fillet(inner_fillet)
    .faces(">Z")
    .workplane()
    .pushPoints([
        (hole_offset_x, hole_offset_y),
        (-hole_offset_x, hole_offset_y),
        (hole_offset_x, -hole_offset_y),
        (-hole_offset_x, -hole_offset_y),
    ])
    .hole(clearance_hole_dia)
)
