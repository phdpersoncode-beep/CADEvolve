import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical_leg = (
            cq.Workplane('XY')
            .center(m.thickness / 2, m.height / 2)
            .rect(m.thickness, m.height)
            .extrude(m.thickness)
        )
        horizontal_leg = (
            cq.Workplane('XY')
            .center(m.width / 2, m.thickness / 2)
            .rect(m.width, m.thickness)
            .extrude(m.thickness)
        )
        base = vertical_leg.union(horizontal_leg)
        rib = (
            cq.Workplane('XY')
            .box(m.rib_depth, m.rib_height, m.thickness)
            .translate((-m.rib_depth / 2, m.height / 2, 0))
        )
        model = base.union(rib)
        model = model.edges().chamfer(m.chamfer)
        # vertical leg holes on outer +X face
        model = (
            model
            .faces('>X')
            .workplane()
            .pushPoints([
                (-m.height / 2 + m.vertical_hole_offset, 0),
                (m.height / 2 - m.vertical_hole_offset, 0),
            ])
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        # horizontal leg holes on bottom -Z face
        model = (
            model
            .faces('<Z')
            .workplane()
            .pushPoints([
                (-m.width / 2 + m.horizontal_hole_offset, 0),
                (m.width / 2 - m.horizontal_hole_offset, 0),
            ])
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.model = model

measures = Measures(
    width=80.0,
    height=60.0,
    thickness=8.0,
    rib_depth=12.0,
    rib_height=30.0,
    chamfer=1.0,
    hole_diameter=6.0,
    cbore_diameter=8.0,
    cbore_depth=3.0,
    vertical_hole_offset=15.0,
    horizontal_hole_offset=20.0,
)

result = LBracket(cq.Workplane('XY'), measures).model
