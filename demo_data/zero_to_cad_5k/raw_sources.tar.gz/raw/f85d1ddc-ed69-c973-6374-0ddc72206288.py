import cadquery as cq
vertical_leg_height=80.0
horizontal_leg_length=60.0
leg_width=15.0
wall_thickness=5.0
result = (
    cq.Workplane('XY')
    .moveTo(0,0)
    .lineTo(0, vertical_leg_height)
    .lineTo(leg_width, vertical_leg_height)
    .lineTo(leg_width, leg_width)
    .lineTo(horizontal_leg_length, leg_width)
    .lineTo(horizontal_leg_length, 0)
    .close()
    .extrude(wall_thickness)
)
