import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.measures = measures
        self.model = workplane
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.h_leg_length, 0),
                (m.h_leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.v_leg_length + m.leg_thickness),
                (0, m.v_leg_length + m.leg_thickness)
            ])
            .close()
            .extrude(m.leg_height)
        )
        with_holes = (
            base.faces(">Z").workplane(centerOption="CenterOfBoundBox")
            .move(m.h_leg_length/2, m.leg_thickness/2)
            .rect(m.h_leg_length - 2*m.mount_margin, m.leg_thickness - 2*m.mount_margin, forConstruction=True)
            .vertices()
            .hole(m.mount_hole_diameter)
        )
        with_tip_hole = (
            with_holes.faces(">Z").workplane(centerOption="CenterOfBoundBox")
            .move(0, m.v_leg_length/2 + m.leg_thickness/2)
            .hole(m.tip_hole_diameter)
        )
        gusset = (
            cq.Workplane("XY")
            .box(m.gusset_length, m.gusset_thickness, m.gusset_height)
            .translate((m.leg_thickness/2, m.leg_thickness/2, m.gusset_height/2))
        )
        combined = with_tip_hole.union(gusset)
        result = combined.edges("|Z").chamfer(m.chamfer)
        self.model = result

measures = Measures(
    h_leg_length=70.0,
    v_leg_length=50.0,
    leg_thickness=10.0,
    leg_height=8.0,
    mount_margin=5.0,
    mount_hole_diameter=4.0,
    tip_hole_diameter=6.0,
    gusset_length=15.0,
    gusset_thickness=3.0,
    gusset_height=12.0,
    chamfer=0.8,
)

result = LBracket(cq.Workplane("XY"), measures).model
