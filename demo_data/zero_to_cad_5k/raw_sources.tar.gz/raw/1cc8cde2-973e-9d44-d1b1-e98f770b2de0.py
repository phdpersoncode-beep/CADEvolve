import cadquery as cq
from types import SimpleNamespace as Measures

horizontal_length = 80.0
vertical_height = 80.0
leg_thickness = 10.0
taper_length = 20.0
extrude_depth = 10.0
hole_diameter = 4.5
hole_count = 5
hole_spacing = 12.0
hole_offset_from_bottom = 15.0
chamfer_size = 1.0
notch_width = 6.0
notch_height = 12.0
notch_offset_y = 30.0

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_length - m.taper_length, 0),
                (m.horizontal_length, m.leg_thickness),
                (m.horizontal_length, m.vertical_height),
                (m.leg_thickness, m.vertical_height),
                (m.leg_thickness, m.leg_thickness),
                (0, m.leg_thickness),
                (0, 0),
            ])
            .close()
            .extrude(m.extrude_depth)
        )
        notch = (
            cq.Workplane("XY")
            .center(m.leg_thickness/2, m.notch_offset_y + m.notch_height/2)
            .rect(m.notch_width, m.notch_height)
            .extrude(m.extrude_depth)
        )
        solid = base.cut(notch)
        hole_positions = []
        for i in range(m.hole_count):
            y = m.hole_offset_from_bottom + i * m.hole_spacing
            hole_positions.append((m.leg_thickness/2, y))
        solid = solid.faces(">Z").workplane().pushPoints(hole_positions).hole(m.hole_diameter)
        solid = solid.edges("|Z").chamfer(m.chamfer_size)
        self.model = solid

measures = Measures(
    horizontal_length=horizontal_length,
    vertical_height=vertical_height,
    leg_thickness=leg_thickness,
    taper_length=taper_length,
    extrude_depth=extrude_depth,
    hole_diameter=hole_diameter,
    hole_count=hole_count,
    hole_spacing=hole_spacing,
    hole_offset_from_bottom=hole_offset_from_bottom,
    chamfer_size=chamfer_size,
    notch_width=notch_width,
    notch_height=notch_height,
    notch_offset_y=notch_offset_y,
)

result = LBracket(cq.Workplane("XY"), measures).model
