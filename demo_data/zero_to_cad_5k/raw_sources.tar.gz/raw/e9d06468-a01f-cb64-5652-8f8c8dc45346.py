import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        pts = [
            (0, 0),
            (m.thickness, 0),
            (m.thickness, m.vertical_length),
            (m.thickness + m.horizontal_length, m.vertical_length),
            (m.thickness + m.horizontal_length, 0),
            (0, 0),
        ]
        profile = cq.Workplane("XY").polyline(pts).close()
        base = profile.revolve()
        rib = (
            cq.Workplane("XY")
            .center(m.thickness + m.horizontal_length / 2, 0)
            .rect(m.rib_width, m.rib_thickness)
            .extrude(m.rib_height)
        )
        solid = base.union(rib)
        hole = (
            cq.Workplane("XY")
            .center(m.thickness / 2, 0)
            .circle(m.hole_diameter / 2)
            .extrude(200)
        )
        solid = solid.cut(hole)
        self.model = solid

measures = Measures(
    thickness=8.0,
    vertical_length=50.0,
    horizontal_length=40.0,
    rib_width=10.0,
    rib_height=6.0,
    rib_thickness=4.0,
    hole_diameter=6.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
