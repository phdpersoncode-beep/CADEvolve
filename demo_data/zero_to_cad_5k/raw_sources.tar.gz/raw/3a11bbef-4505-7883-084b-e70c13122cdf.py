import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .rect(m.leg_width, m.vertical_length)
            .extrude(m.leg_depth)
            .translate((m.leg_width/2, m.vertical_length/2, 0))
        )
        horizontal = (
            cq.Workplane("XY")
            .rect(m.horizontal_length, m.leg_width)
            .extrude(m.leg_depth)
            .translate((m.horizontal_length/2, m.leg_width/2, 0))
        )
        base = vertical.union(horizontal)
        tip_point = (m.leg_width, m.vertical_length, m.leg_depth/2)
        base = base.edges(cq.selectors.NearestToPointSelector(tip_point)).fillet(m.tip_fillet_radius)
        gusset = (
            cq.Workplane("XY")
            .polyline([(0,0), (m.leg_width,0), (0,m.leg_width)])
            .close()
            .extrude(m.gusset_thickness)
        )
        base = base.union(gusset)
        rib = (
            cq.Workplane("XY")
            .rect(m.rib_width, m.leg_width)
            .extrude(m.leg_depth)
            .translate((m.leg_width + m.rib_width/2, m.vertical_length/2, 0))
        )
        base = base.union(rib)
        slot = (
            cq.Workplane("XY")
            .rect(m.slot_width, m.leg_width)
            .extrude(m.leg_depth - 0.5)
            .translate((m.slot_offset + m.slot_width/2, m.leg_width/2, 0))
        )
        base = base.cut(slot)
        base = (
            base.faces(">Z")
            .workplane()
            .center(m.leg_width/2, m.vertical_length)
            .hole(m.hole_diameter)
        )
        self.model = base

measures = Measures(
    leg_width=10.0,
    leg_depth=8.0,
    vertical_length=60.0,
    horizontal_length=80.0,
    hole_diameter=10.0,
    tip_fillet_radius=5.0,
    gusset_thickness=4.0,
    rib_width=4.0,
    slot_width=12.0,
    slot_offset=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
