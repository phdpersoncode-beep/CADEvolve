import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    outer_radius = 20.0,
    inner_radius = 14.0,
    sleeve_length = 30.0,
    flange_height = 8.0,
    flange_thickness = 3.0,
    opening_fillet = 1.0,
    chamfer_distance = 0.5,
    hole = Measures(
        diameter = 2.5,
        pattern_radius = 8.0,
        count = 4,
        depth = 5.0
    )
)

profile = (
    cq.Workplane("XZ")
    .moveTo(m.inner_radius, 0)
    .lineTo(m.inner_radius, m.sleeve_length - m.flange_height)
    .lineTo(m.inner_radius + m.flange_thickness, m.sleeve_length - m.flange_height)
    .lineTo(m.inner_radius + m.flange_thickness, m.sleeve_length)
    .lineTo(m.outer_radius, m.sleeve_length)
    .lineTo(m.outer_radius, 0)
    .close()
)

result = (
    profile
    .revolve(360)
    .faces("<Z").edges().chamfer(m.chamfer_distance)
    .faces(">Z").edges().fillet(m.opening_fillet)
    .faces("<Z").workplane()
    .polarArray(radius=m.hole.pattern_radius, count=m.hole.count, startAngle=0, angle=360)
    .hole(m.hole.diameter, depth=m.hole.depth)
)
