import cadquery as cq

body_outer_dia = 60
body_length = 70
wall_thickness = 5
conduit_length = 30
vent_width = 20
vent_depth = 10
top_chamfer = 2
mount_hole_dia = 6
mount_hole_spacing = 40

body_radius = body_outer_dia/2
body_inner_radius = body_radius - wall_thickness
conduit_outer_radius = body_radius - wall_thickness/2  # 27.5
conduit_inner_radius = conduit_outer_radius - wall_thickness  # 22.5
conduit_center_offset = body_radius + conduit_outer_radius - wall_thickness  # overlap 5

# Body outer and inner cylinders
body_outer = (
    cq.Workplane("XY")
    .circle(body_radius)
    .extrude(body_length)
)
body_inner = (
    cq.Workplane("XY")
    .circle(body_inner_radius)
    .extrude(body_length)
)
body_shell = body_outer.cut(body_inner)

# Conduit outer and inner cylinders
conduit_outer = (
    cq.Workplane("XY")
    .center(conduit_center_offset, 0)
    .circle(conduit_outer_radius)
    .extrude(body_length + conduit_length)
)
conduit_inner = (
    cq.Workplane("XY")
    .center(conduit_center_offset, 0)
    .circle(conduit_inner_radius)
    .extrude(body_length + conduit_length)
)
conduit_shell = conduit_outer.cut(conduit_inner)

# Union of body and conduit shells (should fuse into single solid)
result = body_shell.union(conduit_shell)

# Chamfer top edges (vertical edges)
result = result.edges("|Z").chamfer(top_chamfer)

# Vent pocket on top face
result = (
    result
    .faces(">Z")
    .workplane()
    .center(0, 0)
    .rect(vent_width, vent_depth)
    .cutBlind(vent_depth)
)

# Mounting holes on top surface
result = (
    result
    .faces(">Z")
    .workplane()
    .pushPoints([(-mount_hole_spacing/2, 0), (mount_hole_spacing/2, 0)])
    .hole(mount_hole_dia)
)
