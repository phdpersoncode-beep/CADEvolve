import cadquery as cq

clip_total_length = 45.0
clip_body_radius = 20.0
clip_wall_thickness = 3.0
clip_outer_radius = clip_body_radius + clip_wall_thickness
snap_latch_width = 12.0
snap_latch_thickness = 2.0
chamfer_distance = 0.5
blind_hole_diameter = 4.0
blind_hole_depth = 15.0

outer_solid = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(0, clip_outer_radius)
    .lineTo(clip_total_length - snap_latch_width, clip_outer_radius)
    .lineTo(clip_total_length - snap_latch_width, clip_outer_radius + snap_latch_thickness)
    .lineTo(clip_total_length, clip_outer_radius + snap_latch_thickness)
    .lineTo(clip_total_length, 0)
    .close()
    .revolve(axisStart=(0, 0, 0), axisEnd=(1, 0, 0))
    .shell(-clip_wall_thickness)
)

result = (
    outer_solid
    .faces(">X")
    .workplane()
    .circle(blind_hole_diameter/2)
    .cutBlind(blind_hole_depth)
    .faces(">X")
    .edges()
    .chamfer(chamfer_distance)
)
