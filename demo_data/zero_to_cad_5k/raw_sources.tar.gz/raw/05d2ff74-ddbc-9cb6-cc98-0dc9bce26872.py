import cadquery as cq
from types import SimpleNamespace as Measures

def part(self, part_class, measures):
    part = part_class(self, measures)
    return self.newObject(part.model.objects)

cq.Workplane.part = part

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_length, 0),
                (m.horizontal_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.vertical_length),
                (0, m.vertical_length),
                (0, 0),
            ])
            .close()
            .extrude(m.leg_thickness)
        )
        rib = (
            base.faces(">X")
            .workplane(centerOption="CenterOfBoundBox")
            .rect(m.leg_thickness, m.rib_height)
            .extrude(-m.rib_thickness)
        )
        chamfered = (
            rib.edges("|Z and >X")
            .chamfer(m.chamfer_size)
        )
        edge_clearance = m.edge_clearance
        hole_spacing = (m.vertical_length - 2 * edge_clearance) / 4
        hole_positions = [
            (m.leg_thickness / 2, edge_clearance + i * hole_spacing) for i in range(5)
        ]
        final = (
            chamfered.faces("<Y")
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        self.model = final

horizontal_length = 70.0
vertical_length = 60.0
leg_thickness = 10.0
rib_height = 30.0
rib_thickness = 5.0
chamfer_size = 2.0
hole_diameter = 4.0
edge_clearance = 5.0

measures = Measures(
    horizontal_length=horizontal_length,
    vertical_length=vertical_length,
    leg_thickness=leg_thickness,
    rib_height=rib_height,
    rib_thickness=rib_thickness,
    chamfer_size=chamfer_size,
    hole_diameter=hole_diameter,
    edge_clearance=edge_clearance,
)

result = cq.Workplane("XY").part(LBracket, measures)
