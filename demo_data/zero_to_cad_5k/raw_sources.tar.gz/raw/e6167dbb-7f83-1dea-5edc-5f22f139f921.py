import cadquery as cq
base_width=80.0;base_depth=30.0;base_thickness=5.0
base=cq.Workplane('XY').rect(base_width,base_depth).extrude(base_thickness)
straight_ext=cq.Workplane('XY').center(0,base_depth/2+5).rect(4,10).extrude(20)
result=base.union(straight_ext)
