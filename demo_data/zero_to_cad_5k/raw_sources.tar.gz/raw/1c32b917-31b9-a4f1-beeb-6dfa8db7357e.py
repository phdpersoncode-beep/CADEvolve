import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_thickness, 0)
            .lineTo(m.leg_thickness, m.vertical_length)
            .lineTo(m.leg_thickness + m.horizontal_length, m.vertical_length)
            .lineTo(m.leg_thickness + m.horizontal_length, m.vertical_length + m.leg_thickness)
            .lineTo(0, m.vertical_length + m.leg_thickness)
            .close()
            .extrude(m.thickness)
            .faces(">Z")
            .edges()
            .chamfer(m.chamfer)
        )
        gusset = (
            cq.Workplane("XY")
            .moveTo(m.leg_thickness, m.vertical_length)
            .lineTo(m.leg_thickness + m.gusset_thickness, m.vertical_length)
            .lineTo(m.leg_thickness, m.vertical_length + m.gusset_thickness)
            .close()
            .extrude(m.thickness)
        )
        model = base.union(gusset)
        model = (
            model.faces("<Z")
            .workplane()
            .moveTo(m.leg_thickness / 2, m.vertical_length / 2)
            .hole(m.m6_diameter)
        )
        spacing = m.horizontal_length / 6
        start_x = m.leg_thickness + m.gusset_thickness + spacing
        y_pos = m.thickness / 2
        for i in range(5):
            model = (
                model.faces("<Z")
                .workplane()
                .moveTo(start_x + i * spacing, y_pos)
                .hole(m.m5_clearance_diameter)
            )
        self.model = model

measures = Measures(
    leg_thickness=12.0,
    thickness=8.0,
    vertical_length=70.0,
    horizontal_length=60.0,
    gusset_thickness=4.0,
    chamfer=4.0,
    m6_diameter=6.0,
    m5_clearance_diameter=5.5,
)

result = LBracket(cq.Workplane("XY"), measures).model