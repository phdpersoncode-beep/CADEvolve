import cadquery as cq

bracket_length = 70.0
bracket_width = 40.0
bracket_thickness = 10.0
pocket_width = 20.0
pocket_height = 6.0
pocket_depth = 30.0
hole_diameter = 4.0
hole_spacing = 20.0
hole_offset = 12.0
rib_thickness = 3.0
rib_height = 4.0
chamfer_distance = 1.5
outer_chamfer = 0.8

base = cq.Workplane('XY').rect(bracket_length, bracket_width).extrude(bracket_thickness)

pocket_cut = (
    base
    .faces('>Y')
    .workplane()
    .center(0, pocket_height / 2.0)
    .rect(pocket_width, pocket_height)
    .cutBlind(-pocket_depth)
)

pocket_chamfer = (
    pocket_cut
    .edges('|Z and >Y')
    .chamfer(chamfer_distance)
)

holes = (
    pocket_chamfer
    .faces('>Z')
    .workplane()
    .center(-bracket_length / 2 + hole_offset, 0)
    .rarray(hole_spacing, 0, 3, 1)
    .hole(hole_diameter)
)

result = holes
rib_positions = [(-bracket_length / 4, 0), (bracket_length / 4, 0)]
for x, y in rib_positions:
    result = (
        result
        .faces('>Z')
        .workplane()
        .center(x, y)
        .rect(rib_thickness, bracket_width - 10)
        .cutBlind(-rib_height)
    )

result = result.edges('|Z and (>X or <X or >Y or <Y)').chamfer(outer_chamfer)
