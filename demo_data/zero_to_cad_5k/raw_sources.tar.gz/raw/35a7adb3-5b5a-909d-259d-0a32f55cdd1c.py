import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.leg_width),
                (m.leg_width, m.leg_width),
                (m.leg_width, m.vertical_leg_length + m.leg_width),
                (0, m.vertical_leg_length + m.leg_width)
            ])
            .close()
        )
        self.model = profile.extrude(m.thickness)
        self.model = self.model.cut(
            cq.Workplane("XY")
            .cylinder(m.thickness + 2, m.fillet_radius)
        )
        pocket_center_x = m.leg_width / 2
        pocket_center_y = m.vertical_leg_length / 2 + m.leg_width
        self.model = (
            self.model
            .faces(">Y")
            .workplane(centerOption="CenterOfBoundBox")
            .center(pocket_center_x - m.leg_width/2, pocket_center_y - (m.vertical_leg_length + m.leg_width)/2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(m.pocket_depth)
        )
        hole_y = m.leg_width / 2
        spacing = (m.horizontal_leg_length - 2 * m.edge_clearance) / (m.hole_count - 1)
        hole_positions = [
            (m.edge_clearance + i * spacing, hole_y) for i in range(m.hole_count)
        ]
        self.model = (
            self.model
            .faces("<Z")
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.clearance_hole_diameter)
        )

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_length=60.0,
    leg_width=20.0,
    thickness=9.0,
    fillet_radius=10.0,
    pocket_width=12.0,
    pocket_height=30.0,
    pocket_depth=5.0,
    clearance_hole_diameter=5.0,
    hole_count=3,
    edge_clearance=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
