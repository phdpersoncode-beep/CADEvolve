import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .rect(m.thickness, m.leg_height, centered=False)
            .extrude(m.thickness)
        )
        horizontal = (
            cq.Workplane("XY")
            .rect(m.arm_length, m.thickness, centered=False)
            .translate((m.thickness, 0, 0))
            .extrude(m.thickness)
        )
        bracket = vertical.union(horizontal)
        # fillet only outer corner edges (those on combination of outer X/Y faces)
        outer_edge_selector = "((>X and >Y) or (>X and <Y) or (<X and >Y) or (<X and <Y)) and |Z"
        bracket = bracket.edges(outer_edge_selector).fillet(m.fillet_radius)
        # hole pattern on inner +X face of vertical leg
        bracket = (
            bracket.faces(">X")
            .workplane()
            .rect(
                m.thickness - 2 * m.hole_margin,
                m.leg_height - 2 * m.hole_margin,
                centered=False,
            )
            .vertices()
            .hole(m.hole_diameter)
        )
        self.model = bracket

params = Measures(
    thickness=10.0,
    leg_height=50.0,
    arm_length=60.0,
    fillet_radius=5.0,
    hole_diameter=4.0,
    hole_margin=5.0,
)

result = LBracket(cq.Workplane("XY"), params).model
