import cadquery as cq
# parameters
length = 100.0
height = 60.0
width = 80.0
web_thickness = 6.0
flange_thickness = 8.0
chamfer_size = 2.0
hole_diameter = 5.0
# derived dimensions
half_width = width / 2.0
half_height = height / 2.0
inner_web_x = web_thickness / 2.0
inner_web_y_bottom = -half_height + flange_thickness
inner_web_y_top = half_height - flange_thickness
# polyline points for half I‑beam cross‑section
pts = [
    (0, -half_height),
    (inner_web_x, -half_height + flange_thickness),
    (half_width, -half_height + flange_thickness),
    (half_width, half_height - flange_thickness),
    (inner_web_x, half_height - flange_thickness),
    (inner_web_x, half_height),
    (0, half_height)
]
result = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .extrude(length)
    .edges("|Z")
    .filter(lambda e: abs(e.Center().x - inner_web_x) < 1e-3 and (
        abs(e.Center().y - inner_web_y_top) < 1e-3 or abs(e.Center().y - inner_web_y_bottom) < 1e-3
    ))
    .chamfer(chamfer_size)
    .faces(">X")
    .workplane()
    .hole(hole_diameter)
    .faces("<X")
    .workplane()
    .hole(hole_diameter)
)
