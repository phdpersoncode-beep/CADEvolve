import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
dim = Measures(
    leg_thickness=20.0,
    long_leg_length=80.0,
    short_leg_length=60.0,
    thickness_z=10.0,
    hole_diameter=5.5,
    hole_rows=2,
    hole_cols=2,
    hole_spacing_x=15.0,
    hole_spacing_y=15.0,
    pocket_width=30.0,
    pocket_height=15.0,
    pocket_depth=6.0,
    chamfer_size=1.0,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # L profile points (counter‑clockwise)
        pts = [
            (0, 0),
            (m.leg_thickness, 0),
            (m.leg_thickness, m.short_leg_length),
            (m.long_leg_length, m.short_leg_length),
            (m.long_leg_length, m.short_leg_length + m.leg_thickness),
            (0, m.short_leg_length + m.leg_thickness),
        ]
        body = (
            cq.Workplane("XY")
            .polyline(pts)
            .close()
            .extrude(m.thickness_z)
        )
        # Chamfer outer edges
        body = body.edges("|Z").chamfer(m.chamfer_size)
        # Clearance holes pattern in vertical leg
        x_start = m.leg_thickness / 2.0 - ((m.hole_cols - 1) * m.hole_spacing_x) / 2.0
        y_start = m.short_leg_length / 2.0 - ((m.hole_rows - 1) * m.hole_spacing_y) / 2.0
        hole_coords = []
        for i in range(m.hole_cols):
            for j in range(m.hole_rows):
                hx = x_start + i * m.hole_spacing_x
                hy = y_start + j * m.hole_spacing_y
                hole_coords.append((hx, hy))
        body = (
            body.faces(">Z")
            .workplane()
            .pushPoints(hole_coords)
            .hole(m.hole_diameter)
        )
        # Sensor pocket on horizontal leg
        pocket_center_x = m.leg_thickness + (m.long_leg_length - m.leg_thickness) / 2.0
        pocket_center_y = m.short_leg_length + m.leg_thickness / 2.0
        body = (
            body.faces(">Z")
            .workplane()
            .moveTo(pocket_center_x, pocket_center_y)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        self.model = body

result = LBracket(cq.Workplane("XY"), dim).model
