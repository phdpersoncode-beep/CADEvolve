import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 5.0
slot_width = 4.0
slot_length = 12.0
num_slots = 5
slot_margin = 8.0
clearance_hole_dia = 10.0
mount_hole_dia = 5.0
mount_hole_offset = 20.0
mount_csk_angle = 45.0
rib_width_factor = 0.6
rib_length_factor = 0.5
rib_thickness_factor = 0.3
pocket_margin = 5.0
pocket_depth = 1.5
tip_chamfer = 2.0
edge_fillet = 0.8

rib_width = leaf_thickness * rib_width_factor
rib_length = leaf_length * rib_length_factor
rib_thickness = leaf_thickness * rib_thickness_factor
pocket_length = leaf_length - 2 * pocket_margin
pocket_width = leaf_width - 2 * pocket_margin

base = (
    cq.Workplane('XY')
    .rect(leaf_length, leaf_width)
    .extrude(leaf_thickness)
)

rib = (
    base.faces('<Z')
    .workplane()
    .rect(rib_length, rib_width)
    .extrude(rib_thickness)
)

slot_pitch = (leaf_length - 2 * slot_margin - slot_length) / (num_slots - 1)
slots = (
    rib.faces('>Z')
    .workplane()
    .center(-leaf_length/2 + slot_margin + slot_length/2, 0)
    .rarray(slot_pitch, 0, num_slots, 1)
    .rect(slot_length, slot_width)
    .cutBlind(-leaf_thickness)
)

clearance = (
    slots.faces('>Z')
    .workplane()
    .hole(clearance_hole_dia)
)

mounting = (
    clearance.faces('>Z')
    .workplane()
    .pushPoints([
        (-leaf_length/2 + mount_hole_offset, 0),
        (leaf_length/2 - mount_hole_offset, 0)
    ])
    .cskHole(mount_hole_dia, mount_hole_dia * 1.5, mount_csk_angle)
)

pocket = (
    mounting.faces('>Z')
    .workplane()
    .rect(pocket_length, pocket_width)
    .cutBlind(-pocket_depth)
)

beveled = (
    pocket.faces('>X').edges().chamfer(tip_chamfer)
)

result = beveled