import cadquery as cq
import math

# Parameters
block_length = 80.0
block_width = 80.0
block_height = 20.0
fin_height = 5.0
hex_radius = 5.0
vent_diameter = 20.0
chamfer_size = 1.0
mount_hole_diameter = 4.0

# Helper to create hexagon points centered at origin
def hexagon_points(radius):
    pts = []
    for i in range(6):
        angle = math.radians(60 * i)
        pts.append((radius * math.cos(angle), radius * math.sin(angle)))
    return pts

# Base block with chamfered vertical edges
base = (
    cq.Workplane('XY')
    .rect(block_length, block_width)
    .extrude(block_height)
    .edges('|Z')
    .chamfer(chamfer_size)
)

# Honeycomb pattern positions
x_spacing = 1.5 * hex_radius
y_spacing = hex_radius * math.sqrt(3)
cols = int((block_length - 2 * hex_radius) // x_spacing) + 1
rows = int((block_width - 2 * hex_radius) // y_spacing) + 1

hex_centers = []
for row in range(rows):
    y = -block_width/2 + hex_radius + row * y_spacing
    offset = 0 if row % 2 == 0 else 0.75 * hex_radius
    col_count = cols if row % 2 == 0 else cols - 1
    for col in range(col_count):
        x = -block_length/2 + hex_radius + offset + col * x_spacing
        if (x - hex_radius < -block_length/2) or (x + hex_radius > block_length/2):
            continue
        hex_centers.append((x, y))

# Build fins by extruding hexagons from the top face
fins = cq.Workplane('XY')
hex_pts = hexagon_points(hex_radius)
for cx, cy in hex_centers:
    fin = (
        cq.Workplane('XY')
        .polyline(hex_pts)
        .close()
        .extrude(fin_height)
        .translate((cx, cy, block_height))
    )
    fins = fins.union(fin)

# Combine base and fins
if fins.objects:
    result = base.union(fins)
else:
    result = base

# Central vent hole through the entire height
result = result.faces('>Z').workplane().hole(vent_diameter)

# Mounting holes on bottom face (four corners inset 10 units)
corner_offsets = [
    ( block_length/2 - 10,  block_width/2 - 10),
    (-block_length/2 + 10,  block_width/2 - 10),
    ( block_length/2 - 10, -block_width/2 + 10),
    (-block_length/2 + 10, -block_width/2 + 10),
]
result = result.faces('<Z').workplane().pushPoints(corner_offsets).hole(mount_hole_diameter)
