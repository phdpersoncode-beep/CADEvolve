import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # vertical leg
        vertical = (
            cq.Workplane("XY")
            .box(m.thickness, m.vertical_leg_height, m.thickness)
            .translate((0, m.vertical_leg_height / 2, 0))
        )
        # horizontal leg
        horizontal = (
            cq.Workplane("XY")
            .box(m.horizontal_leg_length, m.thickness, m.thickness)
            .translate((m.horizontal_leg_length / 2, 0, 0))
        )
        base = vertical.union(horizontal)
        # reinforcement rib on outer vertical face (+X)
        rib = (
            base.faces(">X")
            .workplane()
            .rect(m.rib_width, m.vertical_leg_height)
            .extrude(m.rib_thickness)
        )
        # chamfer inner corner edges (vertical edges at inner corner)
        chamfered = rib.edges("|Z").chamfer(m.chamfer_size)
        # through hole on vertical leg outer face (+X)
        result = (
            chamfered.faces(">X")
            .workplane()
            .center(0, m.vertical_leg_height / 2)
            .hole(m.hole_diameter)
        )
        self.model = result

measures = Measures(
    horizontal_leg_length=50,
    vertical_leg_height=70,
    thickness=10,
    rib_thickness=3,
    rib_width=10,
    chamfer_size=1,
    hole_diameter=9,
)

result = LBracket(cq.Workplane("XY"), measures).model