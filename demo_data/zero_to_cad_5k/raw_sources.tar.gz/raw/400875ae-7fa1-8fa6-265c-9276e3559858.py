import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.bracket_thickness),
                (m.bracket_thickness, m.bracket_thickness),
                (m.bracket_thickness, m.vertical_leg_height),
                (0, m.vertical_leg_height),
                (0, 0),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        rib = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.rib_length_horizontal, 0),
                (m.rib_length_horizontal, m.rib_thickness),
                (m.rib_thickness, m.rib_thickness),
                (m.rib_thickness, m.rib_length_vertical),
                (0, m.rib_length_vertical),
                (0, 0),
            ])
            .close()
            .extrude(m.bracket_thickness)
        )
        solid = base.union(rib)
        slot = (
            solid.faces(">Z").workplane()
            .center(m.horizontal_leg_length / 2, m.bracket_thickness / 2)
            .rect(m.slot_width, m.slot_height)
            .cutBlind(m.bracket_thickness)
        )
        hole = (
            slot.faces(">Z").workplane()
            .center(m.bracket_thickness / 2, m.vertical_leg_height - m.hole_diameter / 2)
            .hole(m.hole_diameter)
        )
        offset = (m.horizontal_leg_length - m.mount_hole_spacing) / 2
        pattern = (
            hole.faces(">Z").workplane()
            .pushPoints([
                (offset + m.bracket_thickness / 2, m.bracket_thickness / 2),
                (m.horizontal_leg_length - offset - m.bracket_thickness / 2, m.bracket_thickness / 2),
            ])
            .hole(m.mount_hole_diameter)
        )
        result = pattern.edges("|Z").chamfer(m.chamfer_size)
        self.model = result

measures = Measures(
    horizontal_leg_length=80.0,
    vertical_leg_height=60.0,
    bracket_thickness=8.0,
    rib_thickness=2.0,
    rib_length_horizontal=20.0,
    rib_length_vertical=20.0,
    chamfer_size=1.0,
    hole_diameter=10.0,
    slot_width=30.0,
    slot_height=4.0,
    mount_hole_diameter=5.0,
    mount_hole_spacing=40.0,
)

result = LBracket(cq.Workplane("XY"), measures).model