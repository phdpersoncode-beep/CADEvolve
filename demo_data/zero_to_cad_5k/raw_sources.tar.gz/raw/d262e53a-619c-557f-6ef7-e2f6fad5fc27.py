import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        l_profile = (
            cq.Workplane('XY')
            .moveTo(0, 0)
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.leg_short)
            .lineTo(m.thickness + m.leg_long, m.leg_short)
            .lineTo(m.thickness + m.leg_long, m.thickness + m.leg_short)
            .lineTo(0, m.thickness + m.leg_short)
            .close()
        )
        solid = (
            l_profile.extrude(m.thickness)
            .edges()
            .chamfer(m.chamfer_dist)
        )
        solid = solid.edges('|Z').filter(lambda e: abs(e.Center().x - m.thickness) < 1e-3).fillet(m.inner_fillet)
        holes = (
            solid.faces('>Z')
            .workplane()
            .pushPoints([
                (m.thickness/2, m.thickness/2 + m.hole_pitch/2),
                (m.thickness/2, m.thickness/2 - m.hole_pitch/2),
                (m.thickness + m.leg_long/2, m.thickness + m.leg_short/2 + m.hole_pitch/2),
                (m.thickness + m.leg_long/2, m.thickness + m.leg_short/2 - m.hole_pitch/2)
            ])
            .hole(m.mount_hole_dia)
        )
        result = (
            holes.faces('>Z')
            .workplane()
            .moveTo(m.thickness/2 + m.leg_long/4, m.thickness/2 + m.leg_short/4)
            .rect(m.keyway_width, m.keyway_depth)
            .cutBlind(-m.keyway_recess)
        )
        self.model = result

measures = Measures(
    thickness=10.0,
    leg_long=70.0,
    leg_short=50.0,
    inner_fillet=5.0,
    chamfer_dist=2.0,
    mount_hole_dia=5.0,
    hole_pitch=20.0,
    keyway_width=8.0,
    keyway_depth=30.0,
    keyway_recess=5.0,
)

result = LBracket(cq.Workplane('XY'), measures).model