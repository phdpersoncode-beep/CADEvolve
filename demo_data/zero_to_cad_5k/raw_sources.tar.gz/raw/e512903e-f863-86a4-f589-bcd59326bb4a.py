import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        vertical = cq.Workplane('XY').box(m.thickness, m.vertical_leg_length, m.width)
        horizontal = cq.Workplane('XY').box(m.horizontal_leg_length, m.thickness, m.width).translate((m.horizontal_leg_length/2 - m.thickness/2, m.vertical_leg_length/2, 0))
        base = vertical.union(horizontal).translate((0, 0, m.width/2))
        boss_center_y = m.vertical_leg_length/2 - m.thickness/2
        boss = cq.Workplane('XY').cylinder(m.boss_height, m.boss_radius).translate((m.thickness/2, boss_center_y, m.width - m.boss_height/2))
        model = base.union(boss)
        model = model.edges('|Z').fillet(m.fillet_radius)
        model = model.faces('>Z').workplane().center(m.thickness/2 + m.boss_radius + m.hole_spacing/2, m.vertical_leg_length - m.thickness/2).rarray(m.hole_spacing, 0, 5, 1).hole(m.hole_diameter)
        self.model = model

measures = Measures(
    thickness=10.0,
    width=20.0,
    vertical_leg_length=60.0,
    horizontal_leg_length=80.0,
    boss_radius=8.0,
    boss_height=15.0,
    fillet_radius=3.0,
    hole_diameter=5.0,
    hole_spacing=12.0,
)

result = LBracket(cq.Workplane('XY'), measures).model
