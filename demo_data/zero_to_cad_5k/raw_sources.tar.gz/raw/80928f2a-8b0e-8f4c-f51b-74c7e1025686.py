import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .lineTo(m.short_leg_length, 0)
            .lineTo(m.short_leg_length, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness)
            .lineTo(m.leg_thickness, m.leg_thickness + m.long_leg_length)
            .lineTo(0, m.leg_thickness + m.long_leg_length)
            .close()
            .extrude(m.thickness)
        )
        rib = (
            cq.Workplane("XY")
            .box(m.rib_width, m.long_leg_length, m.thickness)
            .translate(( -m.rib_width/2, m.leg_thickness + m.long_leg_length/2, m.thickness/2))
        )
        combined = base.union(rib)
        hole_spacing = (m.short_leg_length - 2 * m.hole_edge_margin) / 2
        hole_positions = [
            (m.hole_edge_margin + i * hole_spacing, m.leg_thickness / 2)
            for i in range(3)
        ]
        result = (
            combined
            .faces(">Y")
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        self.model = result

measures = Measures(
    short_leg_length=50,
    leg_thickness=15,
    long_leg_length=70,
    thickness=7,
    rib_width=6,
    hole_diameter=4,
    hole_edge_margin=10,
)

part = LBracket(cq.Workplane("XY"), measures)
result = part.model