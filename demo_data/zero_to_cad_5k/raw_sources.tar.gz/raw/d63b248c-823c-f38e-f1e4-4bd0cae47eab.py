import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        outer = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.long_leg_length, 0),
                (m.long_leg_length, m.bracket_width),
                (m.bracket_width, m.bracket_width),
                (m.bracket_width, m.short_leg_length + m.bracket_width),
                (0, m.short_leg_length + m.bracket_width),
            ])
            .close()
        )
        solid = outer.extrude(m.bracket_thickness)
        solid = solid.shell(-m.shell_thickness)
        solid = solid.edges("|Z").fillet(m.inner_fillet_radius)
        solid = (
            solid.faces(">Z").workplane()
            .center(m.notch_offset_along_long_leg - m.long_leg_length/2, m.bracket_width/2)
            .rect(m.notch_width, m.notch_height)
            .cutBlind(m.notch_depth)
        )
        solid = (
            solid.faces(">Z").workplane()
            .center(-m.bracket_width/2, m.short_leg_length/2 - m.hole_offset_from_end)
            .cboreHole(m.hole_diameter, m.countersink_diameter, m.countersink_depth)
        )
        self.model = solid

measures = Measures(
    long_leg_length=80.0,
    short_leg_length=60.0,
    bracket_width=20.0,
    bracket_thickness=10.0,
    shell_thickness=3.0,
    inner_fillet_radius=4.0,
    notch_width=6.0,
    notch_height=10.0,
    notch_depth=5.0,
    notch_offset_along_long_leg=40.0,
    hole_diameter=5.0,
    countersink_diameter=9.0,
    countersink_depth=2.5,
    hole_offset_from_end=15.0,
)

result = LBracket(cq.Workplane("XY"), measures).model
