import cadquery as cq

# Dimensions (max 100 units = 10 cm)
outer_diameter = 80.0
inner_diameter = 30.0
plate_thickness = 8.0
blind_hole_dia = 10.0
blind_hole_depth = 4.0
through_hole_dia = 12.0
inner_fillet_radius = 0.5
rib_width = 4.0
rib_height = 2.0
rib_thickness = 1.5
rib_count = 6
mount_hole_dia = 5.0
mount_hole_offset = 20.0

# Base washer: outer extrusion with inner through hole
base = (
    cq.Workplane("XY")
    .circle(outer_diameter / 2)
    .extrude(plate_thickness)
    .faces("<Z")
    .workplane()
    .hole(inner_diameter)
    .fillet(inner_fillet_radius)
)

# Add a shallow rectangular pocket on the outer rim for clearance (non‑functional feature)
base = (
    base
    .faces(">Z")
    .workplane(offset=-plate_thickness / 2)
    .rect(outer_diameter * 0.2, plate_thickness * 0.5)
    .cutBlind(plate_thickness * 0.6)
)

# Through‑depth hole on the bottom side
result = (
    base
    .faces("<Z")
    .workplane()
    .hole(through_hole_dia)
)

# Blind hole on the top side
result = (
    result
    .faces(">Z")
    .workplane()
    .hole(blind_hole_dia, depth=blind_hole_depth)
)

# Radial ribs on the top surface for stiffness
rib_radius = outer_diameter / 2 - rib_width / 2 - 2.0
result = (
    result
    .faces(">Z")
    .workplane()
    .polarArray(radius=rib_radius, count=rib_count, startAngle=0, angle=360)
    .rect(rib_width, rib_thickness)
    .extrude(rib_height)
)

# Mounting holes around the inner circle (through the plate)
mount_radius = inner_diameter / 2 + mount_hole_offset
result = (
    result
    .faces("<Z")
    .workplane()
    .polarArray(radius=mount_radius, count=4, startAngle=0, angle=360)
    .hole(mount_hole_dia)
)
