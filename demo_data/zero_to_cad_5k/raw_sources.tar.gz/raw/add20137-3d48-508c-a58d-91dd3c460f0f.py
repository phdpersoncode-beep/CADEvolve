import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 8.0
central_hole_diameter = 10.0
fillet_radius = 2.0
chamfer_distance = 1.0
mount_hole_diameter = 4.0
mount_hole_spacing = 40.0
notch_width = 12.0
notch_depth = 6.0
rib_thickness = 2.0
rib_height = 2.0
rib_spacing = 10.0
rib_count = 3

half_len = leaf_length / 2.0
half_wid = leaf_width / 2.0
half_notch_w = notch_width / 2.0
notch_bottom_y = half_wid - notch_depth

profile = (
    cq.Sketch()
    .polygon([
        (-half_len, -half_wid),
        (half_len, -half_wid),
        (half_len, half_wid),
        (half_notch_w, half_wid),
        (half_notch_w, notch_bottom_y),
        (-half_notch_w, notch_bottom_y),
        (-half_notch_w, half_wid),
        (-half_len, half_wid),
    ])
)

base = (
    cq.Workplane("XY")
    .placeSketch(profile)
    .extrude(leaf_thickness)
)

chamfered = base.edges().chamfer(chamfer_distance)
filleted = chamfered.faces(">Z").edges("|Y").fillet(fillet_radius)

with_hole = filleted.faces(">Z").workplane().hole(central_hole_diameter)

leaf_with_mounts = (
    with_hole
    .workplane(offset=leaf_thickness / 2)
    .pushPoints([(-mount_hole_spacing / 2, 0), (mount_hole_spacing / 2, 0)])
    .hole(mount_hole_diameter)
)

rib_profile = (
    cq.Sketch()
    .rect(rib_thickness, leaf_width - 2 * notch_depth)
)

rib_body = (
    leaf_with_mounts
    .faces(">Z")
    .workplane()
    .rarray(rib_spacing, 0, rib_count, 1)
    .placeSketch(rib_profile)
    .extrude(rib_height)
)

result = leaf_with_mounts.union(rib_body)
