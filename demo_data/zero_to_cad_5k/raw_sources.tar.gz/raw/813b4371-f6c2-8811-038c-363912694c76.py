import cadquery as cq
import math

# Parameters
base_thickness = 8.0
outer_diameter = 80.0
clearance_diameter = 30.0
annulus_inner_radius = 20.0
annulus_outer_radius = 35.0
annulus_height = 5.0
bolt_hole_diameter = 5.0
bolt_circle_diameter = 90.0
num_bolt_holes = 4
inner_fillet_radius = 0.2
rib_width = 4.0
rib_length = 15.0
rib_height = 6.0
num_ribs = 8
slot_width = 4.0
slot_depth = annulus_height
outer_lip_height = 1.0
outer_lip_offset = 2.0

# Base profile (XZ plane)
profile = (
    cq.Workplane("XZ")
    .lineTo(outer_diameter / 2, 0)
    .lineTo(outer_diameter / 2, base_thickness)
    .lineTo(annulus_outer_radius, base_thickness)
    .lineTo(annulus_outer_radius, base_thickness + annulus_height)
    .lineTo(annulus_inner_radius, base_thickness + annulus_height)
    .lineTo(annulus_inner_radius, base_thickness)
    .lineTo(clearance_diameter / 2, base_thickness)
    .lineTo(clearance_diameter / 2, 0)
    .close()
)
result = profile.revolve()

# Central clearance aperture
result = result.faces("<Z").workplane().hole(clearance_diameter)

# Bolt pattern on outer perimeter (through base only)
bolt_radius = bolt_circle_diameter / 2
bolt_positions = [
    (
        bolt_radius * math.cos(math.radians(i * 360 / num_bolt_holes)),
        bolt_radius * math.sin(math.radians(i * 360 / num_bolt_holes))
    )
    for i in range(num_bolt_holes)
]
result = (
    result
    .faces(">Z[-2]")
    .workplane()
    .pushPoints(bolt_positions)
    .hole(bolt_hole_diameter)
)

# Alignment slot through raised annulus
result = (
    result
    .faces(">Z")
    .workplane()
    .center(0, annulus_inner_radius + (annulus_outer_radius - annulus_inner_radius) / 2)
    .rect(slot_width, slot_depth)
    .cutBlind(-base_thickness)
)

# Radial ribs on top of base for stiffness
base_top_wp = result.faces(">Z[-2]").workplane()
for i in range(num_ribs):
    angle = i * 360.0 / num_ribs
    rib = (
        base_top_wp
        .transformed(rotate=(0, 0, angle))
        .center(outer_diameter / 2 - rib_width / 2, 0)
        .rect(rib_width, rib_length)
        .extrude(rib_height)
    )
    result = result.union(rib)

# Outer reinforcing lip (adds material around perimeter)
outer_lip = (
    result.faces(">Z")
    .workplane()
    .circle(outer_diameter / 2 - outer_lip_offset)
    .extrude(outer_lip_height)
)
result = result.union(outer_lip)

# Fillet inner edge of clearance hole for safety
result = result.faces(">Z").edges().fillet(inner_fillet_radius)
