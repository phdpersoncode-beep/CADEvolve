import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        vertical = (
            cq.Workplane("XY")
            .box(m.thickness, m.leg_height, m.thickness)
            .translate((m.thickness / 2, m.leg_height / 2, m.thickness / 2))
        )
        horizontal = (
            cq.Workplane("XY")
            .box(m.arm_length, m.thickness, m.thickness)
            .translate((m.arm_length / 2, m.thickness / 2, m.thickness / 2))
        )
        base = vertical.union(horizontal)
        if m.gusset:
            gusset_profile = (
                cq.Workplane("XY")
                .polyline([
                    (0, 0),
                    (m.gusset_width, 0),
                    (0, m.gusset_height),
                ])
                .close()
                .extrude(m.thickness)
            )
            base = base.intersect(gusset_profile)
        # Apply fillet to the interior 90° edges (edges parallel to Z)
        base = base.edges("|Z").fillet(m.fillet_radius)
        # Recessed cavity on the horizontal arm top surface
        cavity = (
            base.faces(">Z")
            .workplane(centerOption="CenterOfBoundBox")
            .move(m.arm_length / 2, m.thickness / 2)
            .rect(m.cavity_width, m.cavity_depth)
            .cutBlind(m.cavity_depth)
        )
        # Counterbored holes on inner face of vertical leg
        hole_spacing = (m.leg_height - 2 * m.edge_margin) / 2
        drilled = (
            cavity.faces("<X")
            .workplane(centerOption="CenterOfBoundBox")
            .rarray(0, hole_spacing, 1, 3)
            .cboreHole(m.hole_diameter, m.cbore_diameter, m.cbore_depth)
        )
        self.model = drilled

measures = Measures(
    thickness=8.0,
    leg_height=70.0,
    arm_length=80.0,
    cavity_width=30.0,
    cavity_depth=5.0,
    edge_margin=5.0,
    hole_diameter=5.0,
    cbore_diameter=8.0,
    cbore_depth=2.0,
    gusset=True,
    gusset_width=20.0,
    gusset_height=30.0,
    fillet_radius=2.0,
)

result = LBracket(cq.Workplane("XY"), measures).model