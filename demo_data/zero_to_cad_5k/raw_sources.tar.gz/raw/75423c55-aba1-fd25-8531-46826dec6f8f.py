import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base_profile = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.leg_length, 0)
            .lineTo(m.leg_length, m.leg_width)
            .lineTo(m.leg_width, m.leg_width)
            .lineTo(m.leg_width, m.vertical_height)
            .lineTo(0, m.vertical_height)
            .close()
        )
        base_solid = (
            base_profile
            .extrude(m.thickness)
            .edges()
            .fillet(m.fillet_radius)
        )
        hole_positions = []
        start_y = (m.vertical_height - (m.hole_count - 1) * m.hole_spacing) / 2
        for i in range(m.hole_count):
            hole_positions.append((0, start_y + i * m.hole_spacing))
        base_with_holes = (
            base_solid
            .faces("<X")
            .workplane()
            .pushPoints(hole_positions)
            .hole(m.hole_diameter)
        )
        gusset = (
            cq.Workplane("XY")
            .center(m.leg_width/2, m.leg_width/2)
            .rect(m.gusset_width, m.gusset_height)
            .extrude(m.gusset_thickness)
        )
        self.model = base_with_holes.union(gusset)

params = Measures(
    leg_length=80.0,
    leg_width=20.0,
    vertical_height=60.0,
    thickness=10.0,
    fillet_radius=2.0,
    gusset_width=12.0,
    gusset_height=30.0,
    gusset_thickness=10.0,
    hole_diameter=5.0,
    hole_count=4,
    hole_spacing=12.0,
)

result = LBracket(cq.Workplane("XY"), params).model
