import cadquery as cq
import math
prism_len = 80.0
prism_wid = 50.0
prism_ht = 40.0
wall_thick = 3.0
fillet_radius = 2.0
chamfer_dist = 0.8
channel_cross_w = 12.0
channel_cross_h = 8.0
channel_length = math.sqrt(prism_len**2 + prism_wid**2 + prism_ht**2)
angle_x = math.degrees(math.atan2(prism_wid, prism_ht))
angle_y = math.degrees(math.atan2(prism_len, math.sqrt(prism_wid**2 + prism_ht**2)))
outer = (cq.Workplane('XY')
         .box(prism_len, prism_wid, prism_ht, centered=(True, True, False))
         .shell(-wall_thick))
channel = (cq.Workplane()
           .rect(channel_cross_w, channel_cross_h)
           .extrude(channel_length)
           .rotate((0,0,0), (1,0,0), angle_x)
           .rotate((0,0,0), (0,1,0), angle_y)
           .translate((-prism_len/2, -prism_wid/2, 0)))
result = (outer
          .cut(channel)
          .edges('|Z')
          .fillet(fillet_radius)
          .edges('>Z or >X or >Y')
          .chamfer(chamfer_dist))
