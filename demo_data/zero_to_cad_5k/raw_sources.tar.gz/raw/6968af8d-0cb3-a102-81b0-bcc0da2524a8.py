import cadquery as cq

leaf_length = 80.0
leaf_width = 30.0
leaf_thickness = 8.0
boss_radius = 5.0
boss_height = 10.0
clearance_hole_diameter = 4.5
hole_spacing = 30.0
tab_width = 10.0
tab_length = 12.0
rib_width = 6.0
rib_thickness = 3.0
rib_spacing = 12.0
chamfer_size = 0.8

leaf = (
    cq.Workplane('XY')
    .moveTo(-leaf_width / 2, -leaf_length / 2)
    .lineTo(leaf_width / 2, -leaf_length / 2)
    .lineTo(leaf_width / 2, leaf_length / 2 - tab_length)
    .lineTo(leaf_width / 2 + tab_width, leaf_length / 2)
    .lineTo(leaf_width / 2, leaf_length / 2)
    .lineTo(-leaf_width / 2, leaf_length / 2)
    .lineTo(-leaf_width / 2, -leaf_length / 2)
    .close()
    .extrude(leaf_thickness)
)

boss = (
    cq.Workplane('XY')
    .center(0, 0)
    .circle(boss_radius)
    .extrude(boss_height)
    .translate((0, 0, leaf_thickness))
)

base = leaf.union(boss)

hole_positions = [(-hole_spacing / 2, 0), (hole_spacing / 2, 0)]
base = base.faces('>Z').workplane().pushPoints(hole_positions).hole(clearance_hole_diameter)

num_ribs = int((leaf_length - rib_spacing) // rib_spacing) + 1
for i in range(num_ribs):
    y = -leaf_length / 2 + rib_spacing / 2 + i * rib_spacing
    base = base.faces('<Z').workplane().center(0, y).rect(rib_width, leaf_width).extrude(rib_thickness)

base = base.edges('|Z').chamfer(chamfer_size)

result = base