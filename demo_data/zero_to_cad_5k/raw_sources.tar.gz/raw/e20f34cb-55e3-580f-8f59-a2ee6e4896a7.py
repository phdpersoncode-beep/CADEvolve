import cadquery as cq
import math

base_radius = 40.0
base_thickness = 5.0
frame_outer_radius = 30.0
frame_inner_radius = 20.0
frame_height = 10.0
chamfer_size = 0.8
hole_radius = 2.0
hole_depth = base_thickness + frame_height - 1.0
hole_count = 6
hole_pattern_radius = (frame_inner_radius + frame_outer_radius) / 2.0

hole_positions = [
    (hole_pattern_radius * math.cos(2 * math.pi * i / hole_count),
     hole_pattern_radius * math.sin(2 * math.pi * i / hole_count))
    for i in range(hole_count)
]

profile = (
    cq.Workplane("XZ")
    .moveTo(0, 0)
    .lineTo(base_radius, 0)
    .lineTo(base_radius, base_thickness)
    .lineTo(frame_outer_radius, base_thickness)
    .lineTo(frame_outer_radius, base_thickness + frame_height)
    .lineTo(frame_inner_radius, base_thickness + frame_height)
    .lineTo(frame_inner_radius, base_thickness)
    .lineTo(0, base_thickness)
    .close()
)

result = (
    profile
    .revolve(360)
    .edges(">Z").chamfer(chamfer_size)
    .faces(">Z")
    .workplane()
    .pushPoints(hole_positions)
    .circle(hole_radius)
    .cutBlind(-hole_depth)
)
