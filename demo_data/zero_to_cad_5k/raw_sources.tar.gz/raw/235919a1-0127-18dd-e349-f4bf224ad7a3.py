import cadquery as cq
from types import SimpleNamespace as Measures

# Parameters
overall_width = 60.0
overall_height = 80.0
leg_width = 15.0
plate_thickness = 7.0
slot_length = 10.0
slot_width = 2.0
slot_offset_from_corner = 20.0
boss_size = 20.0
boss_height = 5.0
mount_hole_diameter = 5.0
mount_hole_counterbore_diameter = 9.0
mount_hole_counterbore_depth = 2.0
mount_hole_spacing = 30.0
chamfer_size = 0.8

measures = Measures(
    overall_width=overall_width,
    overall_height=overall_height,
    leg_width=leg_width,
    plate_thickness=plate_thickness,
    slot_length=slot_length,
    slot_width=slot_width,
    slot_offset_from_corner=slot_offset_from_corner,
    boss_size=boss_size,
    boss_height=boss_height,
    mount_hole_diameter=mount_hole_diameter,
    mount_hole_counterbore_diameter=mount_hole_counterbore_diameter,
    mount_hole_counterbore_depth=mount_hole_counterbore_depth,
    mount_hole_spacing=mount_hole_spacing,
    chamfer_size=chamfer_size,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Base L plate sketch
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.leg_width, 0),
                (m.overall_width, 0),
                (m.overall_width, m.leg_width),
                (m.overall_width, m.overall_height),
                (m.overall_width - m.leg_width, m.overall_height),
                (m.overall_width - m.leg_width, m.leg_width),
                (0, m.leg_width),
                (0, 0),
            ])
            .close()
            .extrude(m.plate_thickness)
        )
        # Slot on horizontal leg
        slot = (
            base.faces(">Z")
            .workplane(origin=(m.slot_offset_from_corner + m.slot_length/2, m.leg_width/2))
            .rect(m.slot_length, m.slot_width)
            .cutBlind(-m.plate_thickness)
        )
        # Central boss
        boss = (
            slot.faces(">Z")
            .workplane(origin=(m.leg_width/2, m.leg_width/2))
            .rect(m.boss_size, m.boss_size)
            .extrude(m.boss_height)
        )
        # Mounting holes on horizontal leg
        horiz_holes = (
            boss.faces(">Z")
            .workplane(origin=(m.overall_width/2, m.leg_width/2))
            .rarray(m.mount_hole_spacing, 1, 2, 1)
            .cboreHole(m.mount_hole_diameter, m.mount_hole_counterbore_diameter, m.mount_hole_counterbore_depth)
        )
        # Mounting holes on vertical leg
        vert_holes = (
            horiz_holes.faces(">Z")
            .workplane(origin=(m.leg_width/2, m.overall_height/2))
            .rarray(1, m.mount_hole_spacing, 1, 2)
            .cboreHole(m.mount_hole_diameter, m.mount_hole_counterbore_diameter, m.mount_hole_counterbore_depth)
        )
        # Chamfers on outer edges
        final = (
            vert_holes.edges("|Z")
            .chamfer(m.chamfer_size)
        )
        self.model = final

result = LBracket(cq.Workplane("XY"), measures).model
