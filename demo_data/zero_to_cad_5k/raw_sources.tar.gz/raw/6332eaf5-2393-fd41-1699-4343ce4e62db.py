import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        base = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.vertical_leg_length)
            .lineTo(m.thickness + m.horizontal_leg_length, m.vertical_leg_length)
            .lineTo(m.thickness + m.horizontal_leg_length, m.vertical_leg_length + m.thickness)
            .lineTo(0, m.vertical_leg_length + m.thickness)
            .close()
            .extrude(m.bracket_thickness)
        )
        # Chamfer outer vertical edges of base
        base = base.edges("|Z").chamfer(m.chamfer_size)
        # Clearance holes on horizontal leg
        hole_spacing = (m.horizontal_leg_length - 2 * m.hole_margin) / (m.hole_count - 1)
        base = (
            base.faces(">Z")
            .workplane()
            .center(m.thickness + m.hole_margin, m.thickness / 2)
            .rarray(hole_spacing, 0, m.hole_count, 1)
            .hole(m.hole_diameter)
        )
        # Reinforcing rib as inset extrude
        rib = (
            cq.Workplane("XY")
            .moveTo(0, 0)
            .lineTo(m.thickness, 0)
            .lineTo(m.thickness, m.vertical_leg_length)
            .lineTo(m.thickness + m.horizontal_leg_length, m.vertical_leg_length)
            .lineTo(m.thickness + m.horizontal_leg_length, m.vertical_leg_length + m.thickness)
            .lineTo(0, m.vertical_leg_length + m.thickness)
            .close()
            .offset2D(-m.rib_offset)
            .extrude(m.bracket_thickness + m.rib_height)
        )
        result = base.union(rib)
        self.model = result

measures = Measures(
    thickness=8.0,
    horizontal_leg_length=70.0,
    vertical_leg_length=80.0,
    bracket_thickness=10.0,
    hole_diameter=4.0,
    hole_count=5,
    hole_margin=10.0,
    rib_offset=2.0,
    rib_height=4.0,
    chamfer_size=0.5,
)

result = LBracket(cq.Workplane("XY"), measures).model