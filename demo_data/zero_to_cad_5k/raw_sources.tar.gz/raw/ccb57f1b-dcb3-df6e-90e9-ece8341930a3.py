import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()
    def build(self):
        m = self.measures
        shape = (
            cq.Workplane('XY')
            .polyline([
                (0, 0),
                (m.leg_length, 0),
                (m.leg_length, m.leg_thickness),
                (m.leg_thickness, m.leg_thickness),
                (m.leg_thickness, m.leg_width),
                (0, m.leg_width)
            ])
            .close()
            .extrude(m.thickness)
        )
        shape = (
            shape
            .faces('>Z')
            .workplane()
            .center(m.leg_length/2, m.leg_width/2)
            .hole(m.center_hole_diameter)
        )
        shape = (
            shape
            .faces('>Z')
            .workplane()
            .pushPoints([
                (m.leg_length/4, m.leg_width/2),
                (3*m.leg_length/4, m.leg_width/2)
            ])
            .hole(m.leg_hole_diameter)
        )
        shape = (
            shape
            .faces('>Z')
            .workplane(offset=-m.thickness/2)
            .center(m.leg_thickness/2, m.leg_width/2)
            .rect(m.reinforcement_width, m.reinforcement_depth)
            .cutBlind(m.reinforcement_depth)
        )
        shape = shape.edges('|Z').fillet(m.fillet_radius)
        self.model = shape

measures = Measures(
    leg_length=80.0,
    leg_width=60.0,
    leg_thickness=20.0,
    thickness=8.0,
    center_hole_diameter=10.0,
    leg_hole_diameter=5.0,
    reinforcement_width=12.0,
    reinforcement_depth=6.0,
    fillet_radius=5.0,
)

result = LBracket(cq.Workplane('XY'), measures).model