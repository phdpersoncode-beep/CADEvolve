import cadquery as cq
import math

gear_teeth = 48
module = 1.5
gear_thickness = 10.0
bore_diameter = 12.0
keyway_width = 6.0
keyway_depth = 8.0
chamfer_size = 1.0
mount_hole_diameter = 5.0

pitch_diameter = gear_teeth * module
pitch_radius = pitch_diameter / 2.0
addendum = module
dedendum = 1.25 * module
outer_radius = pitch_radius + addendum
root_radius = pitch_radius - dedendum
angular_pitch = 360.0 / gear_teeth
flank_angle = math.radians(angular_pitch / 4.0)

base = cq.Workplane('XY').circle(root_radius).extrude(gear_thickness)

p1x = root_radius * math.cos(flank_angle)
p1y = -root_radius * math.sin(flank_angle)
p2x = outer_radius
p2y = 0.0
p3x = root_radius * math.cos(flank_angle)
p3y = root_radius * math.sin(flank_angle)

tooth = (
    cq.Workplane('XY')
    .moveTo(p1x, p1y)
    .lineTo(p2x, p2y)
    .lineTo(p3x, p3y)
    .close()
    .extrude(gear_thickness)
)

gear = base
for i in range(int(gear_teeth)):
    angle = i * angular_pitch
    gear = gear.union(tooth.rotate((0, 0, 0), (0, 0, 1), angle))

gear = gear.edges('|Z').chamfer(chamfer_size)

gear = gear.faces('>Z').workplane().hole(bore_diameter)

keyway = (cq.Workplane('XY')
    .center(outer_radius - keyway_depth/2, 0)
    .box(keyway_depth, gear_thickness, keyway_width))
gear = gear.cut(keyway)

for i in range(4):
    ang = i * math.pi / 2
    x = root_radius * math.cos(ang)
    y = root_radius * math.sin(ang)
    gear = gear.faces('>Z').workplane().center(x, y).hole(mount_hole_diameter)

result = gear