import cadquery as cq
from types import SimpleNamespace as Measures

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # Create vertical and horizontal plates centered at origin
        vertical = cq.Workplane('XY').box(m.thickness, m.vertical_leg_length, m.thickness).translate((0, m.vertical_leg_length / 2, 0))
        horizontal = cq.Workplane('XY').box(m.horizontal_leg_length, m.thickness, m.thickness).translate((m.horizontal_leg_length / 2, 0, 0))
        base = vertical.union(horizontal)
        # Cut quarter cylinder to form inner fillet (concave)
        quarter_cyl = (
            cq.Workplane('XY')
            .cylinder(radius=m.fillet_radius, height=m.thickness)
            .intersect(
                cq.Workplane('XY')
                .box(m.fillet_radius * 2, m.fillet_radius * 2, m.thickness)
                .translate((m.fillet_radius / 2, m.fillet_radius / 2, 0))
            )
        )
        base = base.cut(quarter_cyl)
        # Ribbed reinforcement placed along inner fillet region
        ribs = cq.Workplane('XY')
        num_ribs = int((m.fillet_radius * 2) / m.rib_spacing)
        for i in range(num_ribs):
            rib = cq.Workplane('XY')\
                .box(m.rib_width, m.rib_height, m.thickness)\
                .translate((m.thickness / 2 + m.rib_width / 2,
                           m.vertical_leg_length - m.fillet_radius - m.rib_height / 2 - i * m.rib_spacing,
                           0))
            ribs = ribs.union(rib)
        reinforced = base.union(ribs)
        # Pocket cut on vertical leg front face
        pocket = (
            reinforced
            .faces('>Z')
            .workplane()
            .center(m.thickness / 2, m.vertical_leg_length / 2)
            .rect(m.pocket_width, m.pocket_height)
            .cutBlind(-m.pocket_depth)
        )
        # Chamfer outer edges for safety
        result = pocket.edges('>Z').chamfer(m.chamfer)
        self.model = result

measures = Measures(
    thickness=15.0,
    vertical_leg_length=80.0,
    horizontal_leg_length=80.0,
    fillet_radius=5.0,
    rib_width=3.0,
    rib_height=10.0,
    rib_spacing=8.0,
    pocket_width=30.0,
    pocket_height=20.0,
    pocket_depth=12.0,
    chamfer=1.0,
)

result = LBracket(cq.Workplane('XY'), measures).model