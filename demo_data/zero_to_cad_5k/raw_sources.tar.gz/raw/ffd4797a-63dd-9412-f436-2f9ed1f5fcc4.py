import cadquery as cq
from math import acos, degrees
from types import SimpleNamespace as Measures

m = Measures(
    linear_width = 55.0,
    depth = 12.0,
    height = 14.0,
    arc_outer_diameter = 100.0,
    profile_extra_cut_diameter = 20.0,
    boss_diameter = 18.0,
    boss_depth = 6.0,
    hole_diameter = 4.0,
    hole_rows = 2,
    hole_columns = 3,
    hole_spacing_x = 15.0,
    hole_spacing_y = 12.0,
    chamfer_distance = 0.8
)

m.arc_outer_radius = 0.5 * m.arc_outer_diameter
m.arc_center_diameter = m.arc_outer_diameter - m.depth
m.arc_center_radius = 0.5 * m.arc_center_diameter
m.arc_center_angle = degrees(acos((2 * m.arc_center_radius**2 - m.linear_width**2) / (2 * m.arc_center_radius**2)))
m.arc_secant_angle = 0.5 * (180 - m.arc_center_angle)

path = (
    cq.Workplane("XY")
    .radiusArc((m.linear_width, 0.0), m.arc_center_radius)
    .wire()
)

sweep_profile = (
    cq.Workplane("XY")
    .transformed(rotate=(90, -m.arc_secant_angle, 0))
    .rect(m.depth, m.height)
    .circle(m.profile_extra_cut_diameter / 2)
    .wire()
)

model = (
    sweep_profile
    .sweep(path, transition="round")
    .faces(">Z")
    .workplane()
    .circle(m.boss_diameter / 2)
    .cutBlind(m.boss_depth)
    .faces(">Z")
    .workplane()
    .rarray(m.hole_spacing_x, m.hole_spacing_y, m.hole_columns, m.hole_rows)
    .hole(m.hole_diameter)
    .edges("|Z")
    .chamfer(m.chamfer_distance)
)

result = model
