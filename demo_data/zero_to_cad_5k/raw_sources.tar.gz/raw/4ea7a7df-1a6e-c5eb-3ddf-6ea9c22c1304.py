import cadquery as cq

beam_length = 80.0
beam_height = 40.0
flange_width = 30.0
flange_thickness = 5.0
web_thickness = 3.0
slot_width = 4.0
slot_height = 12.0
slot_spacing = 10.0
chamfer_size = 1.0

half_beam_height = beam_height / 2.0
half_flange_width = flange_width / 2.0
web_half = web_thickness / 2.0
lower_flange_inner_y = -half_beam_height + flange_thickness
upper_flange_inner_y = half_beam_height - flange_thickness

pts = [
    (half_flange_width, -half_beam_height),
    (half_flange_width, lower_flange_inner_y),
    (web_half, lower_flange_inner_y),
    (web_half, upper_flange_inner_y),
    (half_flange_width, half_beam_height),
    (0.0, half_beam_height),
    (-half_flange_width, half_beam_height),
    (-half_flange_width, upper_flange_inner_y),
    (-web_half, upper_flange_inner_y),
    (-web_half, lower_flange_inner_y),
    (-half_flange_width, lower_flange_inner_y),
    (-half_flange_width, -half_beam_height),
    (0.0, -half_beam_height)
]

result = (cq.Workplane("XY")
          .polyline(pts)
          .close()
          .extrude(beam_length)
          .edges("|Z")
          .chamfer(chamfer_size)
          .faces(">Y")
          .workplane()
          .center(web_half + slot_spacing, 0)
          .rect(slot_width, slot_height)
          .cutBlind(-flange_thickness)
          .center(-2*(web_half + slot_spacing), 0)  # move to opposite side
          .rect(slot_width, slot_height)
          .cutBlind(-flange_thickness)
         )
