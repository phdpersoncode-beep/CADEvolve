import cadquery as cq

# Parameters
bracket_length = 70.0
bracket_width = 45.0
bracket_thickness = 6.0
corner_radius = 8.0
slot_width = 8.0
slot_length = 30.0
hole_diameter = 5.0
hole_offset = 12.0
rib_height = 4.0
rib_thickness = 2.0
rib_spacing = 12.0
chamfer_size = 1.0

# Base plate
base = (
    cq.Workplane('XY')
    .rect(bracket_length, bracket_width)
    .extrude(bracket_thickness)
)
# Fillet vertical outer edges for cable routing corner
base = base.edges("|Z").fillet(corner_radius)
# Slot centered on top edge (positive Y direction)
slot_center_y = (bracket_width / 2) - corner_radius - (slot_width / 2)
slot = (
    cq.Workplane('XY')
    .center(0, slot_center_y)
    .rect(slot_length, slot_width)
    .extrude(bracket_thickness + 0.2)
)
base = base.cut(slot)
# Mounting holes on bottom edge
hole_y = -(bracket_width / 2) + hole_offset
hole_x1 = -(bracket_length / 2) + hole_offset
hole_x2 = (bracket_length / 2) - hole_offset
base = (
    base
    .faces('>Z')
    .workplane()
    .center(hole_x1, hole_y)
    .hole(hole_diameter)
    .center(hole_x2 - hole_x1, 0)
    .hole(hole_diameter)
)
# Stiffening ribs on back face (bottom)
num_ribs = int((bracket_length - 2 * hole_offset) // rib_spacing) + 1
for i in range(num_ribs):
    x_pos = -(bracket_length / 2) + hole_offset + i * rib_spacing
    rib = (
        cq.Workplane('XY')
        .center(x_pos, 0)
        .rect(rib_thickness, rib_height)
        .extrude(-rib_height)
    )
    base = base.union(rib)
# Chamfer top outer edges for handling safety
base = base.edges('>Z').chamfer(chamfer_size)
result = base