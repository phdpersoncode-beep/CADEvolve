import cadquery as cq

# dimensions (max 100 units)
beam_length = 80.0
beam_height = 60.0
flange_width = 40.0
web_thickness = 4.0
flange_thickness = 6.0
slot_width = 3.0
slot_length = 20.0
slot_spacing = 8.0
num_slots = 4
chamfer_size = 1.0

half_height = beam_height / 2.0
half_flange = flange_width / 2.0
inner_top = half_height - flange_thickness
inner_bottom = -half_height + flange_thickness

class IBeamHalf:
    def __init__(self, length, height, flange_w, web_t, flange_t):
        self.length = length
        self.height = height
        self.flange_w = flange_w
        self.web_t = web_t
        self.flange_t = flange_t
        self.half_h = height / 2.0
        self.half_f = flange_w / 2.0
        self.inner_top = self.half_h - flange_t
        self.inner_bottom = -self.half_h + flange_t

    def profile(self):
        h = self.half_h
        ft = self.flange_t
        wt = self.web_t
        hf = self.half_f
        it = self.inner_top
        ib = self.inner_bottom
        pts = [
            (0, h),
            (hf, h),
            (hf, it),
            (wt/2.0, it),
            (wt/2.0, ib),
            (hf, ib),
            (hf, -h),
            (0, -h)
        ]
        return pts

    def solid(self):
        wp = cq.Workplane('XY')
        half = wp.polyline(self.profile()).close().mirrorY()
        return half.extrude(self.length)

beam_half = IBeamHalf(beam_length, beam_height, flange_width, web_thickness, flange_thickness)
base_beam = beam_half.solid()

# create slots in lower flange
bottom_face = base_beam.faces('<<Z')
slot_wp = bottom_face.workplane()
start_x = -half_flange + slot_spacing + slot_width/2.0
slot_wp = slot_wp.center(start_x, 0)
slots = (
    slot_wp
    .rect(slot_width, slot_length)
    .rarray(slot_spacing + slot_width, 0, num_slots, 1)
    .cutBlind(flange_thickness)
)
result = slots

# apply chamfer to vertical edges of web
result = result.edges('|Z').chamfer(chamfer_size)
