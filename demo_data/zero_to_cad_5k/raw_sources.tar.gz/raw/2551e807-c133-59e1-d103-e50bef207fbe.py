import cadquery as cq
from types import SimpleNamespace as Measures

# Parameter definitions
horizontal_leg_length = 80.0
vertical_leg_height = 70.0
bracket_thickness = 6.0
material_depth = 20.0
reinforcement_rib_height = 30.0
reinforcement_rib_width = 12.0
hole_diameter = 4.5
hole_spacing_x = 30.0
hole_spacing_y = 30.0
chamfer_distance = 1.0

measures = Measures(
    horizontal_leg_length=horizontal_leg_length,
    vertical_leg_height=vertical_leg_height,
    bracket_thickness=bracket_thickness,
    material_depth=material_depth,
    reinforcement_rib_height=reinforcement_rib_height,
    reinforcement_rib_width=reinforcement_rib_width,
    hole_diameter=hole_diameter,
    hole_spacing_x=hole_spacing_x,
    hole_spacing_y=hole_spacing_y,
    chamfer_distance=chamfer_distance,
)

class LBracket:
    def __init__(self, workplane, measures):
        self.model = workplane
        self.measures = measures
        self.build()

    def build(self):
        m = self.measures
        # L-shaped base profile
        base = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (m.horizontal_leg_length, 0),
                (m.horizontal_leg_length, m.bracket_thickness),
                (m.bracket_thickness, m.bracket_thickness),
                (m.bracket_thickness, m.vertical_leg_height),
                (0, m.vertical_leg_height),
                (0, 0),
            ])
            .close()
            .extrude(m.material_depth)
        )
        # Reinforcement rib (triangular cross-section) positioned at inner corner
        rib_profile = (
            cq.Workplane("XY")
            .polyline([
                (0, 0),
                (0, m.reinforcement_rib_height),
                (m.reinforcement_rib_width, 0),
            ])
            .close()
            .extrude(m.material_depth)
            .translate((m.bracket_thickness, m.bracket_thickness, 0))
        )
        combined = base.union(rib_profile)
        # Four clearance holes in rectangular pattern around inner corner
        holes = (
            combined.faces(">Z").workplane()
            .pushPoints([
                (m.bracket_thickness + m.hole_spacing_x/2, m.bracket_thickness + m.hole_spacing_y/2),
                (m.bracket_thickness - m.hole_spacing_x/2, m.bracket_thickness + m.hole_spacing_y/2),
                (m.bracket_thickness + m.hole_spacing_x/2, m.bracket_thickness - m.hole_spacing_y/2),
                (m.bracket_thickness - m.hole_spacing_x/2, m.bracket_thickness - m.hole_spacing_y/2),
            ])
            .hole(m.hole_diameter)
        )
        # Chamfer outer edges for safety
        final = holes.edges().chamfer(m.chamfer_distance)
        self.model = final

result = LBracket(cq.Workplane("XY"), measures).model
