import cadquery as cq

beam_length = 80.0
beam_height = 60.0
flange_width = 20.0
web_thickness = 6.0
flange_thickness = 8.0
fillet_radius = 2.0
hole_diameter = 5.0
hole_spacing = 30.0
rib_thickness = 4.0
rib_height = 15.0

pts = [
    (0, 0),
    (0, beam_height),
    (web_thickness, beam_height),
    (web_thickness + flange_width, beam_height),
    (web_thickness + flange_width, beam_height - flange_thickness),
    (web_thickness, beam_height - flange_thickness),
    (web_thickness, flange_thickness),
    (web_thickness + flange_width, flange_thickness),
    (web_thickness + flange_width, 0),
    (web_thickness, 0),
    (0, 0)
]

half_section = cq.Workplane("XY").polyline(pts).close()
full_section = half_section.mirrorY()
solid = full_section.extrude(beam_length)
solid = solid.edges("|Z").fillet(fillet_radius)
# top flange holes pattern
hole_offset = (beam_length - hole_spacing) / 2.0
top_face = solid.faces("+Z")
top_holes = top_face.workplane(centerOption="CenterOfMass").pushPoints([
    (hole_offset, beam_height/2 + flange_thickness/2),
    (beam_length - hole_offset, beam_height/2 + flange_thickness/2)
]).hole(hole_diameter)
# internal rib on web
rib = (solid.faces("<Y")
       .workplane(centerOption="CenterOfMass")
       .center(0, beam_height/2)
       .rect(rib_thickness, rib_height)
       .extrude(rib_thickness))
result = solid.union(rib)
