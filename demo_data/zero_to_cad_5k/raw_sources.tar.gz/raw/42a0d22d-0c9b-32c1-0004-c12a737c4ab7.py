import cadquery as cq

# Parameters
base_radius = 30
top_radius = 45
hub_length = 40
fillet_radius = 3
shaft_hole_diameter = 12
balance_hole_diameter = 6
balance_hole_radius = 20
balance_hole_count = 4
mount_hole_diameter = 8
mount_hole_offset = base_radius - 5
flange_width = 80
flange_length = 80
flange_height = 6
flange_overlap = 0.5
rib_width = 10
rib_depth = 8
rib_height = 6

# Core hub loft
hub = (
    cq.Workplane("XY")
    .circle(base_radius)
    .workplane(offset=hub_length)
    .circle(top_radius)
    .loft()
)

# Fillet external edges
hub = hub.edges().fillet(fillet_radius)

# Central shaft bore through hub
hub = hub.faces(">Z").workplane().hole(shaft_hole_diameter)

# Balance holes arranged polar around hub
hub = (
    hub.faces(">Z")
    .workplane()
    .polarArray(radius=balance_hole_radius, startAngle=0, count=balance_hole_count, angle=360)
    .hole(balance_hole_diameter)
)

# Mounting holes on top face near periphery
hub = (
    hub.faces(">Z")
    .workplane()
    .pushPoints([(-mount_hole_offset, 0), (mount_hole_offset, 0)])
    .hole(mount_hole_diameter)
)

# Base flange solid with slight overlap into hub for solid fusion
flange = (
    cq.Workplane("XY")
    .workplane(offset=-flange_overlap)
    .rect(flange_width, flange_length)
    .extrude(flange_height + flange_overlap)
)

hub = hub.union(flange, clean=True)

# External rib for stiffness on outer cylindrical surface
rib = (
    cq.Workplane("XY")
    .box(rib_width, rib_depth, rib_height)
    .translate((base_radius - rib_width / 2, 0, hub_length / 2))
)

hub = hub.union(rib, clean=True)

result = hub