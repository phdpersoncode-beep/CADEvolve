import cadquery as cq
# Dimensions
beam_length = 80.0
flange_width = 30.0
flange_thickness = 5.0
web_height = 60.0
web_thickness = 4.0
lightening_slot_length = 20.0
lightening_slot_height = 3.0
hole_diameter = 3.0
hole_spacing = 15.0
num_holes = 3
chamfer_distance = 0.5
# Derived dimensions
total_height = web_height + 2 * flange_thickness
half_flange_width = flange_width / 2.0
half_web_thickness = web_thickness / 2.0
# Polyline points for half I‑beam profile (XY plane)
pts = [
    (0, -total_height / 2.0),
    (half_flange_width, -total_height / 2.0),
    (half_flange_width, -total_height / 2.0 + flange_thickness),
    (half_web_thickness, -total_height / 2.0 + flange_thickness),
    (half_web_thickness, web_height / 2.0),
    (half_flange_width, web_height / 2.0),
    (half_flange_width, web_height / 2.0 + flange_thickness),
    (0, web_height / 2.0 + flange_thickness)
]
# Build the solid by extruding the closed polyline (mirrored for symmetry)
beam = (
    cq.Workplane("XY")
    .polyline(pts)
    .close()
    .mirrorY()
    .extrude(beam_length)
)
# Lightening slot cut in the web from the negative X side
beam = (
    beam
    .faces("<X")
    .workplane()
    .rect(lightening_slot_length, lightening_slot_height)
    .cutBlind(web_thickness + 0.01)
)
# Linear array of through holes through the web on the positive X side
hole_positions = [(i * hole_spacing - (num_holes - 1) * hole_spacing / 2.0, 0) for i in range(num_holes)]
beam = (
    beam
    .faces(">X")
    .workplane()
    .pushPoints(hole_positions)
    .hole(hole_diameter)
)
# Chamfer the vertical web edges for safety
beam = beam.edges("|Y").chamfer(chamfer_distance)
result = beam