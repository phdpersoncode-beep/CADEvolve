import cadquery as cq

bracket_length = 70.0
bracket_width = 30.0
base_thickness = 5.0
thick_end_thickness = 9.0
fillet_radius = 2.0
countersink_diameter = 16.0
countersink_angle = 82.0
screw_diameter = 10.0
hole_depth = thick_end_thickness + 2.0
hole_spacing = bracket_length * 0.25
slot_width = bracket_length * 0.6
slot_depth = 4.0

profile = (
    cq.Workplane("XZ")
    .polyline([
        (0, 0),
        (0, base_thickness),
        (bracket_length, thick_end_thickness),
        (bracket_length, 0),
    ])
    .close()
)
main_body = profile.extrude(bracket_width)
solid = main_body.edges().fillet(fillet_radius)

# add a top slot for weight reduction and stiffness
solid = (
    solid
    .faces(">Z")
    .first()
    .workplane()
    .center(0, 0)
    .rect(slot_width, slot_depth)
    .cutBlind(-slot_depth)
)

hole_positions = [(-hole_spacing, 0), (0, 0), (hole_spacing, 0)]
solid = (
    solid
    .faces(">Z")
    .first()
    .workplane()
    .pushPoints(hole_positions)
    .cskHole(screw_diameter, countersink_diameter, countersink_angle, hole_depth)
)

result = solid
