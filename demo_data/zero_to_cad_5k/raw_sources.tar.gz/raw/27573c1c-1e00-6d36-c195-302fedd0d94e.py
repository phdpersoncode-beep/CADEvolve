import cadquery as cq
from types import SimpleNamespace as Measures

leg_long = 80.0
leg_short = 60.0
leg_width = 10.0
extrude_depth = 8.0
fillet_radius = 4.0
through_hole_diameter = 8.0
head_clearance_diameter = 12.0
counterbore_depth = 5.0
mount_hole_diameter = 5.0

measures = Measures(
    leg_long=leg_long,
    leg_short=leg_short,
    leg_width=leg_width,
    extrude_depth=extrude_depth,
    fillet_radius=fillet_radius,
    through_hole_diameter=through_hole_diameter,
    head_clearance_diameter=head_clearance_diameter,
    counterbore_depth=counterbore_depth,
    mount_hole_diameter=mount_hole_diameter,
)

class LBracket:
    def __init__(self, workplane, m):
        self.model = workplane
        self.m = m
        self.build()

    def build(self):
        m = self.m
        pts = [
            (0, 0),
            (m.leg_long, 0),
            (m.leg_long, m.leg_width),
            (m.leg_width, m.leg_width),
            (m.leg_width, m.leg_short),
            (0, m.leg_short),
        ]
        base = (
            cq.Workplane('XY')
            .polyline(pts)
            .close()
            .extrude(m.extrude_depth)
            .edges('|Z')
            .fillet(m.fillet_radius)
        )
        base = base.faces('>Z').workplane().cboreHole(
            m.through_hole_diameter, m.head_clearance_diameter, m.counterbore_depth
        )
        long_holes = (
            base.faces('>X')
            .workplane()
            .pushPoints([
                (m.leg_long/4, m.extrude_depth/2),
                (3*m.leg_long/4, m.extrude_depth/2),
            ])
            .hole(m.mount_hole_diameter)
        )
        short_holes = (
            long_holes.faces('>Y')
            .workplane()
            .pushPoints([
                (m.leg_short/4, m.extrude_depth/2),
                (3*m.leg_short/4, m.extrude_depth/2),
            ])
            .hole(m.mount_hole_diameter)
        )
        self.model = short_holes

result = LBracket(cq.Workplane('XY'), measures).model
