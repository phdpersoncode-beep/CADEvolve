import cadquery as cq
from types import SimpleNamespace as Measures

m = Measures(
    base_width=70.0,
    base_depth=30.0,
    base_height=8.0,
    lip_height=4.0,
    mounting_hole_spacing=40.0,
    mounting_hole_diameter=4.5,
    mounting_hole_cbore_diameter=7.0,
    mounting_hole_cbore_depth=3.5,
    fillet_radius=1.5,
    chamfer_dist=0.8,
    lip_extension=5.0,
)

class LidBracket:
    def __init__(self, measures):
        self.m = measures
        self.model = None
        self.build()
    def build(self):
        m = self.m
        base = cq.Workplane('XY').box(m.base_width, m.base_depth, m.base_height)
        lip = (
            cq.Workplane('XY')
            .box(m.base_width, m.base_depth, m.lip_height)
            .translate((0, 0, 0.5 * (m.base_height + m.lip_height)))
        )
        solid = base.union(lip)
        # mounting holes on top surface (including lip top)
        holes = (
            solid.faces('>Z')
            .workplane()
            .pushPoints([(-m.mounting_hole_spacing/2, 0), (m.mounting_hole_spacing/2, 0)])
            .cboreHole(m.mounting_hole_diameter, m.mounting_hole_cbore_diameter, m.mounting_hole_cbore_depth)
        )
        # fillet internal vertical edge where lip meets base (all vertical edges)
        filleted = holes.edges('|Z').fillet(m.fillet_radius)
        final = filleted.edges('>X or <X or >Y or <Y').chamfer(m.chamfer_dist)
        self.model = final

result = LidBracket(m).model
