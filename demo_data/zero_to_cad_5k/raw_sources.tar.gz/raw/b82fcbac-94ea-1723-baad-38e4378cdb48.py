import cadquery as cq

bracket_width = 80.0
bracket_height = 30.0
bracket_thickness = 8.0
slot_width = 12.0
slot_length = 40.0
slot_fillet = 4.0
hole_diameter = 4.0
hole_depth = 6.0
num_holes = 3
rib_width = 6.0
rib_height = 4.0
rib_spacing = 12.0
edge_fillet = 2.0
corner_chamfer = 1.0
material_margin = 1.0

base = cq.Workplane('XY').rect(bracket_width, bracket_height).extrude(bracket_thickness)
slot_center_x = bracket_width/2 - slot_length/2
slot_cut = cq.Workplane('XY').center(slot_center_x, 0).rect(slot_width, slot_length).extrude(-bracket_thickness)
result = base.cut(slot_cut)
result = result.edges("|Z and (<<Y or >>Y)").fillet(slot_fillet)
hole_spacing = slot_length/(num_holes-1)
result = result.faces('>Z').workplane().center(slot_center_x, 0).rarray(hole_spacing, 0, num_holes, 1).hole(hole_diameter, depth=hole_depth)
rib_y_start = -bracket_height/2 + rib_spacing
rib_count = int((bracket_height - 2 * rib_spacing) // rib_spacing) + 1
for i in range(rib_count):
    y_pos = rib_y_start + i * rib_spacing
    result = result.faces('>Z').workplane().center(0, y_pos).rect(rib_width, rib_height).extrude(2.0)
result = result.edges("|Z and (<<X or >>X or <<Y or >>Y)").chamfer(corner_chamfer)
