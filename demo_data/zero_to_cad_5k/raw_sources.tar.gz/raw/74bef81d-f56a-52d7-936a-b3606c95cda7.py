import cadquery as cq
outer_diameter = 80
body_length = 100
wall_thickness = 5
pressure_hole_diameter = 8
pressure_hole_depth = 30
pressure_hole_chamfer = 1

body = cq.Workplane('XY').circle(outer_diameter/2).extrude(body_length)
# make hollow shell
body = body.shell(-wall_thickness)
# pressure gauge hole on top center with chamfer
result = body.faces('>Z').workplane().hole(pressure_hole_diameter)
