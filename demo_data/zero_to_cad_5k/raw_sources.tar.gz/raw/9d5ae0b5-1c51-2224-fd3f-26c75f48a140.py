import cadquery as cq
import math

base_radius = 30.0
base_height = 8.0
plate_diameter = 20.0
plate_thickness = 4.0
hole_circle_radius = 25.0
countersink_hole_diameter = 3.0
countersink_diameter = 6.0
countersink_angle = 82.0
chamfer_size = 0.5
hole_count = 12
hole_angle_increment = 360 / hole_count

result = (
    cq.Workplane('XY')
    .circle(base_radius)
    .extrude(base_height)
    .faces('>Z')
    .edges()
    .chamfer(chamfer_size)
    .faces('>Z')
    .workplane()
    .polygon(6, plate_diameter)
    .extrude(plate_thickness)
    .faces('>Z')
    .edges()
    .chamfer(chamfer_size)
    .faces('>Z')
    .workplane()
    .pushPoints([
        (hole_circle_radius * math.cos(math.radians(i * hole_angle_increment)),
         hole_circle_radius * math.sin(math.radians(i * hole_angle_increment)))
        for i in range(hole_count)
    ])
    .cskHole(countersink_hole_diameter, countersink_diameter, countersink_angle)
)
